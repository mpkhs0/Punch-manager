==================================================
  Punch Manager 실행 방법 (BAT 파일 없이)
==================================================

[ 최초 1회 — Python 설치 확인 ]

1. Windows 키 + R → "cmd" 입력 → 확인

2. 아래 명령어 입력하여 Python 버전 확인:
   python --version

   ※ "Python 3.10" 이상이 표시되면 OK
   ※ 오류가 나면 https://www.python.org/downloads/ 에서
      Python 3.12 설치 (설치 시 "Add to PATH" 반드시 체크)


[ 최초 1회 — 라이브러리 설치 ]

cmd 창에서 punch_manager 폴더로 이동 후 설치:

   cd C:\경로\punch_manager
   pip install -r requirements.txt


[ 매번 실행 방법 ]

방법 1 — CMD에서 직접 실행 (권장):

   cd C:\경로\punch_manager
   python -m uvicorn main:app --host 0.0.0.0 --port 8000

   → 브라우저에서 http://localhost:8000 접속

방법 2 — 폴더에서 우클릭으로 실행:

   1. punch_manager 폴더 안에서
      Shift + 우클릭 → "PowerShell 창 열기"
   2. 아래 입력:
      python -m uvicorn main:app --host 0.0.0.0 --port 8000
   3. 브라우저에서 http://localhost:8000 접속


[ 종료 방법 ]

CMD/PowerShell 창에서 Ctrl + C


[ 자주 묻는 오류 ]

Q: 'python'은 인식되지 않는 명령어입니다
A: Python이 설치되지 않았거나 PATH 미설정.
   https://www.python.org/downloads/ 에서 재설치
   (설치 시 "Add Python to PATH" 체크 필수)

Q: 포트 8000이 사용 중입니다
A: 포트 번호를 변경하여 실행:
   python -m uvicorn main:app --host 0.0.0.0 --port 8080
   → 브라우저에서 http://localhost:8080 접속

Q: ModuleNotFoundError
A: 라이브러리 재설치:
   pip install -r requirements.txt --break-system-packages

==================================================
