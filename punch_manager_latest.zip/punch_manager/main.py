from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import json, shutil, uuid, re
from pathlib import Path
import openpyxl
from datetime import datetime

app = FastAPI(title="Punch Manager")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

BASE         = Path(__file__).parent
DATA_FILE    = BASE / "data" / "project.json"
UPLOADS      = BASE / "uploads"
UPLOADS_DRW  = UPLOADS / "drawings"
UPLOADS_PID  = UPLOADS / "pids"
STATIC       = BASE / "static"
REGISTRY_DIR  = BASE / "data" / "registry"
REGISTRY_FILE = BASE / "data" / "registry.json"
SNAPSHOT_DIR  = BASE / "data" / "snapshots"   # 펀치리스트별 스냅샷 저장

for d in [UPLOADS_DRW, UPLOADS_PID, BASE / "data", STATIC, REGISTRY_DIR, SNAPSHOT_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# misc 폴더 사전 생성 (StaticFiles 마운트 전)
(UPLOADS / "misc").mkdir(parents=True, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=str(UPLOADS)), name="uploads")
app.mount("/static",  StaticFiles(directory=str(STATIC)),  name="static")


# ── 데이터 ────────────────────────────────────────────────────────
def load_data():
    if DATA_FILE.exists():
        data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        # equip_codes 정규화 (str → dict 형식)
        raw = data.get("equip_codes", [])
        data["equip_codes"] = [
            x if isinstance(x, dict) else {"code": str(x).upper(), "name": ""}
            for x in raw if x
        ]
        return data
    return {"punches": [], "points": {}, "drawings": [], "pids": [], "header": {}, "equip_codes": []}

def save_data(data):
    DATA_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def load_registry():
    if REGISTRY_FILE.exists():
        return json.loads(REGISTRY_FILE.read_text(encoding="utf-8"))
    return {"processed_mail_ids": [], "packages": []}

def save_registry(reg):
    REGISTRY_FILE.write_text(json.dumps(reg, ensure_ascii=False, indent=2), encoding="utf-8")


# ── PDF → PNG 변환 (pymupdf) ──────────────────────────────────────
def pdf_to_images(pdf_path: Path, out_dir: Path, prefix: str, doc_type: str | None = None) -> list[dict]:
    """PDF 각 페이지를 PNG로 변환, 파일 정보 리스트 반환"""
    try:
        import fitz  # pymupdf
    except ImportError:
        raise RuntimeError("pymupdf 가 설치되지 않았습니다. pip install pymupdf 를 실행하세요.")

    doc = fitz.open(str(pdf_path))
    pages = []
    for i, page in enumerate(doc):
        # 목표 가로 4800px — 고해상도, 깃발 렌더링 시 충분한 선명도
        page_w_pt = page.rect.width
        target_px = 4800
        scale     = target_px / page_w_pt
        mat = fitz.Matrix(scale, scale)
        pix = page.get_pixmap(matrix=mat, alpha=False)

        # JPEG로 저장 (PNG 대비 1/4~1/5 용량, 품질 90)
        fname = f"{prefix}_p{i+1}.jpg"
        dest  = out_dir / fname
        pix.save(str(dest), jpg_quality=90)

        if doc_type is None:
            doc_type = "도면" if out_dir.name == "drawings" else "P&ID"
        pages.append({
            "filename": fname,
            "url":      f"/uploads/{out_dir.name}/{fname}",
            "id":       fname,
            "label":    f"{doc_type} {i+1}",
            "page":     i + 1,
            "width_px": pix.width,
            "height_px": pix.height,
        })
    doc.close()
    return pages


# ── Excel 파서 ────────────────────────────────────────────────────
# 실제 컬럼 위치 (0-based)
# 원본 Excel 컬럼 위치 (0-based index) — 2025.06 개정판
COL_PUNCH_NO    = 1   # B열 → 펀치 번호
COL_EQUIP_NO    = 2   # C열 → Tag No.
COL_DRAWING_NO  = 5   # F열 → Drawing No.
COL_DESCRIPTION = 6   # G열 → Punch Description
COL_PICTURE     = 7   # H열 → 최초 펀치 사진 (Open)
COL_PIC_CLOSED  = 8   # I열 → 종결 사진/근거 (Closed)
COL_OLD_CAT     = 9   # J열 → 기존 Category (0/1)
COL_CATEGORY    = 10  # K열 → Punch Category (A/B/C) ★신규
COL_DISCIPLINE  = 11  # L열 → Discipline
COL_ACTION      = 12  # M열 → Proposed Corrective Action
COL_MATERIAL    = 13  # N열 → Material Required (Y/N)
COL_ENGPHY      = 14  # O열 → Engineering / Physical work
COL_ISSUE_DATE  = 15  # P열 → Punch Issue Date
COL_RAISED_BY   = 16  # Q열 → Punch Raised By
COL_RAISED_ENT  = 17  # R열 → Punch Raised Entity
COL_CLOSE_PLAN  = 18  # S열 → Punch Close Plan Date ★신규
COL_CLOSED_DATE = 19  # T열 → Punch Closed Date
COL_CLOSED_BY   = 20  # U열 → Punch Closed By
COL_SIGNATURE   = 21  # V열 → Name Signature ★신규
COL_REMARKS     = 22  # W열 → Remarks
COL_FLAG_NOTE   = 23  # X열 → Flag Note (깃발 주석)

def get_cell(row, idx):
    if idx >= len(row):
        return ""
    v = row[idx]
    if v is None:
        return ""
    if hasattr(v, "strftime"):
        return v.strftime("%Y-%m-%d")
    s = str(v).strip()
    return "" if s.lower() in ("none", "nan", "-", "n/a") else s

def find_header_row(rows):
    """
    2번 열(idx=1)에서 숫자 1이 처음 나오는 행을 데이터 시작으로 확정.
    헤더는 그 직전 행. 데이터는 header_idx+1 부터.
    No.1 펀치가 10행에 있으면 → header_idx=8 (0-based 9번째 행=10행 직전)
    """
    for i, row in enumerate(rows[:50]):
        val = get_cell(row, COL_PUNCH_NO)
        if val and val.replace(".", "").isdigit() and float(val) >= 1:
            header_idx = max(0, i - 1)
            print(f"[DEBUG] 데이터 시작 행(0-based): {i}, 헤더 행(0-based): {header_idx}")
            print(f"[DEBUG] 헤더 행 내용(idx 14,15,16): {get_cell(rows[header_idx], 14)!r}, {get_cell(rows[header_idx], 15)!r}, {get_cell(rows[header_idx], 16)!r}")
            print(f"[DEBUG] 데이터 첫 행 내용(idx 14,15,16): {get_cell(rows[i], 14)!r}, {get_cell(rows[i], 15)!r}, {get_cell(rows[i], 16)!r}")
            return header_idx
    return 0

def extract_excel_images(path: Path, out_dir: Path) -> dict:
    """
    Excel 파일에서 셀 이미지 추출.
    반환: { row_index(1-based): "저장된 이미지 URL" }
    """
    import zipfile, os
    from PIL import Image as PILImage
    import io

    image_map = {}  # { anchor_row(1-based): url }

    try:
        with zipfile.ZipFile(str(path), 'r') as z:
            names = z.namelist()

            # xl/drawings/drawing1.xml 에서 앵커(행 번호) 파싱
            drawing_xml = None
            for n in names:
                if n.startswith('xl/drawings/drawing') and n.endswith('.xml'):
                    drawing_xml = z.read(n).decode('utf-8')
                    break

            if not drawing_xml:
                return {}

            # 이미지 파일 목록
            img_files = sorted([n for n in names if n.startswith('xl/media/')])
            if not img_files:
                return {}

            # XML에서 <xdr:from><xdr:row> 값 추출 (순서대로 이미지와 매핑)
            import re
            # TwoCellAnchor 또는 OneCellAnchor의 from/row 추출
            rows_found = re.findall(r'<xdr:from>.*?<xdr:row>(\d+)</xdr:row>', drawing_xml, re.DOTALL)

            for idx, img_name in enumerate(img_files):
                try:
                    img_data = z.read(img_name)
                    ext = img_name.rsplit('.', 1)[-1].lower()
                    if ext not in ('png', 'jpg', 'jpeg', 'bmp', 'gif'):
                        continue
                    fname = f"punch_img_{uuid.uuid4().hex[:8]}.png"
                    dest  = out_dir / fname
                    # PIL로 PNG 통일
                    img = PILImage.open(io.BytesIO(img_data))
                    img.save(str(dest), 'PNG')
                    url = f"/uploads/punch_images/{fname}"

                    # 앵커 행 번호 매핑 (0-based xdr:row → 1-based Excel row)
                    if idx < len(rows_found):
                        anchor_row = int(rows_found[idx]) + 1  # 0-based → 1-based
                        image_map[anchor_row] = url
                    else:
                        image_map[-(idx+1)] = url  # 매핑 안되면 음수 키로 보관
                except Exception:
                    continue
    except Exception as e:
        print(f"[WARN] Excel 이미지 추출 실패: {e}")

    return image_map

def parse_excel(path: Path):
    # 이미지 저장 폴더
    img_dir = UPLOADS / "punch_images"
    img_dir.mkdir(parents=True, exist_ok=True)

    # 이미지 추출 (행번호 → URL 매핑)
    image_map = extract_excel_images(path, img_dir)

    wb = openpyxl.load_workbook(path, data_only=True)

    # 파일명에서 punch_type 감지: _Vendor, _RI, _Yard
    fname_lower = path.stem.lower()
    if "_ri" in fname_lower:
        file_type = "RI punch"
    elif "_yard" in fname_lower:
        file_type = "Yard punch"
    else:
        file_type = "Vendor punch"

    # ── 첫 번째 시트의 E2~F2 셀에서 Package code(장비코드) 파싱 ──
    # ── E5~F5 셀에서 장비이름 파싱 ──
    file_equip_code = ""
    file_equip_name = ""
    try:
        ws0 = wb.worksheets[0]
        # E2(row=2,col=5), F2(row=2,col=6) 병합 셀일 수 있어서 둘 다 확인
        pkg_val = ws0.cell(2, 5).value or ws0.cell(2, 6).value
        if pkg_val:
            file_equip_code = str(pkg_val).strip().upper()
        # E5(row=5,col=5), F5(row=5,col=6)
        name_val = ws0.cell(5, 5).value or ws0.cell(5, 6).value
        if name_val:
            file_equip_name = str(name_val).strip()
    except Exception as e:
        print(f"[WARN] 장비코드/이름 파싱 실패: {e}")

    print(f"[INFO] 펀치리스트: {file_type}, 장비코드: {file_equip_code!r}, 장비이름: {file_equip_name!r} (파일: {path.name})")

    all_punches = []

    for si, ws in enumerate(wb.worksheets):
        sheet_type = file_type  # 파일명 기반
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            continue

        header_idx = find_header_row(rows)
        punches = []

        for rel_idx, row in enumerate(rows[header_idx + 1:]):
            if not any(c for c in row if c is not None and str(c).strip()):
                continue
            # B열 원시값 직접 확인 (get_cell 거치지 않고)
            raw_b = row[COL_PUNCH_NO] if COL_PUNCH_NO < len(row) else None
            # 숫자 타입(int, float)이거나 순수 숫자 문자열만 허용
            if raw_b is None:
                continue
            if isinstance(raw_b, bool):
                continue  # True/False 스킵
            if isinstance(raw_b, (int, float)):
                no_int = int(raw_b)
            elif isinstance(raw_b, str):
                stripped = raw_b.strip()
                # 순수 숫자 문자열만 허용 (소수점 포함 가능)
                if not stripped or not stripped.replace('.','',1).isdigit():
                    continue  # 텍스트/주석 행 스킵
                no_int = int(float(stripped))
            else:
                continue
            if no_int < 1:
                continue
            no = str(no_int)  # "1.0" → "1" 정규화

            # 실제 Excel 행번호 (1-based)
            excel_row = header_idx + 1 + rel_idx + 1  # header_idx는 0-based, +1로 data시작, +1로 1-based

            # 해당 행의 이미지 URL (없으면 빈 문자열)
            pic_url     = image_map.get(excel_row, "")
            closed_date = get_cell(row, COL_CLOSED_DATE)
            # 날짜 형식 검증: 숫자나 날짜 문자열이면 closed
            is_closed   = bool(closed_date and any(c.isdigit() for c in closed_date))

            punches.append({
                "punch_no":                   no,
                "punch_type":                 sheet_type,
                "equip_code":                 file_equip_code,
                "equip_name":                 file_equip_name,
                "equipment_no":               get_cell(row, COL_EQUIP_NO),
                "drawing_no":                 get_cell(row, COL_DRAWING_NO),
                "punch_description":          get_cell(row, COL_DESCRIPTION),
                "picture_open":               get_cell(row, COL_PICTURE),
                "picture_url":                pic_url,
                "picture_closed":             get_cell(row, COL_PIC_CLOSED),
                "picture_url_closed":         "",
                "old_category":               get_cell(row, COL_OLD_CAT),
                "punch_category":             get_cell(row, COL_CATEGORY),
                "discipline":                 get_cell(row, COL_DISCIPLINE),
                "proposed_corrective_action": get_cell(row, COL_ACTION),
                "material_required":          get_cell(row, COL_MATERIAL),
                "eng_physical":               get_cell(row, COL_ENGPHY),
                "punch_issue_date":           get_cell(row, COL_ISSUE_DATE),
                "punch_raised_by":            get_cell(row, COL_RAISED_BY),
                "punch_raised_entity":        get_cell(row, COL_RAISED_ENT),
                "close_plan_date":            get_cell(row, COL_CLOSE_PLAN),
                "punch_closed_date":          closed_date,
                "punch_closed_by":            get_cell(row, COL_CLOSED_BY),
                "signature":                  get_cell(row, COL_SIGNATURE),
                "remarks":                    get_cell(row, COL_REMARKS),
                "flag_note":                  get_cell(row, COL_FLAG_NOTE),
                "status":                     "closed" if is_closed else "open",
            })

        all_punches.extend(punches)
    
    print(f"[INFO] parse_excel: {len(wb.worksheets)}개 시트에서 총 {len(all_punches)}건 파싱")
    return all_punches


# ── API ───────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def root():
    return FileResponse(str(BASE / "templates" / "index.html"))

@app.post("/api/upload/drawing")
async def upload_drawing(files: list[UploadFile] = File(...)):
    data  = load_data()
    saved = []
    for f in files:
        ext   = Path(f.filename).suffix.lower()
        fbase = uuid.uuid4().hex
        tmp   = UPLOADS_DRW / f"{fbase}{ext}"
        with open(tmp, "wb") as fp:
            shutil.copyfileobj(f.file, fp)

        if ext == ".pdf":
            try:
                pages = pdf_to_images(tmp, UPLOADS_DRW, fbase)
                saved.extend([{**p, "original": f.filename} for p in pages])
            except Exception as e:
                raise HTTPException(500, f"PDF 변환 실패: {e}")
            finally:
                tmp.unlink(missing_ok=True)
        else:
            saved.append({"filename": f.filename, "url": f"/uploads/drawings/{fbase}{ext}",
                          "id": f"{fbase}{ext}", "label": "도면 1"})

    # id를 d1, d2, d3... 형식으로 재부여 (JS의 page_id와 일치)
    for i, pg in enumerate(saved):
        pg["id"] = f"d{i+1}"
        if "label" not in pg or not pg["label"]:
            pg["label"] = f"도면 {i+1}"

    data["drawings"] = saved
    save_data(data)
    return {"ok": True, "files": saved}

@app.post("/api/upload/pid")
async def upload_pid(files: list[UploadFile] = File(...)):
    data  = load_data()
    saved = []
    for f in files:
        ext   = Path(f.filename).suffix.lower()
        fbase = uuid.uuid4().hex
        tmp   = UPLOADS_PID / f"{fbase}{ext}"
        with open(tmp, "wb") as fp:
            shutil.copyfileobj(f.file, fp)

        if ext == ".pdf":
            try:
                pages = pdf_to_images(tmp, UPLOADS_PID, fbase)
                saved.extend([{**p, "original": f.filename} for p in pages])
            except Exception as e:
                raise HTTPException(500, f"PDF 변환 실패: {e}")
            finally:
                tmp.unlink(missing_ok=True)
        else:
            saved.append({"filename": f.filename, "url": f"/uploads/pids/{fbase}{ext}",
                          "id": f"{fbase}{ext}", "label": "P&ID 1"})

    # id를 p1, p2, p3... 형식으로 재부여
    for i, pg in enumerate(saved):
        pg["id"] = f"p{i+1}"
        if "label" not in pg or not pg["label"]:
            pg["label"] = f"P&ID {i+1}"

    data["pids"] = saved
    save_data(data)
    return {"ok": True, "files": saved}

@app.post("/api/upload/punchlist")
async def upload_punchlist(file: UploadFile = File(...), punch_type: str = Form("")):
    data   = load_data()
    suffix = Path(file.filename).suffix.lower()
    # 원본 Excel을 data/ 폴더에 보관 (종결 처리 시 덮어쓰기용)
    excel_keep = BASE / "data" / f"punchlist_original{suffix}"
    tmp        = BASE / "data" / f"tmp_{uuid.uuid4().hex}{suffix}"
    # 일단 tmp로 저장
    with open(tmp, "wb") as fp:
        shutil.copyfileobj(file.file, fp)
    try:
        punches = parse_excel(tmp)
    except Exception as e:
        tmp.unlink(missing_ok=True)
        raise HTTPException(400, f"Excel 파싱 오류: {e}")
    # 파싱 성공 후 원본 보관
    shutil.copy2(str(tmp), str(excel_keep))
    tmp.unlink(missing_ok=True)
    # punch_type: Form에서 직접 선택, 없으면 파일명 기반 감지
    if punch_type and punch_type in ("Vendor punch", "RI punch", "Yard punch"):
        upload_type = punch_type
    else:
        fname_lower = Path(file.filename).stem.lower()
        if fname_lower.endswith("_ri") or "_ri_" in fname_lower:
            upload_type = "RI punch"
        elif fname_lower.endswith("_yard") or "_yard_" in fname_lower:
            upload_type = "Yard punch"
        else:
            upload_type = "Vendor punch"

    # 모든 펀치에 선택된 타입 적용 + (No.XXXX) 설명 접두어
    for p in punches:
        p["punch_type"] = upload_type
        no_str = str(p.get("punch_no", ""))
        desc   = p.get("punch_description", "")
        prefix = f"(No.{int(no_str):04d})" if no_str.isdigit() else ""
        if prefix and not desc.startswith("(No."):
            p["punch_description"] = prefix + " " + desc

    # 업로드된 펀치의 장비코드 추출
    upload_ec = ""
    for p in punches:
        ec = (p.get("equip_code") or "").upper().strip()
        if ec:
            upload_ec = ec
            break

    # 기존 펀치에서 같은 타입 + 같은 장비코드만 교체 (다른 장비코드 펀치 유지)
    if upload_ec:
        existing = [p for p in data.get("punches", [])
                    if not (p.get("punch_type") == upload_type
                            and (p.get("equip_code") or "").upper().strip() == upload_ec)]
    else:
        # 장비코드 없으면 기존 방식 (같은 타입 전체 교체)
        existing = [p for p in data.get("punches", []) if p.get("punch_type") != upload_type]
    existing.extend(punches)
    data["punches"] = existing
    print(f"[INFO] 병합: type={upload_type}, equip={upload_ec}, 신규 {len(punches)}건, 전체 {len(existing)}건")

    # 타입별 원본 Excel 경로 저장
    if "excel_paths" not in data:
        data["excel_paths"] = {}
    data["excel_paths"][upload_type] = str(excel_keep)
    data["excel_path"] = str(excel_keep)   # 마지막 업로드 파일

    # 펀치 데이터에서 장비코드/이름 추출해서 저장
    # 기존 데이터가 str 리스트일 수 있어서 dict 형식으로 정규화
    raw_ec = data.get("equip_codes", [])
    ec_list = []
    for x in raw_ec:
        if isinstance(x, dict):
            ec_list.append(x)
        elif isinstance(x, str) and x:
            ec_list.append({"code": x.upper(), "name": ""})
    data["equip_codes"] = ec_list

    for punch in punches:
        ec = (punch.get("equip_code") or "").strip().upper()
        if not ec:
            continue
        en = punch.get("equip_name", "")
        if not any(x.get("code") == ec for x in data["equip_codes"]):
            data["equip_codes"].append({"code": ec, "name": en})
        else:
            for x in data["equip_codes"]:
                if x.get("code") == ec and en:
                    x["name"] = en
    if "points" not in data:
        data["points"] = {}
    # 업로드한 파일명에서 장비코드 추출 ([S42] 형식)
    import re as _re3
    ec_m = _re3.search(r'\[([A-Za-z0-9]{1,5})\]', Path(file.filename).stem)
    file_ec = ec_m.group(1).upper() if ec_m else ""

    # 파싱된 펀치 전체에 equip_code 강제 설정 (파일명 기준)
    if file_ec:
        for p in data["punches"]:
            if not p.get("equip_code"):
                p["equip_code"] = file_ec

    # 업로드한 파일명(확장자 제외)을 스냅샷 이름으로 사용
    snap_name = Path(file.filename).stem  # e.g. "[S42]_Vendor_punchlist"
    data["snapshot_name"] = snap_name
    save_data(data)

    # ── 스냅샷 자동 저장 ──
    _save_snapshot(snap_name, data)

    return {"ok": True, "count": len(punches), "punches": punches, "snapshot_name": snap_name, "equip_codes": data.get("equip_codes", [])}

@app.post("/api/upload/misc")
async def upload_misc(files: list[UploadFile] = File(...)):
    data  = load_data()
    saved = []
    UPLOADS_MISC = UPLOADS / "misc"
    UPLOADS_MISC.mkdir(exist_ok=True)
    for f in files:
        ext   = Path(f.filename).suffix.lower()
        fbase = uuid.uuid4().hex
        dest  = UPLOADS_MISC / f"{fbase}{ext}"
        with open(dest, "wb") as fp:
            shutil.copyfileobj(f.file, fp)

        if ext == ".pdf":
            try:
                pages = pdf_to_images(dest, UPLOADS_MISC, fbase, doc_type="기타")
                saved.extend([{**p, "original": f.filename} for p in pages])
            except Exception as e:
                raise HTTPException(500, f"PDF 변환 실패: {e}")
            finally:
                dest.unlink(missing_ok=True)
        else:
            saved.append({"filename": f.filename, "url": f"/uploads/misc/{fbase}{ext}",
                          "id": f"{fbase}{ext}", "label": "기타"})
    # id 재부여
    for i, pg in enumerate(saved):
        pg["id"]    = f"m{i+1}"
        pg["label"] = f"기타 {i+1}"
    data["miscs"] = saved
    save_data(data)
    return {"ok": True, "files": saved}


# ── 통합 패키지 (ZIP) ────────────────────────────────────────────
PACKAGE_FOLDERS = {
    "drawings":     UPLOADS_DRW,
    "pids":         UPLOADS_PID,
    "misc":         UPLOADS / "misc",
    "punch_images": UPLOADS / "punch_images",
}

def _to_jpeg_bytes(fpath: Path, quality: int = 88):
    """이미지를 JPEG 바이트로 변환 (용량 최소화). 실패 시 None."""
    from PIL import Image as PILImage
    import io
    try:
        img = PILImage.open(fpath)
        if img.mode in ("RGBA", "LA", "P"):
            rgba = img.convert("RGBA")
            bg = PILImage.new("RGB", rgba.size, (255, 255, 255))
            bg.paste(rgba, mask=rgba.split()[-1])
            img = bg
        else:
            img = img.convert("RGB")
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=quality)
        return buf.getvalue()
    except Exception:
        return None

@app.get("/api/package/export")
async def export_package(only_used: bool = False):
    """
    현재 프로젝트(도면/P&ID/기타문서/펀치 사진 + project.json)를 ZIP 하나로 내보내기.
    이미지는 용량 최소화를 위해 JPEG로 변환하여 포함.
    B관리자는 이 ZIP을 그대로 업로드(/api/package/import)하면 동일한 상태가 재현됨.

    only_used=true 인 경우, 포인트(깃발)가 찍힌 페이지만 포함하여 ZIP 용량을 최소화
    (이메일 첨부용 등).
    """
    import io, zipfile

    data = json.loads(json.dumps(load_data()))  # 깊은 복사 (원본 데이터 보존)

    if only_used:
        used_ids = {pt.get("page_id") for pt in data.get("points", {}).values() if pt.get("page_id")}
        data["drawings"] = [pg for pg in data.get("drawings", []) if pg.get("id") in used_ids]
        data["pids"]     = [pg for pg in data.get("pids", [])     if pg.get("id") in used_ids]
        data["miscs"]    = [pg for pg in data.get("miscs", [])    if pg.get("id") in used_ids]

    def add_pages(pages, folder):
        for pg in pages:
            url = pg.get("url", "")
            rel = [p for p in url.replace("\\", "/").split("/") if p]
            fpath = BASE.joinpath(*rel)
            if not fpath.exists():
                continue
            jpg_bytes = _to_jpeg_bytes(fpath)
            if jpg_bytes is None:
                new_fname = fpath.name
                content   = fpath.read_bytes()
            else:
                new_fname = Path(fpath.name).stem + ".jpg"
                content   = jpg_bytes
            zf.writestr(f"{folder}/{new_fname}", content)
            if pg.get("id") == fpath.name:
                pg["id"] = new_fname
            if pg.get("filename"):
                pg["filename"] = new_fname
            pg["url"] = f"/uploads/{folder}/{new_fname}"

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        add_pages(data.get("drawings", []), "drawings")
        add_pages(data.get("pids", []), "pids")
        add_pages(data.get("miscs", []), "misc")

        # 사진은 패키지에 포함하지 않음 (용량 최소화)
        # B/C 검사원이 펀치리스트 직접 업로드 시 사진 파싱됨

        zf.writestr("project.json", json.dumps(data, ensure_ascii=False, indent=2))

    buf.seek(0)
    fname = f"punch_package_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    return StreamingResponse(
        buf, media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'})

def _apply_package_zip(content: bytes) -> dict:
    """
    통합 패키지 ZIP(project.json + 이미지)을 풀어 현재 프로젝트 상태로 복원.
    /api/package/import 및 레지스터 불러오기에서 공용으로 사용.
    """
    import io, zipfile

    try:
        zf = zipfile.ZipFile(io.BytesIO(content))
    except Exception as e:
        raise HTTPException(400, f"ZIP 파일을 열 수 없습니다: {e}")

    if "project.json" not in zf.namelist():
        raise HTTPException(400, "올바른 패키지 ZIP이 아닙니다 (project.json 없음)")

    try:
        new_data = json.loads(zf.read("project.json").decode("utf-8"))
    except Exception as e:
        raise HTTPException(400, f"project.json 파싱 오류: {e}")

    for d in PACKAGE_FOLDERS.values():
        d.mkdir(parents=True, exist_ok=True)

    for name in zf.namelist():
        if name == "project.json" or name.endswith("/"):
            continue
        parts = name.split("/")
        if len(parts) != 2 or parts[0] not in PACKAGE_FOLDERS:
            continue
        dest = PACKAGE_FOLDERS[parts[0]] / parts[1]
        dest.write_bytes(zf.read(name))

    save_data(new_data)
    return {
        "ok":       True,
        "drawings": len(new_data.get("drawings", [])),
        "pids":     len(new_data.get("pids", [])),
        "miscs":    len(new_data.get("miscs", [])),
        "punches":  len(new_data.get("punches", [])),
        "points":   len(new_data.get("points", {})),
    }


@app.post("/api/package/import")
async def import_package(file: UploadFile = File(...)):
    """
    /api/package/export 로 받은 ZIP을 그대로 업로드하면
    도면/P&ID/기타문서/펀치 사진과 project.json을 복원하여 동일한 상태로 재현.
    """
    content = await file.read()
    return _apply_package_zip(content)


# ── 레지스터 (아웃룩 자동 동기화) ─────────────────────────────────
PACKAGE_PART_RE = re.compile(r"^(.*)-(\d{3})of(\d{3})\.zip$", re.IGNORECASE)

def sync_outlook_registry():
    """
    실행 중인 아웃룩의 받은편지함을 스캔하여 제목이 '-package'로 끝나는 메일의
    ZIP 첨부(분할 파일은 '이름-NNNofMMM.zip' 형식)를 모아 레지스터에 등록.
    """
    try:
        import win32com.client as win32
    except ImportError:
        raise RuntimeError("win32com 미설치: pip install pywin32")
    import zipfile, io

    reg       = load_registry()
    processed = set(reg.get("processed_mail_ids", []))
    packages  = reg.get("packages", [])

    outlook = win32.Dispatch("Outlook.Application")
    ns      = outlook.GetNamespace("MAPI")
    inbox   = ns.GetDefaultFolder(6)  # olFolderInbox

    new_count = 0
    for item in list(inbox.Items):
        try:
            subject = (item.Subject or "").strip()
        except Exception:
            continue
        if not subject.lower().endswith("-package"):
            continue

        mail_id = item.EntryID
        if mail_id in processed:
            continue

        pkg_name = subject[:-len("-package")].strip().rstrip("-").strip()
        if not pkg_name:
            processed.add(mail_id)
            continue

        # 첨부의 ZIP을 모두 저장하고, 분할 파일(NNNofMMM)은 그룹으로 묶음
        groups, single = {}, []
        for att in item.Attachments:
            try:
                fname = att.FileName
            except Exception:
                continue
            if not fname.lower().endswith(".zip"):
                continue
            tmp_path = REGISTRY_DIR / f"_tmp_{uuid.uuid4().hex}.zip"
            try:
                att.SaveAsFile(str(tmp_path))
                part_bytes = tmp_path.read_bytes()
            finally:
                tmp_path.unlink(missing_ok=True)

            m = PACKAGE_PART_RE.match(fname)
            if m:
                base, idx, total = m.group(1), int(m.group(2)), int(m.group(3))
                g = groups.setdefault(base, {"total": total, "parts": {}})
                g["parts"][idx] = part_bytes
            else:
                single.append(part_bytes)

        merged = None
        for g in groups.values():
            if len(g["parts"]) == g["total"]:
                merged = b"".join(g["parts"][i] for i in range(1, g["total"] + 1))
                break
        if merged is None and single:
            merged = single[0]

        if merged is None:
            continue  # 분할 파일이 아직 모두 도착하지 않음 - 다음 동기화에서 재시도

        try:
            zipfile.ZipFile(io.BytesIO(merged))
        except Exception:
            processed.add(mail_id)
            continue

        (REGISTRY_DIR / f"{pkg_name}.zip").write_bytes(merged)

        try:
            received = item.ReceivedTime.strftime("%Y-%m-%d %H:%M:%S")
        except Exception:
            received = ""
        try:
            sender = item.SenderName
        except Exception:
            sender = ""

        packages = [p for p in packages if p.get("name") != pkg_name]
        packages.append({
            "name": pkg_name, "subject": subject, "sender": sender,
            "received_at": received, "size": len(merged),
            "synced_at": datetime.now().isoformat(timespec="seconds"),
        })
        processed.add(mail_id)
        new_count += 1

    reg["processed_mail_ids"] = list(processed)
    reg["packages"] = packages
    save_registry(reg)
    return {"ok": True, "new": new_count, "total": len(packages)}


@app.post("/api/registry/sync")
async def registry_sync():
    """수동 동기화: 아웃룩에서 'xxx-package' 메일을 즉시 스캔하여 레지스터에 등록"""
    try:
        return sync_outlook_registry()
    except RuntimeError as e:
        raise HTTPException(500, str(e))
    except Exception as e:
        raise HTTPException(500, f"아웃룩 동기화 실패: {e}")

@app.get("/api/registry/list")
async def registry_list():
    reg = load_registry()
    packages = sorted(reg.get("packages", []), key=lambda p: p.get("synced_at", ""), reverse=True)
    return {"packages": packages}

@app.post("/api/registry/load/{name}")
async def registry_load(name: str):
    """레지스터에 등록된 패키지를 현재 캔버스(프로젝트)로 불러오기"""
    path = REGISTRY_DIR / f"{name}.zip"
    if not path.exists():
        raise HTTPException(404, "등록된 패키지를 찾을 수 없습니다")
    return _apply_package_zip(path.read_bytes())


@app.on_event("startup")
async def _start_registry_poll():
    """서버 실행 중 1시간 주기로 아웃룩을 자동 동기화 (아웃룩 미설치/미실행 시 조용히 무시)"""
    import asyncio

    async def loop():
        while True:
            await asyncio.sleep(3600)
            try:
                result = sync_outlook_registry()
                print(f"[INFO] 아웃룩 자동 동기화: 신규 {result['new']}건, 총 {result['total']}건")
            except Exception as e:
                print(f"[WARN] 아웃룩 자동 동기화 실패: {e}")

    asyncio.create_task(loop())


@app.get("/api/project")
async def get_project():
    return load_data()

# ── 스냅샷 헬퍼 ──────────────────────────────────────────────────
def _save_snapshot(name: str, data: dict):
    """
    현재 project.json 상태를 snapshots/{name}.json 으로 저장.
    이름이 같으면 덮어씀 (포인트 추가 시 업데이트).
    """
    safe_name = re.sub(r'[\\/:*?"<>|]', '_', name).strip() or "unnamed"
    snap_path = SNAPSHOT_DIR / f"{safe_name}.json"
    snap_data = dict(data)
    snap_data["_snapshot_saved_at"] = datetime.now().isoformat(timespec="seconds")
    snap_data["_snapshot_name"]     = safe_name
    snap_path.write_text(json.dumps(snap_data, ensure_ascii=False, indent=2), encoding="utf-8")
    return safe_name


@app.get("/api/snapshots")
async def list_snapshots():
    """저장된 스냅샷 목록 반환 (최신순)"""
    snaps = []
    for f in sorted(SNAPSHOT_DIR.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True):
        try:
            meta = json.loads(f.read_text(encoding="utf-8"))
            snaps.append({
                "name":       meta.get("_snapshot_name", f.stem),
                "saved_at":   meta.get("_snapshot_saved_at", ""),
                "punches":    len(meta.get("punches", [])),
                "points":     len(meta.get("points", {})),
                "drawings":   len(meta.get("drawings", [])),
                "pids":       len(meta.get("pids", [])),
                "open":       len([p for p in meta.get("punches",[]) if p.get("status")=="open"]),
                "closed":     len([p for p in meta.get("punches",[]) if p.get("status")=="closed"]),
            })
        except Exception:
            continue
    return {"snapshots": snaps}


@app.post("/api/snapshots/save")
async def save_snapshot_now(body: dict):
    """현재 상태를 지정 이름으로 즉시 저장"""
    name = body.get("name", "").strip()
    if not name:
        raise HTTPException(400, "name 필드가 필요합니다")
    data = load_data()
    safe = _save_snapshot(name, data)
    return {"ok": True, "name": safe}



@app.post("/api/snapshots/merge/{name}")
async def merge_snapshot(name: str):
    """스냅샷을 현재 데이터에 병합 (해당 장비코드 펀치만 교체, 나머지 유지)"""
    safe_name = re.sub(r'[\\/:*?\"<>|]', '_', name).strip()
    snap_path = SNAPSHOT_DIR / f"{safe_name}.json"
    if not snap_path.exists():
        raise HTTPException(404, f"스냅샷 '{safe_name}' 없음")

    snap_data = json.loads(snap_path.read_text(encoding="utf-8"))
    for k in ["_snapshot_saved_at", "_snapshot_name"]:
        snap_data.pop(k, None)

    # 스냅샷 이름에서 장비코드 추출: [R59]_xxx → R59
    ec_match = re.search(r'\[([A-Za-z0-9]{1,5})\]', name)
    snap_ec = ec_match.group(1).upper() if ec_match else ""

    snap_punches = snap_data.get("punches", [])
    snap_points  = snap_data.get("points", {})

    # 현재 데이터 로드
    data = load_data()
    current_punches = data.get("punches", [])
    current_points  = data.get("points", {})

    if snap_ec:
        # 스냅샷에서 해당 장비코드 펀치만 추출
        snap_ec_punches = [p for p in snap_punches
                           if (p.get("equip_code") or "").upper() == snap_ec]
        # 현재 데이터에서 해당 장비코드 펀치 제거 → 스냅샷 것으로 교체
        kept = [p for p in current_punches
                if (p.get("equip_code") or "").upper() != snap_ec]
        kept.extend(snap_ec_punches)
        data["punches"] = kept
    else:
        # 장비코드 없으면 전체 교체
        data["punches"] = snap_punches

    # 포인트 병합 (스냅샷 포인트 우선)
    current_points.update(snap_points)
    data["points"] = current_points

    save_data(data)
    print(f"[INFO] 스냅샷 병합: {name}, 장비코드={snap_ec}, 스냅샷 {len(snap_punches)}건, 전체 {len(data['punches'])}건")

    return {
        "ok":      True,
        "name":    safe_name,
        "punches": data["punches"],
        "points":  data["points"],
    }

@app.post("/api/snapshots/load/{name}")
async def load_snapshot(name: str):
    """스냅샷 불러오기 → 현재 project.json 교체"""
    safe_name = re.sub(r'[\\/:*?"<>|]', '_', name).strip()
    snap_path = SNAPSHOT_DIR / f"{safe_name}.json"
    if not snap_path.exists():
        raise HTTPException(404, f"스냅샷 '{safe_name}' 없음")
    snap_data = json.loads(snap_path.read_text(encoding="utf-8"))
    # 메타 키 제거 후 저장
    for k in ["_snapshot_saved_at", "_snapshot_name"]:
        snap_data.pop(k, None)
    save_data(snap_data)
    return {
        "ok":      True,
        "name":    safe_name,
        "punches": len(snap_data.get("punches", [])),
        "points":  len(snap_data.get("points", {})),
    }


@app.delete("/api/snapshots/{name}")
async def delete_snapshot(name: str):
    """스냅샷 삭제"""
    safe_name = re.sub(r'[\\/:*?"<>|]', '_', name).strip()
    snap_path = SNAPSHOT_DIR / f"{safe_name}.json"
    if not snap_path.exists():
        raise HTTPException(404, "스냅샷 없음")
    snap_path.unlink()
    return {"ok": True}


@app.post("/api/reset/punchlist")
async def reset_punchlist_only():
    """펀치리스트만 초기화 (도면/포인트 유지)"""
    data = load_data()
    data["punches"] = []
    data.pop("excel_path", None)
    data.pop("snapshot_name", None)
    save_data(data)
    return {"ok": True}


@app.post("/api/reset")
async def reset_project():
    """캔버스/도면/P&ID/펀치리스트/포인트 등 현재 프로젝트 데이터를 모두 초기화"""
    save_data({"punches": [], "points": {}, "drawings": [], "pids": [], "miscs": [], "header": {}})
    return {"ok": True}

@app.post("/api/point")
async def save_point(body: dict):
    data     = load_data()
    punch_no = str(body.get("punch_no", ""))
    if not punch_no:
        raise HTTPException(400, "punch_no required")
    if body.get("remove"):
        data["points"].pop(punch_no, None)
    else:
        data["points"][punch_no] = {
            "page_id":    body.get("page_id"),
            "page_type":  body.get("page_type"),
            "x":          body.get("x"),
            "y":          body.get("y"),
            "updated_at": datetime.now().isoformat(),
        }
    save_data(data)
    # 스냅샷 자동 업데이트
    snap_name = data.get("snapshot_name")
    if snap_name:
        try: _save_snapshot(snap_name, data)
        except Exception: pass
    return {"ok": True}


@app.post("/api/punch/delete-renumber")
async def delete_renumber(body: dict):
    """선택한 펀치 삭제 후 재넘버링된 전체 리스트 + 포인트 저장"""
    renumbered = body.get("punches", [])
    new_points = body.get("points", {})

    data = load_data()
    data["punches"] = renumbered
    data["points"]  = new_points
    save_data(data)

    snap_name = data.get("snapshot_name")
    if snap_name:
        try: _save_snapshot(snap_name, data)
        except Exception: pass

    return {"ok": True, "count": len(renumbered)}

@app.post("/api/punch/edit")
async def edit_punch(body: dict):
    """펀치 내용 수정 (펀치 번호 변경 포함)"""
    punch_no = str(body.get("punch_no", ""))
    if not punch_no:
        raise HTTPException(400, "punch_no required")

    # 새 번호로 변경 요청 시
    new_no = str(body.get("new_punch_no", "")).strip()

    data = load_data()
    found = False
    for p in data.get("punches", []):
        if str(p.get("punch_no","")) == punch_no:
            # 번호 변경
            if new_no and new_no != punch_no:
                # 중복 번호 체크
                existing_nos = {str(x.get("punch_no","")) for x in data["punches"]}
                if new_no in existing_nos:
                    raise HTTPException(400, f"No.{new_no}은 이미 존재합니다")
                p["punch_no"] = new_no
                # points에서도 키 변경
                if punch_no in data.get("points", {}):
                    data["points"][new_no] = data["points"].pop(punch_no)

            # 나머지 필드 업데이트
            editable = [
                "equipment_no", "drawing_no", "punch_description",
                "punch_category", "discipline", "proposed_corrective_action",
                "material_required", "eng_physical", "punch_issue_date",
                "punch_raised_by", "punch_raised_entity", "close_plan_date",
                "remarks", "punch_type", "equip_code", "flag_note"
            ]
            for key in editable:
                if key in body:
                    p[key] = body[key]
            found = True
            break

    if not found:
        raise HTTPException(404, f"펀치 No.{punch_no} 없음")

    save_data(data)
    snap_name = data.get("snapshot_name")
    if snap_name:
        try: _save_snapshot(snap_name, data)
        except Exception: pass

    result_no = new_no if new_no and new_no != punch_no else punch_no
    return {"ok": True, "punch_no": result_no, "old_no": punch_no}


@app.post("/api/import/mobile")
async def import_mobile(
    files: list[UploadFile] = File(...),
    punch_type: str = Form(""),
    equip_code: str = Form("")
):
    """
    모바일 앱에서 출력한 ZIP 파일(들)을 업로드.
    분할된 ZIP 여러 개를 동시에 올려도 합산 처리.
    ZIP 안에서 .xlsx → 펀치리스트, 이미지 → 사진.
    """
    import io as _io
    import zipfile as _zip

    # ── 사진 파일 저장 및 파일명 매핑 ──
    img_dir = UPLOADS / "punch_images"
    img_dir.mkdir(exist_ok=True)

    # ── 복수 ZIP 파일 읽기 → Excel + 사진 합산 ──
    import zipfile as _zip
    import io as _io2

    photo_map      = {}   # { "photo_no1_r59.jpg": "/uploads/punch_images/uuid.jpg" }
    tmp            = None
    excel_filename = ""

    for upload in files:
        try:
            zip_bytes = await upload.read()
            print(f"[DEBUG] ZIP 파일: {upload.filename}, 크기: {len(zip_bytes)} bytes")
            with _zip.ZipFile(_io2.BytesIO(zip_bytes)) as zf:
                print(f"[DEBUG] ZIP 내부 파일 목록: {zf.namelist()}")
                for member in zf.namelist():
                    name_lower = member.lower().lstrip("/")
                    if name_lower.startswith("__macosx") or name_lower.startswith("."):
                        continue
                    ext = Path(member).suffix.lower()
                    print(f"[DEBUG] 멤버: {member}, ext: {ext}")
                    if ext in (".xlsx", ".xls") and tmp is None:
                        # Excel은 첫 번째 것만 사용
                        tmp = BASE / "data" / f"mobile_import_{uuid.uuid4().hex}{ext}"
                        with open(tmp, "wb") as fp:
                            fp.write(zf.read(member))
                        excel_filename = Path(member).name
                        print(f"[INFO] ZIP({upload.filename}) 내 Excel: {member}")
                    elif ext in (".jpg", ".jpeg", ".png", ".webp", ".gif"):
                        fname_save = uuid.uuid4().hex + ext
                        dest = img_dir / fname_save
                        with open(dest, "wb") as fp:
                            fp.write(zf.read(member))
                        base_name = Path(member).name.lower()
                        photo_map[base_name] = f"/uploads/punch_images/{fname_save}"
        except _zip.BadZipFile as e:
            print(f"[WARN] {upload.filename} ZIP 오류 (스킵): {e}")
            continue

    if tmp is None:
        raise HTTPException(400, "ZIP 안에 Excel 파일(.xlsx)이 없습니다")

    print(f"[INFO] ZIP 합산 완료: Excel 1개, 사진 {len(photo_map)}개 ({len(files)}개 ZIP)")

    try:
        # Form에서 전달된 punch_type 우선, 없으면 A열에서 읽기
        import_type = punch_type if punch_type in ("Vendor punch", "RI punch", "Yard punch") else "Vendor punch"
        # Form에서 전달된 equip_code
        import_ec = equip_code.upper().strip() if equip_code else ""

        # Excel 파싱 (모바일 앱 열 구조)
        wb = openpyxl.load_workbook(str(tmp), data_only=True)
        ws = wb.worksheets[0]
        rows = list(ws.iter_rows(values_only=True))

        # 헤더 행 찾기: B열에 "No." 또는 숫자가 처음 나오는 행
        header_idx = 0
        for i, row in enumerate(rows[:20]):
            val = row[1] if len(row) > 1 else None
            if val and str(val).strip().lower() in ("no.", "no", "번호"):
                header_idx = i
                break
            if val and str(val).strip().replace(".","").isdigit():
                header_idx = max(0, i - 1)
                break

        new_punches = []
        for row in rows[header_idx + 1:]:
            if not row or not any(c for c in row if c is not None and str(c).strip()):
                continue
            # B열 = punch_no — 숫자 타입만 허용, 텍스트/주석 행 스킵
            no_val = row[1] if len(row) > 1 else None
            if no_val is None:
                continue
            if isinstance(no_val, bool):
                continue
            if isinstance(no_val, (int, float)):
                no_int = int(no_val)
            elif isinstance(no_val, str):
                stripped = no_val.strip()
                if not stripped or not stripped.replace('.','',1).isdigit():
                    continue  # 텍스트/주석 스킵
                no_int = int(float(stripped))
            else:
                continue
            if no_int < 1:
                continue
            punch_no = str(no_int)

            def gc(r, idx):
                if idx >= len(r): return ""
                v = r[idx]
                if v is None: return ""
                if isinstance(v, (int, float)):
                    return str(int(v)) if float(v) == int(v) else str(v)
                return str(v).strip()

            # H열 사진 파일명 → URL 매핑
            h_val = gc(row, 7)  # H열 = idx 7
            pic_url = ""
            if h_val:
                # "Photo_No7_ASBJA.jpg (320KB)" → 파일명 추출
                pic_fname = h_val.split(" ")[0].strip().lower()
                pic_url = photo_map.get(pic_fname, "")
                if not pic_url:
                    # 부분 매칭 시도
                    for k, v in photo_map.items():
                        if pic_fname in k or k in pic_fname:
                            pic_url = v
                            break

            # Form에서 선택된 타입 우선, 없으면 A열에서 읽기
            if punch_type and punch_type in ("Vendor punch", "RI punch", "Yard punch"):
                row_type = punch_type
            else:
                row_type_raw = gc(row, 0).strip().lower()
                if "ri" in row_type_raw:
                    row_type = "RI punch"
                elif "yard" in row_type_raw:
                    row_type = "Yard punch"
                elif "vendor" in row_type_raw:
                    row_type = "Vendor punch"
                else:
                    row_type = import_type

            punch = {
                "punch_no":                   punch_no,
                "punch_type":                 row_type,
                "equipment_no":               gc(row, 2),   # C열
                "drawing_no":                 gc(row, 5),   # F열
                "punch_description":          gc(row, 6),   # G열
                "picture_open":               gc(row, 7),   # H열 원문
                "picture_url":                pic_url,       # 매핑된 URL
                "picture_closed":             gc(row, 8),   # I열
                "picture_url_closed":         "",
                "old_category":               gc(row, 9),   # J열
                "punch_category":             gc(row, 10),  # K열
                "discipline":                 gc(row, 11),  # L열
                "proposed_corrective_action": gc(row, 12),  # M열
                "material_required":          gc(row, 13),  # N열
                "eng_physical":               gc(row, 14),  # O열
                "punch_issue_date":           gc(row, 15),  # P열
                "punch_raised_by":            gc(row, 16),  # Q열
                "punch_raised_entity":        gc(row, 17),  # R열
                "close_plan_date":            gc(row, 18),  # S열
                "punch_closed_date":          gc(row, 19),  # T열
                "punch_closed_by":            gc(row, 20),  # U열
                "signature":                  gc(row, 21),  # V열
                "remarks":                    gc(row, 22),  # W열
                "flag_note":                  gc(row, 23),  # X열
                "status":                     "closed" if gc(row, 19) else "open",
            }
            new_punches.append(punch)

        print(f"[INFO] 모바일 가져오기: {len(new_punches)}건, 사진 {len(photo_map)}개")

    except Exception as e:
        tmp.unlink(missing_ok=True)
        raise HTTPException(400, f"Excel 파싱 오류: {e}")
    finally:
        tmp.unlink(missing_ok=True)

    # ── 기존 펀치리스트와 병합 ──
    data = load_data()
    existing = data.get("punches", [])

    # ── 타입별로 독립 재넘버링 ──
    # 기존 펀치에서 타입별 최대 번호 계산
    max_by_type = {}
    for p in existing:
        pt = p.get("punch_type", "Vendor punch")
        try:
            n = int(p.get("punch_no", 0))
            if n > max_by_type.get(pt, 0):
                max_by_type[pt] = n
        except (ValueError, TypeError):
            pass

    # 새 펀치를 타입별로 분류 후 순서대로 번호 부여
    by_type = {}
    for p in sorted(new_punches, key=lambda x: int(x.get("punch_no", 0))):
        pt = p.get("punch_type", "Vendor punch")
        by_type.setdefault(pt, []).append(p)

    remapped = []
    for pt, plist in by_type.items():
        offset = max_by_type.get(pt, 0)
        for i, p in enumerate(plist):
            p = dict(p)
            new_no = offset + i + 1
            p["punch_no"] = str(new_no)
            # Form에서 전달된 equip_code 적용
            if import_ec and not p.get("equip_code"):
                p["equip_code"] = import_ec
            # (No.XXXX) 접두어
            desc = p.get("punch_description", "")
            prefix = f"(No.{new_no:04d})"
            if not desc.startswith("(No."):
                p["punch_description"] = prefix + " " + desc
            remapped.append(p)
        print(f"[INFO] {pt} 재매핑: {len(plist)}건, {offset+1}번부터, equip={import_ec}")

    existing.extend(remapped)
    data["punches"] = existing

    # equip_codes 업데이트
    if import_ec:
        if "equip_codes" not in data:
            data["equip_codes"] = []
        if not any(isinstance(x, dict) and x.get("code") == import_ec for x in data["equip_codes"]):
            data["equip_codes"].append({"code": import_ec, "name": ""})

    save_data(data)

    # 스냅샷 업데이트
    snap_name = data.get("snapshot_name") or "mobile_import"
    try: _save_snapshot(snap_name, data)
    except Exception: pass

    return {
        "ok":        True,
        "punch_type": import_type,
        "imported":  len(remapped),
        "photos":    len(photo_map),
        "matched":   sum(1 for p in new_punches if p.get("picture_url")),
    }


@app.post("/api/punch/add")
async def add_punch(body: dict):
    """
    펀치 수동 추가 — project.json + 원본 Excel에 행 추가
    B열 마지막 번호 +1로 자동 넘버링
    """
    data    = load_data()
    punches = data.get("punches", [])

    # 다음 펀치 번호 계산 — 같은 타입 내 최대값 + 1 (타입별 독립)
    new_type = body.get("punch_type", "Vendor punch")
    max_no = 0
    for p in punches:
        if p.get("punch_type") != new_type:
            continue
        try:
            n = int(p.get("punch_no", 0))
            if n > max_no:
                max_no = n
        except (ValueError, TypeError):
            pass
    next_no = max_no + 1

    # 새 펀치 데이터
    new_punch = {
        "punch_no":                   str(next_no),
        "punch_type":                 new_type,
        "equip_code":                 body.get("equip_code", "").upper(),
        "equipment_no":               body.get("equipment_no", ""),
        "drawing_no":                 body.get("drawing_no", ""),
        "punch_description":          body.get("punch_description", ""),
        "picture_open":               "Y" if body.get("picture_url") else "",
        "picture_url":                body.get("picture_url", ""),
        "picture_closed":             "",
        "picture_url_closed":         "",
        "punch_category":             body.get("punch_category", ""),
        "discipline":                 body.get("discipline", ""),
        "proposed_corrective_action": body.get("proposed_corrective_action", ""),
        "material_required":          body.get("material_required", ""),
        "vendor_required":            body.get("vendor_required", ""),
        "punch_issue_date":           body.get("punch_issue_date", ""),
        "punch_raised_by":            body.get("punch_raised_by", ""),
        "punch_raised_entity":        body.get("punch_raised_entity", ""),
        "punch_closed_date":          "",
        "punch_closed_by":            "",
        "remarks":                    body.get("remarks", ""),
        "status":                     "open",
    }

    # project.json에 추가
    punches.append(new_punch)
    data["punches"] = punches
    save_data(data)

    # 원본 Excel에 행 추가
    excel_path = data.get("excel_path")
    if excel_path and Path(excel_path).exists():
        try:
            wb = openpyxl.load_workbook(str(excel_path))
            ws = wb.worksheets[0]

            # B열에서 마지막 데이터 행 찾기
            last_row = ws.max_row + 1

            # 컬럼 매핑 (0-based index → Excel col)
            # B=2, C=3, F=6, G=7, H=8, I=9, J=10, K=11, L=12, M=13, N=14
            # O=15, P=16, Q=17, R=18, S=19, T=20
            col_map = {
                1:  body.get("punch_type", ""),                    # A: punch_type
                2:  str(next_no),                                  # B: punch_no
                3:  body.get("equipment_no", ""),                   # C: tag_no
                6:  body.get("drawing_no", ""),                     # F: drawing_no
                7:  body.get("punch_description", ""),              # G: description
                8:  "Y" if body.get("picture_url") else "",         # H: picture_open
                9:  "",                                             # I: picture_closed
                10: body.get("old_category", ""),                   # J: old category (0/1)
                11: body.get("punch_category", ""),                 # K: Punch Category (A/B/C)
                12: body.get("discipline", ""),                     # L: discipline
                13: body.get("proposed_corrective_action", ""),     # M: corrective action
                14: body.get("material_required", ""),              # N: material required
                15: body.get("eng_physical", ""),                   # O: Engineering/Physical work
                16: body.get("punch_issue_date", ""),               # P: issue date
                17: body.get("punch_raised_by", ""),                # Q: raised by
                18: body.get("punch_raised_entity", ""),            # R: raised entity
                19: body.get("close_plan_date", ""),                # S: close plan date
                20: "",                                             # T: closed date (빈칸)
                21: "",                                             # U: closed by (빈칸)
                22: "",                                             # V: signature (빈칸)
                23: body.get("remarks", ""),                        # W: remarks
            }

            for col, val in col_map.items():
                ws.cell(row=last_row, column=col, value=val)

            # 사진이 있으면 H열에 이미지 삽입
            pic_url = body.get("picture_url", "")
            if pic_url:
                from openpyxl.drawing.image import Image as XLImage
                from PIL import Image as PILImage
                import io as _io
                pic_rel  = [pp for pp in pic_url.replace("\\","/").split("/") if pp]
                pic_path = BASE.joinpath(*pic_rel)
                if pic_path.exists():
                    try:
                        thumb = PILImage.open(str(pic_path)).convert("RGB")
                        thumb.thumbnail((300, 220), PILImage.LANCZOS)
                        buf = _io.BytesIO()
                        thumb.save(buf, "JPEG", quality=70)
                        buf.seek(0)
                        xl_img = XLImage(buf)
                        xl_img.width  = 180
                        xl_img.height = 135
                        ws.add_image(xl_img, f"H{last_row}")
                        ws.row_dimensions[last_row].height = 105
                    except Exception as e:
                        print(f"[WARN] 펀치 추가 사진 삽입 실패: {e}")

            wb.save(str(excel_path))
            print(f"[INFO] Excel에 No.{next_no} 행 추가 (행 {last_row})")
        except Exception as e:
            print(f"[WARN] Excel 행 추가 실패: {e}")

    # 스냅샷 업데이트
    snap_name = data.get("snapshot_name")
    if snap_name:
        try: _save_snapshot(snap_name, data)
        except Exception: pass

    return {"ok": True, "punch": new_punch}


@app.post("/api/punch/close-photo")
async def upload_close_photo(file: UploadFile = File(...)):
    """종결 사진 업로드"""
    img_dir = UPLOADS / "punch_images"
    img_dir.mkdir(exist_ok=True)
    ext   = Path(file.filename).suffix.lower() or ".jpg"
    fname = f"closed_{uuid.uuid4().hex[:8]}{ext}"
    dest  = img_dir / fname
    with open(dest, "wb") as fp:
        shutil.copyfileobj(file.file, fp)
    return {"ok": True, "url": f"/uploads/punch_images/{fname}"}


@app.post("/api/punch/status")
async def update_punch_status(body: dict):
    """펀치 상태(open/closed) 변경 + 종결 정보 저장"""
    punch_no   = str(body.get("punch_no", ""))
    new_status = body.get("status", "open")
    close_date = body.get("closed_date", "")
    close_by   = body.get("closed_by", "")
    evidence   = body.get("evidence", "")   # 사진 URL 또는 텍스트

    if not punch_no:
        raise HTTPException(400, "punch_no required")
    if new_status not in ("open", "closed"):
        raise HTTPException(400, "status must be open or closed")

    data    = load_data()
    changed = False
    for p in data.get("punches", []):
        if str(p.get("punch_no", "")) == punch_no:
            p["status"] = new_status
            if new_status == "closed":
                p["punch_closed_date"] = close_date or datetime.now().strftime("%Y-%m-%d")
                p["punch_closed_by"]   = close_by
                # evidence가 URL이면 picture_url_closed, 텍스트면 picture_closed 필드에
                if evidence.startswith("/uploads/"):
                    p["picture_url_closed"] = evidence
                    p["picture_closed"]     = "Y"
                else:
                    p["picture_closed"]     = evidence  # 텍스트 근거
                    p["picture_url_closed"] = ""
            else:  # open으로 되돌리기
                p["punch_closed_date"]  = ""
                p["punch_closed_by"]    = ""
                p["picture_closed"]     = ""
                p["picture_url_closed"] = ""
            changed = True
            break

    if not changed:
        raise HTTPException(404, f"펀치 No.{punch_no} 없음")

    save_data(data)
    snap_name = data.get("snapshot_name")
    if snap_name:
        try: _save_snapshot(snap_name, data)
        except Exception: pass

    # 원본 Excel 업데이트 (파일이 있으면)
    _update_excel_row(punch_no, data)

    return {"ok": True, "punch_no": punch_no, "status": new_status}


def _update_excel_row(punch_no: str, data: dict):
    """
    원본 Excel은 수정하지 않음 (openpyxl 저장 시 외부참조/기존이미지 손상 방지).
    모든 변경사항은 project.json에만 기록하고,
    '업데이트 Excel 다운로드' 시 복사본에 한 번만 적용.
    """
    print(f"[INFO] No.{punch_no}: 종결 정보 project.json에 저장됨 (원본 Excel 미수정, 다운로드 시 반영)")



@app.post("/api/upload/template")
async def upload_template(
    file: UploadFile = File(...),
    punch_type: str = Form(...)
):
    """Vendor/RI/Yard 별 펀치 양식(빈 Excel) 등록"""
    allowed = {"Vendor punch", "RI punch", "Yard punch"}
    if punch_type not in allowed:
        raise HTTPException(400, f"punch_type must be one of {allowed}")

    suffix = Path(file.filename).suffix.lower()
    if suffix not in (".xlsx", ".xls"):
        raise HTTPException(400, "Excel 파일만 가능합니다")

    # templates 폴더에 저장
    tpl_dir = BASE / "data" / "templates"
    tpl_dir.mkdir(exist_ok=True)
    safe_type = punch_type.replace(" ", "_")  # Vendor_punch
    dest = tpl_dir / f"template_{safe_type}{suffix}"
    with open(dest, "wb") as fp:
        shutil.copyfileobj(file.file, fp)

    print(f"[INFO] 템플릿 저장: {punch_type} → {dest.name}")
    return {"ok": True, "punch_type": punch_type, "filename": dest.name}


@app.get("/api/templates")
async def get_templates():
    """등록된 템플릿 목록 반환"""
    tpl_dir = BASE / "data" / "templates"
    result = {}
    for pt in ["Vendor punch", "RI punch", "Yard punch"]:
        safe = pt.replace(" ", "_")
        for ext in [".xlsx", ".xls"]:
            p = tpl_dir / f"template_{safe}{ext}"
            if p.exists():
                result[pt] = p.name
                break
    return result

@app.get("/api/export/punchlist")
async def export_punchlist():
    """
    원본 Excel 기반으로 내보내기:
    - 기존 행: 전체 필드 + 종결정보 업데이트
    - 신규 행(모바일/수동 추가): 원본 마지막 행 아래에 추가
    원본 없으면 project.json 전체로 새 파일 생성
    """
    import io, shutil as _shutil
    from openpyxl.drawing.image import Image as _XLImg
    from PIL import Image as _PIL
    from fastapi.responses import StreamingResponse

    data       = load_data()
    excel_path = data.get("excel_path")
    punches    = sorted(data.get("punches", []),
                        key=lambda p: int(p.get("punch_no",0)) if str(p.get("punch_no","")).isdigit() else 0)

    def cell_val(p, key):
        v = p.get(key, "")
        return v if v is not None else ""

    def embed_photo(ws, pic_url, row_num):
        """사진 URL → 셀에 이미지 삽입"""
        if not pic_url:
            return False
        rel   = [pp for pp in pic_url.replace("\\","/").split("/") if pp]
        fpath = BASE.joinpath(*rel)
        if not fpath.exists():
            return False
        try:
            thumb = _PIL.open(str(fpath)).convert("RGB")
            thumb.thumbnail((300, 220), _PIL.LANCZOS)
            buf = io.BytesIO()
            thumb.save(buf, "JPEG", quality=70)
            buf.seek(0)
            xl_img        = _XLImg(buf)
            xl_img.width  = 180
            xl_img.height = 135
            ws.add_image(xl_img, f"I{row_num}")
            ws.row_dimensions[row_num].height = 105
            return True
        except Exception as e:
            print(f"[WARN] 사진 삽입 실패: {e}")
            return False

    if excel_path and Path(excel_path).exists():
        tmp_out = BASE / "data" / "punchlist_export_tmp.xlsx"
        _shutil.copy2(excel_path, str(tmp_out))

        try:
            wb = openpyxl.load_workbook(str(tmp_out), keep_links=False)
            ws = wb.worksheets[0]

            punch_map = {str(p.get("punch_no","")).strip(): p for p in punches}

            # ── 기존 행 업데이트 ──
            updated_nos = set()
            for row in ws.iter_rows():
                if len(row) < 2:
                    continue
                cell_b = row[1].value
                if cell_b is None:
                    continue
                if isinstance(cell_b, bool):
                    continue
                if isinstance(cell_b, (int, float)):
                    key = str(int(cell_b))
                else:
                    s = str(cell_b).strip()
                    if not s.replace('.','',1).isdigit():
                        continue
                    key = str(int(float(s)))

                p = punch_map.get(key)
                if not p:
                    continue

                row_num = row[0].row
                updated_nos.add(key)

                # 전체 필드 업데이트 (원본 양식 유지, 값만 교체)
                # B=1, C=2, F=5, G=6, H=7, I=8, J=9, K=10, L=11, M=12
                # N=13, O=14, P=15, Q=16, R=17, S=18, T=19, U=20, V=21, W=22
                col_map = {
                    2:  cell_val(p, "equipment_no"),
                    5:  cell_val(p, "drawing_no"),
                    6:  cell_val(p, "punch_description"),
                    9:  cell_val(p, "old_category"),
                    10: cell_val(p, "punch_category"),
                    11: cell_val(p, "discipline"),
                    12: cell_val(p, "proposed_corrective_action"),
                    13: cell_val(p, "material_required"),
                    14: cell_val(p, "eng_physical"),
                    15: cell_val(p, "punch_issue_date"),
                    16: cell_val(p, "punch_raised_by"),
                    17: cell_val(p, "punch_raised_entity"),
                    18: cell_val(p, "close_plan_date"),
                    19: cell_val(p, "punch_closed_date"),
                    20: cell_val(p, "punch_closed_by"),
                    22: cell_val(p, "remarks"),
                    23: cell_val(p, "flag_note"),
                }
                for col_idx, val in col_map.items():
                    if val and col_idx < len(row):
                        row[col_idx].value = val
                    elif val and col_idx >= len(row):
                        ws.cell(row=row_num, column=col_idx+1, value=val)

                # I열(8): 종결 사진 / 근거
                pic_closed_url = p.get("picture_url_closed","")
                if pic_closed_url:
                    if not embed_photo(ws, pic_closed_url, row_num):
                        if len(row) > 8:
                            row[8].value = p.get("picture_closed","")
                else:
                    evidence = p.get("picture_closed","")
                    if evidence and len(row) > 8:
                        row[8].value = evidence

                # H열(7): open 사진
                pic_open_url = p.get("picture_url","")
                if pic_open_url and not ws.cell(row=row_num, column=8).value:
                    embed_photo(ws, pic_open_url, row_num)

            # ── 신규 행 추가 (원본에 없던 펀치) ──
            new_punches = [p for p in punches if str(p.get("punch_no","")).strip() not in updated_nos]
            if new_punches:
                last_row = ws.max_row + 1
                print(f"[INFO] 신규 펀치 {len(new_punches)}건 Excel {last_row}행부터 추가")
                for p in new_punches:
                    col_data = {
                        1:  cell_val(p, "punch_no"),          # B
                        2:  cell_val(p, "equipment_no"),       # C
                        5:  cell_val(p, "drawing_no"),         # F
                        6:  cell_val(p, "punch_description"),  # G
                        8:  "Y" if p.get("picture_url") else cell_val(p, "picture_open"),  # H
                        9:  cell_val(p, "old_category"),       # J
                        10: cell_val(p, "punch_category"),     # K
                        11: cell_val(p, "discipline"),         # L
                        12: cell_val(p, "proposed_corrective_action"),  # M
                        13: cell_val(p, "material_required"),  # N
                        14: cell_val(p, "eng_physical"),       # O
                        15: cell_val(p, "punch_issue_date"),   # P
                        16: cell_val(p, "punch_raised_by"),    # Q
                        17: cell_val(p, "punch_raised_entity"),# R
                        18: cell_val(p, "close_plan_date"),    # S
                        19: cell_val(p, "punch_closed_date"),  # T
                        20: cell_val(p, "punch_closed_by"),    # U
                        22: cell_val(p, "remarks"),            # W
                        23: cell_val(p, "flag_note"),           # X
                    }
                    for col_idx, val in col_data.items():
                        ws.cell(row=last_row, column=col_idx, value=val)

                    # 오픈 사진 삽입
                    if not embed_photo(ws, p.get("picture_url",""), last_row):
                        pass  # 이미 H열에 "Y" 기입됨

                    # 종결 사진 삽입
                    if not embed_photo(ws, p.get("picture_url_closed",""), last_row):
                        evidence = p.get("picture_closed","")
                        if evidence:
                            ws.cell(row=last_row, column=9, value=evidence)

                    last_row += 1

            wb.save(str(tmp_out))
            buf = io.BytesIO(tmp_out.read_bytes())
            return StreamingResponse(
                buf,
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": "attachment; filename=punchlist_updated.xlsx"}
            )
        except Exception as e:
            print(f"[WARN] Excel 업데이트 실패: {e}")
            import traceback; traceback.print_exc()
            buf = io.BytesIO(Path(excel_path).read_bytes())
            return StreamingResponse(
                buf,
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": "attachment; filename=punchlist_updated.xlsx"}
            )

    # 원본 없으면 project.json 기반 신규 생성
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Punch List"

    hdr_fill = PatternFill("solid", fgColor="1F4E79")
    hdr_font = Font(bold=True, color="FFFFFF", size=10)
    thin = Side(style="thin", color="CCCCCC")
    brd  = Border(left=thin, right=thin, top=thin, bottom=thin)
    ctr  = Alignment(horizontal="center", vertical="center", wrap_text=True)
    lft  = Alignment(horizontal="left",   vertical="center", wrap_text=True)

    headers = ["No.", "Equipment No.", "Drawing No.", "Punch Description",
               "Pic(Open)", "Pic(Closed)", "Category", "Discipline",
               "Corrective Action", "Material Req.", "Vendor Req.",
               "Issue Date", "Raised By", "Raised Entity",
               "Closed Date", "Closed By", "Remarks",
               "Closed Date(R)", "Closed By(S)"]

    for ci, h in enumerate(headers, 1):
        c = ws.cell(row=1, column=ci, value=h)
        c.font = hdr_font; c.fill = hdr_fill
        c.alignment = ctr; c.border = brd
        ws.column_dimensions[get_column_letter(ci)].width = 16
    ws.row_dimensions[1].height = 22

    for ri, p in enumerate(punches, 2):
        vals = [
            p.get("punch_no",""),         p.get("equipment_no",""),
            p.get("drawing_no",""),       p.get("punch_description",""),
            p.get("picture_open",""),     p.get("picture_closed",""),
            p.get("punch_category",""),   p.get("discipline",""),
            p.get("proposed_corrective_action",""),
            p.get("material_required",""), p.get("vendor_required",""),
            p.get("punch_issue_date",""), p.get("punch_raised_by",""),
            p.get("punch_raised_entity",""), p.get("punch_closed_date",""),
            p.get("punch_closed_by",""),  p.get("remarks",""),
            p.get("punch_closed_date",""), p.get("punch_closed_by",""),
        ]
        for ci, val in enumerate(vals, 1):
            c = ws.cell(row=ri, column=ci, value=val)
            c.alignment = lft if ci == 4 else ctr
            c.border = brd
        ws.row_dimensions[ri].height = 18

    buf = io.BytesIO()
    wb.save(buf); buf.seek(0)
    from fastapi.responses import StreamingResponse
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=punchlist_updated.xlsx"}
    )


@app.post("/api/points/import")
async def import_points(body: dict):
    """
    포인트 JSON을 서버에 병합 저장 (JSON 불러오기용).
    같은 펀치 번호가 이미 있으면 updated_at이 더 최신인 쪽만 적용
    (여러 검사원의 변경분 JSON을 순서 상관없이 병합 가능).
    """
    data    = load_data()
    pts     = body.get("points", {})
    count   = 0
    skipped = 0
    for no, pt in pts.items():
        if pt and pt.get("page_id") and pt.get("x") is not None:
            existing    = data["points"].get(str(no))
            new_updated = pt.get("updated_at")
            if existing and existing.get("updated_at") and new_updated and existing["updated_at"] >= new_updated:
                skipped += 1
                continue
            data["points"][str(no)] = {
                "page_id":    pt["page_id"],
                "page_type":  pt.get("page_type", ""),
                "x":          pt["x"],
                "y":          pt["y"],
                "updated_at": new_updated or datetime.now().isoformat(),
            }
            count += 1
    save_data(data)
    print(f"[INFO] import_points: {count}개 저장, {skipped}개 건너뜀(기존이 최신), points={list(data['points'].keys())}")
    # 스냅샷 자동 업데이트
    snap_name = data.get("snapshot_name")
    if snap_name:
        try: _save_snapshot(snap_name, data)
        except Exception: pass
    return {"ok": True, "count": count, "skipped": skipped}

@app.get("/api/mail/clarification/{punch_no}")
async def send_clarification_mail(punch_no: str):
    """
    선택한 펀치의 내용을 아웃룩 새 메일 작성 창으로 전달
    win32com으로 아웃룩 직접 제어 (서버 PC에 아웃룩 설치 필요)
    """
    try:
        import win32com.client as win32
    except ImportError:
        raise HTTPException(500, "win32com 미설치: pip install pywin32")

    data    = load_data()
    punches = data.get("punches", [])
    points  = data.get("points",  {})

    p = next((x for x in punches if str(x["punch_no"]) == str(punch_no)), None)
    if not p:
        raise HTTPException(404, f"펀치 No.{punch_no} 없음")

    pt        = points.get(str(punch_no))
    all_pages = []
    for f in data.get("drawings", []):
        all_pages.append({**f, "type":"drawing"})
    for f in data.get("pids", []):
        all_pages.append({**f, "type":"pid"})
    pg = next((x for x in all_pages if pt and x["id"] == pt.get("page_id")), None)

    # ── 도면 마크업 이미지 생성 (깃발 1개만 강조) ──
    from PIL import Image as PILImage, ImageDraw, ImageFont
    import base64, tempfile, os

    markup_path = None
    if pg and pt:
        url   = pg.get("url","")
        rel   = [pp for pp in url.replace("\\","/").split("/") if pp]
        fpath = BASE.joinpath(*rel)
        if fpath.exists():
            try:
                img  = PILImage.open(str(fpath)).convert("RGB")
                # 메일 첨부용 축소 (가로 1600px)
                ratio = 1600 / img.width
                img   = img.resize((1600, int(img.height*ratio)), PILImage.LANCZOS)
                draw  = ImageDraw.Draw(img)
                sx, sy = int(pt["x"]*ratio), int(pt["y"]*ratio)
                # 깃발 (빨간색 강조)
                pole_top = sy - 75
                draw.line([(sx,pole_top),(sx,sy)], fill=(60,60,60), width=4)
                draw.polygon([(sx,pole_top),(sx+65,pole_top+18),(sx,pole_top+36)],
                             fill=(226,75,74), outline=(163,45,45))
                # 번호
                try:
                    font = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 20)
                except Exception:
                    font = ImageFont.load_default()
                draw.text((sx+32, pole_top+18), str(punch_no),
                          fill=(255,255,255), font=font, anchor="mm")
                # 원형 강조
                r = 60
                draw.ellipse([(sx-r,sy-r),(sx+r,sy+r)],
                             outline=(226,75,74), width=4)
                tmp = tempfile.NamedTemporaryFile(
                    suffix=".jpg", delete=False,
                    prefix=f"Location_Information_No{punch_no}_",
                    dir=tempfile.gettempdir())
                img.save(tmp.name, "JPEG", quality=85)
                markup_path = tmp.name
            except Exception as e:
                print(f"[WARN] 마크업 이미지 생성 실패: {e}")

    # ── 펀치 사진 첨부 ──
    pic_path = None
    pic_url  = p.get("picture_url","")
    if pic_url:
        pic_rel  = [pp for pp in pic_url.replace("\\","/").split("/") if pp]
        pic_file = BASE.joinpath(*pic_rel)
        if pic_file.exists():
            pic_path = str(pic_file)

    # ── 메일 본문 HTML ──
    page_label = pg.get("label","—") if pg else "—"
    zone_info  = ""
    if pt:
        import math
        img_obj = None
        if pg:
            url2  = pg.get("url","")
            rel2  = [pp for pp in url2.replace("\\","/").split("/") if pp]
            fp2   = BASE.joinpath(*rel2)
            if fp2.exists():
                try:
                    with PILImage.open(str(fp2)) as im2:
                        iw, ih = im2.size
                    cx,cy = iw/2, ih/2
                    dx,dy = pt["x"]-cx, pt["y"]-cy
                    angle = math.degrees(math.atan2(dx,-dy))%360
                    hour  = int(angle/30) or 12
                    dist  = int(math.hypot(dx,dy)/math.hypot(cx,cy)*100)
                    zone_info = f"약 {hour}시 방향, 중심에서 {dist}%"
                except Exception:
                    pass

    # ── Drawing 페이지 번호 표현: "Drawing 7page" ──
    if pg:
        import re as _re
        num_match = _re.search(r'\d+', pg.get("label",""))
        pg_num    = num_match.group() if num_match else "?"
        pg_type   = "P&ID" if pg.get("type","") == "pid" else "Drawing"
        drawing_label = f"{pg_type} {pg_num}page"
    else:
        drawing_label = "—"

    body_html = f"""
<html><body style="font-family:Arial,sans-serif;font-size:13px;color:#222">
<h2 style="color:#1a5fa8;border-bottom:2px solid #1a5fa8;padding-bottom:6px">
  Punch Clarification Request — No.{p['punch_no']}
</h2>
<table style="border-collapse:collapse;width:100%;max-width:700px">
  <tr style="background:#f0f4fa">
    <td style="padding:7px 12px;font-weight:bold;width:160px">Equipment No.</td>
    <td style="padding:7px 12px">{p.get('equipment_no','—')}</td>
  </tr>
  <tr>
    <td style="padding:7px 12px;font-weight:bold">Drawing</td>
    <td style="padding:7px 12px">{drawing_label}</td>
  </tr>
  <tr style="background:#f0f4fa">
    <td style="padding:7px 12px;font-weight:bold">Punch No.</td>
    <td style="padding:7px 12px"><b>No.{p['punch_no']}</b></td>
  </tr>
  <tr>
    <td style="padding:7px 12px;font-weight:bold">Description</td>
    <td style="padding:7px 12px">{p.get('punch_description','—')}</td>
  </tr>
  <tr style="background:#f0f4fa">
    <td style="padding:7px 12px;font-weight:bold">Issue Date</td>
    <td style="padding:7px 12px">{p.get('punch_issue_date','—')}</td>
  </tr>
  <tr>
    <td style="padding:7px 12px;font-weight:bold">Raised By</td>
    <td style="padding:7px 12px">{p.get('punch_raised_by','—')}</td>
  </tr>
  <tr style="background:#f0f4fa">
    <td style="padding:7px 12px;font-weight:bold">Raised Entity</td>
    <td style="padding:7px 12px">{p.get('punch_raised_entity','—')}</td>
  </tr>
</table>
<br>
<p style="background:#fff8e1;border-left:4px solid #f5a623;padding:10px 14px;margin:0">
  <b>Please clarify the above punch item and provide your response at the earliest.</b>
</p>
<br>
<p style="color:#888;font-size:11px">
  * Drawing markup, punch photo, and punch list are attached.<br>
  * This email is generated from Punch Manager system.
</p>
</body></html>"""

    # ── 펀치 단일 행 Excel 생성 (헤더 + 해당 펀치 1행 + 사진) ──
    import tempfile
    import openpyxl as _openpyxl
    from openpyxl.styles import Font as _Font, Alignment as _Align, PatternFill as _Fill, Border as _Border, Side as _Side
    from openpyxl.drawing.image import Image as _XLImg
    from openpyxl.utils import get_column_letter as _gcl
    import io as _io

    excel_path = None
    try:
        wb2 = _openpyxl.Workbook()
        ws2 = wb2.active
        ws2.title = "Punch Clarification"

        hdr_fill   = _Fill("solid", fgColor="1F4E79")
        hdr_font   = _Font(bold=True, color="FFFFFF", size=11)
        thin       = _Side(style="thin", color="CCCCCC")
        brd        = _Border(left=thin, right=thin, top=thin, bottom=thin)
        ctr        = _Align(horizontal="center", vertical="center", wrap_text=True)
        lft        = _Align(horizontal="left",   vertical="center", wrap_text=True)

        headers    = ["No.", "Equipment No.", "Drawing No.", "Punch Description",
                      "Pic(Open)", "Pic(Closed)", "Category", "Discipline",
                      "Corrective Action", "Material Req.", "Vendor Req.",
                      "Issue Date", "Raised By", "Raised Entity",
                      "Closed Date", "Closed By", "Remarks", "Photo"]
        col_widths = [8, 18, 20, 45, 10, 10, 12, 12, 25, 12, 12, 13, 22, 16, 13, 16, 20, 22]

        for ci, (h, w) in enumerate(zip(headers, col_widths), 1):
            cell = ws2.cell(row=1, column=ci, value=h)
            cell.font = hdr_font; cell.fill = hdr_fill
            cell.alignment = ctr; cell.border = brd
            ws2.column_dimensions[_gcl(ci)].width = w
        ws2.row_dimensions[1].height = 22

        # 데이터 행
        row_vals = [
            p.get("punch_no",""),       p.get("equipment_no",""),
            p.get("drawing_no",""),     p.get("punch_description",""),
            p.get("picture_open",""),   p.get("picture_closed",""),
            p.get("punch_category",""), p.get("discipline",""),
            p.get("proposed_corrective_action",""),
            p.get("material_required",""), p.get("vendor_required",""),
            p.get("punch_issue_date",""), p.get("punch_raised_by",""),
            p.get("punch_raised_entity",""), p.get("punch_closed_date",""),
            p.get("punch_closed_by",""),    p.get("remarks",""),
        ]
        for ci, val in enumerate(row_vals, 1):
            cell = ws2.cell(row=2, column=ci, value=val)
            cell.alignment = lft if ci == 4 else ctr
            cell.border = brd

        # 사진 삽입 (18번 열)
        row_h = 30
        if pic_path and os.path.exists(pic_path):
            try:
                from PIL import Image as _PIL2
                thumb = _PIL2.open(pic_path).convert("RGB")
                thumb.thumbnail((200,150), _PIL2.LANCZOS)
                t_buf = _io.BytesIO()
                thumb.save(t_buf, "JPEG", quality=60)
                t_buf.seek(0)
                xl_img = _XLImg(t_buf)
                xl_img.width = 120; xl_img.height = 90
                ws2.add_image(xl_img, f"{_gcl(18)}2")
                row_h = 70
            except Exception:
                ws2.cell(row=2, column=18, value="사진 없음").alignment = ctr
        else:
            ws2.cell(row=2, column=18, value="—").alignment = ctr
        ws2.cell(row=2, column=18).border = brd
        ws2.row_dimensions[2].height = row_h

        tmp_xl = tempfile.NamedTemporaryFile(
            suffix=".xlsx", delete=False,
            prefix=f"Punch_List_for_No{punch_no}_",
            dir=tempfile.gettempdir())
        wb2.save(tmp_xl.name)
        excel_path = tmp_xl.name
    except Exception as e:
        print(f"[WARN] 펀치 Excel 생성 실패: {e}")

    # ── 아웃룩 메일 작성 창 열기 ──
    try:
        outlook = win32.Dispatch("Outlook.Application")
        mail    = outlook.CreateItem(0)
        mail.Subject  = f"[Punch Clarification] No.{p['punch_no']} — {p.get('equipment_no','')}"
        mail.HTMLBody = body_html

        # 첨부: 도면 마크업
        if markup_path and os.path.exists(markup_path):
            mail.Attachments.Add(markup_path)
        # 첨부: 펀치 사진 (파일명 지정 복사본)
        pic_attach_path = None
        if pic_path and os.path.exists(pic_path):
            import shutil as _shutil
            pic_ext = Path(pic_path).suffix or ".jpg"
            pic_attach_path = os.path.join(
                tempfile.gettempdir(),
                f"Picture_for_Punch_No{p['punch_no']}{pic_ext}")
            _shutil.copy2(pic_path, pic_attach_path)
            mail.Attachments.Add(pic_attach_path)
        # 첨부: 펀치 단일 행 Excel
        if excel_path and os.path.exists(excel_path):
            mail.Attachments.Add(excel_path)

        mail.Display(False)

        # 임시 파일 정리 (약간 지연 후 삭제 — 아웃룩이 읽을 시간 확보)
        import threading
        def cleanup():
            import time; time.sleep(5)
            for f in [markup_path, excel_path, pic_attach_path]:
                if f and os.path.exists(f):
                    try: os.unlink(f)
                    except Exception: pass
        threading.Thread(target=cleanup, daemon=True).start()

        return {"ok": True, "message": "메일 작성 창이 열렸습니다"}
    except Exception as e:
        raise HTTPException(500, f"아웃룩 오류: {e}")


@app.get("/api/export/inspector")
async def export_inspector():
    """
    Open 펀치 깃발을 도면에 렌더링한 JPEG + 레지스터 Excel을
    서버 exports/ 폴더에 저장하고 저장 결과를 반환
    """
    import io
    from PIL import Image as PILImage, ImageDraw, ImageFont
    import openpyxl
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.drawing.image import Image as XLImage
    from openpyxl.utils import get_column_letter

    data    = load_data()
    punches = data.get("punches", [])
    points  = data.get("points",  {})

    # exports 폴더 생성
    export_dir = BASE / "exports"
    export_dir.mkdir(exist_ok=True)
    # 기존 파일 정리
    for f in export_dir.glob("*"):
        f.unlink(missing_ok=True)

    # Open 펀치만 필터
    punch_map = {str(p["punch_no"]): p for p in punches}
    open_nos  = {str(p["punch_no"]) for p in punches if p.get("status","open") == "open"}
    open_pts  = {no: pt for no, pt in points.items()
                 if no in open_nos and pt.get("page_id")}

    if not open_pts:
        raise HTTPException(404, "내보낼 Open 펀치 포인트가 없습니다")

    # 페이지별 포인트 그룹핑
    page_pts = {}
    for no, pt in open_pts.items():
        pid = pt["page_id"]
        page_pts.setdefault(pid, []).append((no, pt))

    all_pages = []
    for f in data.get("drawings", []):
        all_pages.append({**f, "type": "drawing"})
    for f in data.get("pids", []):
        all_pages.append({**f, "type": "pid"})

    # ── 폰트 로드 (영문 전용 — 한글 폰트 없는 환경 대응) ──
    import os, glob as _glob
    def load_font(size):
        candidates = [
            # Windows
            "C:/Windows/Fonts/arialbd.ttf",
            "C:/Windows/Fonts/arial.ttf",
            "C:/Windows/Fonts/calibrib.ttf",
            "C:/Windows/Fonts/calibri.ttf",
            "C:/Windows/Fonts/segoeui.ttf",
            # Linux
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
        ]
        # Windows 폰트 폴더 자동 탐색
        win_font_dir = os.environ.get("WINDIR","C:/Windows") + "/Fonts/"
        for pat in ["arialbd.ttf","arial.ttf","calibrib.ttf","verdanab.ttf"]:
            candidates.insert(0, win_font_dir + pat)

        for path in candidates:
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                pass
        return ImageFont.load_default()

    # ── 깃발 그리기 (4800px 기준) ──
    def draw_flag(draw, x, y, no):
        pole_top = y - 180
        draw.line([(x, pole_top), (x, y)], fill=(60, 60, 60), width=10)
        tri = [(x, pole_top), (x+160, pole_top+45), (x, pole_top+90)]
        draw.polygon(tri, fill=(55, 138, 221), outline=(24, 95, 165))
        font = load_font(52)
        text = str(no)
        cx, cy = x + 80, pole_top + 45
        bbox = draw.textbbox((0,0), text, font=font)
        tw, th = bbox[2]-bbox[0], bbox[3]-bbox[1]
        for dx, dy in [(-2,0),(2,0),(0,-2),(0,2)]:
            draw.text((cx-tw//2+dx, cy-th//2+dy), text, fill=(0,0,0,180), font=font)
        draw.text((cx-tw//2, cy-th//2), text, fill=(255,255,255), font=font)

    # ── 우측 상단 도면 제목 박스 ──
    def label_to_eng(label: str) -> str:
        """
        한글 라벨 → 영문 라벨 변환 (한글 폰트 없는 환경 대응)
        예: "도면 3" → "DWG-3", "P&ID 5" → "PID-5"
        """
        import re
        num = re.search(r"\d+", label)
        n   = num.group() if num else "?"
        lo  = label.lower()
        if "p&id" in lo or "pid" in lo:
            return f"PID-{n}"
        return f"DWG-{n}"

    def draw_title(img, draw, label):
        """
        이미지 우측 상단에 도면 제목 박스 렌더링
        박스 폭: 이미지 폭의 1/6
        폰트: 이전 대비 1.5배 크게
        """
        img_w, img_h = img.size
        box_w  = img_w // 6
        margin = img_w // 60
        text   = label_to_eng(label)   # 영문 변환

        # 폰트 크기: 박스 폭의 1/3 (기존 1/5의 1.5배)
        font_size = max(90, box_w // 3)
        font = load_font(font_size)
        bbox = draw.textbbox((0,0), text, font=font)
        tw   = bbox[2] - bbox[0]
        th   = bbox[3] - bbox[1]
        # 박스보다 크면 줄이기
        while tw > box_w - 30 and font_size > 40:
            font_size -= 10
            font = load_font(font_size)
            bbox = draw.textbbox((0,0), text, font=font)
            tw   = bbox[2] - bbox[0]
            th   = bbox[3] - bbox[1]

        pad    = font_size // 3
        box_h  = th + pad * 2
        box_x0 = img_w - box_w - margin
        box_y0 = margin
        box_x1 = img_w - margin
        box_y1 = box_y0 + box_h

        # 배경 박스 (진한 파란)
        draw.rectangle([(box_x0, box_y0), (box_x1, box_y1)],
                       fill=(20, 70, 140), outline=(255, 255, 255), width=6)
        # 텍스트 중앙 정렬
        tx = box_x0 + (box_w - tw) // 2
        ty = box_y0 + pad
        # 검은 외곽선 (가독성)
        for dx, dy in [(-3,0),(3,0),(0,-3),(0,3),(-2,-2),(2,2),(-2,2),(2,-2)]:
            draw.text((tx+dx, ty+dy), text, fill=(0,0,0), font=font)
        draw.text((tx, ty), text, fill=(255, 255, 255), font=font)

    # ── 도면 이미지 렌더링 & 저장 ──
    saved_images = []  # [(page_label, file_path)]
    for pg in all_pages:
        pid = pg.get("id","")
        if pid not in page_pts:
            continue
        url   = pg.get("url","")
        rel   = [p for p in url.replace("\\","/").split("/") if p]
        fpath = BASE.joinpath(*rel)
        if not fpath.exists():
            continue

        img  = PILImage.open(str(fpath)).convert("RGB")
        draw = ImageDraw.Draw(img)

        # 깃발 먼저 그리기
        for no, pt in sorted(page_pts[pid],
                              key=lambda x: int(x[0]) if x[0].isdigit() else 0):
            draw_flag(draw, int(pt["x"]), int(pt["y"]), no)

        # 우측 상단 도면 제목 박스
        page_label = pg.get("label", pid)
        draw_title(img, draw, page_label)

        label    = page_label.replace(" ","_").replace("/","_")
        out_path = export_dir / f"{label}.jpg"
        img.save(str(out_path), "JPEG", quality=90, optimize=True)
        saved_images.append((page_label, out_path))

    # ── 위치 계산 함수 ──
    import math

    def get_position_info(x, y, img_w, img_h):
        """
        도면 좌표 → 9분할 구역 + 시계 방향 + 중심 거리(%) 반환
        """
        cx, cy = img_w / 2, img_h / 2
        dx, dy = x - cx, y - cy

        # 1. 9분할 구역
        col = 0 if x < img_w/3 else (1 if x < img_w*2/3 else 2)
        row_z = 0 if y < img_h/3 else (1 if y < img_h*2/3 else 2)
        zone_map = {
            (0,0):"Top-Left",    (1,0):"Top-Center",    (2,0):"Top-Right",
            (0,1):"Mid-Left",    (1,1):"Center",         (2,1):"Mid-Right",
            (0,2):"Bottom-Left", (1,2):"Bottom-Center",  (2,2):"Bottom-Right",
        }
        zone = zone_map.get((col, row_z), "Center")

        # 2. 시계 방향 (12시=정상단, 시계방향)
        # atan2: y축이 아래로 증가하므로 dy 부호 반전
        angle_deg = math.degrees(math.atan2(dx, -dy)) % 360
        hour = angle_deg / 30  # 360도 / 12시간 = 30도/시간
        hour_int = int(hour) if int(hour) > 0 else 12
        if hour_int == 0:
            hour_int = 12
        clock = f"~{hour_int}시"

        # 3. 중심 거리 (%)
        max_dist = math.hypot(img_w/2, img_h/2)
        dist     = math.hypot(dx, dy)
        dist_pct = int(dist / max_dist * 100)

        return zone, clock, dist_pct

    # ── 레지스터 Excel 생성 ──
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Punch Register"

    # 스타일
    hdr_fill  = PatternFill("solid", fgColor="1F4E79")
    hdr_font  = Font(bold=True, color="FFFFFF", size=11)
    thin      = Side(style="thin", color="CCCCCC")
    border    = Border(left=thin, right=thin, top=thin, bottom=thin)
    center    = Alignment(horizontal="center", vertical="center", wrap_text=True)
    left      = Alignment(horizontal="left",   vertical="center", wrap_text=True)

    # 헤더 (위치 정보 3컬럼 추가)
    headers    = ["No.", "DWG", "Zone(9-Grid)",
                  "Clock Dir.", "Dist.%",
                  "Tag No.", "Punch Description", "Issue Date", "Raised By", "Photo"]
    col_widths = [8, 14, 14, 10, 10, 18, 45, 13, 20, 22]

    for ci, (h, w) in enumerate(zip(headers, col_widths), 1):
        cell = ws.cell(row=1, column=ci, value=h)
        cell.font      = hdr_font
        cell.fill      = hdr_fill
        cell.alignment = center
        cell.border    = border
        ws.column_dimensions[get_column_letter(ci)].width = w
    ws.row_dimensions[1].height = 30

    # 페이지 라벨 & 이미지 크기 조회
    page_label_map = {pg.get("id",""): pg.get("label","") for pg in all_pages}

    # 이미지 실제 크기 캐시 (page_id → (w, h))
    page_size_cache = {}
    for pg in all_pages:
        pid = pg.get("id","")
        url = pg.get("url","")
        rel = [p for p in url.replace("\\","/").split("/") if p]
        fp  = BASE.joinpath(*rel)
        if fp.exists():
            try:
                with PILImage.open(str(fp)) as im:
                    page_size_cache[pid] = im.size
            except Exception:
                pass

    # 데이터 행
    data_row = 2
    sorted_pts = sorted(open_pts.items(),
                        key=lambda x: int(x[0]) if x[0].isdigit() else 0)

    for no, pt in sorted_pts:
        p       = punch_map.get(str(no), {})
        pid     = pt.get("page_id","")
        p_label = page_label_map.get(pid, pid)
        eng_lbl = label_to_eng(p_label)

        # 위치 정보 계산
        img_w, img_h = page_size_cache.get(pid, (4800, 3394))
        zone, clock, dist_pct = get_position_info(
            int(pt.get("x", img_w//2)),
            int(pt.get("y", img_h//2)),
            img_w, img_h
        )

        # 위치 요약 셀 색상 (구역별)
        zone_colors = {
            "Top-Left":"DEEAF1",    "Top-Center":"BDD7EE",    "Top-Right":"9DC3E6",
            "Mid-Left":"D6E4BC",    "Center":    "FFFF99",     "Mid-Right":"FFE699",
            "Bottom-Left":"FCE4D6", "Bottom-Center":"F4B183",  "Bottom-Right":"FF7C80",
        }
        zone_fill = PatternFill("solid", fgColor=zone_colors.get(zone,"FFFFFF"))

        def sc(col_i, val, align=center):
            c = ws.cell(row=data_row, column=col_i, value=val)
            c.alignment = align
            c.border    = border
            return c

        sc(1,  f"No.{no}")
        sc(2,  eng_lbl)
        c3 = sc(3, zone)
        c3.fill = zone_fill
        sc(4,  clock)
        sc(5,  f"{dist_pct}%")
        sc(6,  p.get("equipment_no",""))
        sc(7,  p.get("punch_description",""), left)
        sc(8,  p.get("punch_issue_date",""))
        sc(9,  p.get("punch_raised_by",""))

        # 사진 embed
        pic_url  = p.get("picture_url","")
        row_h    = 30
        if pic_url:
            pic_rel  = [pp for pp in pic_url.replace("\\","/").split("/") if pp]
            pic_path = BASE.joinpath(*pic_rel)
            if pic_path.exists():
                try:
                    thumb = PILImage.open(str(pic_path)).convert("RGB")
                    thumb.thumbnail((200, 150), PILImage.LANCZOS)
                    t_buf = io.BytesIO()
                    thumb.save(t_buf, "JPEG", quality=50)
                    t_buf.seek(0)
                    xl_img  = XLImage(t_buf)
                    xl_img.width  = 120
                    xl_img.height = 90
                    ws.add_image(xl_img, f"{get_column_letter(10)}{data_row}")
                    row_h = 70
                except Exception:
                    sc(10, "사진 오류")
            else:
                sc(10, "파일 없음")
        else:
            sc(10, "—")

        ws.row_dimensions[data_row].height = row_h
        data_row += 1

    # 레지스터 저장
    reg_path = export_dir / "punch_register.xlsx"
    wb.save(str(reg_path))

    # 결과 반환
    files = [f.name for f in export_dir.iterdir() if f.is_file()]
    return {
        "ok":       True,
        "folder":   str(export_dir),
        "files":    sorted(files),
        "exported": len(saved_images),
        "punches":  len(sorted_pts),
    }


MOBILE_TEMPLATE = '<!DOCTYPE html>\n<html lang="ko">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">\n<title>Punch Point Map</title>\n<style>\n*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}\nhtml,body{width:100%;height:100%;overflow:hidden;background:#222;font-family:system-ui,sans-serif;color:#f0f0f0}\n#app{display:flex;flex-direction:column;height:100vh;height:100dvh}\n\n/* 세로모드 안내 */\n#rotate-msg{display:none;position:fixed;inset:0;background:#111;z-index:999;\n  flex-direction:column;align-items:center;justify-content:center;gap:16px;color:#aaa}\n#rotate-msg p{font-size:14px}\n@media(orientation:portrait){#rotate-msg{display:flex}#app{display:none}}\n@media(orientation:landscape){#rotate-msg{display:none}#app{display:flex}}\n\n/* 상단 바 */\n#topbar{background:#111;padding:6px 12px;flex-shrink:0;display:flex;align-items:center;\n  gap:8px;border-bottom:1px solid #333;min-height:40px}\n#topbar h1{font-size:12px;font-weight:500;color:#ddd;white-space:nowrap}\n#topbar small{font-size:10px;color:#555;margin-left:4px}\n#fit-btn{margin-left:auto;font-size:11px;padding:4px 10px;border-radius:6px;\n  border:1px solid #444;background:#1e1e1e;color:#ccc;cursor:pointer;flex-shrink:0;\n  -webkit-appearance:none;appearance:none}\n\n/* 번호 버튼 바 */\n#num-bar{background:#111;padding:5px 8px;flex-shrink:0;overflow-x:auto;white-space:nowrap;\n  border-bottom:1px solid #2a2a2a;scrollbar-width:none;min-height:48px;\n  display:flex;align-items:center;gap:4px;touch-action:pan-x}\n#num-bar::-webkit-scrollbar{display:none}\n.num-btn{display:inline-flex;align-items:center;justify-content:center;\n  min-width:40px;height:40px;border-radius:8px;border:1.5px solid #3a3a3a;\n  background:#1a1a1a;color:#bbb;font-size:13px;font-weight:700;\n  cursor:pointer;flex-shrink:0;padding:0 6px;\n  -webkit-appearance:none;appearance:none;\n  user-select:none;-webkit-user-select:none}\n.num-btn.active{background:#378ADD;border-color:#378ADD;color:#fff}\n.num-btn.other{border-color:#252525;color:#3a3a3a}\n.num-btn.closed-btn{border-color:#444;color:#666}\n\n/* 탭 바 */\n#tab-bar{background:#0e0e0e;display:flex;padding:0 6px;border-bottom:1px solid #2a2a2a;\n  flex-shrink:0;overflow-x:auto;scrollbar-width:none;min-height:34px;touch-action:pan-x}\n#tab-bar::-webkit-scrollbar{display:none}\n.ptab{font-size:11px;padding:7px 12px;color:#555;border-bottom:2px solid transparent;\n  white-space:nowrap;cursor:pointer;flex-shrink:0;user-select:none;-webkit-user-select:none}\n.ptab.active{color:#378ADD;border-bottom-color:#378ADD}\n\n/* 펀치 정보 바 */\n#info-bar{background:#1a2a3a;border-bottom:1px solid #2a3a4a;flex-shrink:0;\n  padding:5px 12px;display:none;align-items:center;gap:8px;min-height:36px}\n#info-bar.show{display:flex}\n#info-no{font-size:12px;font-weight:700;color:#378ADD;white-space:nowrap;flex-shrink:0}\n#info-desc{font-size:11px;color:#b0c4d8;overflow:hidden;white-space:nowrap;\n  text-overflow:ellipsis;flex:1}\n#info-status{font-size:10px;padding:2px 7px;border-radius:999px;white-space:nowrap;flex-shrink:0}\n.st-open{background:#1a3a5a;color:#6abaff}\n.st-closed{background:#2a2a2a;color:#888}\n#info-close{font-size:16px;color:#555;cursor:pointer;flex-shrink:0;\n  padding:0 6px;line-height:1;user-select:none;-webkit-user-select:none}\n\n/* 캔버스 */\n#canvas-wrap{flex:1;overflow:hidden;position:relative;background:#2a2a2a;touch-action:none}\n#canvas-inner{position:absolute;top:0;left:0;transform-origin:0 0;will-change:transform}\n#canvas-doc{position:relative;line-height:0}\n#canvas-doc img{display:block;max-width:none;pointer-events:none}\n\n/* 깃발 — canvas-doc 기준 */\n.flag-marker{position:absolute;transform:translate(-9px,-66px);z-index:10;\n  pointer-events:all;cursor:pointer;user-select:none;-webkit-user-select:none}\n\n/* 툴팁 */\n#tooltip{position:absolute;bottom:12px;left:50%;transform:translateX(-50%);\n  background:rgba(0,0,0,0.9);color:#f0f0f0;font-size:11px;padding:6px 14px;\n  border-radius:8px;pointer-events:none;opacity:0;transition:opacity 0.2s;z-index:30;\n  white-space:nowrap;max-width:90vw;overflow:hidden;text-overflow:ellipsis;border:1px solid #444}\n#tooltip.show{opacity:1}\n</style>\n</head>\n<body>\n\n<div id="rotate-msg">\n  <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="1.5">\n    <rect x="4" y="2" width="16" height="20" rx="2"/>\n    <path d="M9 21h6"/>\n  </svg>\n  <p>가로 방향으로 돌려주세요</p>\n</div>\n\n<div id="app">\n  <div id="topbar">\n    <div><h1>Punch Point Map</h1><small id="summary"></small></div>\n    <button id="fit-btn">&#8862; 맞춤</button>\n  </div>\n  <div id="num-bar"></div>\n  <div id="tab-bar"></div>\n  <div id="info-bar">\n    <span id="info-no"></span>\n    <span id="info-desc"></span>\n    <span id="info-status"></span>\n    <span id="info-close">&#x2715;</span>\n  </div>\n  <div id="canvas-wrap">\n    <div id="canvas-inner"><div id="canvas-doc"></div></div>\n    <div id="tooltip"></div>\n  </div>\n</div>\n\n<script>\nvar PAGES      = __PAGES__;\nvar POINTS     = __POINTS__;\nvar DESCS      = __DESCS__;\nvar URIS       = __URIS__;\nvar STATUS_MAP = __STATUS_MAP__;\n\nvar curIdx=0, activeNo=null, scale=1, tx=0, ty=0;\nvar dragging=false, dragStart=null, pinchDist=null, tipTimer=null;\n\nvar wrap   = document.getElementById(\'canvas-wrap\');\nvar inner  = document.getElementById(\'canvas-inner\');\nvar cdoc   = document.getElementById(\'canvas-doc\');\nvar tip    = document.getElementById(\'tooltip\');\nvar numBar = document.getElementById(\'num-bar\');\nvar tabBar = document.getElementById(\'tab-bar\');\nvar infoBar= document.getElementById(\'info-bar\');\n\nfunction curPage(){ return PAGES[curIdx]||null; }\nfunction applyT(){ inner.style.transform=\'translate(\'+tx+\'px,\'+ty+\'px) scale(\'+scale+\')\'; }\n\nfunction resetView(){\n  var pg=curPage(); if(!pg) return;\n  var wr=wrap.getBoundingClientRect();\n  scale=Math.min(wr.width/pg.nat_w, wr.height/pg.nat_h)*0.96;\n  tx=(wr.width-pg.nat_w*scale)/2;\n  ty=(wr.height-pg.nat_h*scale)/2;\n  applyT();\n}\n\n// ── 탭 렌더 ──\nfunction renderTabs(){\n  tabBar.innerHTML=\'\';\n  PAGES.forEach(function(p,i){\n    var d=document.createElement(\'div\');\n    d.className=\'ptab\'+(i===curIdx?\' active\':\'\');\n    d.textContent=p.label;\n    d.addEventListener(\'touchend\', function(e){\n      e.preventDefault();\n      goPage(i);\n    });\n    d.addEventListener(\'click\', function(){ goPage(i); });\n    tabBar.appendChild(d);\n  });\n}\n\n// ── 번호 버튼 렌더 ──\nfunction renderNums(){\n  numBar.innerHTML=\'\';\n  var nos=Object.keys(POINTS).sort(function(a,b){return Number(a)-Number(b);});\n  nos.forEach(function(no){\n    var pt=POINTS[no];\n    var pg=curPage();\n    var here=pg&&pt.page_id===pg.id;\n    var closed=STATUS_MAP[no]===\'closed\';\n    var btn=document.createElement(\'div\');\n    btn.className=\'num-btn\'+(no==activeNo?\' active\':\'\')+(here?\'\':(closed?\' closed-btn\':\' other\'));\n    btn.textContent=no;\n    // touchend + click 둘 다 등록 (로컬 파일 호환)\n    btn.addEventListener(\'touchend\', function(e){\n      e.preventDefault();\n      e.stopPropagation();\n      selectNo(no);\n    });\n    btn.addEventListener(\'click\', function(e){\n      e.stopPropagation();\n      selectNo(no);\n    });\n    numBar.appendChild(btn);\n  });\n  // 활성 버튼 스크롤\n  if(activeNo){\n    var active=numBar.querySelector(\'.num-btn.active\');\n    if(active) active.scrollIntoView({behavior:\'smooth\',block:\'nearest\',inline:\'center\'});\n  }\n}\n\n// ── 깃발 렌더 ──\nfunction renderFlags(){\n  cdoc.querySelectorAll(\'.flag-marker\').forEach(function(m){m.remove();});\n  var pg=curPage(); if(!pg) return;\n  Object.keys(POINTS).forEach(function(no){\n    var pt=POINTS[no];\n    if(pt.page_id!==pg.id) return;\n    var status=STATUS_MAP[no]||\'open\';\n    var m=document.createElement(\'div\');\n    m.className=\'flag-marker\';\n    m.style.left=pt.x+\'px\';\n    m.style.top=pt.y+\'px\';\n    m.innerHTML=flagSVG(no, no==activeNo, status);\n    m.addEventListener(\'touchend\',function(e){\n      e.preventDefault();\n      e.stopPropagation();\n      selectNo(no);\n    });\n    m.addEventListener(\'click\',function(e){\n      e.stopPropagation();\n      selectNo(no);\n    });\n    cdoc.appendChild(m);\n  });\n}\n\nfunction flagSVG(no, active, status){\n  var fc=active?\'#0C447C\':(status===\'closed\'?\'#888780\':\'#378ADD\');\n  var sc=active?\'#06284D\':(status===\'closed\'?\'#5F5E5A\':\'#185FA5\');\n  return \'<svg width="64" height="68" viewBox="0 0 64 68" xmlns="http://www.w3.org/2000/svg">\'\n    +\'<line x1="9" y1="2" x2="9" y2="66" stroke="#888" stroke-width="2.5" stroke-linecap="round"/>\'\n    +\'<polygon points="9,3 52,19 9,35" fill="\'+fc+\'" stroke="\'+sc+\'" stroke-width="1.2"/>\'\n    +\'<text x="30" y="21" text-anchor="middle" dominant-baseline="central"\'\n    +\' font-size="13" font-weight="700" fill="#fff" font-family="system-ui,sans-serif">\'+no+\'</text>\'\n    +\'</svg>\';\n}\n\n// ── 페이지 로드 ──\nfunction loadPage(onReady){\n  var pg=curPage();\n  cdoc.querySelectorAll(\'.flag-marker\').forEach(function(m){m.remove();});\n  if(!pg){cdoc.innerHTML=\'\';return;}\n  cdoc.style.width=pg.nat_w+\'px\';\n  cdoc.style.height=pg.nat_h+\'px\';\n  cdoc.innerHTML=\'<div style="width:\'+pg.nat_w+\'px;height:\'+pg.nat_h+\'px;display:flex;align-items:center;justify-content:center;color:#666;font-size:13px">로딩 중...</div>\';\n  var img=new Image();\n  img.onload=function(){\n    cdoc.innerHTML=\'\';\n    img.style.cssText=\'display:block;width:\'+pg.nat_w+\'px;height:\'+pg.nat_h+\'px;pointer-events:none\';\n    cdoc.appendChild(img);\n    renderFlags();\n    if(onReady) onReady();\n    else resetView();\n  };\n  img.onerror=function(){\n    cdoc.innerHTML=\'<div style="color:#c00;font-size:14px;padding:20px">이미지 로드 실패</div>\';\n  };\n  img.src=URIS[pg.id];\n}\n\nfunction goPage(idx){\n  curIdx=idx; renderTabs(); renderNums(); loadPage();\n}\n\n// ── 번호 선택 ──\nfunction selectNo(no){\n  activeNo=(activeNo==no)?null:no;\n  if(activeNo){\n    var pt=POINTS[String(activeNo)];\n    if(pt){\n      var pgIdx=-1;\n      for(var i=0;i<PAGES.length;i++){if(PAGES[i].id===pt.page_id){pgIdx=i;break;}}\n      if(pgIdx>=0&&pgIdx!==curIdx){\n        curIdx=pgIdx; renderTabs(); renderNums();\n        loadPage(function(){centerOn(pt.x,pt.y);renderFlags();showInfo(activeNo);});\n        return;\n      }\n      centerOn(pt.x,pt.y);\n    }\n    showInfo(activeNo);\n  } else {\n    clearInfo();\n  }\n  renderFlags();\n  renderNums();\n}\n\nfunction centerOn(px,py){\n  var wr=wrap.getBoundingClientRect();\n  tx=wr.width/2-px*scale; ty=wr.height/2-py*scale; applyT();\n}\n\n// ── 정보 바 ──\nfunction showInfo(no){\n  var desc=DESCS[String(no)]||\'\';\n  var status=STATUS_MAP[String(no)]||\'open\';\n  document.getElementById(\'info-no\').textContent=\'No.\'+no;\n  document.getElementById(\'info-desc\').textContent=desc||\'(내용 없음)\';\n  var st=document.getElementById(\'info-status\');\n  st.textContent=status===\'closed\'?\'Closed\':\'Open\';\n  st.className=status===\'closed\'?\'st-closed\':\'st-open\';\n  infoBar.classList.add(\'show\');\n}\nfunction clearInfo(){\n  activeNo=null;\n  infoBar.classList.remove(\'show\');\n  renderFlags(); renderNums();\n}\n\n// ── 터치 (캔버스만 touch-action:none) ──\nwrap.addEventListener(\'touchstart\',function(e){\n  e.preventDefault();\n  if(e.touches.length===1){\n    dragging=true; pinchDist=null;\n    dragStart={x:e.touches[0].clientX-tx, y:e.touches[0].clientY-ty};\n  } else if(e.touches.length===2){\n    dragging=false;\n    pinchDist=Math.hypot(\n      e.touches[0].clientX-e.touches[1].clientX,\n      e.touches[0].clientY-e.touches[1].clientY);\n  }\n},{passive:false});\n\nwrap.addEventListener(\'touchmove\',function(e){\n  e.preventDefault();\n  if(e.touches.length===1&&dragging){\n    tx=e.touches[0].clientX-dragStart.x;\n    ty=e.touches[0].clientY-dragStart.y;\n    applyT();\n  } else if(e.touches.length===2&&pinchDist){\n    var d=Math.hypot(\n      e.touches[0].clientX-e.touches[1].clientX,\n      e.touches[0].clientY-e.touches[1].clientY);\n    var r=wrap.getBoundingClientRect();\n    var mx=(e.touches[0].clientX+e.touches[1].clientX)/2-r.left;\n    var my=(e.touches[0].clientY+e.touches[1].clientY)/2-r.top;\n    var ns=Math.min(10,Math.max(0.05,scale*d/pinchDist));\n    tx=mx-(mx-tx)*(ns/scale); ty=my-(my-ty)*(ns/scale);\n    scale=ns; pinchDist=d; applyT();\n  }\n},{passive:false});\n\nwrap.addEventListener(\'touchend\',function(e){\n  dragging=false;\n  if(e.touches.length<2) pinchDist=null;\n});\n\n// 마우스 (PC 호환)\nwrap.addEventListener(\'mousedown\',function(e){dragging=true;dragStart={x:e.clientX-tx,y:e.clientY-ty};});\nwrap.addEventListener(\'mousemove\',function(e){if(!dragging)return;tx=e.clientX-dragStart.x;ty=e.clientY-dragStart.y;applyT();});\nwrap.addEventListener(\'mouseup\',function(){dragging=false;});\nwrap.addEventListener(\'mouseleave\',function(){dragging=false;});\nwrap.addEventListener(\'wheel\',function(e){\n  e.preventDefault();\n  var r=wrap.getBoundingClientRect();\n  var mx=e.clientX-r.left, my=e.clientY-r.top;\n  var ns=Math.min(10,Math.max(0.05,scale*(e.deltaY<0?1.15:0.87)));\n  tx=mx-(mx-tx)*(ns/scale); ty=my-(my-ty)*(ns/scale); scale=ns; applyT();\n},{passive:false});\n\n// 버튼 이벤트 (addEventListener — 로컬파일 보안 우회)\ndocument.getElementById(\'fit-btn\').addEventListener(\'touchend\',function(e){e.preventDefault();resetView();});\ndocument.getElementById(\'fit-btn\').addEventListener(\'click\',function(){resetView();});\ndocument.getElementById(\'info-close\').addEventListener(\'touchend\',function(e){e.preventDefault();clearInfo();});\ndocument.getElementById(\'info-close\').addEventListener(\'click\',function(){clearInfo();});\n\n// 초기화\ndocument.getElementById(\'summary\').textContent=\n  PAGES.length+\'페이지 · \'+Object.keys(POINTS).length+\'개 포인트\';\nrenderTabs();\nrenderNums();\nloadPage();\n</script>\n</body>\n</html>'


# ── 모바일 전용 HTML 생성 (이미지 base64 embed, 오프라인 동작) ────
async def generate_mobile_html(data: dict) -> str:
    import base64 as _b64, json as _json

    punches = data.get("punches", [])
    points  = data.get("points",  {})

    used_page_ids = {v["page_id"] for v in points.values() if v.get("page_id")}

    all_pages = []
    for idx, f in enumerate(data.get("drawings", [])):
        all_pages.append({**f, "type": "drawing",
                          "label": f.get("label") or f"도면 {idx+1}"})
    for idx, f in enumerate(data.get("pids", [])):
        all_pages.append({**f, "type": "pid",
                          "label": f.get("label") or f"P&ID {idx+1}"})

    pages_embedded = []
    print(f"[DEBUG] used_page_ids: {used_page_ids}")
    print(f"[DEBUG] all_pages count: {len(all_pages)}")
    for pg in all_pages:
        pid = pg.get("id", "")
        print(f"[DEBUG] checking page id={pid!r}, url={pg.get('url','')!r}")
        if pid not in used_page_ids:
            print(f"[DEBUG]   -> skip (no points)")
            continue
        url   = pg.get("url", "")
        # Windows/Linux 모두 안전하게 경로 조합
        # url 예: /uploads/drawings/abc_p1.png
        rel_parts = [p for p in url.replace("\\", "/").split("/") if p]
        fpath = BASE.joinpath(*rel_parts)
        print(f"[DEBUG]   -> fpath: {fpath}, exists: {fpath.exists()}")
        if not fpath.exists():
            # uploads 폴더 직접 탐색 시도
            fname = Path(url).name
            for candidate in [
                UPLOADS_DRW / fname,
                UPLOADS_PID / fname,
                UPLOADS / "drawings" / fname,
                UPLOADS / "pids" / fname,
            ]:
                if candidate.exists():
                    fpath = candidate
                    print(f"[DEBUG]   -> found at: {fpath}")
                    break
            else:
                print(f"[WARN] 파일을 찾을 수 없음: {url}")
                continue
        # 픽셀 크기 — Pillow
        try:
            from PIL import Image as _PIL
            with _PIL.open(str(fpath)) as im:
                nat_w, nat_h = im.size
            print(f"[DEBUG]   -> size: {nat_w}x{nat_h}")
        except Exception as e:
            print(f"[WARN] 이미지 크기 읽기 실패: {e}")
            nat_w, nat_h = 4800, 3394
        # base64 embed
        file_size = fpath.stat().st_size
        print(f"[DEBUG]   -> file size: {file_size/1024:.1f} KB, embedding...")
        ext_lower = fpath.suffix.lower()
        mime      = "image/jpeg" if ext_lower in (".jpg", ".jpeg") else "image/png"
        b64       = _b64.b64encode(fpath.read_bytes()).decode("ascii")
        data_uri  = f"data:{mime};base64,{b64}"
        print(f"[DEBUG]   -> data_uri length: {len(data_uri)} chars")
        pages_embedded.append({
            "id": pid, "label": pg["label"], "type": pg["type"],
            "nat_w": nat_w, "nat_h": nat_h, "data_uri": data_uri,
        })
    print(f"[DEBUG] pages_embedded count: {len(pages_embedded)}")

    punch_desc  = {str(p["punch_no"]): p.get("punch_description","") for p in punches}
    pages_json  = _json.dumps([{k:v for k,v in p.items() if k!="data_uri"}
                                for p in pages_embedded], ensure_ascii=False)
    points_json = _json.dumps(points,     ensure_ascii=False)
    desc_json   = _json.dumps(punch_desc, ensure_ascii=False)
    uris_json   = _json.dumps({p["id"]: p["data_uri"] for p in pages_embedded},
                               ensure_ascii=False)

    status_map  = {str(p["punch_no"]): p.get("status","open") for p in punches}
    status_json = _json.dumps(status_map, ensure_ascii=False)

    html = MOBILE_TEMPLATE
    html = html.replace("__PAGES__",      pages_json)
    html = html.replace("__POINTS__",     points_json)
    html = html.replace("__DESCS__",      desc_json)
    html = html.replace("__URIS__",       uris_json)
    html = html.replace("__STATUS_MAP__", status_json)
    return html
