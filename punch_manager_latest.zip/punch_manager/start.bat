@echo off
cd /d "%~dp0"
echo.
echo ================================
echo   Punch Manager
echo ================================
echo.
start "" "http://localhost:8000"
python -m uvicorn main:app --host 0.0.0.0 --port 8000
pause
