"""Copilot 이 조회할 조인트 자료 — 블록별로 나누고, 색인으로 찾아간다.

현업이 원본 엑셀을 통째로 올려 조회했더니 너무 느렸다. 나누는 것 자체는
쉬운데, **나누기만 하면 오히려 느려진다** — 조회를 블록으로 시작하지 않기
때문이다. 실측(TRION):

    도면번호   358개 중  82개(23%)가 블록 여럿에 걸쳐 있다
    Joint No 6,778개 중 3,111개(46%)

색인이 없으면 「이 도면번호」 한 건에 66개 파일을 전부 열게 된다.
"""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import pytest
from openpyxl import Workbook

from backend.services import joint_export as J, verifier as V


def _qmg(path: Path, rows: list[dict]) -> Path:
    """QMG 최소 형태 — 데이터는 6행부터."""
    wb = Workbook()
    ws = wb.active
    for _ in range(5):
        ws.append([])
    for r in rows:
        line = [None] * 80
        line[V.Col.DRAWING_NO - 1] = r.get("dwg", "")
        line[V.Col.BLOCK - 1]      = r.get("block", "")
        line[V.Col.LOT - 1]        = r.get("lot", "")
        line[V.Col.JOINT_NO - 1]   = r.get("joint", "")
        line[V.Col.THICKNESS1 - 1] = r.get("thk")
        line[V.Col.MATERIAL1 - 1]  = r.get("mat", "")
        line[V.Col.GROOVE - 1]     = r.get("groove", "")
        line[V.Col.WPS_NO - 1]     = r.get("wps", "")      # 있으면 시공분
        line[V.Col.REPAIR_MARK - 1] = r.get("repair", "")  # E열 - 있으면 수리 시공
        if r.get("deleted"):
            line[V.Col.DELETE_STATUS - 1] = "삭제"
        ws.append(line)
    wb.save(path)
    return path


def _read(d: Path, name: str) -> dict:
    """색인 파일(순수 JSON)을 읽는다."""
    return json.loads((d / name).read_text(encoding="utf-8"))


def _rows(d: Path, name: str) -> list[tuple[str, dict]]:
    """블록 파일을 읽는다 — **한 덩어리 JSON 이 아니다.**

    한 줄이 «열쇠 + 빈칸 + 자료 JSON» 이고 줄 사이에 빈 줄이 있다.
    받는 쪽(Copilot)이 글자로 찾기 때문이다. (열쇠, 자료) 로 돌려준다.
    """
    out = []
    for ln in (d / name).read_text(encoding="utf-8").splitlines():
        if not ln or ln.startswith("#"):
            continue
        key, _, blob = ln.partition(" ")
        out.append((key, json.loads(blob)))
    return out


@pytest.fixture
def built(tmp_path):
    src = _qmg(tmp_path / "qmg.xlsx", [
        {"dwg": "D-1", "block": "B1", "lot": "L1", "joint": "J1",
         "thk": 12, "mat": "ASTM A36", "groove": "SB", "wps": "TR-FC-G01"},
        # 같은 Joint No 가 다른 블록에도 있다 - 실데이터의 46% 가 이렇다
        {"dwg": "D-1", "block": "B2", "lot": "L1", "joint": "J1",
         "thk": 20, "mat": "ASTM A36", "groove": "SV", "wps": "TR-FC-G02"},
        # WPS 가 비었다 = 작업 예정 물량
        {"dwg": "D-2", "block": "B2", "lot": "L2", "joint": "J9",
         "thk": 9, "mat": "NV-A36", "groove": "FL"},
    ])
    info = J.build(src, tmp_path / "out", today=date(2026, 9, 18))
    return info, Path(info["dir"])


# ── 나누기 ─────────────────────────────────────────────────────────────────
def test_the_block_file_is_key_line_then_json_line(built):
    """받는 쪽이 글자로 찾는다 — **한 덩어리 JSON 으로 두면 못 집는다.**

    블록 파일은 찾고도 그 안에서 행을 못 집었다(2026-09-18). 열쇠를 제 줄에
    그대로 두고, 바로 다음 줄에 자료를, 사이에 빈 줄을 둔다.
    """
    _info, d = built
    lines = (d / "B2.txt").read_text(encoding="utf-8").splitlines()
    assert lines[0].startswith("# block: B2")
    body = lines[lines.index("") + 1:]            # 머리말 다음부터
    assert body[0].startswith("B2/L1/J1 {"), body[0][:40]
    assert body[1] == "", "레코드 사이에 빈 줄 한 줄"
    assert body[2].startswith("B2/L2/J9 {"), body[2][:40]
    assert len(body) == 3, "끝에 군더더기가 없어야 한다"


def test_the_json_after_the_key_parses_on_its_own(built):
    """받는 쪽이 줄의 첫 `{` 부터 떼어 읽으면 되도록."""
    _info, d = built
    got = _rows(d, "B1.txt")
    assert len(got) == 1
    assert got[0][0] == "B1/L1/J1" and got[0][1]["joint_no"] == "J1"


def test_the_files_are_utf8_without_bom(built):
    """받는 쪽이 UTF-8 로 읽는다. BOM 이 붙으면 첫 줄이 깨진다."""
    _info, d = built
    for f in d.iterdir():
        raw = f.read_bytes()
        assert not raw.startswith(b"\xef\xbb\xbf"), f.name
        raw.decode("utf-8")                       # 디코딩이 되어야 한다


def test_one_file_per_block_plus_two_indexes(built):
    info, d = built
    assert info["blocks"] == 2
    names = {f.name for f in d.iterdir()}
    assert names == {"B1.txt", "B2.txt", J.INDEX_NAME, J.JOINT_INDEX_NAME}
    assert info["files"] == 4


def test_a_deleted_row_is_not_offered_for_lookup(tmp_path):
    """삭제 행을 담으면 **없는 물량을 조회하게 된다.**"""
    src = _qmg(tmp_path / "q.xlsx", [
        {"dwg": "D-1", "block": "B1", "joint": "J1", "wps": "W"},
        {"dwg": "D-1", "block": "B1", "joint": "J2", "deleted": True},
    ])
    info = J.build(src, tmp_path / "out")
    assert info["rows"] == 1 and info["deleted_excluded"] == 1


# ── 색인 ───────────────────────────────────────────────────────────────────
def test_the_lookup_key_is_findable_as_one_literal_string(built):
    """Block·Lot·Joint No 가 따로 있으면 받는 쪽이 못 찾는다.

    실제로 블록 파일은 찾았는데 그 안에서 행을 못 집었다 —
    「CV261/FR01/1P02T」 라는 문자열이 파일에 아예 없었기 때문이다.
    세 값을 이어 **한 문자열**로 줄 맨 앞에 둔다.
    """
    _info, d = built
    raw = (d / "B1.txt").read_text(encoding="utf-8")
    assert "\nB1/L1/J1 {" in raw, "열쇠가 줄 맨 앞에 그대로 있어야 한다"
    key, _rec = _rows(d, "B1.txt")[0]
    assert key == "B1/L1/J1"


def test_the_key_is_not_repeated_inside_the_json(built):
    """열쇠는 줄 앞에 있다 — JSON 안에 또 두면 무게만 는다."""
    _info, d = built
    _key, rec = _rows(d, "B1.txt")[0]
    assert "lookup_key" not in rec, list(rec)[:4]


def test_the_lookup_key_starts_with_the_file_name(built):
    """앞자리가 곧 블록 이름이자 파일 이름이다 — 열쇠만 보고 파일을 안다."""
    _info, d = built
    for name in ("B1", "B2"):
        for key, _rec in _rows(d, f"{name}.txt"):
            assert key.split("/")[0] == name, key


def test_the_index_names_the_lookup_key_as_the_search_key(built):
    """색인이 «무엇으로 찾는가» 를 말해야 한다 — 안 그러면 세 값을 따로 맞추려 든다."""
    _info, d = built
    idx = _read(d, J.INDEX_NAME)
    assert idx["search_keys"] == ["lookup_key"]
    assert idx["search_key_parts"] == ["block", "lot", "joint_no"]
    how = " ".join(idx["how_to_use"])
    assert "그대로 찾아라" in how and "따로 맞추려 들면 못 찾는다" in how
    assert "첫 `{` 부터 읽어라" in how, "새 형식을 말해야 한다"
    assert "그대로 보여 줘라" in how, "추천 문구를 그대로 전하라고 해야 한다"


def test_the_index_says_which_block_file_to_open(built):
    """조회 열쇠는 **Block · Lot · Joint No** 셋이다(현업 확인 2026-09-18).

    블록은 파일 이름이 곧 답이고, 나머지 둘은 블록을 가로지르므로 색인이
    필요하다 — 없으면 Lot 하나에 파일을 전부 열게 된다.
    """
    _info, d = built
    idx = _read(d, J.INDEX_NAME)
    assert idx["by_lot"]["L1"] == ["B1", "B2"], "블록 둘에 걸친 Lot"
    assert idx["by_lot"]["L2"] == ["B2"]
    assert {b["block"] for b in idx["blocks"]} == {"B1", "B2"}
    assert "by_drawing" not in idx, "도면번호로는 조회하지 않는다"


def test_the_drawing_number_is_reference_only(built):
    """열쇠는 아니지만 **참고 값으로는 남긴다.**

    (Block, Lot, Joint No) 셋이 유일하지 않다 — 실측 30,871개 조합 중
    522개(1.7%)에 행이 여럿 걸리고, 457개는 도면번호로만 갈린다(한 조합에
    최대 13행). 빼면 그 522건에서 여러 줄이 똑같아 보여 고를 수가 없다.

    **«참고 값»이라는 것을 받는 쪽에 말해 줘야 한다** — 안 그러면 그것으로
    찾으려 든다(색인에 없으니 파일을 전부 열게 된다).
    """
    _info, d = built
    assert _rows(d, "B1.txt")[0][1]["drawing_no"] == "D-1"

    idx = _read(d, J.INDEX_NAME)
    roles = {c["key"]: c.get("role") for c in idx["columns"] if c.get("role")}
    assert roles == {"lookup_key": "search_key",
                     "block": "search_key", "lot": "search_key",
                     "joint_no": "search_key", "drawing_no": "reference"}
    how = " ".join(idx["how_to_use"])
    assert "조회 열쇠가 아니다" in how and "참고 값" in how


def test_the_joint_index_is_a_separate_file(built):
    """Joint No 색인 하나가 색인 무게의 대부분이다(실측 345KB 중 295KB).

    도면번호·Lot·블록으로 찾는 흔한 경우까지 그 무게를 지면 나눈 뜻이 없다.
    """
    _info, d = built
    idx = _read(d, J.INDEX_NAME)
    assert "by_joint" not in idx, "무거운 색인은 본 색인에 두지 않는다"
    assert idx["joint_index_file"] == J.JOINT_INDEX_NAME, "어디 있는지는 말해야 한다"
    jidx = _read(d, J.JOINT_INDEX_NAME)
    assert jidx["by_joint"]["J1"] == ["B1", "B2"]


def test_the_index_tells_the_agent_to_use_it_first(built):
    """지시가 없으면 받는 쪽이 파일을 전부 연다 — 나눈 것이 되레 손해가 된다."""
    _info, d = built
    how = " ".join(_read(d, J.INDEX_NAME)["how_to_use"])
    assert "먼저" in how and "색인" in how
    assert "planned" in how, "작업 예정 물량을 어떻게 거르는지 말해야 한다"


# ── 실적은 담지 않는다 ─────────────────────────────────────────────────────
def test_the_actual_wps_is_never_exported(built):
    """실제로 쓴 WPS 를 주면 에이전트가 그 답을 그대로 베낀다.

    **계획 단계 조인트에는 그 값이 없다** — 추천이 「맞는 것처럼 보이지만
    쓸모없어」진다(현업 목적 2026-09-18). `planned` 한 칸만 둔다.
    """
    _info, d = built
    blob = (d / "B1.txt").read_text(encoding="utf-8")
    assert "TR-FC-G01" not in blob, "실제 쓴 WPS 가 새어 나갔다"
    rec = _rows(d, "B1.txt")[0][1]
    assert rec["planned"] is False
    assert not any(k.startswith("wps") for k in rec), rec


def test_planned_rows_are_marked(built):
    """「작업 예정 물량을 보여 달라」가 이 값으로 걸러진다."""
    info, d = built
    assert info["planned"] == 1
    b2 = [r for _k, r in _rows(d, "B2.txt")]
    assert [r["planned"] for r in b2] == [False, True]


# ── 날짜 폴더 ──────────────────────────────────────────────────────────────
def test_a_second_run_on_the_same_day_makes_a_new_folder(tmp_path):
    """덮어쓰면 **블록이 줄어든 회차에서 옛 파일이 남는다** — 사라진 물량이
    그대로 조회되고, 오류도 경고도 나지 않는다."""
    src = _qmg(tmp_path / "q.xlsx", [{"dwg": "D", "block": "B1", "joint": "J"}])
    out = tmp_path / "out"
    a = J.build(src, out, today=date(2026, 9, 18))
    b = J.build(src, out, today=date(2026, 9, 18))
    assert a["name"] == "2026-09-18" and b["name"] == "2026-09-18_2"
    assert Path(a["dir"]).is_dir() and Path(b["dir"]).is_dir()


def test_latest_reports_what_the_screen_must_show(tmp_path):
    """버튼을 눌러야만 갱신되므로 «언제 만든 것인지»가 화면에 늘 보여야 한다."""
    out = tmp_path / "out"
    assert J.latest(out) is None
    src = _qmg(tmp_path / "q.xlsx", [{"dwg": "D", "block": "B1", "joint": "J"}])
    J.build(src, out, today=date(2026, 9, 18))
    got = J.latest(out)
    assert got["name"] == "2026-09-18"
    assert got["generated_at"] and got["source"] == "q.xlsx"
    assert got["rows"] == 1 and got["blocks"] == 1


def test_a_block_name_that_is_not_a_legal_filename(tmp_path):
    """실데이터 66개는 전부 안전했지만 `Q530-SMR/ITER생산부` 같은 값이 다른
    열에 실재한다 — 블록에 나타나면 파일 생성이 통째로 실패한다."""
    src = _qmg(tmp_path / "q.xlsx", [{"dwg": "D", "block": "A/B:1", "joint": "J"}])
    info = J.build(src, tmp_path / "out")
    d = Path(info["dir"])
    assert info["blocks"] == 1
    idx = _read(d, J.INDEX_NAME)
    entry = idx["blocks"][0]
    assert entry["block"] == "A/B:1", "원래 이름은 색인에 그대로 남는다"
    assert (d / entry["file"]).is_file()


# ── 쓸 만한 WPS 추천 ───────────────────────────────────────────────────────
#
# **점수를 지어내지 않는다.** 같은 조건의 과거 시공분이 무엇을 골랐는지 센다.
# 가중치를 사람이 정하면 그럴듯한 오답이 된다.
_WPS = {
    "RU-FC-G01": {"process": "FCAW", "joint_detail": "SB, SV", "position": "All",
                  "materials": [{"base_metal": "ASTM A36", "thk_range": "6~40"}]},
    "RU-FC-G02": {"process": "FCAW", "joint_detail": "SB, SV", "position": "All",
                  "materials": [{"base_metal": "ASTM A36", "thk_range": "6~40"}]},
    "RU-FC-G03": {"process": "FCAW", "joint_detail": "SB, SV", "position": "All",
                  "materials": [{"base_metal": "ASTM A36", "thk_range": "6~40"}]},
}


def _mk(lot: str, joint: str, thk: int, wps: str = "", **kw) -> dict:
    return dict({"dwg": "D", "block": "B1", "lot": lot, "joint": joint,
                 "thk": thk, "mat": "ASTM A36", "groove": "SB", "wps": wps}, **kw)


def _rec(tmp_path, rows: list[dict], name: str = "q.xlsx"):
    src = _qmg(tmp_path / name, rows)
    info = J.build(src, tmp_path / ("out_" + name), wps_table=_WPS)
    return info, {k: v.get("rec") for k, v in _rows(Path(info["dir"]), "B1.txt")}


def test_the_ranking_comes_from_what_was_actually_used(tmp_path):
    """같은 조건의 시공분이 고른 것을 센다 — 많이 쓴 순서다."""
    info, rec = _rec(tmp_path, [
        *[_mk("L", f"A{i}", 12, "RU-FC-G01") for i in range(7)],
        *[_mk("L", f"B{i}", 12, "RU-FC-G02") for i in range(3)],
        _mk("L", "P1", 12),                      # 계획 물량 - 여기에 추천이 붙는다
    ])
    got = rec["B1/L/P1"]
    assert [t.split(" —")[0] for t in got] == ["RU-FC-G01", "RU-FC-G02"]
    assert "10건 중 7건(70%)" in got[0], got[0]
    assert "10건 중 3건(30%)" in got[1], got[1]


def test_only_as_many_as_there_is_evidence_for(tmp_path):
    """서명 562개 중 507개는 과거에 쓴 WPS 가 **하나뿐**이었다(실측).

    그 자리에 2개를 채우려면 이력 0건인 WPS 를 넣어야 하는데, 그건
    «써도 된다»이지 «이걸 쓴다»가 아니다(현업 결정 2026-09-21).
    """
    _info, rec = _rec(tmp_path, [
        _mk("L", "A1", 12, "RU-FC-G01"),
        _mk("L", "P1", 12),
    ])
    assert len(rec["B1/L/P1"]) == 1, rec["B1/L/P1"]


def test_at_most_two(tmp_path):
    _info, rec = _rec(tmp_path, [
        *[_mk("L", f"A{i}", 12, "RU-FC-G01") for i in range(3)],
        *[_mk("L", f"B{i}", 12, "RU-FC-G02") for i in range(2)],
        _mk("L", "C1", 12, "RU-FC-G03"),
        _mk("L", "P1", 12),
    ])
    assert len(rec["B1/L/P1"]) == 2


def test_a_wps_the_judgment_would_flag_is_never_recommended(tmp_path):
    """과거에 썼어도 **지금 기준에 안 맞으면 뺀다** — 실수를 되풀이하지 않는다.

    실측(TRION)으로 이력 2,748건이 이렇게 걸러졌다.
    """
    wps = dict(_WPS)
    wps["RU-FC-X01"] = {"process": "FCAW", "joint_detail": "SB",
                        "materials": [{"base_metal": "ASTM A36",
                                       "thk_range": "6~10"}]}   # 12mm 는 범위 밖
    src = _qmg(tmp_path / "q.xlsx", [
        *[_mk("L", f"A{i}", 12, "RU-FC-X01") for i in range(9)],   # 과거엔 이걸 썼다
        _mk("L", "B1", 12, "RU-FC-G01"),
        _mk("L", "P1", 12),
    ])
    info = J.build(src, tmp_path / "out", wps_table=wps)
    got = {k: v.get("rec") for k, v in _rows(Path(info["dir"]), "B1.txt")}["B1/L/P1"]
    assert [t.split(" —")[0] for t in got] == ["RU-FC-G01"], got


def test_a_loose_match_says_it_is_weak(tmp_path):
    """같은 조건이 없으면 두께를 빼고 찾되 **«두께 다름»을 적는다.**

    계획 물량의 24%가 이 자리다(실측). 비워 두면 정작 필요한 곳에서 못 준다.
    """
    _info, rec = _rec(tmp_path, [
        *[_mk("L", f"A{i}", 12, "RU-FC-G01") for i in range(4)],
        _mk("L", "P1", 30),                       # 두께만 다르다
    ])
    got = rec["B1/L/P1"]
    assert got and "두께 다름" in got[0], got


def test_no_basis_leaves_the_field_out(tmp_path):
    """근거가 없으면 칸을 **아예 두지 않는다** — 빈 목록은 «없다»로 읽힌다."""
    _info, rec = _rec(tmp_path, [
        _mk("L", "P1", 12, groove="TKY"),         # 어느 WPS 도 통과 못 한다
    ])
    assert rec["B1/L/P1"] is None


def test_the_reason_carries_the_share_and_the_fit(tmp_path):
    """받는 쪽은 이 문구를 **그대로 보여 주기만** 한다 — 혼자 읽혀야 한다."""
    _info, rec = _rec(tmp_path, [
        *[_mk("L", f"A{i}", 12, "RU-FC-G01") for i in range(4)],
        _mk("L", "P1", 12),
    ])
    t = rec["B1/L/P1"][0]
    assert t.startswith("RU-FC-G01 — ")
    assert "4건 중 4건(100%) 사용" in t          # 얼마나 쓰였나
    assert "두께 6~40mm 허용" in t                # 왜 쓸 수 있나
    assert "Groove SB" in t and "FCAW" in t


def test_the_accuracy_is_measured_on_this_data(tmp_path):
    """**개발 데이터의 수치를 붙이면 거짓말이 된다.** 그 서버 자료로 잰다.

    자기 행을 빼고(leave-one-out) 재야 부풀려지지 않는다.
    """
    info, _out = _rec(tmp_path, [
        *[_mk("L", f"A{i}", 12, "RU-FC-G01") for i in range(8)],
        *[_mk("L", f"B{i}", 12, "RU-FC-G02") for i in range(2)],
    ])
    q = info["recommendation"]
    assert q["measured_on"] == "이 서버의 이 QMG 자료"
    assert q["checked_rows"] == 10
    assert q["top2_accuracy_pct"] == 100.0, q
    assert q["top1_accuracy_pct"] == 80.0, q     # G02 두 행은 1위가 G01 이다
    assert "leave-one-out" in q["note"]


def test_the_index_tells_the_agent_to_echo_not_reason(tmp_path):
    """지시가 없으면 받는 쪽이 자기 지식으로 답한다 — 1번에서 겪은 것과 같다."""
    info, _out = _rec(tmp_path, [
        *[_mk("L", f"A{i}", 12, "RU-FC-G01") for i in range(4)],
        _mk("L", "P1", 12)])
    idx = _read(Path(info["dir"]), J.INDEX_NAME)
    how = " ".join(idx["how_to_use"])
    assert "그대로 보여 줘라" in how
    assert "근거가 있는 만큼만" in how
    assert "두께 다름" in how
    assert idx["recommendation"]["top2_accuracy_pct"] is not None


def test_too_little_data_reports_no_accuracy_rather_than_a_number(tmp_path):
    """대조할 행이 없으면 **수치를 지어내지 않는다.**

    시공분이 한 건뿐이면 자기 행을 뺀 순간 근거가 0이 된다 — 그때 100%라고
    적으면 거짓말이다. `None` 으로 두고 화면이 «잴 수 없음»으로 말한다.
    """
    info, _out = _rec(tmp_path, [_mk("L", "A1", 12, "RU-FC-G01"),
                                 _mk("L", "P1", 12)])
    q = info["recommendation"]
    assert q["checked_rows"] == 0
    assert q["top2_accuracy_pct"] is None and q["top1_accuracy_pct"] is None


# ── qc-data-verifier 가 찾은 것들 (2026-09-21) ─────────────────────────────
def test_project_rules_are_not_stubbed_away(tmp_path, monkeypatch):
    """`chk._rules = []` 로 비워 두면 **프로파일의 프로젝트 규칙이 통째로 꺼진다.**

    시험용 코드를 그대로 옮긴 실수였다. 실측(TRION)으로 `TR-FC-G05` 가
    Check 105(두께 3~25mm)에 걸리는데도 742행에서 후보로 올라왔다 —
    오류도 경고도 없었다.
    """
    from backend.services import rule_catalog
    RULE = [{"key": "thin", "no": "101", "name": "A36 두께", "color": "Blue",
             "kind": "thickness_range",
             "when": {"material_contains": ["ASTM A36"]},
             "param": {"range": "6~20"}, "overrides": [3], "scope": "side"}]
    monkeypatch.setattr(rule_catalog, "active_checks", lambda: RULE)

    src = _qmg(tmp_path / "q.xlsx", [
        *[_mk("L", f"A{i}", 30, "RU-FC-G01") for i in range(4)],   # 30mm
        _mk("L", "P1", 30),
    ])
    info = J.build(src, tmp_path / "out", wps_table=_WPS)
    rec = {k: v.get("rec") for k, v in _rows(Path(info["dir"]), "B1.txt")}
    # 프로젝트 규칙이 살아 있으면 30mm 는 6~20 밖이라 후보가 없다
    assert rec["B1/L/P1"] is None, rec["B1/L/P1"]


def test_wps_dependent_suitability_checks_are_asked(tmp_path):
    """Check 8·9·20 을 안 물으면 후보가 엔진보다 헐거워진다.

    셋 다 서명에 든 열(재질·두께·Groove)만 읽으므로 memo 가 성립한다.
    """
    import inspect
    src = inspect.getsource(J._allowed)
    for fn in ("_c3_thickness", "_c4_groove", "_c11_material_not_allowed",
               "_c24_tky_wps", "_c25_q01_joint_type", "_c27_dissimilar_grade",
               "_c8_tr_fc_g03", "_c9_tr_smfc_g01", "_c20_api_groove_process"):
        assert fn in src, fn


def test_check21_is_not_used_as_a_filter(tmp_path):
    """Check 21 은 «이 WPS 가 맞는가»가 아니라 **«용접재를 둘 적었는가»** 다.

    기록 품질이지 적합성이 아니다. 게다가 **AL 열은 서명에 없어서**, 걸면
    같은 서명인데 답이 달라져 memo 가 틀린 답을 퍼뜨린다(실측 132건).
    """
    import inspect
    assert "_c21_mixed_consumables" not in inspect.getsource(J._allowed)


def test_a_wps_name_with_a_newline_cannot_break_the_format(tmp_path):
    """실데이터에 `TR-FC-G51\\n(Welder Test)` 가 있다.

    그대로 문구에 실리면 «한 줄 = 한 레코드» 형식이 깨져 받는 쪽이 파일을
    통째로 못 읽는다.
    """
    # **기량시험용이 아닌** 줄바꿈 이름으로 본다 — 그쪽은 아예 후보에서 빠진다
    wps = {"RU-FC-G01\n(Rev.8)": _WPS["RU-FC-G01"]}
    src = _qmg(tmp_path / "q.xlsx", [
        *[_mk("L", f"A{i}", 12, "RU-FC-G01\n(Rev.8)") for i in range(3)],
        _mk("L", "P1", 12)])
    info = J.build(src, tmp_path / "out", wps_table=wps)
    body = (Path(info["dir"]) / "B1.txt").read_text(encoding="utf-8")
    for ln in body.splitlines():
        assert ln == "" or ln.startswith("#") or " {" in ln, repr(ln[:60])
    rec = {k: v.get("rec") for k, v in _rows(Path(info["dir"]), "B1.txt")}
    assert "\n" not in rec["B1/L/P1"][0]
    assert rec["B1/L/P1"][0].startswith("RU-FC-G01 (Rev.8) — ")


def test_the_memo_key_covers_everything_the_filter_reads(tmp_path):
    """서명이 같으면 후보도 같아야 memo 가 성립한다.

    안 그러면 **틀린 답을 서명 전체에 퍼뜨린다.** 실측(TRION 32,975행 전수)
    으로 불일치 0행이지만, 검사를 더할 때마다 다시 봐야 한다.
    """
    from backend.services import verifier as VV
    src = _qmg(tmp_path / "q.xlsx", [
        _mk("L", "A1", 12, "RU-FC-G01"),
        _mk("L", "A2", 12, "RU-FC-G02"),
        _mk("L", "B1", 30, "RU-FC-G01"),
    ])
    loader = VV.QCDataLoader()
    loader.load_qmg(src)
    loader.wps_table = dict(_WPS)
    chk = VV.QCChecker(loader)
    seen: dict = {}
    for _rn, row in loader.qmg_rows:
        sig = J._signature(row)
        got = tuple(J._allowed(chk, _WPS, row))
        assert seen.setdefault(sig, got) == got, sig


def test_only_planned_rows_get_a_recommendation(tmp_path):
    """**시공분에는 추천이 붙지 않는다.**

    이미 WPS 가 들어가 있어 추천할 이유가 없다(현업 확인 2026-09-21).
    시공분은 «이력»으로만 쓴다. 덤으로 실적 행에서만 나던 모순도 사라진다
    (Check 21 모순 551건이 전부 시공분이었다).
    """
    _info, rec = _rec(tmp_path, [
        *[_mk("L", f"A{i}", 12, "RU-FC-G01") for i in range(4)],
        _mk("L", "P1", 12),
    ])
    assert rec["B1/L/P1"], "계획 행에는 붙는다"
    for key, got in rec.items():
        if key != "B1/L/P1":
            assert got is None, f"{key}: 시공분에 추천이 붙었다"


def test_recommendation_costs_almost_nothing_now(tmp_path):
    """계획 행에만 붙으므로 파일이 거의 안 커진다.

    실측(TRION 32,975행 중 계획 131행): 8.50 -> 8.53 MB.
    한때 시공분까지 붙여 13.9 MB 였다.
    """
    rows = [*[_mk("L", f"A{i}", 12, "RU-FC-G01") for i in range(20)],
            _mk("L", "P1", 12)]
    src = _qmg(tmp_path / "q.xlsx", rows)
    a = J.build(src, tmp_path / "a", wps_table=_WPS)
    b = J.build(src, tmp_path / "b")
    # **블록 파일**로 잰다 — 색인에는 `recommendation` 설명이 고정비로 들어가
    # 행수와 무관하다. 커지는 것은 추천이 붙은 행 하나뿐이어야 한다.
    big = (Path(a["dir"]) / "B1.txt").stat().st_size
    small = (Path(b["dir"]) / "B1.txt").stat().st_size
    assert big - small < 250, (big, small)
    assert a["bytes"] - b["bytes"] < 1500, "색인 고정비도 한 쪽 분량이어야 한다"


def test_accuracy_is_measured_on_every_worked_row(tmp_path):
    """계획 행과 같은 조건만 재면 **유리한 쪽만 고른 값**이 된다.

    실측으로 그렇게 재면 8,887행에 100%, 시공분 전부를 재면 32,362행에
    98.3% 였다. 낮은 쪽이 정직하다.
    """
    _info, _r = _rec(tmp_path, [
        *[_mk("L", f"A{i}", 12, "RU-FC-G01") for i in range(6)],
        *[_mk("L", f"B{i}", 12, "RU-FC-G02") for i in range(2)],
        # 계획 행과 조건이 겹치지 않는 시공분 — 이것도 대조에 들어가야 한다
        *[_mk("M", f"C{i}", 30, "RU-FC-G01") for i in range(4)],
        _mk("L", "P1", 12),
    ])
    info, _r2 = _rec(tmp_path, [
        *[_mk("L", f"A{i}", 12, "RU-FC-G01") for i in range(6)],
        *[_mk("L", f"B{i}", 12, "RU-FC-G02") for i in range(2)],
        *[_mk("M", f"C{i}", 30, "RU-FC-G01") for i in range(4)],
        _mk("L", "P1", 12),
    ], name="q2.xlsx")
    q = info["recommendation"]
    assert q["checked_rows"] == 12, "시공분 12행 전부를 대조해야 한다"
    assert "시공분 전부" in q["checked_note"]


def test_a_welder_test_wps_is_never_a_candidate(tmp_path):
    """용접사 **기량시험용** WPS 를 생산 조인트에 권하면 안 된다.

    판정 기준(재질·두께·Groove)으로는 보통 WPS 와 구별되지 않아 후보로
    통과한다. TRION 의 `TR-FC-G51\\n(Welder Test)` 가 계획 131행 중 **84행**
    에서 후보였다. 시공 이력이 0건이라 추천되지는 않았지만, 누가 한 번이라도
    그것으로 기록을 남기면 1위로 올라온다.
    """
    wps = dict(_WPS)
    wps["RU-FC-G51\n(Welder Test)"] = _WPS["RU-FC-G01"]
    src = _qmg(tmp_path / "q.xlsx", [
        *[_mk("L", f"A{i}", 12, "RU-FC-G51\n(Welder Test)") for i in range(9)],
        _mk("L", "B1", 12, "RU-FC-G01"),
        _mk("L", "P1", 12),
    ])
    info = J.build(src, tmp_path / "out", wps_table=wps)
    rec = {k: v.get("rec") for k, v in _rows(Path(info["dir"]), "B1.txt")}
    got = rec["B1/L/P1"]
    assert got, "다른 후보는 남아야 한다"
    assert all("Welder Test" not in t for t in got), got
    assert [t.split(" —")[0] for t in got] == ["RU-FC-G01"]


def test_what_was_excluded_is_stated(tmp_path):
    """조용히 빼면 「왜 이 WPS 가 안 나오나」를 되짚을 길이 없다."""
    wps = dict(_WPS)
    wps["RU-FC-G51\n(Welder Test)"] = _WPS["RU-FC-G01"]
    src = _qmg(tmp_path / "q.xlsx", [
        _mk("L", "A1", 12, "RU-FC-G01"), _mk("L", "P1", 12)])
    info = J.build(src, tmp_path / "out", wps_table=wps)
    q = info["recommendation"]
    assert q["excluded_test_wps"] == ["RU-FC-G51 (Welder Test)"]
    how = " ".join(_read(Path(info["dir"]), J.INDEX_NAME)["how_to_use"])
    assert "기량시험용" in how


@pytest.mark.parametrize("name,out", [
    ("RU-FC-G51\n(Welder Test)", True),
    ("TR-FC-G51 (WELDER TEST)", True),
    ("RU-FC-기량시험-01", True),
    ("RU-FC-G01", False),
    ("RU-TEST-G01", False),          # 'TEST' 만으로는 거르지 않는다
])
def test_only_clear_test_markers_are_excluded(name, out):
    """표기를 넓게 잡으면 멀쩡한 WPS 가 조용히 사라진다."""
    assert J._is_test_wps(name) is out
