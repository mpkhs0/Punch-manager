"""내보내는 WPS 근거가 «서버가 실제로 판정하는 것»과 같은가.

WPS 문서에서 읽은 값이 판정의 전부가 아니다. 그 위에 세 층이 더 얹힌다:

    1. WPS 보정 ('WPS 설정' 탭)   특정 WPS×재질을 콕 집은 값. 가장 구체적이다.
    2. 프로젝트 규칙 (101~199)    `when`이 맞으면 공통 Check 3의 자리를 선점한다.
    3. 취사선택                    꺼 둔 항목은 플래그가 **아예 생기지 않는다.**

한동안 이 셋이 내보내기에서 빠져 있었다. 실측(TRION)으로 프로젝트 규칙 5개가
전부 Check 3을 선점하고 있었고, Check 5·7은 꺼져 있었다. 그 상태로 넘기면
받는 쪽이 **문서값만 보고 판단**해서, 서버와 다른 답을 내면서도 그 사실을
알 수 없다 - 「추천대로 썼는데 결함」이 되고 원인을 짚을 길이 없다.
"""
from __future__ import annotations

import pytest

from backend.services import (project_checks, rule_catalog, verifier as V,
                              wps_export, wps_overrides)


@pytest.fixture
def table():
    """WPS 두 종. 문서에서 읽은 원문만 든 최소 형태."""
    return {
        "TR-FC-G01": {"process": "FCAW", "position": "All",
                      "joint_detail": "SB, SV",
                      "materials": [{"base_metal": "ASTM A36", "thk_range": "6~20"}]},
        "TR-SMFC-G01": {"process": "SMFC", "position": "All",
                        "joint_detail": "SB",
                        "materials": [{"base_metal": "ASTM A500", "thk_range": ""}]},
    }


# ── 1. WPS 보정 ────────────────────────────────────────────────────────────
def test_wps_overrides_ride_along(table, monkeypatch):
    """문서의 **빈 칸**을 메운 값이 함께 나가야 한다.

    두께 범위가 비면 판정은 «통과»로 본다(자료가 없으면 결함이 아니다).
    보정을 빼고 내보내면 받는 쪽은 그 WPS를 «두께 제한 없음»으로 읽는다 -
    정반대다.
    """
    monkeypatch.setattr(wps_overrides, "load", lambda: {
        "TR-SMFC-G01": {"materials": [
            {"id": "A500", "match": ["ASTM A500"], "range": "6~20",
             "note": "G열 누락"},
        ]}})
    d = wps_export.build(table)
    w = next(x for x in d["wps"] if x["wps_no"] == "TR-SMFC-G01")
    assert w["overrides"] == [{
        "material_key": "A500", "match": ["ASTM A500"],
        "thickness": [[6.0, 20.0]], "thickness_raw": "6~20", "note": "G열 누락"}]
    other = next(x for x in d["wps"] if x["wps_no"] == "TR-FC-G01")
    assert other["overrides"] == [], "걸리지 않은 WPS에는 붙지 않는다"


def test_an_empty_range_is_not_exported(table, monkeypatch):
    """빈 범위는 «무조건 통과»가 되어 보정으로 고치려던 문제를 그대로 재현한다.

    저장 단계에서 버리는 것과 **같은 처리**여야 한다.
    """
    monkeypatch.setattr(wps_overrides, "load", lambda: {
        "TR-SMFC-G01": {"materials": [{"id": "A500", "range": "", "note": ""}]}})
    d = wps_export.build(table)
    w = next(x for x in d["wps"] if x["wps_no"] == "TR-SMFC-G01")
    assert w["overrides"] == []


def test_overrides_match_across_the_project_prefix(table, monkeypatch):
    """WPS 이름 맨 앞 마디는 «프로젝트 번호»다 - 떼고 맞춘다.

    판정(`wps_overrides.find_material`)이 하는 것과 같은 처리여야 한다.
    통째로 비교하면 프로젝트가 바뀌는 순간 보정이 조용히 전부 죽는다.
    """
    monkeypatch.setattr(wps_overrides, "load", lambda: {
        "RU-SMFC-G01": {"materials": [
            {"id": "A500", "range": "6~20", "note": ""}]}})
    d = wps_export.build(table)
    w = next(x for x in d["wps"] if x["wps_no"] == "TR-SMFC-G01")
    assert w["overrides"], "RU- 키가 TR- WPS에 걸려야 한다"


# ── 2. 프로젝트 규칙 (101~199) ─────────────────────────────────────────────
_RULES = [
    {"key": "kt40", "no": "101", "name": "KT-40 두께", "color": "Blue",
     "kind": "thickness_range", "when": {"material_contains": ["KT-40", "KT40"]},
     "param": {"range": "12~50"}, "overrides": [3], "scope": "side"},
    {"key": "kt", "no": "102", "name": "KT 두께", "color": "Blue",
     "kind": "thickness_range", "when": {"material_contains": ["KT"]},
     "param": {"range": "12~50"}, "overrides": [3], "scope": "side"},
]


def test_project_checks_are_exported_with_what_they_preempt(table, monkeypatch):
    """이 규칙들은 공통 Check 3의 자리를 **선점**한다.

    빼고 내보내면 받는 쪽이 문서의 두께만 보고 «되는 조합»이라고 답한다.
    """
    monkeypatch.setattr(rule_catalog, "active_checks", lambda: _RULES)
    d = wps_export.build(table)
    got = d["project_checks"]
    assert [r["check_no"] for r in got] == ["101", "102"]
    assert got[0]["when"]["material_contains"] == ["KT-40", "KT40"]
    assert got[0]["param"] == {"range": "12~50"}
    assert [str(x) for x in got[0]["preempts"]] == ["3"], \
        "무엇을 선점하는지 말해야 한다"


def test_project_check_order_is_preserved(table, monkeypatch):
    """**순서가 곧 의미다** - 위에서부터 먼저 맞는 것을 쓴다.

    좁은 조건이 앞에 있다(`KT-40`이 `KT`보다 앞). 정렬해서 내보내면
    `S355KT-40`이 'KT-40' 대신 'KT'에 걸리는 식으로 조용히 뒤집힌다.
    """
    monkeypatch.setattr(rule_catalog, "active_checks", lambda: _RULES)
    d = wps_export.build(table)
    assert [r["check_no"] for r in d["project_checks"]] == ["101", "102"]
    assert "순서" in d["project_checks_note"]


# ── 3. 취사선택 ────────────────────────────────────────────────────────────
def test_disabled_checks_are_named(table, monkeypatch):
    """꺼 둔 항목은 플래그가 **아예 생기지 않는다.**

    받는 쪽이 그 규칙을 «지켜야 하는 것»으로 읽으면 서버보다 엄하게 답한다.
    """
    monkeypatch.setattr(rule_catalog, "enabled_map",
                        lambda: {"3": True, "4": False, "11": True})
    d = wps_export.build(table)
    assert d["enabled_checks"]["4"] is False
    assert d["enabled_checks"]["3"] is True


def test_precedence_is_stated(table):
    """같은 (WPS, 재질)에 여러 층이 걸릴 때의 순서를 받는 쪽이 알아야 한다."""
    d = wps_export.build(table)
    assert len(d["precedence"]) == 3
    assert "overrides" in d["precedence"][0]
    assert "project_checks" in d["precedence"][1]
    assert "materials" in d["precedence"][2]


# ── 4. 답의 «형태» — 지시가 없으면 받는 쪽이 제멋대로 답한다 ────────────────
def test_the_answer_contract_comes_before_the_data(table):
    """`answer_contract` 가 **앞쪽**에 있어야 한다.

    실제로 Copilot 이 WPS 이름 대신 `AWS B6 Category` 같은 규격 분류를
    답하는 일이 있었다. 이 파일에 'AWS' 라는 글자는 한 번도 안 나온다 -
    «무엇을 답하라»가 없으니 자기 지식으로 메운 것이다.
    """
    d = wps_export.build(table)
    keys = list(d)
    assert "answer_contract" in keys
    assert keys.index("answer_contract") < keys.index("wps"), \
        "자료보다 앞에 있어야 받는 쪽이 먼저 읽는다"


def test_the_contract_forbids_answering_with_a_spec_category(table):
    """«무엇을 답하지 마라»까지 적어야 한다 — 실제로 그렇게 틀렸다."""
    c = wps_export.build(table)["answer_contract"]
    joined = " ".join(c["must_not"])
    assert "Category" in joined and "AWS" in joined
    assert "지어내지" in joined, "목록에 없는 이름을 만들지 말라고 해야 한다"


def test_several_candidates_are_normal_and_each_carries_a_reason(table):
    """여러 개가 동시에 가능한 것이 정상이다 - 하나로 좁히면 안 된다.

    그리고 「가능하다」만 주면 현업이 그 판단을 되짚을 수 없다.
    """
    c = wps_export.build(table)["answer_contract"]
    assert "하나로 좁히지 마라" in c["return"]
    assert "전부" in c["when_many"]
    assert "with_reason" in c, "이유는 선택이 아니라 기본이다"


def test_the_example_is_computed_from_the_real_list(table):
    """예시는 **실제 목록으로 계산한다.** 지어낸 예시는 틀리면 더 나쁘다.

    거르는 데 쓰는 것도 판정 함수 그대로라, 예시와 실제 판정이 갈라지지 않는다.
    """
    d = wps_export.build(table)
    ex = d["answer_example"]
    assert ex is not None
    names = {w["wps_no"] for w in ex["answer"]["usable_wps"]}
    assert names <= set(table), "목록에 없는 이름이 예시에 나오면 안 된다"
    assert ex["answer"]["count"] == len(ex["answer"]["usable_wps"])
    for w in ex["answer"]["usable_wps"]:
        assert w["why"].strip(), f"{w['wps_no']}: 이유가 비었다"


def test_the_example_never_breaks_the_export(monkeypatch, table):
    """예시는 **곁들이는 것**이다. 여기서 예외가 나서 내보내기가 멈추면 안 된다."""
    monkeypatch.setattr(V, "QCChecker",
                        lambda *_a, **_k: (_ for _ in ()).throw(RuntimeError("boom")))
    d = wps_export.build(table)
    assert d["answer_example"] is None
    assert len(d["wps"]) == 2, "나머지는 그대로 나와야 한다"
