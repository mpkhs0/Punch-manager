"""Check 이름이 «화면»과 «백엔드»에서 같은지 정적으로 본다.

## 왜 필요한가

Check 이름은 **두 곳에 따로 적혀 있다.**

    backend/services/verifier.py   CHECK_NAMES   결과 Excel '결함 목록' 시트 ·
                                                 부서/팀 메일 본문 · 요약 시트
    frontend/static/js/app.js      CHECK_META    화면 배지 · Check 카드 ·
                                                 목록 모달 · 결함 표

갈라지면 **«화면에서 본 이름»과 «첨부 파일에 적힌 이름»이 달라진다.** 같은 결함을
두고 두 사람이 다른 이름으로 말하게 되는데, 어느 쪽이 맞는지 알 방법이 없다.

**아무 데서도 오류가 나지 않는다.** 번호는 맞고 이름만 다르므로 배지도 뜨고
Excel도 나온다. 사람이 둘을 나란히 놓고 볼 때만 드러난다.

실제로 그렇게 됐다(2026-09-02): Check 24를 양방향으로 확장하면서 `CHECK_META`의
이름만 고치고 `CHECK_NAMES`를 그대로 두어, 대시보드는 「이음 Type·프로세스별 WPS
끝자리 부적합」인데 프로젝트 세팅 카드와 결과 Excel은 「TKY 이음 전용 WPS 미적용」
이었다. `ui-regression-checker`가 실제 화면을 훑어서 찾았다 — 저장소의 어떤
테스트도 **이름**을 대조하지 않았기 때문이다(번호 집합만 봤다).
"""
from __future__ import annotations

import re

import pytest

from backend import config
from backend.services import verifier as V


def _check_meta() -> dict[str, str]:
    """`app.js`의 `CHECK_META`에서 번호 -> 이름을 뽑는다.

    **정규식 대신 평문 조각으로 찾는다.** 이 저장소에서 정규식의 `\\b`가 리터럴
    백스페이스(0x08)가 되어 영원히 매칭되지 않은 사고가 두 번 있었다 — 아무것도
    검사하지 않는 테스트가 통과했고, 소스에 보이지도 않았다.
    """
    src = (config.STATIC_DIR / "js" / "app.js").read_text(encoding="utf-8")
    # **정의 자리**를 찾는다. 그냥 `"CHECK_META"`로 찾으면 위쪽 주석과 사용처가
    # 먼저 걸려 빈 블록을 읽는다 — 그러면 대조가 «통과»로 보인다.
    start = src.index("const CHECK_META = [")
    end = src.index("];", start)
    block = src[start:end]

    out: dict[str, str] = {}
    for line in block.splitlines():
        line = line.strip()
        if not line.startswith("{no:"):
            continue
        # {no:'24', name:'…', col:'AJ', …}
        no = line.split("no:'", 1)[1].split("'", 1)[0]
        name = line.split("name:'", 1)[1].split("'", 1)[0]
        out[no] = name
    return out


@pytest.mark.synthetic
def test_check_meta_was_parsed_at_all():
    """파서가 헛돌면 뒤의 대조가 «통과»로 보인다 — 먼저 그것부터 막는다."""
    meta = _check_meta()
    assert len(meta) >= 20, f"CHECK_META를 제대로 읽지 못했다 (항목 {len(meta)}개)"
    assert "24" in meta and "3" in meta


@pytest.mark.synthetic
def test_screen_and_backend_use_the_same_check_names():
    """같은 번호는 같은 이름이어야 한다."""
    meta = _check_meta()
    mismatched: list[str] = []
    for no, name in V.CHECK_NAMES.items():
        if no == V.CHECK_UNWORKED:
            continue                      # 미작업은 화면이 따로 다룬다
        got = meta.get(str(no))
        if got is None:
            continue                      # 누락은 아래 테스트가 본다
        if got != name:
            mismatched.append(f"Check {no}: 화면 '{got}' vs 백엔드 '{name}'")
    assert not mismatched, (
        "화면과 백엔드의 Check 이름이 다르다 — 결과 Excel·메일과 화면이 갈라진다:\n  "
        + "\n  ".join(mismatched))


@pytest.mark.synthetic
def test_every_backend_check_has_a_screen_entry():
    """백엔드에 있는 번호는 화면에도 있어야 한다.

    없으면 그 배지가 **무색에 이름 없이** 뜬다. 결번(5·13)도 마찬가지다 —
    이미 붙은 검토 기록이 화면에서 읽혀야 하므로 정의를 남긴다.
    """
    meta = _check_meta()
    missing = [no for no in V.CHECK_NAMES
               if no != V.CHECK_UNWORKED and str(no) not in meta]
    assert not missing, f"화면 CHECK_META에 없는 Check: {missing}"


@pytest.mark.synthetic
def test_no_screen_only_check_numbers():
    """반대 방향 — 화면에만 있는 번호는 «없는 검사»를 있는 것처럼 보여준다."""
    meta = _check_meta()
    backend = {str(no) for no in V.CHECK_NAMES}
    extra = sorted(set(meta) - backend)
    assert not extra, f"백엔드에 없는데 화면에만 있는 Check: {extra}"
