"""프로세스 표기가 프로젝트마다 달라도 **같은 판정**이 나와야 한다.

TRION 물량은 합성 코드를 그대로 쓴다(`SMFC`). RUYA WPS 등록부는 풀어 쓴다
(`SMAW+FCAW`). 실측으로 TRION은 raw data AK열과 등록부 E열 표기가 **항상
같았으므로**, 등록부가 풀어 쓰는 프로젝트는 AK열도 풀어 쓴다고 봐야 한다.

예전에는 합성 코드를 **부분문자열로만** 찾아서 풀어 쓴 표기가 «혼합이 아닌 것»이
됐고, 한 프로젝트에서만 조용히 셋이 어긋났다 — 예외도 경고도 없이:

    Check 21   용접재료 2종 요구가 아예 안 돈다
    Check 6    보조 인원 완화가 안 걸려 **정상 시공에 없던 결함이 생긴다**
    Check 19   SMFC 합성자격 요구(현업 확정 2026-09-03)가 안 걸린다
"""
import pytest

from backend.services import verifier as V
from backend.services.verifier import Col

# (합성 코드, 풀어 쓴 표기) — 넷 다 두 글자 어근 둘의 조합이다
PAIRS = [("SMFC", "SMAW+FCAW"), ("GTFC", "GTAW+FCAW"),
         ("FCSA", "FCAW+SAW"),  ("GMSA", "GMAW+SAW")]


@pytest.mark.parametrize("code,spelled", PAIRS)
def test_spelled_out_notation_is_the_same_mixed_process(code, spelled):
    assert V._mixed_code(spelled) == code
    assert V._is_mixed_process(spelled) is True


def test_single_process_is_not_mixed():
    for p in ("FCAW", "SAW", "SMAW", "GTAW", "STUD", ""):
        assert V._mixed_code(p) is None, p


def test_carriage_notation_stays_unmixed():
    """`FCAW-CARRIAGE,FCAW`는 TRION 등록부의 실제 표기다. 혼합이 아니다."""
    assert V._mixed_code("FCAW-CARRIAGE,FCAW") is None


def test_composite_listed_with_another_process():
    """`SAW,SMFC`는 종전에도 혼합이었다 — 부분문자열 빠른 길이 살아 있어야 한다."""
    assert V._mixed_code("SAW,SMFC") == "SMFC"


# ── 판정이 실제로 같은가 ────────────────────────────────────────────────────
class _Loader:
    """자격 DB만 있으면 되는 최소 loader."""
    welder_qual = {
        "W-SMFC": {"process": ("SMFC",)},        # 합성 자격 보유
        "W-FCAW": {"process": ("FCAW",)},        # 보조 인원
        "W-SMAW": {"process": ("SMAW",)},
        "W-SPELL": {"process": ("SMAW+FCAW",)},  # 한 사람 자격이 풀어 적힌 경우
    }
    retired_welders: set = set()
    wps_table: dict = {}
    wps_rows: dict = {}


def _row(**cells):
    r = [None] * 80
    for k, v in cells.items():
        r[getattr(Col, k) - 1] = v
    return tuple(r)


def _judge(prc, welders, lot="A1"):
    chk = V.QCChecker(_Loader())
    chk._enabled, chk._rules, chk._rule_problems = {}, [], []
    cells = {"WPS_PROCESS": prc, "CONSUMABLE_LOT": lot}
    for i, w in enumerate(welders, 1):
        cells[f"WELDER{i}_NO"] = w
        cells[f"WELDER{i}_PROC"] = prc
    row = _row(**cells)
    return (chk._c19_wps_process_welder(row, prc) is not None,
            len(chk._c6_welders(row, prc)),
            chk._c21_mixed_consumables(row, prc) is not None)


SCENARIOS = [
    (["W-SMFC", "W-FCAW"], "합성자격자 1명 + 보조 1명 — 정상 시공"),
    (["W-SMAW", "W-FCAW"], "SMAW 1명 + FCAW 1명 — 현업 확정상 불합격"),
    (["W-FCAW"],           "FCAW 1명만"),
    (["W-SPELL"],          "한 사람 자격이 'SMAW+FCAW'로 적힌 경우"),
]


@pytest.mark.parametrize("welders,label", SCENARIOS)
def test_both_notations_judge_identically(welders, label):
    assert _judge("SMFC", welders) == _judge("SMAW+FCAW", welders), label


def test_relaxation_actually_fires_for_spelled_notation():
    """정상 시공(합성자격자 + 보조)에 Check 6이 붙으면 안 된다.

    이 오탐이 이 버그의 가장 비싼 증상이었다 — 시정할 수 없는 건이
    보조 인원 수만큼 나온다.
    """
    _, c6, _ = _judge("SMAW+FCAW", ["W-SMFC", "W-FCAW"])
    assert c6 == 0


def test_split_qualification_still_fails_smfc():
    """SMFC는 **합성 자격 자체**를 요구한다(현업 확정 2026-09-03).

    풀어 쓴 표기에서도 그 구분이 살아 있어야 한다 — 안 그러면 이 프로젝트만
    2026-08-28 이전 기준으로 판정한다.
    """
    c19, _, _ = _judge("SMAW+FCAW", ["W-SMAW", "W-FCAW"])
    assert c19 is True


# ── Check 20 · 24 도 같은 부분문자열 함정을 밟고 있었다 ─────────────────────
def _c20(prc, groove, mat="API 5L X65"):
    chk = V.QCChecker(_Loader())
    chk._enabled, chk._rules, chk._rule_problems = {}, [], []
    return chk._c20_api_groove_process(
        _row(MATERIAL1=mat, GROOVE=groove, WPS_PROCESS=prc), prc) is not None


@pytest.mark.parametrize("groove", ["SB", "DB"])
def test_c20_spelled_notation_is_not_a_false_positive(groove):
    """`SMFC`가 통과하는 Groove는 `SMAW+FCAW`도 통과해야 한다.

    부분문자열로 물으면 `"SMFC" in "SMAW+FCAW"`가 거짓이라 **같은 이음이 반대로
    판정된다** — 풀어 쓰는 프로젝트에서 정상 시공이 전부 오탐이 됐다.
    """
    assert _c20("SMFC", groove) == _c20("SMAW+FCAW", groove) is False


def test_c20_fillet_still_demands_plain_fcaw():
    """FL/FW는 **정확히 FCAW**다 — SMFC는 부적합(현업 예시).

    집합 포함으로 바꾸면 `SMFC ⊇ FCAW`라 이 규칙이 조용히 사라진다.
    풀어 쓴 표기도 같은 답이어야 한다.
    """
    assert _c20("FCAW", "FL") is False
    assert _c20("SMFC", "FL") is True
    assert _c20("SMAW+FCAW", "FL") is True


def test_c24_scope_gate_sees_spelled_notation():
    """Check 24②의 SMFC 관문. 부분문자열로 물으면 관문이 조용히 0이 된다."""
    chk = V.QCChecker(_Loader())
    chk._enabled, chk._rules, chk._rule_problems = {}, [], []
    for prc in ("SMFC", "SMAW+FCAW"):
        chk._scope.clear()
        chk._c24_tky_wps(_row(WPS_NO="RU-SMFC-G01", WPS_PROCESS=prc), "RU-SMFC-G01", prc)
        assert chk._scope["24"] == 1, prc
