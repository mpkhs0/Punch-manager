"""검증시트(회차 보관·전환)를 고정한다 — 2026-09-04 현업 결정.

예전에는 회차를 **하나만** 보관했다(`KEEP_RUNS = 1`). 새로 검증하면 직전
결과가 사라져서, 파일을 바꿔 가며 비교하려면 매번 다시 돌려야 했다.

여기서 지키는 것은 넷이고, 넷 다 **아무 데서도 오류가 나지 않는** 종류다:

1. 조회가 «최신»에 다시 박히지 않았는가.
   한 곳이라도 남으면 시트를 바꿨을 때 **그 표만 다른 회차**를 보여준다.
2. 없는 시트를 물었을 때 빈 결과를 주지 않는가.
   빈 결과는 화면에서 «결함 0건»으로 읽힌다 — 조용히 틀린다.
3. 상한을 넘으면 실제로 지워지고, 딸린 행도 함께 지워지는가.
4. 마지막 한 장은 지울 수 없는가.
   전부 지우면 화면이 «검증 전»으로 돌아가는데 되돌릴 방법이 없다.
"""
from __future__ import annotations

import re
import sqlite3
from pathlib import Path

import pytest

from backend.services import result_store as rs
from tests.test_result_store import make_result   # 합성 회차 생성기


@pytest.fixture
def db(tmp_path: Path) -> Path:
    return tmp_path / "qc.db"


def _save(db: Path, name: str, run_at: str = "2026-09-04 00:00") -> int:
    r = make_result(2)
    r["run_at"] = run_at
    r["sheet_name"] = name
    return rs.save_run(r, path=db)


# ── 1. 조회가 시트를 가리는가 ────────────────────────────────────────────
@pytest.mark.synthetic
def test_no_query_is_pinned_to_the_latest_run():
    """SQL에 «최신 회차»가 **다시 박히지 않았는지** 정적으로 본다.

    조회 함수가 스무 곳 가까이 되어, 새 함수를 추가하며 옛 패턴을 복사해 오기
    쉽다. 그러면 시트를 바꿔도 그 표만 최신을 보여준다 — 예외가 나지 않는다.

    정규식 대신 **평문 조각**으로 찾는다(이 저장소에서 `\\b`가 리터럴
    백스페이스가 되어 영원히 매칭되지 않은 사고가 있었다).
    """
    src = Path(rs.__file__).read_text(encoding="utf-8")
    pinned = "run_id=(SELECT id FROM run ORDER BY id DESC LIMIT 1)"
    hits = [ln for ln in src.splitlines()
            if pinned in ln and not ln.lstrip().startswith("#")]
    assert not hits, (
        "조회에 «최신 회차»가 박혀 있다 — 시트를 바꿔도 그 표만 안 바뀐다:\n  "
        + "\n  ".join(hits))


@pytest.mark.synthetic
def test_queries_answer_for_the_asked_sheet(db: Path):
    """같은 조회라도 시트를 지정하면 그 시트의 값이 나와야 한다."""
    a = _save(db, "시트 A", "2026-09-01 00:00")
    b = _save(db, "시트 B", "2026-09-02 00:00")
    assert a != b

    latest = rs.aggregate_flags(checks=None, path=db)
    by_b   = rs.aggregate_flags(checks=None, run_id=b, path=db)
    by_a   = rs.aggregate_flags(checks=None, run_id=a, path=db)
    # 최신 지정 없음 == 최신 시트
    assert latest == by_b
    # 두 시트가 각각 답한다 (합성 회차라 내용은 같지만 «답이 온다»가 요점)
    assert by_a["total_flags"] == by_b["total_flags"]


@pytest.mark.synthetic
def test_an_unknown_sheet_is_not_silently_empty(db: Path):
    """없는 시트는 «0건»이 아니라 «없음»이어야 한다.

    저장소는 빈 결과를 주는 것이 자연스럽지만, 그걸 화면까지 흘리면
    «결함 0건»으로 읽힌다. 그래서 라우터가 `run_exists()`로 먼저 끊는다.
    """
    _save(db, "하나뿐")
    assert rs.run_exists(1, path=db) is True
    assert rs.run_exists(999_999, path=db) is False


# ── 2. 보관 상한 ─────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_cap_prunes_oldest_and_cascades(db: Path):
    """상한을 넘으면 **가장 오래된 것부터** 지워지고 딸린 행도 함께 사라진다.

    상한과 같은 수만 만들면 «지우는 코드가 없어도» 통과한다 — 두 장 더 만든다.
    """
    for i in range(rs.KEEP_RUNS + 2):
        _save(db, f"시트 {i + 1}", f"2026-09-{i + 1:02d} 00:00")

    runs = rs.list_runs(db)
    assert len(runs) == rs.KEEP_RUNS
    # 최신이 앞이고, 가장 오래된 둘이 빠졌다
    assert runs[0]["name"] == f"시트 {rs.KEEP_RUNS + 2}"
    assert all(r["name"] != "시트 1" for r in runs)

    with sqlite3.connect(db) as conn:
        for tbl in ("flag", "row_raw", "unworked"):
            orphan = conn.execute(
                f"SELECT COUNT(*) FROM {tbl} "
                "WHERE run_id NOT IN (SELECT id FROM run)").fetchone()[0]
            assert orphan == 0, f"{tbl}에 지운 시트의 행이 남았다 ({orphan}행)"


# ── 3. 이름 ──────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_name_falls_back_to_the_filename(db: Path):
    """이름이 비면 업로드 파일명으로 대신한다. 둘 다 없으면 회차 번호.

    탭에 빈 칸이 뜨면 누를 수는 있는데 무엇인지 알 수 없다.
    """
    r = make_result(2)
    r["sheet_name"] = ""
    r["qmg_filename"] = "QMG4520 7월물량.xlsx"
    rid = rs.save_run(r, path=db)
    assert rs.list_runs(db)[0]["name"] == "QMG4520 7월물량.xlsx"

    assert rs.rename_run(rid, "7월 물량 재검토", path=db) is True
    assert rs.list_runs(db)[0]["name"] == "7월 물량 재검토"

    # 빈 이름 = 되돌리기
    assert rs.rename_run(rid, "  ", path=db) is True
    assert rs.list_runs(db)[0]["name"] == "QMG4520 7월물량.xlsx"


@pytest.mark.synthetic
def test_sheet_name_comes_from_the_uploaded_filename():
    """판정 엔진이 시트 기본 이름을 채운다 — 확장자는 뗀다(탭이 좁다)."""
    from backend.services import verifier as V
    src = Path(V.__file__).read_text(encoding="utf-8")
    assert '"sheet_name":' in src, "판정 결과에 sheet_name이 없다"
    # 확장자를 떼는 처리가 실제로 있는지
    assert "xlsm" in src.split('"sheet_name":')[1][:300], \
        "시트 이름에서 확장자를 떼지 않는다"


# ── 4. 삭제 ──────────────────────────────────────────────────────────────
@pytest.mark.synthetic
def test_the_last_sheet_cannot_be_deleted(db: Path):
    """전부 지우면 화면이 «검증 전»으로 돌아가고 되돌릴 방법이 없다."""
    a = _save(db, "A", "2026-09-01 00:00")
    b = _save(db, "B", "2026-09-02 00:00")
    assert rs.delete_run(a, path=db) is True
    assert len(rs.list_runs(db)) == 1
    # 마지막 한 장은 거부
    assert rs.delete_run(b, path=db) is False
    assert len(rs.list_runs(db)) == 1


@pytest.mark.synthetic
def test_deleting_a_sheet_takes_its_rows(db: Path):
    a = _save(db, "A", "2026-09-01 00:00")
    _save(db, "B", "2026-09-02 00:00")
    rs.delete_run(a, path=db)
    with sqlite3.connect(db) as conn:
        left = conn.execute("SELECT COUNT(*) FROM flag WHERE run_id=?",
                            (a,)).fetchone()[0]
    assert left == 0, "지운 시트의 플래그가 남았다"


# ── 5. 화면이 시트를 실어 보내는가 ───────────────────────────────────────
@pytest.mark.synthetic
def test_the_screen_attaches_the_sheet_to_every_query():
    """`_qs()` **한 곳**에서 붙여야 한다.

    호출부마다 적으면 한 곳만 빠뜨려도 그 표만 다른 시트를 보여주는데,
    오류가 나지 않아 발견이 아주 늦다.
    """
    from backend import config
    js = (config.STATIC_DIR / "js" / "app.js").read_text(encoding="utf-8")
    head = js[js.index("function _qs("):]
    head = head[:head.index("\n}")]
    assert "S.runId" in head and "set('run'" in head, \
        "_qs()가 시트 번호를 붙이지 않는다"
    # 직접 호출용 보조도 있어야 한다(_qs를 안 거치는 경로)
    assert "function _withRun(" in js
    for path in ("/api/result'", "/api/result/row/", "/api/result/unworked"):
        idx = js.find(path)
        assert idx > 0, f"{path} 호출을 찾지 못했다"
        around = js[max(0, idx - 120):idx + 40]
        assert "_withRun" in around, f"{path} 호출에 시트 번호가 안 붙는다"


@pytest.mark.synthetic
def test_history_view_is_registered_in_setview():
    """`setView()`의 하드코딩 배열에 안 넣으면 그 화면이 «안 사라진다».

    다른 화면 위에 겹쳐 뜨고 오류는 나지 않는다.
    """
    from backend import config
    js = (config.STATIC_DIR / "js" / "app.js").read_text(encoding="utf-8")
    blk = js[js.index("function setView("):]
    blk = blk[:blk.index("forEach(id =>")]
    assert "'history'" in blk, "setView 배열에 history가 없다"
    html = (config.FRONTEND_DIR / "index.html").read_text(encoding="utf-8")
    assert 'id="view-history"' in html
    assert 'id="sheet-tabs"' in html
