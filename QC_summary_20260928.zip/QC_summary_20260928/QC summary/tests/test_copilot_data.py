"""Copilot 자료 — 원본 여러 벌을 «한 벌»로 합치는 규칙.

현업이 Copilot에 넣을 자료를 서버가 정리해서 내준다. 여기서 지키는 것은 셋이다.

    1. 사람당 한 줄     원본은 «자격 한 건 = 한 줄»이라 한 사람이 여러 줄이다.
                        그대로 올리면 에이전트가 같은 사번을 여러 사람으로 읽고,
                        「이 사람이 FCAW를 할 수 있나」에 다른 줄을 못 본 채 답한다.
    2. 파일 사이 합집합  승인 용접봉은 목록이 여러 벌로 나뉜다. 합치지 않으면
                        에이전트가 파일 하나만 보고 「승인되지 않았다」고 답한다.
    3. 자료가 없으면 «빈 파일»이 아니라 거절  빈 엑셀을 내려주면 에이전트가
                        「승인된 용접봉이 하나도 없다」로 읽는다 — 사실이 아니다.

**합성 데이터만 쓴다.** 실제 자격 DB에는 사번과 이름이 들어 있어 이 저장소에
둘 수 없다(CLAUDE.md「사내 실데이터를 tests/에 커밋하지 마라」).
"""
from __future__ import annotations

from datetime import date
from pathlib import Path

import pytest
from openpyxl import Workbook, load_workbook

from backend.services import copilot_data, verifier as svc


# ── 합성 원본 만들기 ────────────────────────────────────────────────────────
def _welder_book(path: Path, rows: list[dict]) -> Path:
    """옛 형식(`WelderLayout.OLD`) 자격 DB — 머리말 3행 · C열 번호 · F열 Process."""
    wb = Workbook()
    ws = wb.active
    for _ in range(3):
        ws.append([])
    for r in rows:
        line = [None] * 80
        line[2]  = r["no"]                      # C
        line[3]  = r.get("name", "")            # D
        line[4]  = r.get("spec", "")            # E
        line[5]  = r["process"]                 # F
        line[8]  = r.get("cert_no", "")         # I
        line[9]  = r.get("cert_date")           # J
        line[10] = r.get("position", "")        # K
        line[67] = r.get("cls", "")             # BP
        line[79] = r.get("status", "")          # CB
        ws.append(line)
    wb.save(path)
    return path


def _consumable_book(path: Path, header: list[str], rows: list[list]) -> Path:
    """현업 양식 — 머리말 4행(마지막이 열 이름) · 데이터 5행부터 · 3열이 Lot No."""
    wb = Workbook()
    ws = wb.active
    ws.append(["승인 용접봉 리스트"])
    ws.append([])
    ws.append([])
    ws.append(header)
    for r in rows:
        ws.append(r)
    wb.save(path)
    return path


def _sheet(path: Path, name: str) -> list[tuple]:
    wb = load_workbook(path)
    return list(wb[name].iter_rows(values_only=True))


# ── 2. Welder search ───────────────────────────────────────────────────────
def test_one_row_per_welder_merges_every_qualification(tmp_path):
    """한 사람의 자격 여러 줄이 **한 줄**로 합쳐진다."""
    src = _welder_book(tmp_path / "w.xlsx", [
        {"no": "W1", "process": "FCAW", "position": "3G", "cert_no": "C-1"},
        {"no": "W1", "process": "SMFC", "position": "4G", "cert_no": "C-2"},
        {"no": "W2", "process": "SAW",  "position": "1G", "cert_no": "C-9"},
    ])
    out = tmp_path / "o.xlsx"
    info = copilot_data.build_welder_xlsx(src, out)
    assert info["welders"] == 2

    rows = _sheet(out, "용접사 자격")
    head, body = rows[0], rows[1:]
    assert len(body) == 2, "사람 수만큼만 나와야 한다"
    w1 = dict(zip(head, body[0]))
    assert w1["용접사번호"] == "W1"
    assert w1["보유 프로세스"] == "FCAW, SMFC"
    assert w1["자세(Position)"] == "3G, 4G"
    assert w1["자격번호"] == "C-1, C-2"


def test_joined_values_are_sorted_so_the_file_is_comparable(tmp_path):
    """집합은 순서가 없다 — 정렬하지 않으면 같은 자료로 만든 파일이 매번 달라
    보이고, 그러면 «무엇이 바뀐 것인지» 대조할 수 없다."""
    src = _welder_book(tmp_path / "w.xlsx", [
        {"no": "W1", "process": "SMFC"},
        {"no": "W1", "process": "FCAW"},
        {"no": "W1", "process": "GTAW"},
    ])
    out = tmp_path / "o.xlsx"
    copilot_data.build_welder_xlsx(src, out)
    w1 = dict(zip(*_sheet(out, "용접사 자격")[:2]))
    assert w1["보유 프로세스"] == "FCAW, GTAW, SMFC"


def test_missing_expiry_is_not_reported_as_valid(tmp_path):
    """「만료일 없음」을 «유효»로 뭉개면 자료의 빈칸이 사라진다.

    그 빈칸 자체가 Check 7이 지적하는 결함이다 — 에이전트가 그 사람을
    «자격 유효»로 읽으면 정반대가 된다.
    """
    src = _welder_book(tmp_path / "w.xlsx", [{"no": "W1", "process": "FCAW"}])
    out = tmp_path / "o.xlsx"
    info = copilot_data.build_welder_xlsx(src, out)
    assert info["unknown"] == 1 and info["valid"] == 0
    w1 = dict(zip(*_sheet(out, "용접사 자격")[:2]))
    assert w1["자격 상태"] == "만료일 없음"
    # 빈 칸은 openpyxl이 None으로 되돌려 준다 — «비어 있다»만 확인한다
    assert not w1["유효 만료일"]


def test_info_sheet_comes_first(tmp_path):
    """Copilot은 시트를 순서대로 읽는다 — 설명이 뒤에 있으면 에이전트가 열
    이름만 보고 뜻을 지어낸다. 그럴듯한 오답이 제일 나쁘다."""
    src = _welder_book(tmp_path / "w.xlsx", [{"no": "W1", "process": "FCAW"}])
    out = tmp_path / "o.xlsx"
    copilot_data.build_welder_xlsx(src, out)
    assert load_workbook(out).sheetnames[0] == "정보"


def test_unreadable_welder_file_is_refused(tmp_path):
    """형식을 못 읽으면 **빈 파일을 만들지 않는다.** 만들면 「용접사가 하나도
    없다」로 읽히는데, 원인이 «형식»이라는 것은 알 방법이 없다."""
    src = _welder_book(tmp_path / "w.xlsx", [])
    with pytest.raises(ValueError):
        copilot_data.build_welder_xlsx(src, tmp_path / "o.xlsx")


# ── 3. Weld consumable search ──────────────────────────────────────────────
def test_lots_from_several_files_are_merged_and_credited(tmp_path):
    """여러 목록을 합치고, 같은 Lot은 한 줄로 묶되 **출처를 전부** 적는다."""
    files = [
        {"filename": "A.xlsx", "lots": ["L1", "L2"]},
        {"filename": "B.xlsx", "lots": ["L2", "L3"]},
    ]
    out = tmp_path / "c.xlsx"
    info = copilot_data.build_consumable_xlsx(files, out)
    assert info == {"lots": 3, "files": 2, "columns": 0, "duplicated": 1}

    rows = _sheet(out, "승인 용접봉")
    body = {r[0]: r[1] for r in rows[1:]}
    assert set(body) == {"L1", "L2", "L3"}
    assert body["L2"] == "A.xlsx / B.xlsx"


def test_source_columns_ride_along_without_duplicating_the_lot(tmp_path):
    """원본 열을 함께 싣되 **Lot 열은 빼고** 싣는다 — 첫 열이 이미 Lot이다."""
    src = _consumable_book(tmp_path / "s.xlsx",
                           ["No", "제조사", "Lot No", "AWS 규격"],
                           [[1, "현대", "L1", "E71T-1C"]])
    loader = svc.QCDataLoader()
    loader.load_consumables(src)
    assert "Lot No" not in loader.consumable_columns

    out = tmp_path / "c.xlsx"
    copilot_data.build_consumable_xlsx(
        [{"filename": "s.xlsx", "lots": sorted(loader.consumable_lots),
          "columns": loader.consumable_columns, "rows": loader.consumable_rows}],
        out)
    head = _sheet(out, "승인 용접봉")[0]
    assert head.count("Lot No") == 1, head
    row = dict(zip(head, _sheet(out, "승인 용접봉")[1]))
    assert row["제조사"] == "현대" and row["AWS 규격"] == "E71T-1C"


def test_old_cache_without_columns_still_merges(tmp_path):
    """옛 캐시에는 Lot 번호뿐이다. **그래도 합쳐 주는 것이** 원본 여러 개보다 낫다."""
    out = tmp_path / "c.xlsx"
    info = copilot_data.build_consumable_xlsx(
        [{"filename": "old.xlsx", "lots": ["L1"]}], out)
    assert info["columns"] == 0
    assert _sheet(out, "승인 용접봉")[0] == ("Lot No", "출처 파일")


def test_judgment_still_sees_only_the_lot_set(tmp_path):
    """원본 열을 담게 됐어도 **판정이 보는 것은 종전 그대로** Lot 집합이다.

    Check 18은 「이 Lot이 목록에 있는가」 하나만 묻는다. 여기가 달라지면
    Copilot 자료를 위한 변경이 판정을 바꾼 것이 된다.
    """
    src = _consumable_book(tmp_path / "s.xlsx",
                           ["No", "제조사", "Lot No", "AWS 규격"],
                           [[1, "현대", "l1", "E71T-1C"],
                            [2, "고려", "L2", "E7016"]])
    loader = svc.QCDataLoader()
    assert loader.load_consumables(src) == 2
    assert loader.consumable_lots == {"L1", "L2"}, "대문자로 걷는 것도 그대로"


# ── 라우터 — «없음»과 «비었음»을 가른다 ─────────────────────────────────────
def _client(monkeypatch, tmp_path):
    """자료가 하나도 없는 상태의 서버."""
    from fastapi.testclient import TestClient
    from backend import config
    from backend.routers import copilot as cp, verify as vr

    monkeypatch.setattr(config, "UPLOADS_DIR", tmp_path / "up")
    monkeypatch.setattr(config, "COPILOT_DIR", tmp_path / "cop")
    monkeypatch.setattr(config, "CONSUMABLE_CACHE", tmp_path / "cons.json")
    # WPS도 격리한다 - 안 하면 이 저장소의 실제 Raw data를 읽어
    # 「자료 없음」시나리오가 성립하지 않는다.
    monkeypatch.setattr(config, "WPS_CACHE", tmp_path / "wps.json")
    monkeypatch.setattr(config, "current_wps_ref", lambda: tmp_path / "none.xlsx")
    monkeypatch.setattr(cp, "require_login", lambda *_a, **_k: "TESTER")
    monkeypatch.setattr(vr, "_welder_name", "")
    from backend.main import app
    return TestClient(app)


def test_missing_data_is_refused_not_served_as_an_empty_file(monkeypatch, tmp_path):
    """빈 엑셀을 내려주면 에이전트가 「승인된 용접봉이 하나도 없다」로 읽는다.

    그건 사실이 아니라 «아직 안 올렸다»이다. 둘을 뭉개면 받는 사람이
    구분할 방법이 없다.
    """
    c = _client(monkeypatch, tmp_path)
    for path in ("/api/copilot/welders", "/api/copilot/consumables"):
        r = c.get(path, headers={"X-Employee-Id": "TESTER"})
        assert r.status_code == 409, (path, r.status_code)
        assert "올리" in r.json()["detail"], r.json()


def test_status_tells_the_screen_what_is_missing(monkeypatch, tmp_path):
    """버튼을 끌 근거와 «무엇을 올려야 하는지»를 함께 준다."""
    c = _client(monkeypatch, tmp_path)
    d = c.get("/api/copilot/status", headers={"X-Employee-Id": "TESTER"}).json()
    for key in ("wps", "welders", "consumables"):
        assert key in d, d.keys()
        assert d[key]["ready"] is False
        assert d[key]["hint"], f"{key}: 무엇을 올려야 하는지 말해야 한다"


def test_status_keys_match_the_download_paths(monkeypatch, tmp_path):
    """화면이 `status`의 키를 그대로 URL에 쓴다 — 어긋나면 «버튼이 늘 비활성»
    으로만 보이고 오류는 나지 않는다."""
    c = _client(monkeypatch, tmp_path)
    d = c.get("/api/copilot/status", headers={"X-Employee-Id": "TESTER"}).json()
    from backend.main import app
    paths = set(app.openapi()["paths"])
    for key in d:
        if key == "project":
            continue
        assert f"/api/copilot/{key}" in paths, key


# ── 화면 — 뷰를 늘릴 때 «조용히» 어긋나는 세 자리 ───────────────────────────
def _read(rel: str) -> str:
    from backend import config
    return (Path(config.FRONTEND_DIR) / rel).read_text(encoding="utf-8")


def test_new_view_is_registered_everywhere_it_must_be():
    """`setView()`의 배열에 안 넣으면 그 화면이 **«안 사라진다»** — 다른 화면
    위에 겹쳐 뜨고 오류는 나지 않는다(CLAUDE.md).

    빵부스러기(CRUMBS)가 빠지면 상단에 내부 키가 그대로 나온다.
    """
    html, js = _read("index.html"), _read("static/js/app.js")
    assert 'id="view-copilot"' in html
    assert "onclick=\"setView('copilot')\"" in html
    assert "'exports','copilot'" in js, "setView()의 뷰 배열에 없다"
    assert "copilot:'Copilot 자료'" in js, "CRUMBS에 없다"
    assert "if (v === 'copilot')" in js, "진입 시 자료를 불러오지 않는다"


def test_screen_only_uses_css_that_exists():
    """없는 클래스·변수는 **예외 없이 «무색으로 그냥 보이는»** 상태가 된다.

    실제로 `var(--r1)`(정의된 것은 `--r2`뿐)로 한 번 겪었다.
    """
    js, css = _read("static/js/app.js"), _read("static/css/style.css")
    block = js[js.index("const COPILOT_ITEMS"):]
    import re
    for var in sorted(set(re.findall(r"var\((--[a-z0-9-]+)\)", block))):
        assert f"{var}:" in css, f"{var}가 style.css에 정의돼 있지 않다"
    for cls in ("pill", "p-blue", "empty", "cp-card", "cp-body",
                "cp-title", "cp-what", "cp-meta", "cp-hint", "cp-note"):
        assert f".{cls}" in css, f".{cls}가 style.css에 없다"


# ── 이관이 «덜 옮겨졌을» 때 ────────────────────────────────────────────────
def test_server_starts_even_when_the_copilot_files_were_not_transferred(tmp_path,
                                                                        monkeypatch):
    """부가 기능 파일 하나 때문에 **서버 전체가 죽으면 안 된다.**

    이관은 사람이 폴더를 복사해서 한다. 덮어쓰기만 하는 방식으로 옮기면 «새
    파일»은 생기지 않는데, 실제로 그 상태에서 기동이 통째로 실패해
    **로그인조차 되지 않았다.** pywin32·scikit-learn과 같은 취급이어야 한다.
    """
    import importlib
    import sys

    real = sys.modules.pop("backend.routers.copilot", None)
    real_main = sys.modules.pop("backend.main", None)

    class _Blocker:
        def find_module(self, name, path=None):
            return self if name == "backend.routers.copilot" else None

        def load_module(self, name):
            raise ImportError(f"No module named {name!r}")

    blocker = _Blocker()
    sys.meta_path.insert(0, blocker)
    try:
        main = importlib.import_module("backend.main")
        assert main.copilot_router is None
        assert main.COPILOT_MISSING, "무엇이 빠졌는지 남겨야 한다"
        # 나머지 기능은 그대로 돈다
        paths = set(main.app.openapi()["paths"])
        assert "/api/verify" in paths, "판정까지 멈추면 안 된다"
        assert not [p for p in paths if "copilot" in p]
        assert main.server_info()["copilot"] is False
    finally:
        sys.meta_path.remove(blocker)
        sys.modules.pop("backend.main", None)
        if real is not None:
            sys.modules["backend.routers.copilot"] = real
        if real_main is not None:
            sys.modules["backend.main"] = real_main
        importlib.import_module("backend.main")


def test_the_screen_hides_the_menu_when_the_feature_is_absent():
    """없는 메뉴를 눌러 404를 보는 것보다 아예 안 보이는 편이 낫다.

    **키가 없는 옛 서버는 «있다»로 본다** — 없다고 단정해 감추면 멀쩡한
    기능이 사라진다(`=== false`로 물어야 하는 이유).
    """
    js = _read("static/js/app.js")
    assert "info.copilot === false" in js, "옛 서버에서 메뉴가 사라진다"
    assert "nav-copilot" in js


# ── 1. Joint search — WPS를 «어디서» 가져오는가 ─────────────────────────────
def _wps_book(path: Path) -> Path:
    """WPS 참조 파일 최소 형태. 실제 등록부 대신 한 줄만 둔다."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Hull & Topside WPS List"
    for _ in range(5):                              # 데이터는 6행부터
        ws.append([])
    line = [None] * 30
    line[2] = "RU-FC-G01"                           # C: WPS No  (WPSCol.WPS_NO)
    line[4] = "FCAW"                                # E: Process (WPSCol.PROCESS)
    ws.append(line)
    wb.save(path)
    return path


def test_wps_comes_from_the_same_place_the_judgment_reads(tmp_path, monkeypatch):
    """캐시가 있으면 **캐시가 이긴다** — `run_verification()`과 같은 순서다.

    처음에는 'Raw data' 폴더만 봤다. 그런데 실제 서버는 화면에서 WPS List를
    올려 쓰기 때문에 목록이 캐시에 있다. 그대로 두면 **판정이 쓰는 WPS와
    Copilot에 넘기는 WPS가 갈라진다** — 「추천대로 썼는데 결함」이 나오고
    원인을 짚을 길이 없다.
    """
    import json
    from backend import config
    from backend.routers import copilot as cp, verify as vr

    raw = tmp_path / "Raw data"
    raw.mkdir()
    _wps_book(raw / "ref.xlsx")
    monkeypatch.setattr(config, "WPS_CACHE", tmp_path / "wps_cache.json")
    monkeypatch.setattr(config, "current_wps_ref", lambda: raw / "ref.xlsx")

    # 캐시가 없으면 Raw data 를 본다
    table, src = cp._wps_table()
    assert set(table) == {"RU-FC-G01"} and src == "ref.xlsx"

    # 캐시가 생기면 그쪽이 이긴다
    config.WPS_CACHE.write_text(
        json.dumps({"RU-SMFC-G01": {"process": "SMAW+FCAW"}}, ensure_ascii=False),
        encoding="utf-8")
    monkeypatch.setattr(vr, "_wps_name", "올린목록.xlsx")
    table, src = cp._wps_table()
    assert set(table) == {"RU-SMFC-G01"}, "캐시가 우선이어야 한다"
    assert src == "올린목록.xlsx"


def test_a_file_dropped_after_startup_is_seen_without_a_restart(tmp_path,
                                                                monkeypatch):
    """`config.WPS_REF`는 **모듈을 읽을 때 한 번** 정해진다.

    그래서 서버를 띄운 뒤 'Raw data'에 파일을 갖다 놓으면 재기동 전까지
    「WPS 0건」으로 보였다. 화면에는 그 이유가 드러나지 않는다 — 원인이
    «기동 시각»이라는 것은 짐작할 단서가 없다.

    `config.current_wps_ref()`가 매번 다시 찾는다.
    """
    from backend import config
    from backend.routers import copilot as cp

    raw = tmp_path / "Raw data"
    raw.mkdir()
    monkeypatch.setattr(config, "WPS_CACHE", tmp_path / "none.json")
    monkeypatch.setattr(config, "DATA_ROOT", tmp_path)

    assert cp._wps_table() == ({}, ""), "아직 파일이 없다"
    _wps_book(raw / "ref.xlsx")                     # 기동 «후에» 갖다 놓는다
    table, src = cp._wps_table()
    assert set(table) == {"RU-FC-G01"}, "재기동 없이 보여야 한다"
    assert src == "ref.xlsx"


def test_the_hint_names_the_usual_path_first():
    """안내는 **보통 쓰는 길**을 먼저 말해야 한다.

    실제 서버는 업로드 화면에서 WPS List를 올려 쓴다. 'Raw data 폴더에
    두십시오'만 말하면, 올려서 쓰던 사람은 엉뚱한 곳을 보게 된다.
    """
    src = (Path("backend") / "routers" / "copilot.py").read_text(encoding="utf-8")
    hint = src[src.index('"hint": "" if wps_table'):][:260]
    assert hint.index("업로드") < hint.index("Raw data")


def test_the_cached_wps_gives_the_same_export_as_the_file(tmp_path, monkeypatch):
    """업로드해서 캐시된 목록으로 만든 것과, 파일에서 직접 만든 것이 **같아야** 한다.

    실제 서버는 업로드 화면에서 WPS List를 올려 쓰므로 목록이 캐시에만 있다.
    두 경로가 다른 결과를 내면 「판정이 본 WPS」와 「Copilot에 넘긴 WPS」가
    갈라지고, 그건 둘을 나란히 놓고 대조해 보기 전에는 알 수 없다.
    """
    import json
    from backend import config
    from backend.routers import copilot as cp, verify as vr
    from backend.services import wps_export

    src = _wps_book(tmp_path / "ref.xlsx")
    loader = svc.QCDataLoader()
    loader.load_wps(str(src))
    direct = wps_export.build(loader.wps_table)

    # `upload_wps`가 쓰는 것과 **똑같이** 캐시를 만든다
    cache = tmp_path / "wps_cache.json"
    cache.write_text(json.dumps(loader.wps_table, ensure_ascii=False, indent=2),
                     encoding="utf-8")
    monkeypatch.setattr(config, "WPS_CACHE", cache)
    monkeypatch.setattr(config, "current_wps_ref", lambda: tmp_path / "none.xlsx")
    monkeypatch.setattr(vr, "_wps_name", "올린목록.xlsx")

    table, _ = cp._wps_table()
    cached = wps_export.build(table)

    direct.pop("generated_at", None)
    cached.pop("generated_at", None)
    assert direct == cached, "캐시 경로와 파일 경로가 갈라졌다"
