"""WPS 보정 값의 «모양»이 어긋나도 적재가 멈추면 안 된다.

실제로 멈췄다(2026-09-18). '프로젝트 세팅' 화면이 `wps_corrections` 를 «쌍»
편집기로 그렸는데, 그 값은 문자열이 아니라 dict 다:

    {"FC-G01": {"add_joint_detail": ["FL"], "add_materials": [...]}}

쌍 편집기는 값을 `String()` 으로 그려 저장할 때 그 **문자열**이 들어간다.
그러면 `_apply_one()` 이 `corr.get(...)` 에서 터지고, `load_wps()` ·
`load_wps_from_dict()` 가 그것을 부르므로 **검증도 Copilot 자료도 500** 이
된다. Groove 별칭만 고치고 저장해도 이 칸이 함께 망가졌다.

고친 자리는 둘이다:
  · `apply_corrections()`   모양이 어긋난 값을 건너뛴다 (판정을 막지 않는다)
  · 화면                    `wps_corrections` 를 JSON 편집기로 그린다 (망가뜨리지 않는다)

**건너뛰기만 하면 이번엔 «조용히 안 걸리는» 쪽이 된다.** 그래서
`check_rules_alive()` 가 화면에도 띄운다.
"""
from __future__ import annotations

import unittest.mock as mock
from pathlib import Path

import pytest

from backend.services import wps_rules as R

_BROKEN = "{'add_joint_detail': ['FL']}"      # 화면이 망가뜨린 모양


def _table() -> dict:
    return {"TR-FC-G01": {"joint_detail": "SB, SV", "materials": [],
                          "process": "FCAW"}}


def test_a_broken_correction_does_not_stop_the_load():
    """보정 하나 때문에 WPS 적재가 통째로 멈추면 검증도 못 돈다."""
    with mock.patch.object(R, "wps_corrections", lambda: {"FC-G01": _BROKEN}):
        t = _table()
        assert R.apply_corrections(t) == [], "적용된 보정은 없다"
        assert t["TR-FC-G01"]["joint_detail"] == "SB, SV", "표는 그대로다"


@pytest.mark.parametrize("bad", [_BROKEN, "", [], 0, None, ["FL"]])
def test_every_wrong_shape_is_skipped_not_raised(bad):
    with mock.patch.object(R, "wps_corrections", lambda: {"FC-G01": bad}):
        R.apply_corrections(_table())          # 예외가 나지 않아야 한다


def test_a_correct_correction_still_applies():
    """건너뛰기가 정상 값까지 먹으면 안 된다."""
    good = {"FC-G01": {"add_joint_detail": ["FL"]}}
    with mock.patch.object(R, "wps_corrections", lambda: good):
        t = _table()
        assert R.apply_corrections(t), "보정이 적용돼야 한다"
        assert "FL" in t["TR-FC-G01"]["joint_detail"]


def test_the_screen_is_told_about_the_broken_value():
    """**건너뛰기만 하면 «조용히 안 걸리는» 쪽이 된다.**

    사용자는 보정을 넣어 뒀다고 믿는데 한 행에도 안 걸린다 — 그건 터지는
    것보다 발견이 늦다.
    """
    with mock.patch.object(R, "wps_corrections", lambda: {"FC-G01": _BROKEN}):
        found = [f for f in R.check_rules_alive({"TR-FC-G01"}, {"TR-FC-G01"})
                 if f.get("kind") == "corr_shape"]
    assert len(found) == 1, found
    assert found[0]["level"] == "error"
    assert "FC-G01" in found[0]["msg"]
    assert "적용되지 않습니다" in found[0]["msg"]
    assert "프로젝트 세팅" in found[0]["msg"], "어디서 고치는지 말해야 한다"


def test_a_correct_correction_raises_no_shape_warning():
    good = {"FC-G01": {"add_joint_detail": ["FL"]}}
    with mock.patch.object(R, "wps_corrections", lambda: good):
        assert not [f for f in R.check_rules_alive({"TR-FC-G01"}, {"TR-FC-G01"})
                    if f.get("kind") == "corr_shape"]


# ── 화면이 다시 망가뜨리지 않는가 ──────────────────────────────────────────
def test_the_screen_does_not_edit_corrections_as_string_pairs():
    """«쌍» 편집기는 값을 `String()` 으로 그려 dict 를 문자열로 만든다.

    값이 dict 인 항목은 JSON 편집기로 그려야 왕복한다
    (`_pmCollect` 의 else 갈래가 `JSON.parse` 한다).
    """
    from backend import config
    js = (Path(config.STATIC_DIR) / "js" / "app.js").read_text(encoding="utf-8")
    block = js[js.index("  wps_corrections: {"):]
    block = block[:block.index("\n  },")]
    assert "kind: 'json'" in block, block[:200]
    assert "kind: 'pairs'" not in block, "dict 값을 쌍으로 그리면 다시 망가진다"
