"""2026-09-02 판정 로직 변경 8건을 고정한다.

전부 **손으로 만든 행 튜플**로 돈다 — 판정 조건을 코드 없이 읽을 수 있어야
하기 때문이다(`test_checks_19_20.py`와 같은 모양).

여기서 지키는 것은 「바꿨다」가 아니라 **「이렇게 바꾸기로 했다」**이다.
되돌리면 실패해야 한다.

| 항목 | 내용 |
|---|---|
| 1 | E열 Repair 행은 NDE 요율(Check 26)에서만 빠진다 (2026-09-03 복원) |
| 2 | 혼합 프로세스 용접재 2종 — 기존 Check 21이 이미 한다 |
| 3 | Check 24: TT는 GK · SMFC 비TT는 G 계열 |
| 4·5 | 사외업체(BF가 Q·C로 시작하지 않음)는 판정 제외 |
| 6 | 이상치는 플래그를 만들지 않는다 (Check 13 결번) |
| 7 | 용접재 구분자에 `/` `;` 줄바꿈 포함 (Check 18·21 공용) |
| 8 | Check 14는 «도면+Block+Lot+Joint»에서 본용접 중복만 본다 |
"""
from __future__ import annotations

import pytest

from backend.services import verifier as V
from backend.services.verifier import Col
from tests.test_checks_16_17 import FakeLoader, make_row


class _Loader(FakeLoader):
    """`FakeLoader`에 판정 엔진이 실제로 부르는 두 가지를 더한다.

    - `consumable_lots` — Check 18의 «승인 목록». 비우면 «미승인» 쪽이 아예
      돌지 않는다(그게 설계다).
    - `wps_of()` — Check 2·3·4·11이 부른다. 표가 비면 전부 None을 받는다.
    """

    def __init__(self, consumables: set[str] | None = None) -> None:
        super().__init__({})
        self.consumable_lots = consumables or set()
        self.welder_expiry = {}          # Check 7 — 비면 한 행도 판정하지 않는다

    def wps_of(self, wps_no: str) -> dict | None:
        return self.wps_table.get(wps_no)


def _checker(rows: list[tuple[int, tuple]] | None = None,
             consumables: set[str] | None = None) -> V.QCChecker:
    c = V.QCChecker(_Loader(consumables))
    c._enabled = {}
    c._rules, c._rule_problems = [], []
    c._judged_rows_cache = rows or []
    return c


# ── 항목 7 · 2 — 용접재 구분자 ───────────────────────────────────────────────
@pytest.mark.synthetic
@pytest.mark.parametrize("text", [
    "F902A5B5A7, 10005625BB25140",       # 쉼표 + 공백
    "F902A5B5A7,10005625BB25140",        # 쉼표만
    "F902A5B5A7/10005625BB25140",        # 슬래시 — 실데이터에 있다
    "F902A5B5A7 / 10005625BB25140",      # 슬래시 + 공백
    "F902A5B5A7  ,  10005625BB25140",    # 공백 두 칸씩
    "F902A5B5A7;10005625BB25140",        # 세미콜론
    "F902A5B5A7\n10005625BB25140",       # 줄바꿈
])
def test_two_consumables_are_seen_as_two(text):
    """구분자가 무엇이든 «2종»이어야 한다.

    슬래시를 못 읽어 실측 Check 21의 **35.1%(2,614건)**, Check 18의 8.6%
    (3,275건)가 오탐이었다.
    """
    assert V._split_consumables(text) == ["F902A5B5A7", "10005625BB25140"]


@pytest.mark.synthetic
def test_a_single_consumable_stays_single():
    """구분자를 늘렸다고 «하나»가 둘로 쪼개지면 안 된다 — 반대 방향 오탐이다."""
    assert V._split_consumables("F902A5B5A7") == ["F902A5B5A7"]
    assert V._split_consumables("  F902A5B5A7  ") == ["F902A5B5A7"]


@pytest.mark.synthetic
def test_c21_accepts_slash_separated_pair():
    """항목 2 — 혼합 프로세스는 재료가 둘이어야 하고, 슬래시도 «둘»이다."""
    c = _checker()
    row = make_row(CONSUMABLE_LOT="10007488BB22CA1/F902A5B5A7")
    assert c._c21_mixed_consumables(row, "SMFC") is None


@pytest.mark.synthetic
def test_c21_still_flags_a_real_single():
    """진짜로 하나만 적힌 경우는 **여전히 결함**이어야 한다."""
    c = _checker()
    row = make_row(CONSUMABLE_LOT="F902A4L5D7")
    f = c._c21_mixed_consumables(row, "GTFC")
    assert f is not None and f.check_no == "21"


@pytest.mark.synthetic
def test_c18_and_c21_split_the_same_way():
    """나누는 방식이 갈라지면 «21은 2종인데 18은 미승인»이 된다.

    평문 비교다 — 정규식의 `\\b`가 리터럴 백스페이스가 되어 영원히 매칭되지
    않은 사고가 이 저장소에 있었다.
    """
    import inspect
    body18 = inspect.getsource(V.QCChecker._c18_consumable_lot)
    body21 = inspect.getsource(V.QCChecker._c21_mixed_consumables)
    assert "_split_consumables(" in body18 and "_split_consumables(" in body21, \
        "둘 중 하나가 직접 split()을 쓰고 있다 — 갈라지면 조용히 어긋난다"
    assert ".split(','" not in body18 and ".split(','" not in body21


# ── 항목 1 — Repair 행은 NDE 요율에서만 빠진다 ───────────────────────────────
@pytest.mark.synthetic
@pytest.mark.parametrize("mark,expected", [
    ("",   False),
    ("  ", False),      # 공백뿐이면 수리가 아니다
    ("R",  True),       # **한 글자도 수리다** — 예전 Check 26은 2글자 이상이었다
    ("U1", True),
    ("RE", True),
    ("M1", True),
])
def test_repair_is_any_non_empty_mark(mark, expected):
    assert V._is_repair(make_row(REPAIR_MARK=mark)) is expected


@pytest.mark.synthetic
def test_a_repair_row_still_gets_the_normal_checks():
    """수리 행도 **정규 항목을 전부** 판정받는다 (현업 확정 2026-09-03).

    2026-09-02에 한때 「Check 23만」으로 두었다가 되돌렸다 — 그러면 실측
    824건의 판정이 통째로 사라졌다(C13 253 · C14 201 · C18 160 · C21 74 …).
    수리 용접이라고 두께·재질·용접봉·자격이 면제되는 것이 아니다.
    """
    c = _checker()
    row = make_row(REPAIR_MARK="U1", WPS_NO="TR-FC-G01",
                   WPS_PROCESS="FCAW", CONSUMABLE_LOT="")   # AL 공란 = Check 18
    got = {f.check_no for f in c._check_row(row)}
    assert "18" in got, f"수리 행인데 AL 공란(Check 18)이 안 잡혔다: {sorted(got)}"
    assert "23" in got, "수리인데 수리 WPS가 아닌 것도 여전히 잡아야 한다"


@pytest.mark.synthetic
def test_a_repair_row_is_out_of_the_nde_rate_scope():
    """**유일한 제외 지점은 Check 26의 모수다.**

    약식 시공이라 전수 촬영 규정이 적용되지 않는다. 여기서 빼지 않으면
    수리 행이 요율 분모에 섞여 «요율이 낮게 나오는» 방향으로 조용히 틀린다.
    """
    c = _checker()
    base = dict(NDT_REPORT="SAVI14996")
    assert c._c26_in_scope(make_row(REPAIR_MARK="", **base)) is True
    assert c._c26_in_scope(make_row(REPAIR_MARK="U1", **base)) is False
    # 한 글자도 수리다 — Check 23과 같은 기준을 쓴다(2026-09-02 통일)
    assert c._c26_in_scope(make_row(REPAIR_MARK="R", **base)) is False


@pytest.mark.synthetic
def test_check_23_still_fires_on_a_repair_row():
    """**Check 23까지 빼면 그 검사가 영구히 0건이 된다** — 실측 1,283건이다."""
    c = _checker()
    row = make_row(REPAIR_MARK="U1", WPS_NO="TR-FC-G01")
    got = [f for f in c._check_row(row) if f.check_no == "23"]
    assert got, "수리인데 수리 WPS가 아닌 행을 Check 23이 못 잡았다"


@pytest.mark.synthetic
def test_a_repair_row_with_a_repair_wps_has_no_check_23():
    """수리 WPS를 제대로 썼으면 Check 23은 안 붙는다 (다른 항목은 별개로 돈다)."""
    c = _checker()
    row = make_row(REPAIR_MARK="U1", WPS_NO="TR-FC-R01")
    assert "23" not in {f.check_no for f in c._check_row(row)}


@pytest.mark.synthetic
def test_a_normal_row_is_unaffected():
    """수리가 아닌 행은 예전 그대로 전부 판정받는다."""
    c = _checker()
    row = make_row(REPAIR_MARK="", WPS_NO="TR-FC-G01",
                   WPS_PROCESS="FCAW", CONSUMABLE_LOT="")
    got = {f.check_no for f in c._check_row(row)}
    assert "18" in got, "정규 행인데 AL 공란(Check 18)이 안 잡혔다"


# ── 항목 4·5 — 사외업체 ──────────────────────────────────────────────────────
@pytest.mark.synthetic
@pytest.mark.parametrize("dept,is_sub", [
    ("Q520-해양내업생산부", False),
    ("C7H0-건조5부",       False),
    ("q520-소문자",         False),   # 대소문자를 가리지 않는다
    ("SWYE-세보테크놀로지",  True),    # 실데이터의 유일한 사외업체
    ("",                   True),    # 공란 — 미작업이 먼저 걸러 가는 것이 정상
])
def test_subcontractor_is_decided_by_the_department_prefix(dept, is_sub):
    assert V._is_subcontractor(make_row(DEPARTMENT=dept)) is is_sub


@pytest.mark.synthetic
def test_unworked_is_checked_before_subcontractor():
    """BF가 비었고 AJ부터 실적이 없는 행은 **미작업**이지 사외업체가 아니다.

    순서를 바꾸면 아직 검사가 진행되지 않은 사내 물량이 미작업 목록에서
    조용히 사라진다.
    """
    blank = make_row(DEPARTMENT="", WPS_NO="")
    assert V._is_unworked(blank), "미작업 판정이 먼저 성립해야 한다"
    import inspect
    src = inspect.getsource(V.QCChecker.run)
    assert src.index("_is_unworked(row)") < src.index("_is_subcontractor(row)"), \
        "사외업체 판정이 미작업보다 앞에 있다 — BF 공란 행이 잘못 분류된다"


# ── 항목 6 — 이상치는 판정 항목이 아니다 ────────────────────────────────────
@pytest.mark.synthetic
def test_check_13_is_retired():
    """13은 결번이다 — **Check 5와 같은 취급.**

    「결번」은 «정의를 지운다»가 아니라 «판정하지 않는다»이다:

        이름 · 색 · 축   남긴다  <- 이미 붙은 검토 기록 2건이 화면에서 읽혀야 한다
        Flag(13) 호출    없앤다  <- 더 이상 결함이 아니다
        _SCOPED_CHECKS   뺀다    <- 관문을 세지 않는다

    이름을 지우면 옛 검토 기록이 «이름 없는 배지»가 된다. Check 5(337건)의
    이름을 남겨 둔 것과 같은 이유다. 번호 재사용은 여전히 금지다.
    """
    assert 13 in V.CHECK_NAMES,  "옛 검토 기록이 이름 없이 뜬다"
    assert 13 in V.CHECK_COLORS, "옛 검토 기록의 배지가 무색이 된다"
    assert "13" not in V._SCOPED_CHECKS, "판정하지 않는데 관문을 세고 있다"


@pytest.mark.synthetic
def test_the_anomaly_detector_creates_no_flag():
    """탐지는 하되 **플래그를 만들지 않는다.**

    만들면 결함 목록·부서 실적·Excel·부서 메일이 전부 그것을 결함으로
    실어 나른다 — 실측 5,397건이 그렇게 나가고 있었다.
    """
    import inspect
    # **호출**을 본다 — 주석에 그 이름이 나오는 것은 상관없다(왜 안 부르는지를
    # 적어 두었다). 정규식 대신 평문 비교다.
    calls = [ln for ln in inspect.getsource(V.QCChecker._detect_ml_anomalies)
             .splitlines()
             if "self._register_flag(" in ln and not ln.lstrip().startswith("#")]
    assert not calls, \
        f"이상치 탐지가 다시 플래그를 만든다 — 2026-09-02 결정과 어긋난다: {calls}"


@pytest.mark.synthetic
def test_the_anomaly_analysis_is_kept():
    """플래그만 뺀 것이지 **분석을 지운 것이 아니다** — 비지도학습 탭이 쓴다."""
    import inspect
    src = inspect.getsource(V.QCChecker._detect_ml_anomalies)
    assert "self.ml_meta" in src and "self.ml_detail" in src


# ── 항목 3 — Check 24 양방향 ─────────────────────────────────────────────────
@pytest.mark.synthetic
@pytest.mark.parametrize("joint,proc,wps,flagged", [
    # TKY(TT)는 프로세스와 무관하게 GK를 써야 한다
    ("TT", "SMFC", "RU-SMFC-GK01", False),
    ("TT", "SMFC", "RU-SMFC-G01",  True),
    ("TT", "FCAW", "RU-FC-G01",    True),    # SMFC가 아니어도 TT면 본다
    ("TT", "FCAW", "RU-FC-GK01",   False),
    # 비TT SMFC는 GK·G 둘 다 허용 (현업 확인 2026-09-02)
    ("T",  "SMFC", "RU-SMFC-G01",  False),
    ("T",  "SMFC", "RU-SMFC-GK01", False),
    ("T",  "SMFC", "RU-SMFC-F01",  True),    # G로 시작하지 않으면 결함
    # SMFC도 TT도 아니면 이 검사가 돌지 않는다
    ("T",  "FCAW", "RU-FC-F01",    False),
])
def test_c24_joint_type_and_process(joint, proc, wps, flagged):
    c = _checker()
    row = make_row(JOINT_TYPE=joint, WPS_PROCESS=proc, WPS_NO=wps)
    got = c._c24_tky_wps(row, wps, proc)
    assert (got is not None) is flagged, \
        f"{joint}/{proc}/{wps} -> {'결함' if flagged else '통과'}이어야 한다"


# ── 항목 8 — Check 14 본용접 중복 ────────────────────────────────────────────
def _joint(i: int, *, dn="2S-CC010", block="CC011", lot="LG02",
           jn="2P01B", repair="") -> tuple[int, tuple]:
    return (i, make_row(DRAWING_NO=dn, BLOCK=block, LOT=lot,
                        JOINT_NO=jn, REPAIR_MARK=repair))


def _c14_rows(rows: list[tuple[int, tuple]]) -> set[int]:
    c = _checker(rows)
    c._detect_check14_duplicates()
    return {r for r, fl in c.row_flags.items()
            if any(f.check_no == "14" for f in fl)}


@pytest.mark.synthetic
def test_main_weld_plus_repairs_is_not_a_defect():
    """본용접 1 + 수리 N = 정상. 수리는 여러 번 나올 수 있다.

    첨부 이미지의 사례가 정확히 이것이다 — B·C·D가 같고 E열만 다르다.
    """
    assert _c14_rows([_joint(1), _joint(2, repair="U1"),
                      _joint(3, repair="U2")]) == set()


@pytest.mark.synthetic
def test_two_main_welds_is_a_defect():
    """E열이 빈 행이 둘이면 같은 이음을 두 번 등록한 것이다."""
    assert _c14_rows([_joint(1), _joint(2)]) == {1, 2}


@pytest.mark.synthetic
def test_the_flag_lands_only_on_the_main_welds():
    """수리 행에는 플래그를 붙이지 않는다 — 중복의 원인이 아니다.

    수리 행은 정규 항목을 전부 판정받지만(2026-09-03 복원), 중복의 «원인»은
    아니다 — 같은 이음에 여러 번 나오는 것이 정상이다.
    """
    assert _c14_rows([_joint(1), _joint(2),
                      _joint(3, repair="U1")]) == {1, 2}


@pytest.mark.synthetic
def test_a_different_lot_is_a_different_joint():
    """Block-Lot이 다르면 같은 Joint No라도 다른 이음이다."""
    assert _c14_rows([_joint(1, lot="LG02"), _joint(2, lot="LG03")]) == set()


@pytest.mark.synthetic
def test_a_different_block_is_a_different_joint():
    assert _c14_rows([_joint(1, block="CC011"),
                      _joint(2, block="CC012")]) == set()


@pytest.mark.synthetic
def test_a_different_drawing_is_a_different_joint():
    """도면번호는 그룹 키에 남는다.

    Joint No는 도면 안에서만 유일하다 — 같은 번호가 최대 41개 도면에 있다.
    빼면 무관한 행이 대량으로 오탐 처리된다.
    """
    assert _c14_rows([_joint(1, dn="2S-CC010"),
                      _joint(2, dn="2S-CC020")]) == set()


@pytest.mark.synthetic
def test_differing_values_alone_are_no_longer_a_defect():
    """예전 조건(재질/두께/WPS 불일치)은 **걷어냈다**(현업 결정 2026-09-02).

    되돌리면 이 테스트가 실패한다 — 실측 37,885건이 그 조건으로 나오고 있었다.
    """
    rows = [
        (1, make_row(DRAWING_NO="D1", BLOCK="B1", LOT="L1", JOINT_NO="J1",
                     MATERIAL1="A36", THICKNESS1="12", WPS_NO="RU-FC-G01")),
        (2, make_row(DRAWING_NO="D1", BLOCK="B1", LOT="L1", JOINT_NO="J1",
                     MATERIAL1="S355", THICKNESS1="30", WPS_NO="RU-FC-G02",
                     REPAIR_MARK="U1")),
    ]
    assert _c14_rows(rows) == set(), \
        "값이 다르다는 이유만으로 다시 결함이 됐다 — 본용접은 1행뿐이다"
