"""WPS 보정 레이어 — 문서값을 덮지 않고 얹는다.

보정이 조용히 틀리는 자리가 셋이다. 전부 예외가 나지 않는다:

1. **보정이 비었는데 판정이 달라진다** — 그러면 옛 회차와 비교할 수 없다
2. **보정했는데 판정이 안 달라진다** — 표기가 실데이터와 안 맞는 경우가 대부분인데,
   사용자는 고쳤다고 믿는다
3. **범위가 안 읽히는데 저장된다** — 빈/깨진 범위는 `_thickness_in_range()`가
   **참**을 주므로 «무조건 통과»가 된다. 보정으로 고치려던 문제 그 자체다
"""
from __future__ import annotations

import pytest

from backend.services import verifier as V
from backend.services import wps_overrides


# ── 조회 의미론 ──────────────────────────────────────────────────────────────

_OV = {
    "TR-SMFC-G01": {
        "materials": [
            {"id": "A500", "match": ["ASTM A500"], "range": "6~20", "note": ""},
            {"id": "", "match": ["S355KT-40"], "range": "12~50", "note": ""},
        ]
    }
}


@pytest.mark.synthetic
def test_finds_by_material_key():
    assert wps_overrides.find_material(_OV, "TR-SMFC-G01", "A500", "")["range"] == "6~20"


@pytest.mark.synthetic
def test_finds_by_free_expression_when_key_is_none():
    """**매핑표에 없는 재질이 이 기능의 존재 이유다.**

    `_get_material_key("S355KT-40")`은 `None`을 준다. 자유 표기로 못 찾으면
    그 재질은 보정을 해도 판정에 닿지 못한다.
    """
    assert V._get_material_key("S355KT-40") is None, "매핑표가 바뀌었다 — 이 시험의 전제"
    hit = wps_overrides.find_material(_OV, "TR-SMFC-G01", None, "S355KT-40")
    assert hit is not None and hit["range"] == "12~50"


@pytest.mark.synthetic
def test_material_key_wins_over_free_expression():
    """키가 있으면 키가 먼저다 — 순서가 흔들리면 예측할 수 없다."""
    hit = wps_overrides.find_material(_OV, "TR-SMFC-G01", "A500", "S355KT-40")
    assert hit["range"] == "6~20"


@pytest.mark.synthetic
def test_finds_across_project_prefix():
    """RUYA는 TRION 자료로 WPS를 만들어 앞자리만 다르다(`TR-` / `RU-`).

    `wps_rules.apply_corrections()`가 이미 같은 규칙으로 찾으므로 여기서만
    다르게 굴면 «보정이 왜 안 먹는지»를 알 방법이 없다.
    """
    assert wps_overrides.find_material(_OV, "RU-SMFC-G01", "A500", "") is not None


@pytest.mark.synthetic
def test_does_not_leak_to_other_wps_or_material():
    assert wps_overrides.find_material(_OV, "TR-FC-G01", "A500", "") is None
    assert wps_overrides.find_material(_OV, "TR-SMFC-G01", "E36", "NV A36") is None


# ── 저장 정규화 ──────────────────────────────────────────────────────────────

@pytest.mark.synthetic
def test_normalize_drops_rows_without_a_range():
    """**범위 없는 보정 행은 «무조건 통과»가 된다.**

    빈 범위를 그대로 두면 `_thickness_in_range()`가 참을 주므로, 그 재질은
    두께를 아무리 벗어나도 안 걸린다 — 보정으로 고치려던 상태 그대로다.
    """
    out = wps_overrides.normalize({"W1": {"materials": [
        {"id": "A500", "range": ""},
        {"id": "E36", "range": "3~50"},
    ]}})
    ids = [r["id"] for r in out["W1"]["materials"]]
    assert ids == ["E36"]


@pytest.mark.synthetic
def test_normalize_drops_rows_that_point_at_nothing():
    out = wps_overrides.normalize({"W1": {"materials": [
        {"id": "", "match": [], "range": "3~50"},
    ]}})
    assert "W1" not in out


@pytest.mark.synthetic
def test_normalize_drops_empty_wps_entries():
    """보정 행도 메모도 없으면 통째로 뺀다 — 빈 껍데기가 쌓이면 화면에서
    «보정됨»으로 보인다."""
    assert wps_overrides.normalize({"W1": {"materials": []}}) == {}
    assert "W1" in wps_overrides.normalize({"W1": {"materials": [], "note": "확인 중"}})


@pytest.mark.synthetic
def test_normalize_survives_garbage():
    """화면에서 온 것을 그대로 믿지 않는다."""
    assert wps_overrides.normalize(None) == {}
    assert wps_overrides.normalize({"W1": "문자열"}) == {}
    assert wps_overrides.normalize({"W1": {"materials": ["문자열"]}}) == {}


# ── 판정 연동 ────────────────────────────────────────────────────────────────

def _checker(ov: dict) -> V.QCChecker:
    """판정에 필요한 최소 상태만 세운 checker (전체 초기화는 실데이터가 필요하다)."""
    ck = V.QCChecker.__new__(V.QCChecker)
    ck._wps_overrides = ov
    ck._ov_matched = {}
    ck._rules = []
    ck._rule_problems = []
    ck._rule_matched = {}
    ck._suppressed = {}
    ck._enabled = {}
    return ck


_WPS_EMPTY_THK = {
    "process": "SMFC", "position": "All", "joint_detail": "SB, SV",
    # 실데이터에 있는 모양 — `apply_corrections`가 얹은 재질은 두께가 빈다
    "materials": [{"base_metal": "ASTM A500", "thk_range": ""}],
}


@pytest.mark.synthetic
def test_empty_document_thickness_passes_everything_without_an_override():
    """**이 시험이 보정이 필요한 이유다.**

    두께 텍스트가 비면 `_thickness_in_range()`가 참을 준다 — 그 재질은 두께를
    아무리 벗어나도 안 걸린다. 오류도 경고도 나지 않는다.
    """
    ck = _checker({})
    assert ck._c3_side(_WPS_EMPTY_THK, "TR-SMFC-G01", 999.0,
                       "ASTM A500 Gr.B", "J", 10) is None


@pytest.mark.synthetic
def test_override_makes_check3_judge_again():
    ck = _checker(_OV)
    assert ck._c3_side(_WPS_EMPTY_THK, "TR-SMFC-G01", 10.0,
                       "ASTM A500 Gr.B", "J", 10) is None
    flag = ck._c3_side(_WPS_EMPTY_THK, "TR-SMFC-G01", 25.0,
                       "ASTM A500 Gr.B", "J", 10)
    assert flag is not None
    # **번호는 3 그대로다.** 보정은 «새 판정»이 아니라 «자료의 정정»이라
    # 번호를 새로 따지 않는다 — 따면 색 정의 여섯 곳과 검토 기록 키가 흔들린다.
    assert str(flag.check_no) == "3"
    assert "보정값" in flag.msg


@pytest.mark.synthetic
def test_override_counts_the_sides_it_judged():
    """0이면 «고쳤는데 한 행도 안 걸렸다» — 표기가 실데이터와 다를 때가
    대부분이라 화면이 그걸 말할 수 있어야 한다."""
    ck = _checker(_OV)
    ck._c3_side(_WPS_EMPTY_THK, "TR-SMFC-G01", 10.0, "ASTM A500", "J", 10)
    ck._c3_side(_WPS_EMPTY_THK, "TR-SMFC-G01", 25.0, "ASTM A500", "K", 11)
    assert ck._ov_matched == {"TR-SMFC-G01": 2}


@pytest.mark.synthetic
def test_override_also_allows_the_material_for_check11():
    """**«WPS-재질-두께»는 한 구조다.**

    보정으로 재질을 얹었는데 Check 11이 모르면, 같은 행을 Check 3은 정상
    판정하고 Check 11은 «허용 재질이 아님»으로 찍는 모순이 난다.
    """
    base = ["NV A36, EN S355NH"]          # A500이 없는 허용 재질 목록
    assert _checker(_OV)._c11_check_one_material(
        _WPS_EMPTY_THK, "TR-SMFC-G01", "A500", "ASTM A500 Gr.B",
        base, 13, "M") is None
    # 보정이 없으면 지금까지와 똑같이 지적한다
    flag = _checker({})._c11_check_one_material(
        _WPS_EMPTY_THK, "TR-SMFC-G01", "A500", "ASTM A500 Gr.B",
        base, 13, "M")
    assert flag is not None and str(flag.check_no) == "11"


@pytest.mark.synthetic
def test_no_override_changes_nothing():
    """**보정이 비면 판정이 한 건도 달라지면 안 된다.** 옛 회차와 비교할 수
    있어야 하므로, 이 성질이 깨지면 회귀 기준값이 통째로 무의미해진다."""
    wps = {"process": "FCAW", "position": "All", "joint_detail": "SB",
           "materials": [{"base_metal": "NV A36", "thk_range": "A36\n: 3~24"}]}
    for thk in (2.0, 10.0, 30.0):
        got = _checker({})._c3_side(wps, "TR-FC-G01", thk, "NV-A36", "J", 10)
        exp = _checker({})._c3_thickness_side(wps, "TR-FC-G01", thk, "E36", "J", 10, "NV-A36")
        assert (got is None) == (exp is None), f"{thk}mm에서 갈렸다"
