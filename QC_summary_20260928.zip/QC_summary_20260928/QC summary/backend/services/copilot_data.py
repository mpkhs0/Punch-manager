"""Copilot 에이전트에 올릴 자료를 **서버가 한 벌로 정리해서** 내준다.

현업이 Copilot에 넣으려면 원본 엑셀 여러 개를 그대로 올려야 했다. 원본은
사람이 보라고 만든 서식이라 머리말이 여러 줄이고, 한 사람이 자격마다 한 줄씩
차지하며, 승인 용접봉은 파일이 여러 개로 나뉘어 있다. 그대로 올리면 에이전트가
같은 사람을 여러 명으로 읽거나 파일 사이의 중복을 알지 못한다.

여기서 **하나로 합쳐서** 내려준다. 합치는 규칙은 판정 엔진이 쓰는 것과 **같은
적재 코드**(`QCDataLoader`)를 거친다 — 갈라지면 「Copilot이 본 자격」과
「판정이 본 자격」이 달라지고, 그건 둘을 대조해 보기 전에는 알 수 없다.

세 가지를 만든다:

    1. Joint search      WPS 선정 근거 (JSON 본문 · .txt)   <- wps_export
    2. Welder search     용접사 자격 (사람당 1행 · .xlsx)
    3. Weld consumable   승인 용접봉 (Lot당 1행 · .xlsx)

**개인정보는 이 VM을 거치지 않는다.** 여기 있는 것은 «어떻게 정리할지»뿐이고,
사번·이름이 든 실제 파일은 회사 PC의 서버에서만 읽힌다.
"""
from __future__ import annotations

import logging
from datetime import date, datetime
from pathlib import Path
from typing import Any, Iterable

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from backend.services import verifier as svc

logger = logging.getLogger(__name__)

_HDR_FILL = PatternFill("solid", start_color="1F3864", end_color="1F3864")
_HDR_FONT = Font(color="FFFFFF", bold=True)
_NOTE_FONT = Font(color="555555", italic=True)


def _d(v: date | datetime | None) -> str:
    """날짜를 «에이전트가 읽는» 한 가지 형식으로. 비면 빈 칸이다."""
    if v is None:
        return ""
    if isinstance(v, datetime):
        v = v.date()
    return v.isoformat()


def _join(vals: Iterable[Any]) -> str:
    """집합을 정렬해 «, »로 잇는다. 집합은 순서가 없어 그대로 쓰면 매번 바뀐다 —
    파일이 매번 달라 보이면 «무엇이 바뀐 것인지» 대조할 수 없다."""
    return ", ".join(sorted({str(v).strip() for v in (vals or ()) if str(v).strip()}))


def _sheet(wb: Workbook, title: str, headers: list[str]) -> Any:
    ws = wb.create_sheet(title)
    ws.append(headers)
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill, cell.font = _HDR_FILL, _HDR_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.freeze_panes = "A2"
    return ws


def _autosize(ws: Any, widths: dict[int, int]) -> None:
    for idx, w in widths.items():
        ws.column_dimensions[get_column_letter(idx)].width = w


def _info_sheet(wb: Workbook, title: str, lines: list[tuple[str, str]],
                notes: list[str]) -> None:
    """첫 시트에 «이 파일이 무엇인가»를 적는다.

    Copilot은 시트를 순서대로 읽으므로 여기가 맨 앞이어야 한다. 없으면
    에이전트가 열 이름만 보고 뜻을 지어낸다 — 그럴듯한 오답이 제일 나쁘다.
    """
    ws = wb.create_sheet(title, 0)
    ws.append(["항목", "값"])
    for c in (1, 2):
        ws.cell(row=1, column=c).fill = _HDR_FILL
        ws.cell(row=1, column=c).font = _HDR_FONT
    for k, v in lines:
        ws.append([k, v])
    ws.append([])
    ws.append(["읽을 때 주의할 것", ""])
    ws.cell(row=ws.max_row, column=1).font = Font(bold=True)
    for n in notes:
        ws.append(["", n])
        ws.cell(row=ws.max_row, column=2).font = _NOTE_FONT
        ws.cell(row=ws.max_row, column=2).alignment = Alignment(wrap_text=True)
    _autosize(ws, {1: 26, 2: 96})


# ─── 2. Welder search ────────────────────────────────────────────────────────
def build_welder_xlsx(welder_path: Path, out: Path, *,
                      source_name: str = "", ref_date: date | None = None) -> dict:
    """용접사 자격을 **사람당 한 줄**로 편다.

    원본은 «자격 한 건 = 한 줄»이라 한 사람이 프로세스마다 반복된다. 그대로
    올리면 에이전트가 같은 사번을 여러 사람으로 읽고, 「이 사람이 FCAW를 할 수
    있나」에 그 사람의 다른 줄을 못 본 채 답한다.

    **적재는 판정 엔진과 같은 `load_welders()`를 쓴다.** 형식 판별(새/옛)도,
    같은 사람이 여러 줄일 때 «가장 이른 만료일»을 쓰는 규칙도 그대로 따라온다.
    여기서 다시 구현하면 두 곳이 갈라진다.
    """
    ref = ref_date or date.today()
    loader = svc.QCDataLoader()
    layout = loader.load_welders(welder_path)
    if not layout:
        raise ValueError("용접사 번호와 Process를 한 건도 찾지 못했습니다")

    wb = Workbook()
    wb.remove(wb.active)
    ws = _sheet(wb, "용접사 자격", [
        "용접사번호", "이름", "보유 프로세스", "자세(Position)",
        "자격규격", "자격번호", "선급",
        "최초 자격일", "최근 자격일", "만료일", "박탈일", "유효 만료일",
        "자격 상태", "퇴사",
    ])

    n_valid = n_expired = n_unknown = 0
    for no in sorted(loader.welder_qual):
        q    = loader.welder_qual[no]
        cert = loader.welder_certs.get(no) or {}
        exp  = loader.welder_expiry.get(no) or {}
        eff  = exp.get("effective")
        # 상태는 세 가지다 — «만료일이 없다»를 «유효»로 뭉개면 자료의 빈칸이
        # 사라진다. 그 빈칸 자체가 Check 7이 지적하는 결함이다.
        if eff is None:
            status = "만료일 없음"
            n_unknown += 1
        elif eff >= ref:
            status = "유효"
            n_valid += 1
        else:
            status = "만료"
            n_expired += 1
        ws.append([
            no,
            cert.get("name") or loader.welder_names.get(no, ""),
            _join(q.get("process")),
            _join(q.get("position")),
            _join(cert.get("specs")),
            _join(cert.get("cert_nos")),
            _join(cert.get("classes")),
            _d(cert.get("first_cert_date")),
            _d(cert.get("last_cert_date")),
            _d(exp.get("expire")),
            _d(exp.get("disq")),
            _d(eff),
            status,
            "퇴사" if no in loader.retired_welders else "",
        ])
    ws.auto_filter.ref = ws.dimensions
    _autosize(ws, {1: 14, 2: 24, 3: 22, 4: 16, 5: 16, 6: 20, 7: 12,
                   8: 13, 9: 13, 10: 13, 11: 13, 12: 13, 13: 13, 14: 8})

    _info_sheet(wb, "정보", [
        ("자료", "용접사 자격 (Welder search)"),
        ("원본 파일", source_name or Path(welder_path).name),
        ("읽은 형식", layout),
        ("만든 시각", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        ("자격 상태 기준일", ref.isoformat()),
        ("용접사 수", f"{len(loader.welder_qual):,}명"),
        ("유효 / 만료 / 만료일없음", f"{n_valid:,} / {n_expired:,} / {n_unknown:,}"),
    ], [
        "원본은 «자격 한 건 = 한 줄»이라 한 사람이 여러 줄이다. 이 파일은 "
        "사람당 한 줄로 합쳤고, 보유 프로세스·자세·자격번호는 그 사람의 모든 "
        "줄을 모은 것이다.",
        "「유효 만료일」은 만료일과 박탈일 중 **이른 쪽**이다. 늦은 쪽을 쓰면 "
        "자격이 없던 기간을 놓친다.",
        "「만료일 없음」은 «무기한 유효»가 아니라 **자료에 만료일이 비어 있다**는 "
        "뜻이다. 유효한 것으로 읽지 마라.",
        "「자격 상태」는 위 기준일로 계산한 값이다. 날짜가 지나면 다시 내려받아라.",
        "프로세스 표기 SMFC = SMAW + FCAW, GTFC = GTAW + FCAW, "
        "FCSA = FCAW + SAW, GMSA = GMAW + SAW. 같은 뜻을 «SMAW+FCAW»처럼 "
        "풀어 적은 자료도 있다.",
        "퇴사 여부는 자격 유무와 별개다 — 퇴사자도 자격은 유효할 수 있다.",
    ])
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)
    return {"welders": len(loader.welder_qual), "layout": layout,
            "valid": n_valid, "expired": n_expired, "unknown": n_unknown}


# ─── 3. Weld consumable search ───────────────────────────────────────────────
def build_consumable_xlsx(files: list[dict], out: Path) -> dict:
    """승인 용접봉을 **Lot당 한 줄**로. 여러 파일을 합치고 중복을 없앤다.

    현업은 승인 리스트를 여러 벌 나눠 받는다(제조사별·시기별). 그대로 올리면
    에이전트가 파일 사이의 중복을 모르고, 「이 Lot이 승인됐나」에 파일 하나만
    보고 답한다.

    `files`는 `{"filename", "lots", (선택) "columns", "rows"}` 목록이다.
    `rows`가 있으면 원본 열을 그대로 싣는다 — 없으면(옛 캐시) Lot 번호만
    싣는다. **Lot 번호만이라도 합쳐 주는 것이 원본 여러 개보다 낫다.**
    """
    # 원본 열이 하나라도 있으면 그 열 이름을 쓴다. 파일마다 열이 다르면
    # 합집합을 쓰되 **순서는 먼저 본 파일 기준**이다 — 정렬하면 원본과 달라져
    # 대조가 안 된다.
    columns: list[str] = []
    for f in files:
        for c in (f.get("columns") or []):
            if c and c not in columns:
                columns.append(str(c))

    wb = Workbook()
    wb.remove(wb.active)
    headers = ["Lot No", "출처 파일"] + columns
    ws = _sheet(wb, "승인 용접봉", headers)

    seen: dict[str, list[str]] = {}     # Lot -> 그 Lot이 나온 파일들
    rows_by_lot: dict[str, list[Any]] = {}
    for f in files:
        fname = f.get("filename") or ""
        by_lot = {str(r.get("lot", "")).strip().upper(): r
                  for r in (f.get("rows") or []) if r.get("lot")}
        for lot in (f.get("lots") or []):
            key = str(lot).strip().upper()
            if not key:
                continue
            seen.setdefault(key, [])
            if fname and fname not in seen[key]:
                seen[key].append(fname)
            if key not in rows_by_lot and key in by_lot:
                cells = by_lot[key].get("cells") or {}
                rows_by_lot[key] = [cells.get(c, "") for c in columns]

    for lot in sorted(seen):
        ws.append([lot, " / ".join(seen[lot])]
                  + (rows_by_lot.get(lot) or [""] * len(columns)))
    ws.auto_filter.ref = ws.dimensions
    _autosize(ws, {1: 26, 2: 34, **{i: 18 for i in range(3, len(headers) + 1)}})

    dup = sum(1 for v in seen.values() if len(v) > 1)
    _info_sheet(wb, "정보", [
        ("자료", "승인 용접봉 (Weld consumable search)"),
        ("원본 파일 수", f"{len(files)}개"),
        ("원본 파일", " / ".join(f.get("filename") or "(이름 없음)" for f in files)),
        ("만든 시각", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        ("승인 Lot 수", f"{len(seen):,}개 (중복 제거 후)"),
        ("둘 이상의 파일에 있는 Lot", f"{dup:,}개"),
        ("원본 열 포함", "예" if columns else "아니오 — Lot 번호만"),
    ], [
        "여러 파일을 합치고 같은 Lot은 한 줄로 묶었다. 「출처 파일」이 그 Lot이 "
        "어느 목록에서 왔는지 말한다.",
        "**이 목록에 없는 Lot은 «승인되지 않은 것»이다.** 다만 목록 자체가 "
        "최신인지는 이 파일로 알 수 없다 — 만든 시각을 함께 보라.",
        "혼합 프로세스(SMFC·GTFC·FCSA·GMSA) 이음은 용접재료를 **두 종** 쓴다. "
        "실제 기재는 쉼표·슬래시 등으로 이어 적는다 "
        "(예: 10007488BB22CA1/F902A5B5A7).",
    ] + ([] if columns else [
        "원본의 나머지 열은 이 서버에 보관돼 있지 않아 싣지 못했다. 승인 "
        "리스트를 다시 올리면 그때부터 원본 열이 함께 실린다.",
    ]))
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)
    return {"lots": len(seen), "files": len(files), "columns": len(columns),
            "duplicated": dup}
