"""Copilot 이 조회할 «조인트 자료» — raw data 의 A~V 열만, 블록별로 나눠서.

## 왜 나누나

현업이 원본 엑셀을 통째로 올려 조회했더니 너무 느렸다. 실측(TRION 32,994행):

    A~V 18열만 추려도 JSON 9.23 MB
    블록(B열)으로 나누면 블록당 평균 143 KB · 최대 1.2 MB

## 조회 열쇠는 «한 문자열»이어야 한다

Block·Lot·Joint No 를 따로 두면 받는 쪽이 「CV261/FR01/1P02T」를 글자로
찾지 못한다 — 그런 문자열이 파일에 아예 없기 때문이다. 실제로 블록 파일은
찾았는데 그 안에서 행을 못 집었다. 그래서 `lookup_key` 를 **행 맨 앞**에
둔다. 앞자리가 곧 블록 이름이자 파일 이름이라, 열쇠만 보고 어느 파일을
열지도 알 수 있다.

## 나누기만 하면 오히려 느려진다 — 색인이 함께 있어야 한다

조회 열쇠가 **Block · Lot · Joint No** 셋인데(현업 확인 2026-09-18), 그중
블록만 파일 이름으로 바로 풀린다. 나머지 둘은 블록을 가로지른다. 실측:

    Lot(C열)        575개 중 444개(77%)가 블록 여럿에 걸쳐 있다
    Joint No(D열) 6,778개 중 3,111개(46%)

색인이 없으면 「이 Lot 조회」에 에이전트가 **66개를 전부 열어 본다** — 한
덩어리일 때보다 나쁘다. 그래서 `_index` 파일이 «무엇 -> 어느 블록»을 준다.

## 도면번호는 «열쇠»가 아니지만 «값»으로는 남긴다

조회에 쓰지 않으므로 색인에서 뺐다. 다만 행에서는 빼지 않는다 —
**(Block, Lot, Joint No) 셋이 유일하지 않기 때문**이다. 실측 30,871개 조합 중
522개(1.7%)에 행이 여럿 걸리고, 그중 457개는 도면번호로만 갈린다(한 조합에
최대 13행). 이 값을 빼면 그 522건에서 **여러 줄이 똑같아 보여** 고를 수가
없다. 값으로 두는 비용은 1.0 MB(12%)다.

## 실적(AJ 이후)은 담지 않는다

현업 목적이 **작업 예정 물량의 A~V 를 확인하고 그 정보로 WPS 를 추천**하는
것이다(2026-09-18). 실제로 쓴 WPS 를 함께 주면 에이전트가 그 답을 그대로
베끼는데, **계획 단계 조인트에는 그 값이 없다** — 추천이 «맞는 것처럼 보이지만
쓸모없어»진다. `planned` 한 칸만 둔다(WPS 가 배정됐는가 / 아직인가).

## 쓸 수 있는 WPS 를 **프로그램이 계산해서 적어 준다**

에이전트에게 추론시키면 느리고, 판정과 갈라진다. 대신 판정 함수를 그대로
불러 «이 행에 이 WPS 를 쓰면 지적받는가»를 26~36종에 전부 물어 통과한 것만
적는다(현업 결정 2026-09-18).

검증했다 — 누락 458건이 **전부** 엔진도 지적하는 행이었다(설명 안 되는 누락
0건). 즉 이 목록은 «엔진이 통과시킬 WPS» 와 **정확히 같다.**

계산은 «서명»(재질·두께·Groove·Type·수리)으로 memo 한다 — 실측 32,975행이
서명 572개라 161초가 2.6초가 된다.

**이름과 사유는 행에 그대로 적는다.** 한때 색인에 집합표를 두고 행에는 번호만
넣어 0.13 MB 로 줄였는데, 받는 쪽이 그 번호를 그대로 답했다(「WPS: 6」).
사유를 안 주었을 때도 「같은 JSON 레코드에서 확인된 값입니다」라고만 답했다 —
그건 사유가 아니다. **가볍게 만들려다 쓸모를 잃으면 안 된다.**

실측(TRION): 전체 25.8 MB · 최대 블록 3.2 MB · 색인 25 KB. 조회는 색인 25 KB
와 블록 하나만 열면 되고, 블록 중앙값은 190행이다.

## 확장자는 `.txt` 다

내용은 JSON 이지만 Copilot 이 지식 파일로 `.txt` 만 인식한다. 1번 폴더의
WPS 선정 근거와 같은 처리다.
"""
from __future__ import annotations

import json
import logging
from collections import Counter, defaultdict
from datetime import date, datetime
from pathlib import Path
from typing import Any

from openpyxl.utils import get_column_letter

from backend.services import verifier as V, wps_rules
from backend.services.wps_export import _INPUT_COLS

logger = logging.getLogger(__name__)

SCHEMA = "qc-joint-search/1"
INDEX_NAME = "_index.txt"
# Joint No 색인은 **따로 뺀다.** 실측으로 색인 345 KB 중 295 KB 가 이것 하나였다
# (Joint No 6,778개). 도면번호·Lot·블록으로 찾는 흔한 경우까지 그 무게를 늘
# 지고 가면, 나누어 놓은 뜻이 없어진다. 필요할 때만 이 파일을 연다.
JOINT_INDEX_NAME = "_index_joint.txt"

# **들여쓰기를 넣지 않는다.** 읽는 쪽이 사람이 아니라 에이전트라 보기 좋을
# 이유가 없고, 실측으로 블록 파일 24% · 색인 35% 가 공백이었다.
_COMPACT = {"ensure_ascii": False, "separators": (",", ":")}
_UNNAMED = "(블록없음)"


def _cell(v: Any) -> Any:
    """JSON 에 담을 수 있는 값으로. 날짜는 ISO 로 편다."""
    if isinstance(v, (datetime, date)):
        return v.isoformat()[:10]
    if isinstance(v, str):
        return v.strip()
    return v


def _safe(name: str) -> str:
    """블록 이름을 파일명으로. 실데이터 66개는 전부 안전했지만 **확인은 한다** —
    `Q530-SMR/ITER생산부` 같은 값이 다른 열에 실재한다."""
    out = "".join("_" if c in '\\/:*?"<>|' else c for c in name).strip(" .")
    return out or "_"


def _block_text(block: str, rows: list[dict]) -> str:
    """블록 파일 본문 — «열쇠 + 자료»가 한 줄, 사이에 빈 줄.

    **한 덩어리 JSON 이 아니다.** 받는 쪽(Copilot)이 글자로 찾기 때문이다:

        CV261/FR01/1P02T {"row":6,"drawing_no":"...","block":"CV261",...}

        CV261/LG05/1P01E8 {"row":7,...}

    ## 두 번 고쳤다 — 둘 다 받는 쪽이 «못 찾는다»여서다

        ① Block·Lot·Joint No 를 따로 둠   -> 「CV261/FR01/1P02T」가 파일에 없다
        ② `lookup_key: <열쇠>` 를 앞 줄에 -> 두 줄로 갈라 두니 그것도 못 읽는다

    지금은 **줄 맨 앞이 곧 열쇠**이고 같은 줄에 자료가 온다. 사이의 빈 줄이
    «어디서 한 행이 끝나는지»를 보여 준다.

    열쇠 뒤의 JSON 은 **그대로 올바른 JSON** 이다 — 첫 `{` 부터 떼어 읽으면
    된다. 열쇠는 줄 앞에 있으므로 JSON 안에 되풀이하지 않는다.
    """
    head = [
        f"# block: {block}",
        f"# rows: {len(rows)}",
        "# 각 줄: Block/Lot/JointNo 다음에 그 조인트의 자료가 옵니다.",
        "",
    ]
    body = []
    for r in rows:
        key = r.pop("lookup_key")
        body.append(f"{key} {json.dumps(r, **_COMPACT)}")
    # 머리말 뒤에도 빈 줄 한 줄 — 레코드 사이와 같은 간격이라야 경계가 고르다
    return "\n".join(head) + "\n" + "\n\n".join(body) + "\n"


def _signature(row: tuple) -> tuple:
    """판정 결과가 같아지는 «조건». 이게 같으면 답도 같다."""
    return (V._clean(V._row_val(row, V.Col.MATERIAL1)),
            V._clean(V._row_val(row, V.Col.MATERIAL2)),
            V._row_val(row, V.Col.THICKNESS1),
            V._row_val(row, V.Col.THICKNESS2),
            V._clean(V._row_val(row, V.Col.GROOVE)).upper(),
            V._clean(V._row_val(row, V.Col.JOINT_TYPE)).upper(),
            V._is_repair(row))


def _loose(row: tuple) -> tuple:
    """두께를 뺀 열쇠. 같은 조건의 시공분이 없을 때 **물러설 자리**다.

    계획 물량의 24%가 여기서만 근거를 찾는다(실측 TRION). 추천의 진짜 대상이
    계획 물량이라, 이 자리를 비우면 정작 필요한 곳에서 못 준다. 다만 근거가
    약하므로 **사유에 그렇게 적는다.**
    """
    return (V._clean(V._row_val(row, V.Col.MATERIAL1)),
            V._clean(V._row_val(row, V.Col.GROOVE)).upper(),
            V._clean(V._row_val(row, V.Col.JOINT_TYPE)).upper(),
            V._is_repair(row))


def _repair_wps(wps_no: str) -> bool:
    """수리용 WPS 인가 — **Check 23 의 기준 그대로** 끝에서 세 번째 문자가 `R`.

    `_is_repair_wps()`(프로파일 접두사)와 축이 다르다. 그쪽은 «Check 2·4·11 을
    건너뛸 WPS 인가»이고, 여기는 «수리 시공에 써야 할 WPS 인가»다. 접두사로
    물으면 수리 WPS 가 4·11 을 건너뛰어 **모든 행의 후보로 올라온다.**
    """
    return len(wps_no) >= 3 and wps_no[-3].upper() == "R"


def _allowed(chk: "V.QCChecker", wps_table: dict, row: tuple) -> list[str]:
    """이 행에 **그 WPS 를 쓰면 지적받지 않는가**. 판정 함수를 그대로 부른다.

    여기서 다시 구현하면 추천과 판정이 갈라져 「추천대로 썼는데 결함」이
    나오고, 원인을 짚을 길이 없다.

    **«엔진이 통과시킬 WPS 와 정확히 같다»고는 말할 수 없다.** 두 가지가
    다르다:

        수리 축   Check 23 을 목록으로 묻지 않고 **게이트**로 쓴다. 그래서
                  「비수리 행 × 수리 WPS」가 후보에서 빠지는데, 엔진은 그
                  조합을 지적하지 않는다(Check 23 은 반대 방향만 본다).
                  추천으로는 이쪽이 맞다 — 본용접에 수리 WPS 를 권할 수 없다.

        Check 2   AK열(실적)과 등록부를 대조하는 검사다. 계획 행에는 AK 가
                  없고, 있더라도 «이 후보를 썼다면»이 아니라 «지금 쓴 것»을
                  보는 것이라 추천에는 쓸 수 없다.

        Check 21  «이 WPS 가 이 이음에 맞는가»가 아니라 **«용접재를 둘 적었는가»**
                  다 — 기록 품질이지 적합성이 아니다. 혼합 프로세스를 골랐으면
                  용접재를 둘 적는 것이 따라오는 일이지, 그 때문에 WPS 를 바꿀
                  일이 아니다. 계획 행은 AL 이 비어 있어 애초에 걸리지도 않는다.

                  **게다가 AL 열은 서명에 없다.** 넣으면 같은 서명인데 답이
                  달라져 memo 가 틀린 답을 퍼뜨린다(실제로 132건이 그랬다).
    """
    repair_row = V._is_repair(row)
    out: list[str] = []
    for no in sorted(wps_table):
        # 기량시험용은 생산 조인트에 권하지 않는다
        if _is_test_wps(no):
            continue
        # 수리 시공에는 수리 WPS 를, 본용접에는 본용접 WPS 를 (Check 23)
        if repair_row != _repair_wps(no):
            continue
        skip = V._is_repair_wps(no)
        # **그 WPS 를 썼다면의 프로세스**다. AK열(실적)이 아니라 등록부 값을
        # 쓴다 — 계획 행에는 AK 가 없고, 있더라도 «지금 쓴 것»이지 «이 후보를
        # 썼다면»이 아니다.
        prc = (wps_table[no].get("process") or "")
        if any(f is not None for f in (
                chk._c11_material_not_allowed(row, no, skip),
                chk._c3_thickness(row, no),
                chk._c4_groove(row, no, skip),
                chk._c24_tky_wps(row, no, prc),
                chk._c25_q01_joint_type(row, no),
                chk._c27_dissimilar_grade(row, no),
                # ── WPS 를 지목하는 나머지 «적합성» 검사 ───────────────
                # 빼 두었더니 후보가 엔진보다 헐거웠다. 셋 다 서명에 든 열만
                # 읽으므로(재질·두께·Groove) memo 가 성립한다.
                chk._c8_tr_fc_g03(row, no),
                chk._c9_tr_smfc_g01(row, no),
                chk._c20_api_groove_process(row, prc))):
            continue
        out.append(no)
    return out


# 용접사 **기량시험용** WPS — 생산 조인트에 권하면 안 된다.
#
# 판정 기준(재질·두께·Groove)으로는 보통 WPS 와 구별되지 않아 후보로 통과한다.
# TRION 등록부의 `TR-FC-G51\n(Welder Test)` 가 계획 131행 중 84행에서 후보였다.
# 지금은 시공 이력이 0건이라 추천되지 않지만, 누가 한 번이라도 그것으로 기록을
# 남기면 1위로 올라올 수 있다 — 그러면 시험용 WPS 를 생산에 권하게 된다.
#
# **프로젝트 값이 아니라 용접 용어다.** `FILLET`을 코드가 아는 것과 같은 이유로
# 여기 둔다(CLAUDE.md 참조). 다만 표기가 다른 프로젝트에는 안 걸리므로,
# **무엇을 뺐는지 색인에 적어** 조용히 사라지지 않게 한다.
_TEST_WPS_MARKERS = ("WELDER TEST", "WELDERTEST", "기량시험")


def _is_test_wps(wps_no: str) -> bool:
    up = _oneline(wps_no).upper()
    return any(m in up for m in _TEST_WPS_MARKERS)


def _oneline(text: str) -> str:
    """줄바꿈을 지운다 — **한 줄 = 한 레코드** 형식을 깨지 않으려고.

    실데이터의 WPS 이름에 줄바꿈이 있다(`TR-FC-G51\n(Welder Test)`). 문구에
    그대로 실리면 받는 쪽이 파일을 못 읽는다.
    """
    return " ".join(str(text or "").split())


def _fit(w: dict, thk: float | None, groove: str) -> str:
    """그 WPS 가 이 행에 «쓸 수 있는» 이유 — 두께 구간 · Groove · 프로세스."""
    bits: list[str] = []
    hit = None
    for m in (w.get("materials") or []):
        for lo, hi in V._parse_thickness_ranges(m.get("thk_range") or ""):
            if thk is not None and lo <= thk <= hi:
                hit = (lo, hi)
                break
        if hit:
            break
    bits.append(f"두께 {hit[0]:g}~{hit[1]:g}mm 허용" if hit else "두께 자료 없음")
    toks = V._joint_detail_tokens(w.get("joint_detail") or "")
    if groove:
        gu = groove.upper()
        alias = {gu} | {a.upper() for a in wps_rules.groove_aliases().get(gu, set())}
        m2 = sorted(alias & toks)
        if m2:
            bits.append(f"Groove {gu}" if m2[0] == gu else f"Groove {gu}={m2[0]}")
    prc = (w.get("process") or "").strip()
    if prc:
        bits.append(prc)
    return " · ".join(bits)


def _recommend(loader: "V.QCDataLoader", wps_table: dict,
               live: list[tuple[int, tuple]]) -> tuple[dict[int, list[str]], dict]:
    """행마다 «쓸 만한 WPS 상위 2개»와 사유. (행번호 -> 문구들, 품질 수치).

    ## 점수는 «지어내지 않는다» — 과거에 실제로 무엇을 썼는가로 매긴다

    같은 조건(재질·두께·Groove·Type·수리)의 시공분이 고른 WPS 를 센다.
    가중치를 사람이 정하면 그럴듯한 오답이 된다. 실측(TRION 32,842행,
    자기 행을 뺀 leave-one-out):

        상위 2개 안에 실제값   98.3%
        1위가 실제값           84.9%

    **판정을 통과하지 못하는 WPS 는 이력에 있어도 뺀다**(실측 2,748건).
    과거의 실수를 되풀이하지 않는다.

    ## 근거가 있는 만큼만 준다

    서명 562개 중 **507개는 과거에 쓴 WPS 가 하나뿐**이다. 그 자리에 2개를
    채우려면 이력 0건인 WPS 를 넣어야 하는데, 그건 «써도 된다»이지 «이걸
    쓴다»가 아니다 — 현업 결정(2026-09-21)으로 **근거 있는 만큼만** 준다.

    ## 근거가 없으면 두께를 빼고 다시 본다

    계획 물량의 24%가 그 자리다(실측). 추천의 진짜 대상이 계획 물량이라
    비워 두면 정작 필요한 곳에서 못 준다. 대신 사유에 «두께 다름»을 적어
    근거가 약하다는 것을 숨기지 않는다.
    """
    # **취사선택과 프로젝트 규칙을 스텁으로 덮지 않는다.** 둘 다 지연 로딩이라
    # 그냥 두면 판정과 같은 것을 읽는다. 한때 `chk._rules = []` 로 비워 두었다가
    # **프로파일의 프로젝트 규칙(101~199)이 통째로 꺼졌다** — 시험용 코드를
    # 그대로 옮긴 것이었다. 실측(TRION)으로 `TR-FC-G05` 가 Check 105(두께
    # 3~25mm)에 걸리는데도 742행에서 후보로 올라왔다. 오류도 경고도 없었다.
    chk = V.QCChecker(loader)

    # ── 이력 ────────────────────────────────────────────────────────────
    exact: dict[tuple, Counter] = defaultdict(Counter)
    loose: dict[tuple, Counter] = defaultdict(Counter)
    for _rn, row in live:
        used = V._clean(V._row_val(row, V.Col.WPS_NO))
        if used and used in wps_table:
            exact[_signature(row)][used] += 1
            loose[_loose(row)][used] += 1

    ok_of: dict[tuple, list[str]] = {}
    out: dict[int, list[str]] = {}
    n_exact = n_loose = n_none = 0

    # **계획 행에만 붙인다.** 시공분은 이미 WPS 가 들어가 있어 추천할 이유가
    # 없다(현업 확인 2026-09-21). 시공분은 «이력»으로만 쓴다.
    #
    # 덤으로 실적 행에서 나던 문제가 사라진다 — Check 21 모순 551건도
    # 전부 시공분이었다.
    for row_num, row in live:
        if not V._is_unworked(row):
            continue
        sig = _signature(row)
        if sig not in ok_of:
            ok_of[sig] = _allowed(chk, wps_table, row)
        ok = set(ok_of[sig])
        if not ok:
            n_none += 1
            continue

        hist = Counter({k: v for k, v in exact.get(sig, {}).items() if k in ok})
        weak = False
        if not hist:
            hist = Counter({k: v for k, v in loose.get(_loose(row), {}).items()
                            if k in ok})
            weak = bool(hist)
        if not hist:
            n_none += 1
            continue
        n_loose += 1 if weak else 0
        n_exact += 0 if weak else 1

        total = sum(hist.values())
        thk = V._to_float(V._row_val(row, V.Col.THICKNESS1))
        grv = V._clean(V._row_val(row, V.Col.GROOVE))
        texts: list[str] = []
        for no, cnt in hist.most_common(2):
            pct = round(cnt / total * 100)
            base = (f"같은 조건 {total}건 중 {cnt}건({pct}%) 사용" if not weak
                    else f"두께 다름 · 비슷한 조건 {total}건 중 {cnt}건({pct}%) 사용")
            # **WPS 이름에 줄바꿈이 들어 있을 수 있다.** 실데이터에
            # `TR-FC-G51\n(Welder Test)` 가 있다 — 그대로 실으면 «한 줄 =
            # 한 레코드» 형식이 깨져 받는 쪽이 파일을 못 읽는다.
            texts.append(f"{_oneline(no)} — {base} · "
                         f"{_oneline(_fit(wps_table[no], thk, grv))}")
        out[row_num] = texts

    # ── 품질 수치 — **그 서버의 자료로 잰다** ───────────────────────────
    #
    # 내 개발 데이터(TRION)의 수치를 붙이면 그건 거짓말이 된다.
    # 자기 행을 빼고(leave-one-out) 재야 부풀려지지 않는다.
    # **시공분 «전부»를 대조한다.** 계획 행과 같은 서명만 재면 그건 유리한
    # 쪽만 고른 값이다(실측: 그렇게 재니 8,887행에 100%, 전부 재니 32,362행에
    # 98.3%). 낮은 쪽이 정직하다.
    hit = top1 = judged = 0
    for _rn, row in live:
        used = V._clean(V._row_val(row, V.Col.WPS_NO))
        if not used or used not in wps_table:
            continue
        sig = _signature(row)
        if sig not in ok_of:
            ok_of[sig] = _allowed(chk, wps_table, row)
        c = Counter({k: v for k, v in exact.get(sig, {}).items()
                     if k in set(ok_of.get(sig, ()))})
        c[used] -= 1
        c = Counter({k: v for k, v in c.items() if v > 0})
        if not c:
            continue
        judged += 1
        ranked = [k for k, _v in c.most_common(2)]
        if used in ranked:
            hit += 1
        if ranked and used == ranked[0]:
            top1 += 1

    excluded = sorted(_oneline(n) for n in wps_table if _is_test_wps(n))
    quality = {
        # **무엇을 뺐는지 밝힌다.** 조용히 빼면 「왜 이 WPS 가 안 나오나」를
        # 되짚을 길이 없다.
        "excluded_test_wps": excluded,
        "applies_to": ("**계획 행(WPS 미배정)에만** 붙는다. 시공분은 이미 WPS 가 "
                       "들어가 있어 추천할 이유가 없고, «이력»으로만 쓴다."),
        "method": ("같은 조건(재질·두께·Groove·이음Type·수리)의 과거 시공분이 "
                   "고른 WPS 를 센다. 판정을 통과하지 못하는 것은 뺀다."),
        "measured_on": "이 서버의 이 QMG 자료",
        "checked_rows": judged,
        "checked_note": ("계획 행이 아니라 **시공분 전부**를 대조한 값이다. "
                         "계획 행과 같은 조건만 재면 유리한 쪽만 고른 값이 된다."),
        "top2_accuracy_pct": round(hit / judged * 100, 1) if judged else None,
        "top1_accuracy_pct": round(top1 / judged * 100, 1) if judged else None,
        "note": ("자기 행을 빼고 잰 값이다(leave-one-out). 「실제로 쓴 WPS 가 "
                 "추천 안에 있었는가」를 **시공분으로 되짚은** 것이다 — "
                 "계획 행에는 정답이 없으므로 이것이 가장 가까운 대리 측정이다."),
        "rows_with_recommendation": len(out),
        "rows_from_exact_match": n_exact,
        "rows_from_loose_match": n_loose,
        "rows_without_basis": n_none,
    }
    return out, quality


def build(qmg_path: str | Path, out_root: Path, *,
          wps_table: dict[str, dict] | None = None,
          wps_source: str = "",
          today: date | None = None) -> dict[str, Any]:
    """블록별 파일 + 색인을 «날짜 폴더»에 쓴다. 만든 것의 요약을 돌려준다.

    **덮어쓰지 않는다.** 같은 날 두 번 만들면 `_2`, `_3` 으로 새 폴더를 판다.
    덮어쓰면 블록이 줄어든 회차에서 옛 블록 파일이 남아, 사라진 물량이 그대로
    조회된다 — 오류도 경고도 없다.
    """
    loader = V.QCDataLoader()
    loader.load_qmg(qmg_path)
    if wps_table:
        loader.wps_table = dict(wps_table)
    live = [(rn, r) for rn, r in loader.qmg_rows if not V._is_deleted(r)]

    # 쓸 만한 WPS 상위 2개. WPS 목록이 없으면 그 칸을 **아예 두지 않는다** —
    # 빈 목록을 주면 받는 쪽이 «쓸 WPS 가 없다»로 읽는다.
    rec_of: dict[int, list[str]] = {}
    quality: dict[str, Any] = {}
    if wps_table:
        rec_of, quality = _recommend(loader, wps_table, live)

    cols = [(col, key) for col, key, _n, _t in _INPUT_COLS]
    blocks: dict[str, list[dict]] = {}
    by_joint: dict[str, set[str]] = {}
    by_lot: dict[str, set[str]] = {}
    deleted = planned = 0

    for row_num, row in loader.qmg_rows:
        # 삭제 행은 담지 않는다 — 없는 물량을 조회하게 된다.
        if V._is_deleted(row):
            deleted += 1
            continue
        vals = {key: _cell(V._row_val(row, col)) for col, key in cols}

        # ── 조회 열쇠를 **한 문자열로** 맨 앞에 둔다 ──────────────────────
        #
        # Block·Lot·Joint No 가 따로 있으면 받는 쪽이 「CV261/FR01/1P02T」를
        # 글자로 찾지 못한다 — 그런 문자열이 파일에 아예 없기 때문이다.
        # 실제로 블록 파일은 찾았는데 그 안에서 행을 못 집었다.
        #
        # 맨 앞에 두는 이유: 앞자리가 곧 블록 이름이라 **파일 이름과 이어진다.**
        # 열쇠만 보고 어느 파일을 열지 알 수 있다.
        rec: dict[str, Any] = {
            "lookup_key": "/".join(str(vals.get(k) or "")
                                   for k in ("block", "lot", "joint_no")),
            "row": row_num,
        }
        for _col, key in cols:
            val = vals.get(key)
            if val not in (None, ""):
                rec[key] = val
        # **WPS 가 배정됐는가**만 말한다. 어느 WPS 인지는 담지 않는다 —
        # 담으면 에이전트가 추천 대신 그 값을 베낀다.
        is_planned = V._is_unworked(row)
        rec["planned"] = is_planned
        if is_planned:
            planned += 1
        # **맨 뒤에 둔다.** 조인트 정보 다음에 이어지는 것이 읽는 순서다.
        if row_num in rec_of:
            rec["rec"] = rec_of[row_num]

        blk = V._clean(V._row_val(row, V.Col.BLOCK)) or _UNNAMED
        blocks.setdefault(blk, []).append(rec)
        # 조회 열쇠는 **Block · Lot · Joint No 셋**이다(현업 확인 2026-09-18).
        # 블록은 파일 이름이 곧 답이라 색인이 필요 없다.
        for key, table in ((rec.get("joint_no"), by_joint),
                           (rec.get("lot"), by_lot)):
            if key:
                table.setdefault(str(key), set()).add(blk)

    # ── 날짜 폴더 ──────────────────────────────────────────────────────
    stamp = (today or date.today()).isoformat()
    out_dir = out_root / stamp
    n = 2
    while out_dir.exists():
        out_dir = out_root / f"{stamp}_{n}"
        n += 1
    out_dir.mkdir(parents=True)

    files: list[dict[str, Any]] = []
    used: dict[str, str] = {}
    for blk in sorted(blocks):
        fname = f"{_safe(blk)}.txt"
        if fname in used.values():                 # 정제 후 이름이 겹치면
            fname = f"{_safe(blk)}_{len(used)}.txt"
        used[blk] = fname
        rows = blocks[blk]
        path = out_dir / fname
        # **UTF-8, BOM 없음.** 받는 쪽이 그렇게 읽는다.
        path.write_text(_block_text(blk, rows), encoding="utf-8")
        files.append({"block": blk, "file": fname, "rows": len(rows),
                      "planned": sum(1 for r in rows if r["planned"]),
                      "bytes": path.stat().st_size})

    index = {
        "schema": SCHEMA,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": Path(qmg_path).name,
        "purpose": (
            "raw data 의 계획 정보(A~V)를 블록별로 나눈 것. 조인트를 찾고, "
            "그 정보로 «쓸 수 있는 WPS»를 고르는 데 쓴다 — WPS 판단 근거는 "
            "별도 파일(WPS 선정 근거)에 있다."),
        "how_to_use": [
            "조회 열쇠는 **Block/Lot/JointNo** 를 이은 한 문자열이다"
            "(예: `CV261/FR01/1P02T`). **그 문자열을 그대로 찾아라** — 세 값을 "
            "따로 맞추려 들면 못 찾는다.",
            "블록 파일은 **한 덩어리 JSON 이 아니다.** 한 줄이 «열쇠 + 빈칸 + "
            "자료 JSON»이고 줄 사이에 빈 줄이 있다. 열쇠로 줄을 찾고 그 줄의 "
            "첫 `{` 부터 읽어라.",
            "열쇠의 **앞자리가 곧 블록 이름이자 파일 이름**이다 "
            "(`CV261/...` -> `CV261.txt`). 열쇠만 보고 어느 파일을 열지 알 수 "
            "있다.",
            "행 끝의 `rec` 가 **이 조인트에 쓸 만한 WPS** 다. 이 프로그램이 "
            "판정 기준과 과거 시공 실적으로 이미 골라 두었다 — **다시 추론하지 "
            "말고 그 문구를 그대로 보여 줘라.**",
            "`rec` 는 **`planned` 가 true 인 행에만** 있다. 이미 시공된 행은 "
            "`wps_no` 가 정해져 있어 추천할 것이 없다 — 그 행에 `rec` 가 없는 "
            "것은 «쓸 WPS 가 없다»가 아니다.",
            "`rec` 는 **근거가 있는 만큼만** 들어 있다. 하나뿐이면 같은 조건에서 "
            "과거에 그 WPS 만 썼다는 뜻이고, 없으면 대조할 시공분이 없다는 "
            "뜻이다 — 「쓸 WPS 가 없다」가 아니다.",
            "「두께 다름」이 붙은 것은 **근거가 약하다**(같은 조건의 시공분이 "
            "없어 두께를 빼고 찾은 것). 그 말을 빼고 전하지 마라.",
            "추천이 얼마나 맞는지는 색인의 `recommendation` 에 있다 — 이 자료로 "
            "직접 잰 값이다. 거기 `excluded_test_wps` 는 **용접사 기량시험용** "
            "이라 후보에서 뺀 WPS 다(생산 조인트에 권하면 안 된다).",
            "**블록을 모르면 먼저 이 색인을 보라.** `by_lot` 이 «Lot -> 블록 "
            "목록»이다. 색인 없이 찾으면 파일을 전부 열게 되는데, 그건 한 "
            "덩어리로 보는 것보다 느리다.",
            "Joint No 로 찾을 때만 `_index_joint.txt` 를 함께 열어라 — 그 하나가 "
            "색인 무게의 대부분이라 따로 빼 두었다.",
            "Lot 의 77% · Joint No 의 46% 가 **블록 여럿에 걸쳐 있다.** 색인이 "
            "블록을 둘 이상 주면 그 파일을 **전부** 봐야 한다.",
            "`drawing_no`(도면번호)는 **조회 열쇠가 아니다 — 참고 값이다.** "
            "그것으로 찾지 말고, Block·Lot·Joint No 로 찾은 뒤 결과에 함께 "
            "보여 주기만 하라.",
            "**(Block, Lot, Joint No) 셋이 유일하지 않다** — 실측 30,871개 조합 "
            "중 522개(1.7%)에 행이 여럿 걸리고, 한 조합에 최대 13행이다. 그때 "
            "줄을 가르는 것이 `drawing_no` 다(457개가 그렇다). 여러 줄이 나오면 "
            "하나를 고르지 말고 **도면번호와 함께 전부 보여 줘라.**",
            "`planned` 가 true 인 행이 **작업 예정 물량**이다(WPS 미배정). "
            "「예정 물량을 보여 달라」는 이 값으로 거른다.",
            "실제로 어떤 WPS 를 썼는지는 **일부러 담지 않았다.** 계획 단계 "
            "조인트에는 없는 값이라, 그걸 보고 답하면 정작 필요한 자리에서 "
            "쓸 수 없다.",
        ],
        # 조회 열쇠 셋을 **열 정의에 못 박는다.** how_to_use 를 안 읽어도
        # 「무엇으로 찾는가」가 보여야 한다.
        "search_keys": ["lookup_key"],
        "search_key_parts": ["block", "lot", "joint_no"],
        "columns": [
            dict({"column": get_column_letter(col), "key": key, "name": name,
                  "type": typ},
                 **({"role": "search_key"} if key in ("block", "lot", "joint_no")
                    else {"role": "reference",
                          "note": "조회 열쇠가 아니다. 같은 "
                                  "(Block, Lot, Joint No) 에 행이 여럿일 때 "
                                  "줄을 가르는 참고 값이다."}
                    if key == "drawing_no" else {}))
            for col, key, name, typ in _INPUT_COLS
        ] + [{"column": "-", "key": "lookup_key", "name": "조회 열쇠",
              "type": "text", "role": "search_key",
              "note": "Block/Lot/JointNo 를 이은 문자열(예: CV261/FR01/1P02T). "
                      "**줄 맨 앞에 있고 JSON 안에는 없다.** 이 문자열로 줄을 "
                      "찾고 그 줄의 첫 { 부터 읽어라. 앞자리가 블록 이름이자 "
                      "파일 이름이다."},
             {"column": "-", "key": "planned", "name": "작업 예정(WPS 미배정)",
              "type": "bool"},
             {"column": "-", "key": "row", "name": "원본 엑셀 행번호",
              "type": "number"},
             {"column": "-", "key": "rec",
              "name": "쓸 만한 WPS (근거 있는 만큼, 최대 2개)", "type": "list",
              "note": "판정 기준 + 과거 시공 실적으로 고른 것이다. "
                      "문구를 그대로 보여 주면 된다. 다시 추론하지 마라."},
             ],
        "totals": {"rows": sum(f["rows"] for f in files),
                   "planned": planned, "deleted_excluded": deleted,
                   "blocks": len(files)},
        # 추천이 얼마나 맞는지 **이 서버의 자료로 잰 값**. 개발 데이터의
        # 수치를 붙이면 그건 거짓말이 된다.
        "recommendation": quality,
        "wps_source": wps_source,
        "blocks": files,
        "by_lot": {k: sorted(v) for k, v in sorted(by_lot.items())},
        "joint_index_file": JOINT_INDEX_NAME,
    }
    idx = out_dir / INDEX_NAME
    idx.write_text(json.dumps(index, **_COMPACT), encoding="utf-8")

    jidx = out_dir / JOINT_INDEX_NAME
    jidx.write_text(json.dumps(
        {"schema": SCHEMA,
         "note": ("Joint No -> 블록 목록. **같은 Joint No 가 여러 블록에 있다** "
                  "(실측 6,778개 중 3,111개). Block 이나 Lot 을 함께 알면 "
                  "_index.txt 의 blocks · by_lot 으로 먼저 좁혀라."),
         "by_joint": {k: sorted(v) for k, v in sorted(by_joint.items())}},
        **_COMPACT), encoding="utf-8")

    total = (sum(f["bytes"] for f in files) + idx.stat().st_size
             + jidx.stat().st_size)
    logger.info("조인트 자료 생성: %s (블록 %d개 · %d행 · %.1f MB)",
                out_dir.name, len(files), index["totals"]["rows"],
                total / 1024 / 1024)
    return {"dir": str(out_dir), "name": out_dir.name,
            "files": len(files) + 2,
            "blocks": len(files), "rows": index["totals"]["rows"],
            "planned": planned, "deleted_excluded": deleted,
            "bytes": total, "index_bytes": idx.stat().st_size,
            "largest": max((f["bytes"] for f in files), default=0),
            "recommendation": quality}


def latest(out_root: Path) -> dict[str, Any] | None:
    """가장 최근에 만든 폴더. 없으면 None.

    화면이 «언제 만든 것인지»를 말해야 한다 — 버튼을 눌러야만 갱신되므로,
    표시가 없으면 낡은 자료를 최신으로 읽는다.
    """
    if not out_root.is_dir():
        return None
    dirs = [d for d in out_root.iterdir() if d.is_dir()
            and (d / INDEX_NAME).is_file()]
    if not dirs:
        return None
    newest = max(dirs, key=lambda d: (d / INDEX_NAME).stat().st_mtime)
    try:
        idx = json.loads((newest / INDEX_NAME).read_text(encoding="utf-8"))
    except Exception:
        logger.warning("조인트 자료 색인을 읽지 못했다: %s", newest)
        return None
    tot = idx.get("totals") or {}
    q = idx.get("recommendation") or {}
    return {"name": newest.name, "dir": str(newest),
            "rec_rows": q.get("rows_with_recommendation", 0),
            "rec_top2": q.get("top2_accuracy_pct"),
            "rec_none": q.get("rows_without_basis", 0),
            "generated_at": idx.get("generated_at", ""),
            "source": idx.get("source", ""),
            "blocks": tot.get("blocks", 0), "rows": tot.get("rows", 0),
            "planned": tot.get("planned", 0)}
