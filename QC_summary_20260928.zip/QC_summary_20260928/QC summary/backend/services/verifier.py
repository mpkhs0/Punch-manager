"""
QMG4520 QC 검증 핵심 로직
FastAPI 서비스용 — qc_verifier.py CLI와 동일한 검사 로직, API 친화적 출력 반환
"""
import re
import logging
from datetime import datetime, date
from pathlib import Path
from collections import Counter, defaultdict
from typing import Any, Callable, Iterable, Optional

from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font
from openpyxl.utils import get_column_letter
from openpyxl.comments import Comment

from . import anomaly
from . import recurrence
from . import project_checks
from . import rule_catalog
from . import wps_overrides
from . import wps_rules

logger = logging.getLogger(__name__)

# ─── 컬럼 상수 (1-based) ─────────────────────────────────────────────────────
class Col:
    DRAWING_NO    = 1   # A
    BLOCK         = 2   # B  대구분
    # C  소구분 Lot. Check 14가 **Block과 짝으로** 중복 판정 단위를 만든다
    # (현업 확인 2026-09-02) — Joint No는 Block-Lot 안에서만 유일하다.
    LOT           = 3   # C
    JOINT_NO      = 4   # D  Weld No
    # E  헤더가 'RE' — 수리(Repair) 구분란. 값은 `RE`·`R1`·`U1`·`M1`처럼 다양하고,
    # **비어 있지 않기만 하면 수리 시공**이라는 뜻이다(현업 확인 2026-08-13).
    # 실데이터 10,031행 중 4행에만 값이 있다.
    REPAIR_MARK   = 5   # E
    OUT_DIA       = 9   # I  Out Dia (관재/형강의 외경·형상 규격, 예: 'SHS80X6')
    THICKNESS1    = 10  # J
    THICKNESS2    = 11  # K
    # L  Length — 용접선 길이(mm). 헤더가 `Length`이고 실데이터는 전부 숫자다
    # (50 ~ 15,000). Check 26이 **2000을 경계로 판정을 가른다** — 2000 이상은
    # 요율과 무관하게 전수 촬영, 미만은 요율 판정.
    LENGTH        = 12  # L
    MATERIAL1     = 13  # M
    MATERIAL2     = 14  # N
    NDT_CAT       = 16  # P
    # Q  이음 Type. 실데이터 분포: T 9,626 · B 361 · TT 8.
    # `TT`는 TKY 이음(관재 교차부)이라 전용 WPS를 써야 한다(Check 24).
    JOINT_TYPE    = 17  # Q
    # NDT Extent — 이 조인트에 요구되는 NDT 비율(%). 값이 있으면 그 검사가 요구된다.
    NDT_EXT_RT    = 19  # S
    NDT_EXT_UT    = 20  # T
    NDT_EXT_MT    = 21  # U
    NDT_EXT_PT    = 22  # V
    GROOVE        = 18  # R
    DELETE_STATUS = 24  # X
    CONSUMABLE_LOT = 38  # AL  용접봉 Lot 번호
    WPS_NO        = 36  # AJ
    WPS_PROCESS   = 37  # AK
    WELD_DATE     = 39  # AM
    NDT_DATE      = 41  # AO
    WELDER1_NO    = 42  # AP
    WELDER1_PROC  = 43  # AQ
    WELDER2_NO    = 44  # AR
    WELDER2_PROC  = 45  # AS
    WELDER3_NO    = 46  # AT
    WELDER3_PROC  = 47  # AU
    WELDER4_NO    = 48  # AV
    WELDER4_PROC  = 49  # AW
    # BE  NDT Inspection Plan/Application > Report — NDT 리포트 번호(예: 'SAVI14996')
    #
    # 산출물의 **추적 키**다. 현업은 도면번호가 아니라 이 번호로 원본 검사기록을
    # 찾는다. 실데이터 9,997행 중 5,520행(55.2%)에 값이 있고 서로 다른 번호가
    # 166개다 — 한 리포트가 여러 조인트를 덮으므로 행마다 유일하지 않다.
    # 공란(44.8%)은 NDT 계획 자체가 없는 행이라, 비어 있는 것이 정상이다.
    # BD  NDT Inspection Plan/Application > Date — 계획/신청일.
    # 이 날짜가 있으면 «검사를 걸어 둔 조인트»라는 뜻이라, 리포트 번호가 확정돼야 한다.
    NDT_PLAN_DATE = 56  # BD
    NDT_REPORT    = 57  # BE
    DEPARTMENT    = 58  # BF  Dep't
    TEAM          = 59  # BG  Team (부서 하위 팀/협력사)
    VT_DATE       = 61  # BI  Visual Inspection 수행일
    RT_DATE       = 65  # BM  RT(방사선) 수행일
    UT_DATE       = 68  # BP  UT(초음파) 수행일
    MT_DATE       = 71  # BS  MT(자분) 수행일
    PT_DATE       = 74  # BV  PT(침투) 수행일
    # 검사별 리포트 번호 — 각 수행일 바로 오른쪽 열이다.
    #
    # **번호 끝의 `*`는 «촬영하지 않은 수량»**이라는 표기다(현업 확인 2026-08-13).
    # `MSOU00001`(촬영함) 2건 + `MSOU00001*`(안 함) 8건이면 그 리포트 묶음의 실제
    # 촬영율은 20%다 — Check 26이 이 묶음 요율을 S~V열 요구 요율과 대조한다.
    RT_REPORT     = 66  # BN
    UT_REPORT     = 69  # BQ
    MT_REPORT     = 72  # BT
    PT_REPORT     = 75  # BW

class WPSCol:
    WPS_NO       = 3   # C
    PROCESS      = 5   # E
    BASE_METAL   = 6   # F
    THICKNESS    = 7   # G
    POSITION     = 11  # K
    JOINT_DETAIL = 12  # L

# ─── 용접사 파일의 «두 형식» ─────────────────────────────────────────────────
#
# 2026-08-20에 현업이 **만료일이 든 새 파일**로 갈아탔다. 자격 DB와 만료일 파일을
# 따로 올리던 것을 하나로 합친 것이다 — 두 파일에 같은 사람이 있어도 서로 몰라서
# «한쪽에만 있는 사람»이 Check 6과 7에서 **따로 지적되던** 문제가 있었다.
#
# **옛 형식을 계속 읽는 이유**: 이미 올려 둔 파일이 그대로 있는 설치가 있다.
# 그걸 새 형식으로 읽으면 B열에서 번호를 못 찾아 **전원이 «자격 미등록»으로
# 잡힌다** — 오류가 아니라 «갑자기 결함이 수천 건»으로만 보여서 원인을 짐작할
# 단서가 없다. 그래서 둘 다 시도해 보고 사람이 나오는 쪽을 쓴다.
#
# 어느 형식으로 읽었는지는 **로그와 업로드 응답에 남긴다.** 안 남기면 «왜 만료일
# 검사가 안 도나»를 되짚을 방법이 없다.
class WelderLayout:
    """(이름, 머리말 행수, 열 번호들). `cols`에 없는 키는 그 형식에 없는 것이다."""

    NEW = ("만료일 포함", 10, {
        "no": 2,        # B
        "name": 3,      # C
        "process": 4,   # D
        "expire": 13,   # M  Expire date
        "disq": 14,     # N  Dis-qualified date
    })
    OLD = ("기존 자격 DB", 3, {
        "no": 3,        # C
        "name": 4,      # D
        "spec": 5,      # E
        "process": 6,   # F
        "cert_no": 9,   # I
        "cert_date": 10,  # J
        "position": 11,   # K
        "cls": 68,      # BP
        "status": 80,   # CB
    })
    ALL = (NEW, OLD)


class WelderCol:
    NO        = 3   # C
    NAME      = 4   # D  Name(Kor) — 'HONG GIL DONG(홍길동)' 형식
    SPEC      = 5   # E  Applicable Spec. (AWS 등)
    PROCESS   = 6   # F
    CERT_NO   = 9   # I  Certified No.
    CERT_DATE = 10  # J  자격 취득일 (만료일 L열은 전량 공란 — 11-6 참조)
    POSITION  = 11  # K
    CLASS     = 68  # BP 선급 (DNV 등)
    STATUS    = 80  # CB

# ─── 색상 (Excel 출력용 + API 전달용 이름) ──────────────────────────────────
_FILLS: dict[str, PatternFill] = {
    "Red":    PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid"),
    "Green":  PatternFill(start_color="00B050", end_color="00B050", fill_type="solid"),
    "Blue":   PatternFill(start_color="0070C0", end_color="0070C0", fill_type="solid"),
    "Yellow": PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid"),
    "Orange": PatternFill(start_color="FF7F00", end_color="FF7F00", fill_type="solid"),
    "Black":  PatternFill(start_color="000000", end_color="000000", fill_type="solid"),
    "Purple": PatternFill(start_color="7030A0", end_color="7030A0", fill_type="solid"),
    "Teal":   PatternFill(start_color="008080", end_color="008080", fill_type="solid"),
    "Gray":   PatternFill(start_color="BFBFBF", end_color="BFBFBF", fill_type="solid"),
    "Cyan":   PatternFill(start_color="00B0C0", end_color="00B0C0", fill_type="solid"),
    "Brown":  PatternFill(start_color="833C00", end_color="833C00", fill_type="solid"),
    "Olive":  PatternFill(start_color="808000", end_color="808000", fill_type="solid"),
    "Maroon": PatternFill(start_color="7B2E2E", end_color="7B2E2E", fill_type="solid"),
    "Indigo": PatternFill(start_color="4B3F8F", end_color="4B3F8F", fill_type="solid"),
    "Navy":   PatternFill(start_color="1F3864", end_color="1F3864", fill_type="solid"),
    "Rose":   PatternFill(start_color="C0504D", end_color="C0504D", fill_type="solid"),
}
_PRIORITY: dict[str, int] = {
    "Black": 0, "Red": 1, "Purple": 2, "Orange": 3, "Yellow": 4,
    "Blue": 5, "Teal": 6, "Olive": 7, "Green": 8, "Navy": 9,
    "Gray": 10, "Cyan": 11, "Brown": 12, "Rose": 13,
    "Maroon": 14, "Indigo": 15,
}

CHECK_COLORS: dict[int, str] = {
    0: "Gray",
    1: "Red", 2: "Green", 3: "Blue", 4: "Yellow", 5: "Blue",
    6: "Orange", 7: "Yellow", 8: "Blue", 9: "Green", 10: "Black",
    # 13은 결번이지만 **색도 남긴다** — 이름과 같은 이유다(옛 검토 기록의 배지).
    11: "Purple", 12: "Teal", 13: "Cyan", 14: "Brown",
    # 18은 Rose에서 Orange로 바꿨다(2026-08-20) — 승인 목록 대조가 들어와
    # «기재 누락»보다 무거운 판정을 함께 하게 됐다. 같은 AL열을 보는 Check 21
    # (Rose=13)과 겹치면 우선순위가 높은 쪽(Orange=3)이 칠해진다.
    16: "Olive", 17: "Navy", 18: "Orange",
    19: "Maroon", 20: "Indigo",
    # 2026-08-13 추가. 색은 기존 16색에서 고른다 — `_FILLS`에 없는 색을 쓰면
    # 엑셀이 무색이 되고, `style.css`에 `--ck-*`가 없으면 화면 배지도 무색이 된다.
    21: "Rose", 22: "Olive", 23: "Gray", 24: "Cyan",
    25: "Teal", 26: "Navy", 27: "Purple",
}
CHECK_NAMES: dict[int, str] = {
    0:  "미작업 수량",
    1:  "일정 오류",           2:  "WPS/Process 불일치",
    3:  "두께 허용범위 초과",  4:  "Groove 불일치",
    5:  "특수규칙 P+G01",      6:  "용접사 자격 미등록",
    7:  "용접사 승인기간 이후 작업",
    8:  "TR-FC-G03 특수",
    9:  "TR-SMFC-G01 특수",    10: "복합 오류 (3+8)",
    11: "재질-WPS 부적합",     12: "관재 DIA 확인 필요",
    # 13은 **결번이다** (2026-09-02) — 아래 `_ANOMALY_IS_NOT_A_CHECK` 참조.
    # **이름은 지우지 않는다.** Check 5와 같은 취급이다 — 이미 붙은 검토 기록
    # 2건이 화면·Excel '검토 기록' 시트에서 이름 없이 뜨게 된다.
    13: "이상치(특이 조합) 확인 필요",
    14: "Joint 중복 등록 (본용접 중복)",
    16: "NDT 요구 대비 미수행",
    17: "육안검사(VT) 미수행",
    18: "용접봉 Lot 미기재·미승인",
    19: "WPS Process 자격자 미투입",
    20: "API 재질 Groove별 프로세스 부적합",
    21: "혼합 프로세스 용접재료 누락",
    22: "NDT 리포트 번호 미확정",
    23: "수리 시공 · 수리 WPS 미적용",
    # 이름을 바꾸면 `app.js`의 `CHECK_META`도 함께 고쳐야 한다 — 백엔드 이름은
    # 결과 Excel '결함 목록' 시트와 부서·팀 메일 본문이 쓰고, 화면 배지는
    # `CHECK_META`가 쓴다. 갈라지면 «화면에서 본 이름»과 «첨부에 적힌 이름»이
    # 달라진다. `tests/test_check_names_match.py`가 정적으로 대조한다.
    24: "이음 Type·프로세스별 WPS 끝자리 부적합",
    25: "Q01 WPS · 이음 Type 부적합",
    26: "NDE 적용 요율 미달",
    27: "이종재 상위 그레이드 WPS 부적합",
}

# ─── Check 13은 결번이다 (2026-09-02 현업 결정) ───────────────────────────────
#
# 이상치 탐지(IsolationForest)는 **규칙 위반이 아니라 통계적 이례성**이다.
# 그런데 플래그가 되는 순간 결함 목록·부서 실적·Excel·부서 메일이 전부 그것을
# «결함»으로 실어 나른다 — 현업이 「결함이 아닌데 결함처럼 보인다」고 지적했다.
# 실측 5,397건이 그렇게 나가고 있었다.
#
# 그래서 **분석은 그대로 두고 플래그만 만들지 않는다.** `_detect_ml_anomalies()`가
# `ml_meta`·`ml_detail`을 계속 채우고, '비지도학습' 탭이 거기서 수량을 보여 준다.
#
# **번호는 재사용하지 않는다.** 검토 기록 키가 `도면번호|Joint No|WPS No|Check No`
# 라서, 13을 새 검사에 다시 쓰면 **과거 이상치 검토 의견이 무관한 항목에 붙는다**
# (§11-7과 같은 사고). Check 15·28과 같은 취급이다 — 새 공통 검사는 29부터.
_ANOMALY_IS_NOT_A_CHECK = 13

# Check 16이 쓰는 «요구 Extent 열 -> 수행일 열» 대응.
# 엑셀에서 두 묶음이 멀리 떨어져 있어(S~V열 vs BM~BV열) 짝을 눈으로 맞추기 어렵다.
# 한 줄에 나란히 두는 편이 열을 바꿔 넣는 실수를 막는다.
_NDT_EXTENT_PAIRS: tuple[tuple[str, int, int], ...] = (
    ('RT', Col.NDT_EXT_RT, Col.RT_DATE),
    ('UT', Col.NDT_EXT_UT, Col.UT_DATE),
    ('MT', Col.NDT_EXT_MT, Col.MT_DATE),
    ('PT', Col.NDT_EXT_PT, Col.PT_DATE),
)

# Check 0(미작업)은 '결함'이 아니라 '아직 용접이 수행되지 않은 계획 물량'이다.
# 결함률 통계·용접사 평가·부서 실적 어디에도 결함으로 섞이면 표본이 오염되므로
# 판정 대상(judged_rows)에서 아예 제외하고 별도 수량으로만 집계한다.
CHECK_UNWORKED = 0

# ─── 유틸리티 ────────────────────────────────────────────────────────────────
def _clean(v: Any) -> str:
    return "" if v is None else str(v).strip()

def _normalize_process(v: Any) -> str:
    s = _clean(v).upper()
    s = re.sub(r'\(.*?\)', '', s)
    s = re.sub(r'[\n\r\s]+', '', s)
    s = re.sub(r'-CARRIAGE$', '', s)
    return s

# 어떤 자격이 어떤 시공 프로세스를 «덮는가».
#
# 현업 확인(2026-08-11): **SMFC 자격 보유자는 FCAW 작업이 허용된다.**
# 실데이터에서 Check 6의 «프로세스 자격 없음» 36건이 **전부** 이 경우였다
# (FCAW 시공 / 보유 SMFC 또는 SAW,SMFC). 오탐이므로 결함으로 잡지 않는다.
#
# Check 6과 Check 19가 **같은 함수**를 쓴다 — 갈라지면 «6에서는 통과인데
# 19에서는 결함»이 되어, 같은 행에 서로 모순되는 지적이 붙는다.
# 용접 프로세스인가 — **닫힌 집합으로 본다.** 파일 형식을 가릴 때만 쓴다.
#
# 처음에는 «ASCII 대문자면 프로세스»로 봤는데 그게 부족했다. 옛 파일의 이름 열
# `NA YEONG SEOG(나영석)`이 괄호가 벗겨지면 `NAYEONGSEOG`가 되어 그 조건을
# 통과한다 — 옛 파일이 새 형식으로 989행, 옛 형식으로 1,020행 읽혀 **판별이
# 종이 한 장 차이**였다. 조금만 달랐으면 통째로 잘못 읽었을 것이다.
#
# 용접 프로세스는 표준 코드라 실제로는 몇 개뿐이다(실측: FCAW · SMFC · SAW ·
# GTFC 넷). 두 글자 어근의 조합(SM+FC = SMAW+FCAW)까지 받아 주면 충분하다.
#
# **적재에는 이 조건을 쓰지 않는다** — 판별에만 쓴다. 여기 없는 표기를 만나도
# 그 행을 버리지 않아야 한다.
_PROCESS_FULL = frozenset((
    "SMAW", "GMAW", "GTAW", "FCAW", "SAW", "PAW", "ESW", "EGW", "OFW", "SW",
    "GMAWP", "FCAWS", "FCAWG",
))
_PROCESS_ROOTS = frozenset(("SM", "GM", "GT", "FC", "SA", "PA", "ES", "EG", "OF"))


def _looks_like_process(s: str) -> bool:
    """`FCAW` · `SMFC` · `SAW,SMFC`는 참, `NAYEONGSEOG` · `Q557`은 거짓."""
    for part in re.split(r"[,/+]", s):
        p = part.strip()
        if not p:
            continue
        if p in _PROCESS_FULL:
            return True
        # 4글자 합성(SMFC = SMAW + FCAW) — 두 글자 어근 둘로 나뉘는가
        if len(p) == 4 and p[:2] in _PROCESS_ROOTS and p[2:] in _PROCESS_ROOTS:
            return True
    return False

# 두 글자 어근 -> 온전한 프로세스 이름. `SMFC` = `SM` + `FC` = SMAW + FCAW.
_ROOT_FULL: dict[str, str] = {
    "SM": "SMAW", "GM": "GMAW", "GT": "GTAW", "FC": "FCAW", "SA": "SAW",
    "PA": "PAW", "ES": "ESW", "EG": "EGW", "OF": "OFW",
}


def _process_set(v: Any) -> set[str]:
    """프로세스 표기를 **기본 프로세스의 집합**으로 편다.

        FCAW              -> {FCAW}
        SMAW / + / FCAW   -> {SMAW, FCAW}      <- 줄바꿈·«+»로 둘을 적은 것
        SMFC              -> {SMAW, FCAW}      <- 합성 코드도 같은 뜻이다
        SAW,SMFC          -> {SAW, SMAW, FCAW}

    현업 질문(2026-08-24)에서 드러났다. 예전에는 `SMAW+FCAW`를 **한 덩어리
    문자열**로 비교해서, 그 WPS를 쓰는 행은 무엇을 써도 전부 Check 2에 걸렸다 —
    `SMFC`(글자 그대로 SMAW+FCAW)조차 결함이었다.

    **모르는 표기는 버리지 않고 그대로 담는다.** 버리면 «프로세스를 안 적은
    행»과 구분되지 않아, 새 코드가 들어온 프로젝트에서 이 검사가 조용히 죽는다.
    """
    out: set[str] = set()
    for part in re.split(r"[,/+&]+", _normalize_process(v)):
        p = part.strip()
        if not p:
            continue
        if len(p) == 4 and p[:2] in _ROOT_FULL and p[2:] in _ROOT_FULL:
            out.add(_ROOT_FULL[p[:2]])
            out.add(_ROOT_FULL[p[2:]])
        else:
            out.add(p)
    return out


def _process_covers(qualification: str, worked: str) -> bool:
    """**한 사람**의 자격으로 `worked` 프로세스를 시공할 수 있는가.

    기본 프로세스 집합으로 펴서 «요구가 보유에 포함되는가»를 본다.

        SMFC 자격 -> {SMAW,FCAW} ⊇ {FCAW}    FCAW 시공 가능 (현업 확인 2026-08-11)
        FCAW 자격 -> {FCAW}      ⊉ {SMAW,FCAW}   SMFC 시공 불가 — 반대 방향은 안 열린다

    예전에는 문자열 완전일치 + 예외표(`{"SMFC": ("FCAW",)}`) 한 줄이었다.
    그러면 **혼합 프로세스마다 예외를 손으로 늘려야 하고**, 빠뜨린 것은
    조용히 오탐이 된다 — FCSA·GMSA·GTFC가 실제로 그 상태였다.
    집합으로 보면 예외표 없이 같은 답이 나온다.
    """
    q = _process_set(qualification)
    w = _process_set(worked)
    if not q or not w:
        return False
    return w <= q


def _held_processes(quals: Iterable[str]) -> set[str]:
    """여러 사람의 보유 자격을 **기본 프로세스 집합**으로 합친다."""
    out: set[str] = set()
    for q in quals:
        out |= _process_set(q)
    return out


# 혼합 프로세스별 **허용 자격 목록** (현업 확정 2026-09-03).
#
# 이 중 **하나라도** 가진 사람이 그 이음에 있으면 합격이다. 프로세스마다 목록이
# 다르다 — 규칙을 유도할 수 있는 형태가 아니라 현업이 정한 것이라 표로 못 박는다.
#
#   GTFC  GTAW 또는 GTFC 자격자 1명 이상        (FCAW는 추가로 들어가도 된다)
#   FCSA  FCAW 또는 SAW 또는 FCSA 자격자 1명 이상
#   SMFC  SMFC 자격자 1명 이상                  <- 기본 자격(SMAW)만으로는 불합격
#   GMSA  GMSA 자격자 1명 이상
#
# **원문 표기로 대조한다.** `_process_set()`으로 펴면 `SMFC` 자격이
# `{SMAW, FCAW}`가 되어 「SMFC 자격자 한 명」과 「SMAW 한 명 + FCAW 한 명」이
# 구분되지 않는다 — SMFC 규칙은 정확히 그 둘을 가르는 것이라 펴면 안 된다.
_MIXED_QUAL_ALLOWED: dict[str, frozenset[str]] = {
    "GTFC": frozenset({"GTAW", "GTFC"}),
    "FCSA": frozenset({"FCAW", "SAW", "FCSA"}),
    "SMFC": frozenset({"SMFC"}),
    "GMSA": frozenset({"GMSA"}),
}


def _joint_process_covered(held_raw: set[str], wps_prc: str) -> bool:
    """이 이음에 투입된 사람들의 자격이 요구 프로세스를 덮는가.

    `held_raw`는 **원문 자격 표기**의 합집합이다(펴지 않은 것). 아래 혼합
    프로세스 판정이 원문을 봐야 하기 때문이다.

    ## 혼합 프로세스 — 허용 자격 목록에 하나라도 해당하면 합격

    현업 확정(2026-09-03). `_MIXED_QUAL_ALLOWED` 참조:

        GTFC 이음  <-  GTAW 또는 GTFC 자격자 1명  -> 합격
        FCSA 이음  <-  FCAW 또는 SAW 자격자 1명    -> 합격
        SMFC 이음  <-  SMFC 자격자 1명             -> 합격
                   <-  SMAW 한 명 + FCAW 한 명     -> **불합격**

    예전에는 넷 다 「요구 집합 ⊆ 보유 집합」이었다(2026-08-28). SMFC를
    `{SMAW, FCAW}`로 펴서 두 사람이 나눠 가져도 합격이었는데, 현업이 SMFC는
    **합성 자격 자체**를 요구하는 것으로 확정했다. 실데이터에서 SMFC 이음
    13,000건 중 12,000건 이상에 이미 SMFC 자격자가 투입돼 있어(TRION),
    이 강화로 결함이 폭증하지는 않는다.

    ## 그 밖의 프로세스 — 종전대로 «요구 집합 포함»

    단일 프로세스(FCAW·SAW…)는 원문을 펴서 요구 프로세스가 들어 있는지 본다.
    `SMFC` 자격자는 `{SMAW, FCAW}`로 펴지므로 FCAW 이음을 덮는다.
    """
    # 표기가 프로젝트마다 다르므로 **합성 코드로 맞춘 뒤** 대조한다
    # (`SMAW+FCAW`도 `SMFC`와 같은 이음이다 — `_mixed_code` 참조).
    allowed = _MIXED_QUAL_ALLOWED.get(_mixed_code(wps_prc) or "")
    if allowed is not None:
        # **자격은 사람 단위로 담긴 원문 토큰이다.** 펴서 합치면 「SMFC 자격자
        # 한 명」과 「SMAW 한 명 + FCAW 한 명」이 구분되지 않는다 — SMFC 규칙은
        # 정확히 그 둘을 가르는 것이라 펴면 안 된다. 다만 한 사람의 자격이
        # `SMAW+FCAW`로 적힌 경우는 **그 한 사람이 둘 다 가진 것**이므로
        # `_mixed_code`로 합성 코드에 맞춰 준다.
        held = {_mixed_code(h) or _normalize_process(h) for h in held_raw}
        return bool(held & allowed)

    need = _process_set(wps_prc)
    held = _held_processes(held_raw)
    return bool(need) and bool(held) and need <= held


# 두 프로세스를 한 이음에서 함께 쓰는 «혼합» 프로세스. 이런 이음은 용접재료를
# 둘 적어야 하고(Check 21), 자격은 투입 인원이 **합쳐서** 갖추면 된다.
#
#   FCSA = FCAW + SAW      SMFC = SMAW + FCAW
#   GMSA = GMAW + SAW      GTFC = GTAW + FCAW
#
# **GMSA가 한동안 빠져 있었다.** 넷 다 두 글자 어근 둘의 조합이라 `_process_set()`은
# 올바르게 폈는데, 이 목록에만 없어서 Check 21(소모품 둘)과 Check 6 완화가 GMSA
# 이음에서만 조용히 안 돌았다. TRION 물량에 GMSA가 없어 드러나지 않았을 뿐이다.
_MIXED_PROCESSES = ("SMFC", "GTFC", "FCSA", "GMSA")

# 합성 코드 -> 그것이 뜻하는 기본 프로세스 쌍.
#
# **프로젝트마다 표기가 다르다.** TRION 물량은 합성 코드를 그대로 쓰지만
# (`SMFC`), RUYA WPS 등록부는 풀어서 적는다(`SMAW+FCAW`). 실측으로 TRION은
# raw data AK열과 등록부 E열의 표기가 **항상 같았다** — 즉 등록부가 풀어 쓰는
# 프로젝트는 AK열도 풀어 쓴다고 봐야 한다.
#
# 예전에는 합성 코드를 **부분문자열로만** 찾아서, 풀어 쓴 표기가 «혼합이
# 아닌 것»이 됐다. 그러면 한 프로젝트에서만 조용히 셋이 어긋난다:
#   · Check 21   용접재료 2종 요구가 아예 안 돈다
#   · Check 6    보조 인원 완화가 안 걸려 **정상 시공에 없던 결함이 생긴다**
#   · Check 19   SMFC 합성자격 요구(현업 확정 2026-09-03)가 안 걸린다
# 셋 다 예외도 경고도 없다.
_MIXED_PAIRS: dict[str, frozenset[str]] = {
    "SMFC": frozenset({"SMAW", "FCAW"}),
    "GTFC": frozenset({"GTAW", "FCAW"}),
    "FCSA": frozenset({"FCAW", "SAW"}),
    "GMSA": frozenset({"GMAW", "SAW"}),
}


def _mixed_code(process: Any) -> str | None:
    """프로세스 표기를 «혼합 코드»로. 아니면 None.

        SMFC        -> "SMFC"      합성 코드 그대로
        SAW,SMFC    -> "SMFC"      다른 프로세스와 함께 적힌 것
        SMAW+FCAW   -> "SMFC"      풀어 쓴 표기 (RUYA)
        FCAW        -> None
        FCAW,SAW    -> "FCSA"      둘을 나열한 것도 «함께 쓴다»는 뜻이다

    합성 코드가 글자로 보이면 그대로 쓴다(빠른 길이자 종전 동작 그대로).
    안 보이면 기본 프로세스로 펴서 «쌍이 들어 있는가»를 본다.
    """
    p = _normalize_process(process)
    if not p:
        return None
    for m in _MIXED_PROCESSES:
        if m in p:
            return m
    expanded = _process_set(p)
    for code, pair in _MIXED_PAIRS.items():
        if pair <= expanded:
            return code
    return None


def _is_mixed_process(process: str) -> bool:
    return _mixed_code(process) is not None


# 재질 등급의 «상하»를 아는 만큼만. **[보류] — 전체 등급표는 아직 없다.**
#
# 현업이 2026-08-13에 확인해 준 두 가지만 담는다:
#   · 재질명 끝의 시험온도 — 낮을수록 상위 (-40 > -20)
#   · S355 < S420
#
# 등급표를 받으면 `_GRADE_ORDER`를 채운다. 그때까지 나머지 조합은 None을
# 돌려 판정하지 않는다 — 근거 없이 찍으면 오탐이고, 오탐은 «이 검사는 못
# 믿는다»로 이어져 진짜 결함까지 묻힌다.
_GRADE_ORDER: dict[str, int] = {
    "S355": 1,
    "S420": 2,
}


def _material_token(material: str) -> str:
    """재질명을 «표기 흔들림을 지운» 형태로. 같은 강재인지 볼 때 쓴다.

    `ASTM-A36` · `ASTM A36` · `astma36`이 전부 `ASTMA36`이 된다. 이걸 안 하면
    표기만 다른 같은 강재가 이종재로 분류되어 Check 3의 K열 판정이 사라진다.
    """
    return "".join(ch for ch in (material or "").upper() if ch.isalnum())


def _material_grade_rank(material: str) -> Optional[int]:
    """`_GRADE_ORDER`로 아는 등급이면 순위, 모르면 None."""
    m = (material or "").upper().replace(" ", "")
    for key, rank in _GRADE_ORDER.items():
        if key in m:
            return rank
    return None


# 재질명 **끝**에 시험온도가 붙는 표기: `S355KT-40` · `S355KL-0` · `S355KL-50Z`.
#
# `K`(KT/KL 등 온도 등급 문자) 뒤의 `-숫자`만 온도로 읽는다. 그냥 «끝의 -숫자»로
# 잡으면 **`ASTM-A36`의 36을 -36℃로 읽어 버린다** — A36은 강도 등급이지 온도가
# 아니다. 선급강 표기(`NV-E36`)는 `_material_impact_temp_c()`가 따로 안다.
_TEMP_IN_NAME = re.compile(r"K[A-Z]?-(\d{1,3})Z?$")


def _temp_from_name(material: str) -> Optional[int]:
    m = _TEMP_IN_NAME.search((material or "").upper().replace(" ", ""))
    return -int(m.group(1)) if m else None


def _higher_material_grade(a: str, b: str) -> Optional[str]:
    """둘 중 «상위 그레이드». 판단 근거가 없으면 None.

    먼저 시험온도로 본다(낮을수록 상위). 온도가 없거나 같으면 등급표를 본다.
    둘 다 모르면 None이다 — **여기서 임의로 하나를 고르면 조용히 틀린다.**
    """
    ta = _material_impact_temp_c(a)
    if ta is None:
        ta = _temp_from_name(a)
    tb = _material_impact_temp_c(b)
    if tb is None:
        tb = _temp_from_name(b)
    if ta is not None and tb is not None and ta != tb:
        return a if ta < tb else b
    ra, rb = _material_grade_rank(a), _material_grade_rank(b)
    if ra is not None and rb is not None and ra != rb:
        return a if ra > rb else b
    return None


def _parse_date(v: Any) -> Optional[date]:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = _clean(v)
    if not s or s in (' ', 'None'):
        return None
    for fmt in ('%Y-%m-%d', '%Y/%m/%d', '%d/%m/%Y', '%m/%d/%Y', '%Y.%m.%d'):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None

def _to_float(v: Any) -> Optional[float]:
    if v is None:
        return None
    try:
        return float(str(v).strip())
    except (ValueError, TypeError):
        return None

def _is_deleted(row: tuple) -> bool:
    v = _clean(row[Col.DELETE_STATUS - 1] if len(row) >= Col.DELETE_STATUS else None)
    return bool(v)

def _same_wps(a: str, b: str) -> bool:
    """두 WPS 번호가 «같은 WPS»인가. 맨 앞 프로젝트 코드는 빼고 본다.

        TR-FC-G03  ==  RU-FC-G03      같은 WPS다
        TR-FC-G03  !=  TR-FC-G01
    """
    if not a or not b:
        return False
    return a.upper() == b.upper() or wps_rules.wps_core(a) == wps_rules.wps_core(b)


def _is_repair_wps(wps_no: str) -> bool:
    """수리(repair) WPS인지. 접두사는 활성 프로파일의 `params`에서 온다.

    매크로 원문의 접두사는 `RU-`인데 실데이터는 `TR-`이다(§11-9). 프로젝트마다
    다를 수 있어 설정으로 뺐다.

    **접두사가 비면 «수리 WPS 없음»이다.** `startswith("")`는 항상 True라, 그냥
    넘기면 **모든 WPS가 수리로 분류되어 Check 2·4·11이 통째로 빠진다.**
    실측(params 없는 프로파일): Check 4 36 -> 0, Check 11 94 -> 0.

    params가 없는 프로파일은 «새 프로젝트를 처음 돌리는» 경로 그 자체라, 이 결함은
    가장 중요한 순간에 «결함이 거의 없는 깨끗한 결과»를 만들어 낸다. 오류도 경고도
    나지 않는다 — `check_rules_alive()`가 접두사가 빈 것을 따로 경고한다.
    """
    prefixes = wps_rules.repair_prefixes()
    if not wps_no or not prefixes:
        return False
    # 맨 앞 «TR»은 프로젝트 번호다(현업 확인 2026-08-14). 접두사가 `TR-FC-R`이어도
    # RUYA의 `RU-FC-R01`에 걸려야 한다 — 같은 WPS를 프로젝트 번호만 바꿔 만든다.
    # 통째로 비교하면 프로젝트가 바뀌는 순간 **수리 WPS를 한 행도 못 알아본다.**
    #
    # 접두사는 **여럿**일 수 있다. RUYA는 수리 WPS가 `FC`·`GTFC`·`SMFC` 세 계열에
    # 걸쳐 있어 하나로는 덮이지 않는다.
    name = wps_no.upper()
    core = wps_rules.wps_core(wps_no)
    return any(name.startswith(p) or core.startswith(wps_rules.wps_core(p))
               for p in prefixes)

def _groove_in_joint_detail(groove: str, joint_detail: str) -> bool:
    """QMG의 Groove(R열)가 WPS의 Joint Detail(L열)에 포함되는지.

    Check 4가 쓰던 로직을 모듈 수준으로 올린 것이다. Check 5 재정의(개선계획 4번)가
    "이 Groove를 추천 WPS가 받을 수 있는가"를 판단할 때 같은 규칙이 필요해졌다.
    두 곳이 서로 다르게 매칭하면 «G03으로 옮기라 해놓고 옮기면 Check 4 위반»이 되는
    모순이 생긴다.

    괄호 주석과 repair/multi/pass 같은 수식어를 걷어낸 뒤 토큰으로 쪼개 비교한다.

    ## 표기 해석은 **프로젝트 설정**에서 온다

    같은 이음을 프로젝트마다 다르게 적는다(현업 2026-08-24):

        TRION   L열 `SB, DB, SV, DV, FL`      — 다 풀어 적는다
        RUYA    L열 `DB/DV, PJP, SB/SV 중 하나`  — 묶어 적고 `FILLET`이 FL·FW를 뜻한다

    그래서 `PP -> PJP` 하나만 코드에 두던 것을 `wps_rules.groove_aliases()`로
    옮겼다. **기본값이 그 하나뿐이라 설정을 안 건드린 프로젝트는 한 행도
    달라지지 않는다.**
    """
    if not groove or not joint_detail:
        return True          # 판단 근거가 없으면 «아니다»라고 단정하지 않는다
    gr = groove.upper().strip()
    aliases = {gr} | wps_rules.groove_aliases().get(gr, set())
    if aliases & _joint_detail_tokens(joint_detail):
        return True
    # **한글이 붙어 있어도 읽는다.** `FILLET중 하나`처럼 띄어쓰기가 사라지면
    # 토큰이 `FILLET중`이 되어 안 맞는다 — 한글 문서에서 띄어쓰기는 언제든
    # 사라진다(현업 2026-08-24). 앞뒤가 영숫자가 아니면 그 표기가 그 자리에
    # «적혀 있는» 것이다. 영숫자 경계를 두므로 `SB`가 `SBX`에 걸리지는 않는다.
    text = _jd_clean(joint_detail)
    return any(re.search(r"(?<![A-Z0-9])" + re.escape(a) + r"(?![A-Z0-9])", text)
               for a in aliases if a)


def _joint_detail_tokens(joint_detail: str) -> set[str]:
    """WPS의 Joint Detail(L열)을 비교 가능한 토큰 집합으로 만든다.

    괄호 주석과 repair/multi/pass 같은 수식어를 걷어낸 뒤 쪼갠다.
    Check 4의 오류 메시지가 «허용되는 값 목록»을 보여줄 때도 같은 집합을 쓴다 —
    판정에 쓴 것과 다른 목록을 보여주면 현장이 메시지를 못 믿는다.
    """
    # **`/`도 구분자다.** `DB/DV`는 어느 프로젝트에서나 «DB 또는 DV»인데, 안 쪼개면
    # `DB/DV` 한 덩어리가 되어 `DB`도 `DV`도 안 맞는다 — RUYA에서 실제로 그랬다.
    # 토큰을 «더하기»만 하므로 결함이 새로 생길 수는 없다(실측: TRION WPS 26개
    # L열에 `/`가 한 번도 없어 영향이 0이다).
    return {t.strip().upper() for t in re.split(r"[,/\n\r\s]+", _jd_clean(joint_detail))
            if t.strip()}


def _jd_clean(joint_detail: str) -> str:
    """괄호 주석과 repair/multi/pass 같은 수식어를 걷어낸 **대문자 원문.**

    토큰으로 쪼개기 «전»의 글자열이 따로 필요하다 — 한글이 붙어 버린 표기
    (`FILLET중`)는 토큰으로는 못 잡고 원문에서 경계로 찾아야 한다.
    """
    jd = re.sub(r"\(.*?\)", "", joint_detail or "", flags=re.DOTALL)
    jd = re.sub(r"\.?\s*(repair|multi|pass|side|run|both)[^,\n]*", "", jd,
                flags=re.IGNORECASE)
    return jd.upper()


def _row_val(row: tuple, col: int) -> Any:
    idx = col - 1
    return row[idx] if idx < len(row) else None

# 상세 결과 화면의 "원본 데이터" 패널에 표시할 컬럼 — 엑셀 원문 순서대로.
_RAW_SNAPSHOT_COLS: list[tuple[str, int]] = [
    ('도면번호',      Col.DRAWING_NO),
    ('블록',          Col.BLOCK),
    ('Joint No',      Col.JOINT_NO),
    ('Out Dia',       Col.OUT_DIA),
    ('두께 1',        Col.THICKNESS1),
    ('두께 2',        Col.THICKNESS2),
    ('재질 1',        Col.MATERIAL1),
    ('재질 2',        Col.MATERIAL2),
    ('NDT Cat',       Col.NDT_CAT),
    ('Groove',        Col.GROOVE),
    ('WPS No',        Col.WPS_NO),
    ('WPS Process',   Col.WPS_PROCESS),
    ('용접일',        Col.WELD_DATE),
    ('NDT 계획일',    Col.NDT_DATE),
    # 추적 키. 검색은 되는데 «찾은 행에서 그 번호를 볼 수 없는» 상태였다.
    ('NDT REPORT 번호', Col.NDT_REPORT),
    ('VT 수행일',     Col.VT_DATE),
    ('RT 수행일',     Col.RT_DATE),
    ('UT 수행일',     Col.UT_DATE),
    ('MT 수행일',     Col.MT_DATE),
    ('PT 수행일',     Col.PT_DATE),
    ('용접사 1',      Col.WELDER1_NO),
    ('용접사 1 Proc', Col.WELDER1_PROC),
    ('용접사 2',      Col.WELDER2_NO),
    ('용접사 2 Proc', Col.WELDER2_PROC),
    ('용접사 3',      Col.WELDER3_NO),
    ('용접사 3 Proc', Col.WELDER3_PROC),
    ('용접사 4',      Col.WELDER4_NO),
    ('용접사 4 Proc', Col.WELDER4_PROC),
    ('부서',          Col.DEPARTMENT),
    ('팀',            Col.TEAM),
]

# 스냅샷의 «머리말». 행마다 같으므로 한 번만 만들어 둔다.
RAW_SNAPSHOT_HEADER: list[dict] = [
    {'label': label, 'col': get_column_letter(col)}
    for label, col in _RAW_SNAPSHOT_COLS
]


def _row_snapshot(row: tuple) -> list[str]:
    """상세 결과 화면에서 보여줄 '원본 데이터' 스냅샷 — **값만** (엑셀 컬럼 순서).

    예전에는 행마다 `{'label':…, 'col':…, 'value':…}` dict를 30개씩 만들었다.
    `label`과 `col`은 **모든 행에서 똑같은데** 행마다 dict를 새로 만드니, 스냅샷
    하나가 30개 dict(각 3키)가 됐다. 이 스냅샷은 결함 행과 미작업 행 전부에
    붙으므로 결과 payload의 **62%**를 차지했다(실측 60,179행에서 73MB).

    지금은 값만 담고 머리말은 `RAW_SNAPSHOT_HEADER` 하나로 둔다. 화면에 나갈 때
    라우터가 다시 붙인다 — 사용자가 클릭한 **한 행**만 그러면 되므로 공짜다.

    38만 행에서 메모리가 부족해 서버가 스왑으로 멎던 것을 줄이려는 것이다.
    """
    return [_clean(_row_val(row, col)) for _, col in _RAW_SNAPSHOT_COLS]


def raw_with_labels(values: list) -> list[dict]:
    """저장된 값 목록에 머리말을 다시 붙인다. 화면이 기대하는 모양.

    옛 회차가 dict 목록으로 저장돼 있을 수도 있다 — 그때는 그대로 돌려준다.
    `SCHEMA_VERSION`을 올려 두었으므로 정상 경로에서는 생기지 않지만, 여기서
    터지면 **상세 모달만 조용히 비는** 형태가 된다.
    """
    out: list[dict] = []
    for i, v in enumerate(values or []):
        if isinstance(v, dict):
            out.append(v)
            continue
        head = RAW_SNAPSHOT_HEADER[i] if i < len(RAW_SNAPSHOT_HEADER) else {}
        out.append({'label': head.get('label', ''), 'col': head.get('col', ''),
                    'value': v})
    return out

# ─── 두께 범위 파싱 ──────────────────────────────────────────────────────────
def _parse_thickness_ranges(text: str) -> list[tuple[float, float]]:
    """
    "3~50", "3 ~ 50", "3-50", "12.5-50", **"8 to 50"** 등 지원.
    matched set으로 공백 tilde 삼중매칭 버그 방지.

    **`to` 표기를 받는 이유** (2026-09-07): RUYA의 WPS 등록부는 두께를
    `8 to 50`으로 적는다(TRION은 `3~50`). 이걸 못 읽으면 범위가 비고,
    `_thickness_in_range()`는 **빈 범위를 «통과»로 본다** — 그래서 RUYA에서는
    Check 3(두께)이 아무것도 잡지 못한 채 «문제 없음»으로 보인다.
    오류가 아니라 조용히 판정이 사라지는 종류다.
    """
    ranges: list[tuple[float, float]] = []
    matched: set[int] = set()

    # 1) "숫자 [~|-|to] 숫자" (양쪽 경계)
    for m in re.finditer(
            r'(\d+(?:\.\d+)?)\s*(?:[~\-]|\bto\b)\s*(\d+(?:\.\d+)?)',
            text, re.IGNORECASE):
        lo, hi = float(m.group(1)), float(m.group(2))
        if lo <= hi:
            ranges.append((lo, hi))
            matched.update(range(m.start(), m.end()))

    # 2) "숫자~" (상한 없음)
    for m in re.finditer(r'(\d+(?:\.\d+)?)\s*~', text):
        if m.start() not in matched:
            ranges.append((float(m.group(1)), 9999.0))

    # 3) "~숫자" (하한 없음)
    for m in re.finditer(r'~\s*(\d+(?:\.\d+)?)', text):
        if m.start() not in matched:
            ranges.append((0.0, float(m.group(1))))

    return ranges

def _thickness_in_range(thickness: float, range_text: str) -> bool:
    if not range_text:
        return True
    ranges = _parse_thickness_ranges(range_text)
    if not ranges:
        return True
    return any(lo <= thickness <= hi for lo, hi in ranges)

# 선급강 등급 접미사(A/D/E/F) -> 샤르피 충격시험 온도(°C). Check 8은 -40°C 이하
# 등급에서만 발동해야 하는데, 예전 minus40 키워드 리스트는 'DH36'(-20°C, 오류)을
# 포함하고 'NV-E36'/'NV-E36Z'/'NV-EW420Z'(전부 -40°C, 판정대상 기준 각 113/40/3건,
# 합계 156건 실존)를 빠뜨리고
# 있었다(감사에서 확인). MATERIAL_MAP의 'E36' 키는 WPS 커버리지 목적상 A/D/E
# 등급을 하나로 묶어버려 온도 구분에 못 쓰므로, 원문 표기에서 직접 등급 문자를
# 추출한다.
_GRADE_IMPACT_TEMP_C: dict[str, int] = {'A': 0, 'D': -20, 'E': -40, 'F': -60}
_GRADE_SUFFIX_RE = re.compile(r'^([ADEF])[HWO]?(?:36|420)Z?$')

def _material_impact_temp_c(raw_material: str) -> Optional[int]:
    """
    선급강 표기(NV-EH36, NV-EW420Z, DH36 등)에서 등급 접미사를 추출해 충격시험
    온도를 반환한다. ASTM A36처럼 등급 접미사가 없는 일반 표기는 None(판단 불가).
    """
    up = re.sub(r'[\s\-_]+', '', raw_material.upper())
    up = re.sub(r'^NV', '', up)
    m = _GRADE_SUFFIX_RE.match(up)
    return _GRADE_IMPACT_TEMP_C[m.group(1)] if m else None

# ─── 재질 매핑 ────────────────────────────────────────────────────────────────
MATERIAL_MAP: dict[str, list[str]] = {
    'EO420':  ['EO420', 'NV-EO420', 'NV EO420'],
    'EW420':  ['EW420', 'NV-EW420', 'NV EW420', 'NV-EW420Z'],
    'DW420':  ['DW420', 'NV-DW420', 'NV DW420'],
    'API2H':  ['API 2H', 'API2H', 'API-2H'],
    'API5L':  ['API 5L', 'API5L', 'API-5L'],
    'A53B':   ['A53GRB', 'ASTM A53B', 'ASTM-A53B', 'A53B', 'STPG370'],
    'A36_AR': ['ASTM A36', 'ASTM-A36', 'A36 (AS', 'A36(AS', 'AH36 (AS', 'AB AH36'],
    # 11-4 1차 처리(2026-08-02): 예전에는 A500을 'A36_AR' 키로 묶어 F열의
    # "ASTM A36" 문구에 매칭시켰다. A500 Gr.B(냉간성형 중공형강, ~315MPa)는
    # A36(열간압연 판재, 250MPa)보다 강도가 높고 성형이력이 달라 표준 논리상
    # 같은 자격으로 묶일 근거가 없다(QC_검사로직_상세분석.md §11-4 참고) — 그래서
    # 별도 키로 분리한다. WPS F열에 'ASTM A500'이 명시적으로 없는 한 이제
    # 미승인 재질로 잡힌다(실데이터 22건, TR-SMFC-G01).
    'A500':   ['ASTM A500', 'A500'],
    # 'SM355'(KS/JIS 계열 355MPa급)은 WPS G열에서 S355NH와 같은 항목으로 묶여
    # 관리된다는 현업 확인에 따라 S355NH 키로 취급한다(실데이터 SM355A 2,076건).
    'S355NH': ['S355NH', 'EN S355NH', 'SM355', 'KS SS275', 'JIS SS400'],
    'EH36':   ['NV-EH36', 'EH36', 'NV EH36'],
    'DH36':   ['NV-DH36', 'DH36', 'NV DH36'],
    'AH36':   ['NV-AH36', 'AH36', 'NV AH36'],
    # 'E36'은 A/D/E(W)36 계열의 통칭 키. 'AW36','DW36','EW36'만 있고 'E36' 자체가
    # 빠져 있어서 실제 운영 데이터의 'NV-E36'/'NV-E36Z'(153건)가 매핑 실패로
    # 두께 검사에서 통째로 제외되고 있었다(감사에서 확인). 'E36','D36','A36'을 보강.
    # EH36/DH36/AH36 키가 이 항목보다 먼저 조회되므로 'NV-EH36' 등은 여기 걸리지 않는다.
    'E36':    ['NV-A36', 'NV A36', 'A36', 'D36', 'E36', 'AW36', 'DW36', 'EW36'],
}

# ─── §11-1 종결 (2026-08-08 -> 2026-08-10) ────────────────────────────────────
# 한동안 WPS G열의 "A36, S355NH(As Rolled): 3~24"를 PQR 승인범위(12.5~50)로
# 덮어쓰고 있었다. 표준 조사로 «G열 값은 AH36 12mm 시험재에서 나온 것이고 SM355A에는
# 해당하지 않는다»고 추론했기 때문이다.
#
# **현업 확인 결과 그 추론이 틀렸다** — G열의 3~24가 회사가 적용하는 값이다.
# WPS가 PQR보다 좁게 제한한 경우였고, 그건 표준상 허용된다(WPS 범위 ⊆ PQR 범위).
# 오버라이드를 걷어냈다. Check 3이 45건 -> 약 790건으로 돌아온다.
#
# 남길 교훈: **공개 표준으로 도출한 결론은 그 문서의 실제 의도를 대신하지 못한다.**
# 같은 날 §11-3(PJP)·§11-4(A500)도 같은 방식으로 뒤집혔다.

def _get_material_key(material: str) -> str | None:
    """
    QMG M열 재질 표기를 표준 재질 키로 변환.
    매핑표에 없는 재질은 'E36'으로 임의 폴백하지 않고 None을 반환한다 —
    실제 운영 데이터에 A53GRB/ASTM A53B/NV-DW420 등 매핑표에 없던 재질이
    존재했는데, 예전처럼 'E36'으로 폴백하면 전혀 무관한 재질에 E36 계열의
    느슨한 두께범위가 잘못 적용되어 결함을 놓칠 수 있었다(감사 결과 확인됨).
    """
    # 공백/하이픈/언더스코어를 전부 제거해 비교한다 — 'ASTM A36' / 'ASTM-A36' / 'ASTMA36'처럼
    # 구분자 유무만 다른 표기가 서로 다른 키로 갈리는 것을 막는다. 예전에는 하이픈만
    # 공백으로 바꿔서 비교했는데, 구분자가 아예 없는 'ASTMA36'(70건 실존)이 A36_AR의
    # 'ASTM A36' 패턴과 매칭되지 않고 뒤쪽 E36 키의 느슨한 'A36' 패턴에 먼저 걸려
    # 선급 고장력강으로 오분류되고 있었다(감사에서 확인, 두께가 낮아 현재 결과는 무변경).
    m_up = re.sub(r'[\s\-_]+', '', material.upper())
    for key, patterns in MATERIAL_MAP.items():
        for pat in patterns:
            pat_up = re.sub(r'[\s\-_]+', '', pat.upper())
            if pat_up in m_up:
                return key
    return None

def _material_covered_by_wps(material_key: str, wps_base_metal: str) -> bool:
    bm = wps_base_metal.upper()
    checks: dict[str, list[str]] = {
        'EO420':  ['EO420'],
        'EW420':  ['EW420'],
        # 11-4 1차 처리(2026-08-02): DNV 등급 문자는 충격시험 온도를 뜻한다
        # (D=-20℃, E=-40℃). EO420(E등급, -40℃)은 DW420(D등급, -20℃)보다 더
        # 가혹한 조건으로 자격된 것이므로, 420 강도 등급에서 EO420 자격이
        # DW420을 포괄한다고 볼 표준 논리가 성립한다(QC_검사로직_상세분석.md
        # §11-4 참고) — F열에 DW420이 없어도 EO420이 있으면 커버된 것으로 본다.
        'DW420':  ['DW420', 'EO420'],
        'API2H':  ['API 2H', 'API2H', '2H GR'],
        # WPS G열은 API 5L 계열을 그레이드명 'X52'로만 표기하는 경우가 있다
        # (TR-SMFC-G01의 'X52 and No Impact Grade' 항목).
        'API5L':  ['API 5L', 'API5L', 'X52'],
        'A53B':   ['A53B', 'ASTM A53', 'STPG370'],
        'A36_AR': ['A36', 'AS ROLL', 'ASTM A36', 'S355NH'],
        # 11-4 1차 처리: A500은 더 이상 A36_AR과 묶이지 않으므로, WPS F열에
        # 'ASTM A500'이 명시적으로 있어야만 커버된 것으로 본다.
        'A500':   ['ASTM A500', 'A500'],
        'S355NH': ['S355NH', 'SS275', 'SS400'],
        'EH36':   ['E(EW)36', 'EH36', 'EW36', 'A(AW)~E(EW)36'],
        'DH36':   ['D(DW)36', 'DH36', 'A(AW)~E(EW)36'],
        'AH36':   ['A(AW)36', 'AH36', 'AW36', 'A(AW)~E(EW)36'],
        # 'NV E'는 너무 짧아 'NV EO420(Z)'(EO420 전용 WPS)에도 걸려서, E36 계열이
        # EO420 전용 WPS에서 허용된 것으로 오판됐다 → 'NV E36'으로 좁힌다.
        'E36':    ['A(AW)~E(EW)36', 'A36', 'NV A', 'NV E36', 'KS SS', 'JIS SS'],
    }
    for pat in checks.get(material_key, ['A(AW)~E(EW)36']):
        if pat.upper() in bm:
            return True
    return False

_E36_FAMILY = {'AH36', 'DH36', 'EH36', 'E36'}

# 관재(각관·강관) 재질 — 철판이 아니라 I열 Out Dia 규격이 판정 기준이 된다.
# 현재는 현업 확인이 된 A500 계열만 대상으로 한다(Check 12).
_TUBULAR_PATTERNS = ('A500',)

def _is_tubular_material(material: str) -> bool:
    m_up = material.upper().replace('-', ' ').replace('_', ' ')
    return any(p in m_up for p in _TUBULAR_PATTERNS)

# 충격시험 면제강(Impact test exemption grade) 그룹.
# WPS G열은 이 강종들의 두께범위를 개별 재질명이 아니라 강종 그룹명으로 적는다
# (예: TR-FC-F01 'Normal strength steel(Impct exemption steel)',
#      TR-GTFC-G01 'Others, Impact Test Exemption Grades',
#      TR-SMFC-G01 'X52 and No Impact Grade').
# 그룹명 라벨과 개별 재질을 이어주지 않으면 해당 행들이 두께 검사에서 통째로
# 빠지므로(실데이터 1,546건), 아래 재질 키를 그룹 라벨에 매칭시킨다.
_IMPACT_EXEMPT_KEYS = {'A36_AR', 'A53B', 'S355NH'}
_IMPACT_EXEMPT_LABEL_RE = re.compile(
    r'IMPACT\s*(TEST)?\s*EXEMPTION|IMPCT\s*EXEMPTION|NO\s*IMPACT|NORMAL\s*STRENGTH',
    re.IGNORECASE,
)

def _parse_material_thickness_entries(text: str) -> list[tuple[str, str]]:
    """
    WPS G열(두께범위) 셀은 실제로는 별도 행이 아니라 **한 셀 안에 여러 줄로**
    "재질 라벨 : 두께범위" 항목이 나열되어 있다 (예: TR-FC-G01의 G열 =
    "~E36\\n: 3~50\\n\\nEO420 (For Dissimilar)\\n:25~38\\n\\nEW420\\n:13~50\\n...").
    이 함수는 그 텍스트를 (재질 라벨, 두께범위 텍스트) 목록으로 분리를 시도한다.

    실제 WPS 27개를 전수 확인한 결과 셀 서식이 완전히 자유 텍스트라 100% 모든
    변형(중첩 조건 "[1pole]" 등, "All" 단일 텍스트, 라벨 없는 단일 범위)을
    안전하게 다 구조화할 수는 없다 — 그런 경우 이 함수는 빈 리스트를 반환하고,
    호출부(_c3_thickness)가 기존 방식(전체 텍스트에서 범위만 추출)으로 안전하게
    폴백한다. 즉 이 함수가 실패해도 결함을 못 잡는 방향으로만 안전하게 후퇴하며,
    잘못된 재질 매칭으로 새로 오류를 만들어내지는 않는다.
    """
    entries: list[tuple[str, str]] = []
    pending_label = ''
    for raw_line in text.split('\n'):
        line = raw_line.strip()
        if not line:
            continue
        if ':' in line:
            label_part, _, range_part = line.partition(':')
            label_part = label_part.strip()
            label = label_part if label_part else pending_label
            if label and re.search(r'\d', range_part):
                entries.append((label, range_part))
            pending_label = ''
        elif not re.match(r'^[\d\s~\-.]+$', line):
            # 콜론 없는 줄 = 다음 콜론 줄과 짝지어질 재질 라벨 후보.
            # 순수 숫자/범위 기호만 있는 줄은 라벨 후보에서 제외.
            pending_label = line
    return entries

def _label_matches_material(material_key: str, label: str) -> bool:
    """G열의 재질 라벨 한 조각이 주어진 표준 재질 키를 가리키는지 판정."""
    if _material_covered_by_wps(material_key, label):
        return True
    # "~E36", "A(AW)~E(EW)36", "NV E36 and lower grade" 같은 축약 표기는
    # E36 계열(AH36/DH36/EH36/E36) 전체를 통칭하는 조선업계 관용 표기.
    if material_key in _E36_FAMILY:
        label_up = label.upper()
        if re.search(r'E\s*\(?\s*E?W?\)?\s*36', label_up) or '~E36' in label_up.replace(' ', ''):
            return True
    # 충격시험 면제강 그룹명 라벨 ↔ 개별 면제강 재질
    if material_key in _IMPACT_EXEMPT_KEYS and _IMPACT_EXEMPT_LABEL_RE.search(label):
        return True
    return False

# ─── 데이터 로더 ──────────────────────────────────────────────────────────────
class QCDataLoader:
    def __init__(self) -> None:
        self.wps_table: dict[str, dict] = {}
        self.welder_qual: dict[str, dict[str, set[str]]] = defaultdict(
            lambda: {'process': set(), 'position': set()}
        )
        self.retired_welders: set[str] = set()  # 퇴사 상태이나 자격은 유지 포함(11-6)
        # 자격 DB의 부가 정보 — 판정에는 쓰지 않고 화면/리포트 표시용.
        # 용접사 번호만으로는 관리자가 누구인지 특정하기 어려워 이름을 함께 보여준다.
        self.welder_names: dict[str, str] = {}          # 번호 -> 이름
        self.welder_certs: dict[str, dict[str, Any]] = {}  # 번호 -> 자격 상세
        self.qmg_rows: list[tuple[int, tuple]] = []
        # 승인 용접봉 리스트의 Lot No. 집합(대문자·공백 제거). **비어 있으면
        # Check 28이 한 행도 판정하지 않는다** — 그 0건은 «문제 없음»이 아니라
        # «대조할 목록이 없다»이고, `_scope`가 그 둘을 구분해 준다.
        self.consumable_lots: set[str] = set()
        # 아래 둘은 **Copilot 자료 전용**이다 — 판정 경로는 보지 않는다.
        # 원본 워크북은 파싱 뒤 지워지므로, 여기서 안 담으면 되살릴 길이 없다.
        self.consumable_columns: list[str] = []
        self.consumable_rows: list[dict] = []
        # 용접사 번호 -> {"expire": date|None, "disq": date|None, "effective": date}
        # **자격 DB와 별개 파일이다.** 비어 있으면 Check 7이 한 행도 판정하지 않고,
        # `_scope`가 그 사실을 «대상 없음»으로 말한다.
        self.welder_expiry: dict[str, dict] = {}

    # 승인 용접봉 리스트의 «모양». 현업이 준 양식에 고정돼 있다 —
    # 25열 · 머리말 3~4행 · 데이터 5행부터 · **3열이 Lot No.**
    # 여기를 바꾸면 실제 파일과 어긋난다. 열 위치는 `Col`과 같은 성격의 상수다.
    CONSUMABLE_HEADER_ROWS = 4
    CONSUMABLE_LOT_COL     = 3

    def load_consumables(self, path: str | Path) -> int:
        """승인 용접봉 리스트에서 Lot No.를 걷는다. 걷은 개수를 돌려준다.

        **시트 이름을 보지 않는다.** 첫 시트를 쓴다 — 이름을 박아 두면 현업이
        시트 이름을 바꾸는 순간 «목록을 못 읽는다»가 되고, 원인이 시트 이름이라는
        것은 알기 어렵다. WPS 참조 파일을 확장자로 찾는 것과 같은 이유다.

        빈 칸과 머리말 잔재를 걸러 낸다. 파일 끝에 빈 행이 붙어 있는 것이 흔하다.

        ## 원본 열도 함께 담는다 — **판정은 이것을 보지 않는다**

        판정(Check 18)이 묻는 것은 「이 Lot이 목록에 있는가」 하나라 Lot 집합이면
        충분하다. 그런데 Copilot에 올릴 자료는 «그 Lot이 무엇인가»(상표·규격·
        제조사…)를 함께 보여야 쓸모가 있고, 업로드된 원본은 파싱 뒤 지워진다.

        그래서 `consumable_columns`(머리말)와 `consumable_rows`(Lot별 원문)를
        **곁들여** 담는다. `consumable_lots`는 종전 그대로다 — 판정 경로에는
        한 글자도 손대지 않았다.

        열 이름은 머리말의 **마지막 줄**에서 딴다(그 바로 아래가 데이터다).
        비어 있는 칸은 `열3`처럼 번호로 메운다 — 이름이 없다고 그 열을 버리면
        원본에 있던 정보가 조용히 사라진다.
        """
        p = Path(path)
        wb = load_workbook(str(p), data_only=True, read_only=True,
                           keep_vba=(p.suffix.lower() == ".xlsm"))
        try:
            ws = wb[wb.sheetnames[0]]
            lots: set[str] = set()
            header: list[str] = []
            rows: list[dict] = []
            for i, row in enumerate(ws.iter_rows(values_only=True), start=1):
                if i == self.CONSUMABLE_HEADER_ROWS:
                    header = [_clean(v) or f"열{n}"
                              for n, v in enumerate(row or (), start=1)]
                    continue
                if i <= self.CONSUMABLE_HEADER_ROWS:
                    continue
                v = _clean(_row_val(row, self.CONSUMABLE_LOT_COL))
                if not v:
                    continue
                lots.add(v.upper())
                # Lot 열 자신은 빼고 담는다 — 내보낼 때 첫 열이 이미 Lot이라
                # 그대로 두면 같은 값이 두 열에 나온다.
                lot_idx = self.CONSUMABLE_LOT_COL - 1
                rows.append({"lot": v.upper(),
                             "cells": {header[n]: _clean(c)
                                       for n, c in enumerate(row or ())
                                       if n < len(header) and n != lot_idx
                                       and _clean(c)}})
            self.consumable_lots    = lots
            self.consumable_columns = [c for n, c in enumerate(header)
                                       if n != self.CONSUMABLE_LOT_COL - 1]
            self.consumable_rows    = rows
        finally:
            wb.close()
        logger.info("승인 용접봉 %d개 로드 완료: %s", len(self.consumable_lots), p.name)
        return len(self.consumable_lots)

    def load_consumables_from_list(self, lots: list[str]) -> None:
        """캐시 JSON에서 되살린다. 업로드 없이도 검증이 돌아야 한다."""
        self.consumable_lots = {str(x).strip().upper() for x in lots if str(x).strip()}

    def load_wps(self, xlsm_path: str | Path,
                 progress: Callable[[int, str], None] | None = None) -> None:
        p = Path(xlsm_path)
        wb = load_workbook(str(p), data_only=True,
                           keep_vba=(p.suffix.lower() == '.xlsm'))
        if 'Hull & Topside WPS List' not in wb.sheetnames:
            logger.warning("'Hull & Topside WPS List' 시트를 찾을 수 없음")
            wb.close()
            return
        ws = wb['Hull & Topside WPS List']
        current: str | None = None
        for row in ws.iter_rows(min_row=6, values_only=True):
            wps_no = _clean(_row_val(row, WPSCol.WPS_NO))
            bm     = _clean(_row_val(row, WPSCol.BASE_METAL))
            thk    = _clean(_row_val(row, WPSCol.THICKNESS))
            if wps_no:
                # **Rev 표기를 떼고 등록한다.** WPS List에는 `RU-FC-G01(Rev.8)`
                # 처럼 개정 번호가 붙는데 원시 데이터에는 없다 — 그대로 두면
                # 한 행도 안 맞는다(현업 보고 2026-08-24, RUYA).
                key = wps_rules.strip_revision(wps_no) or wps_no
                if key in self.wps_table and self.wps_table[key].get('wps_no') != wps_no:
                    # 같은 WPS의 다른 개정이 둘 이상 실려 있다. **뒤엣것이
                    # 이긴다** — 목록은 대개 개정 순으로 쌓이므로 아래쪽이 최신이다.
                    logger.warning("WPS %s: 개정이 둘 이상 — '%s'를 '%s'로 덮어쓴다",
                                   key, self.wps_table[key].get('wps_no'), wps_no)
                current = key
                self.wps_table[current] = {
                    # 원문을 남긴다. 지적 메시지가 목록에 적힌 이름 그대로여야
                    # 현업이 그 줄을 찾아갈 수 있다.
                    'wps_no':       wps_no,
                    'process':      _normalize_process(_row_val(row, WPSCol.PROCESS)),
                    'position':     _clean(_row_val(row, WPSCol.POSITION)),
                    'joint_detail': _clean(_row_val(row, WPSCol.JOINT_DETAIL)),
                    'materials':    [{'base_metal': bm, 'thk_range': thk}],
                }
            elif current and (bm or thk):
                # 동일 WPS의 재질별 두께 범위 연속 행
                self.wps_table[current]['materials'].append(
                    {'base_metal': bm, 'thk_range': thk}
                )
        wb.close()
        wps_rules.apply_corrections(self.wps_table)
        logger.info("WPS %d개 로드 완료", len(self.wps_table))
        if progress:
            progress(20, f"WPS 참조 로드 완료 ({len(self.wps_table)}개)")

    def load_wps_from_dict(self, wps_data: dict,
                           progress: Callable[[int, str], None] | None = None) -> None:
        """캐시 JSON dict에서 WPS 테이블 로드.

        **옛 캐시는 Rev가 붙은 이름을 열쇠로 갖고 있다.** 여기서 함께 떼지
        않으면 캐시를 쓰는 서버만 계속 오탐이 나고, 원인이 «캐시»라는 것은
        알기 어렵다.
        """
        self.wps_table = {}
        for name, v in (wps_data or {}).items():
            key = wps_rules.strip_revision(name) or name
            if key != name and isinstance(v, dict):
                v = dict(v, wps_no=v.get('wps_no') or name)
            self.wps_table[key] = v
        wps_rules.apply_corrections(self.wps_table)
        logger.info("WPS 캐시 %d개 로드 완료", len(self.wps_table))
        if progress:
            progress(20, f"WPS 캐시 로드 완료 ({len(self.wps_table)}개)")

    def wps_of(self, wps_no: str) -> dict | None:
        """WPS 표 조회 — **Rev 표기를 양쪽에서 뗀다.**

        표는 뗀 이름으로 등록되지만, 원시 데이터 쪽에 개정이 붙어 오는 프로젝트도
        있을 수 있다. 한 곳에서 처리해야 검사마다 다르게 찾는 일이 안 생긴다.
        """
        if not wps_no:
            return None
        got = self.wps_table.get(wps_no)
        if got is not None:
            return got
        return self.wps_table.get(wps_rules.strip_revision(wps_no))

    def load_welders(self, welder_path: str | Path,
                     progress: Callable[[int, str], None] | None = None) -> str:
        """용접사 파일을 읽는다. **어느 형식으로 읽었는지**를 돌려준다.

        ## 한 파일에서 셋을 얻는다

            번호 + Process   -> Check 6(자격 미등록·Process 부적합) · Check 19(자격자 미투입)
            만료일 · 박탈일   -> Check 7(승인기간 이후 작업)          <- 새 형식에만 있다
            이름             -> 용접사 탭 표시 (판정에는 안 쓴다)

        예전에는 자격 DB와 만료일을 **따로** 올렸다. 두 파일에 같은 사람이 있어도
        서로 몰라서, 한쪽에만 있는 사람이 Check 6과 7에서 **따로 지적**됐다.
        하나로 합치면 그 문제가 원천적으로 사라진다.

        ## 형식을 자동으로 가린다 — 조용히 틀리는 것을 막으려고

        옛 파일을 새 형식으로 읽으면 B열에서 번호를 못 찾아 **전원이 «자격
        미등록»으로 잡힌다.** 오류가 아니라 «갑자기 결함이 수천 건»으로만 보여서
        원인을 짐작할 단서가 없다. 그래서 둘 다 시도해 보고 **사람이 나오는 쪽**을
        쓰고, 어느 쪽이었는지 로그와 업로드 응답에 남긴다.

        ## 퇴사 상태(옛 형식 CB열)는 자격 제외 사유가 아니다

        만료일이 전량 공란이라 «용접 시점에 이미 퇴사 후였는지»를 소급 검증할 수
        없었기 때문이다(§11-6). 새 형식에는 만료일이 있으므로 그 판정은 Check 7이
        정식으로 한다 — 퇴사 여부를 볼 이유가 없어졌다.
        """
        wb = load_workbook(str(welder_path), data_only=True, read_only=True)
        try:
            ws = wb.active
            rows = list(ws.iter_rows(values_only=True))
        finally:
            wb.close()

        # 어느 형식인가 — 실제로 «번호 + 그럴듯한 Process»가 나오는 쪽을 쓴다.
        #
        # **그럴듯함 조건이 필요하다.** `_normalize_process()`는 비어 있지만
        # 않으면 무엇이든 통과시켜서, 새 형식 파일의 머리말(「머리6」·「단위6」)이
        # 옛 형식 자리에서 Process로 읽힌다 — 그러면 머리말 두 줄 때문에 옛
        # 형식으로 판정되어 **파일 전체를 잘못 읽는다**(실제로 그랬다).
        #
        # 용접 프로세스는 표준 코드라 전부 ASCII 대문자다(FCAW·GTAW·SMFC…).
        # 여기 조건은 **판별에만** 쓴다 — 실제 적재는 `_normalize_process()`를
        # 그대로 쓰므로 특이 표기를 걸러 버리지 않는다.
        best: tuple[int, tuple] | None = None
        for layout in WelderLayout.ALL:
            _, header, cols = layout
            n = 0
            for r in rows[header:]:
                if not r or not _clean(_row_val(r, cols["no"])):
                    continue
                prc = _normalize_process(_row_val(r, cols["process"]))
                if _looks_like_process(prc):
                    n += 1
            # 같은 점수면 **새 형식이 이긴다** — 지금 쓰는 형식이고, 잘못 골랐을
            # 때 잃는 것이 더 크다(옛 형식으로 읽으면 만료일이 통째로 빠진다).
            if n and (best is None or n > best[0]):
                best = (n, layout)
        if best is None:
            logger.warning("용접사 파일에서 번호+Process를 한 건도 찾지 못했다: %s",
                           welder_path)
            return ""

        _, layout = best
        name, header, cols = layout
        loaded = retired = 0
        for row in rows[header:]:
            if not row:
                continue
            welder_no = _clean(_row_val(row, cols["no"]))
            process   = _normalize_process(_row_val(row, cols["process"]))
            if not welder_no or not process:
                continue
            self.welder_qual[welder_no]['process'].add(process)
            if "position" in cols:
                pos = _clean(_row_val(row, cols["position"]))
                if pos:
                    self.welder_qual[welder_no]['position'].add(pos)
            if "status" in cols:
                status = _clean(_row_val(row, cols["status"]))
                if '퇴사' in status:
                    retired += 1
                    self.retired_welders.add(welder_no)

            # ── 만료일 (새 형식에만 있다) ──
            #
            # **날짜가 비어도 담는다.** 그 사람은 «무기한 유효»가 아니라
            # «만료일이 누락된» 것이고, 그것 자체가 Check 7이 잡는 결함이다.
            if "expire" in cols:
                exp = _parse_date(_row_val(row, cols["expire"]))
                disq = _parse_date(_row_val(row, cols["disq"]))
                dates = [d for d in (exp, disq) if d]
                cur = self.welder_expiry.get(welder_no)
                eff = min(dates) if dates else None
                # 같은 사람이 여러 줄에 나오면 **가장 이른 날**을 쓴다 —
                # 자격이 없던 기간을 놓치지 않으려면 그쪽이 맞다.
                if cur is None or (eff and (cur["effective"] is None
                                            or eff < cur["effective"])):
                    self.welder_expiry[welder_no] = {
                        "expire": exp, "disq": disq, "effective": eff}

            # ── 표시용 부가 정보 (판정에는 관여하지 않음) ──
            wname = _clean(_row_val(row, cols["name"])) if "name" in cols else ""
            if wname and welder_no not in self.welder_names:
                self.welder_names[welder_no] = wname
            cert = self.welder_certs.setdefault(welder_no, {
                'name': wname, 'specs': set(), 'classes': set(),
                'cert_nos': set(), 'first_cert_date': None, 'last_cert_date': None,
            })
            if wname and not cert['name']:
                cert['name'] = wname
            for key, ckey in (('specs', 'spec'), ('classes', 'cls'),
                              ('cert_nos', 'cert_no')):
                if ckey in cols:
                    v = _clean(_row_val(row, cols[ckey]))
                    if v:
                        cert[key].add(v)
            if "cert_date" in cols:
                cdate = _parse_date(_row_val(row, cols["cert_date"]))
                if cdate:
                    if cert['first_cert_date'] is None or cdate < cert['first_cert_date']:
                        cert['first_cert_date'] = cdate
                    if cert['last_cert_date'] is None or cdate > cert['last_cert_date']:
                        cert['last_cert_date'] = cdate
            loaded += 1

        n_exp = sum(1 for r in self.welder_expiry.values() if r["effective"])
        logger.info("용접사 파일 «%s» 형식으로 읽음 — %d명 / %d건"
                    "%s%s", name, len(self.welder_qual), loaded,
                    f" · 만료일 {n_exp}명" if "expire" in cols else " · 만료일 없음",
                    f" · 퇴사 인증행 {retired}건" if retired else "")
        if progress:
            progress(40, f"용접사 DB 로드 완료 ({name} · {len(self.welder_qual)}명)")
        return name

    def load_qmg(self, qmg_path: str | Path,
                 progress: Callable[[int, str], None] | None = None) -> None:
        wb = load_workbook(str(qmg_path), data_only=True, read_only=True)
        ws = wb.active
        self.qmg_rows = []
        for excel_row, row in enumerate(ws.iter_rows(min_row=6, values_only=True), start=6):
            if not any(v for v in row if v not in (None, '', ' ')):
                continue
            self.qmg_rows.append((excel_row, row))
        wb.close()
        logger.info("QMG %d행 로드 완료", len(self.qmg_rows))
        if progress:
            progress(60, f"QMG 데이터 로드 완료 ({len(self.qmg_rows):,}행)")

# ─── 플래그 ──────────────────────────────────────────────────────────────────
class Flag:
    __slots__ = ('check_no', 'col', 'color', 'msg', 'welder_no', 'expected', 'actual')

    def __init__(self, check_no: int | str, col: int, color: str, msg: str,
                 welder_no: str = "", expected: str = "", actual: str = "") -> None:
        # **식별자는 문자열이다.** 공통은 `"3"`, 프로젝트는 `"RUYA1"`.
        # 여기서 정규화하므로 `Flag(3, ...)` 호출 30곳을 그대로 둘 수 있다 —
        # 공통 번호를 문자열로 바꿔도 검토 기록 키(`…|3`)는 f-string이라 같다.
        self.check_no  = str(check_no).strip()
        self.col       = col
        self.color     = color   # "Red" | "Green" | "Blue" | "Yellow" | "Orange" | "Black"
        self.msg       = msg
        self.welder_no = welder_no
        self.expected   = expected   # 기준값 (원본 매크로의 셀 주석에 해당)
        self.actual     = actual     # 실제값

# ─── 검사 엔진 ────────────────────────────────────────────────────────────────
def _team_bucket() -> dict:
    """부서 하위 팀(BG열) 단위 집계 — 부서 버킷과 동일한 지표를 한 단계 더 세분화해서 쌓는다."""
    return {
        'total_rows':     0,   # 판정 대상 행수 (미작업 제외)
        # 그중 임시부재(도면번호 1C*) 행수. 판정에서 빼지는 않고, 대시보드가
        # «임시부재 제외» 토글을 켤 때 **분모를 줄이는 데** 쓴다. 깨끗한 행은
        # flag 테이블에 없어 나중에 셀 수 없으므로 판정하면서 여기서 센다.
        'temp_rows':      0,
        'unworked_rows':  0,   # 미작업(Check 0) 행수 — 결함률 분모에 넣지 않음
        # 사외업체(BF열이 Q·C로 시작하지 않음) 행수 — 판정 대상이 아니다.
        'subcon_rows':    0,
        # 수리 용접(E열 표기) 행수 — **표시용이다.** 정규 항목을 전부 판정받고
        # `total_rows`에도 들어간다. Check 26(NDE 요율)에서만 빠진다.
        'repair_rows':    0,
        'defect_rows':    0,
        'check_stats':    defaultdict(int),
        'welder_totals':  defaultdict(int),
        'welder_defects': defaultdict(int),
        'defects':        [],
        'defect_by_date': defaultdict(int),  # 부서/팀별 "용접 날짜별 결함 발생 추이" (AM열 기준)
    }

def _dept_bucket() -> dict:
    d = _team_bucket()
    d['teams'] = defaultdict(_team_bucket)
    return d

def _is_unworked(row: tuple) -> bool:
    """
    아직 용접이 수행되지 않은 계획 물량인지 판정.

    실제 데이터 전수 확인 결과, WPS No(AJ)가 비어 있는 행은 그 우측의 작업 실적
    컬럼(AK 프로세스 / AM 용접일 / AO NDT계획일 / AP~AW 용접사)이 100% 비어 있고,
    반대로 WPS가 기재된 행 중 용접일이 없는 행은 0건이었다. 즉 WPS 기재 여부가
    '작업 수행 여부'의 정확한 기준이다. 좌측 계획 정보(두께·재질·Groove·NDT Cat)는
    채워져 있으므로 '계획됐지만 아직 미시공'인 물량이다.
    """
    if _clean(_row_val(row, Col.WPS_NO)):
        return False
    for c in (Col.WPS_PROCESS, Col.WELD_DATE, Col.NDT_DATE,
              Col.WELDER1_NO, Col.WELDER2_NO, Col.WELDER3_NO, Col.WELDER4_NO):
        if _clean(_row_val(row, c)):
            return False   # 실적이 일부라도 있으면 미작업으로 단정하지 않는다
    return True


# 사내 부서 코드의 머리글자. 이것으로 시작하지 않으면 **사외업체**다.
_INHOUSE_DEPT_PREFIXES = ("Q", "C")


def _is_subcontractor(row: tuple) -> bool:
    """사외업체 시공 행인가 (현업 확인 2026-09-02).

    부서명(BF열)이 `Q`·`C`로 시작하지 않으면 사외업체다 — 실데이터의 사내 부서는
    `Q520-해양내업생산부`·`C7H0-건조5부`처럼 전부 이 두 글자로 시작한다.

    **사외업체는 판정하지 않는다.** raw data 관리가 부정확해서 판정해도 그 결함이
    시공 품질을 뜻하지 않는다 — 지적해 봐야 «고칠 수 없는 결함»만 쌓인다.
    실측(38만 행 물량): `SWYE-세보테크놀로지` 한 곳, 판정대상 3,255행(0.9%)에
    플래그 7,044건(5.2%)이 달려 있었다.

    **미작업 판정보다 «뒤»에 둔다.** BF가 비어 있는 행은 AJ열부터 실적이 통째로
    비어 있어 `_is_unworked()`가 먼저 미작업으로 가져간다 — 순서를 바꾸면 그
    행들이 «사외업체»로 잘못 분류되고, 실제로는 아직 검사가 진행되지 않은
    사내 물량이다.
    """
    dept = _clean(_row_val(row, Col.DEPARTMENT)).upper()
    return not dept.startswith(_INHOUSE_DEPT_PREFIXES)


def _is_repair(row: tuple) -> bool:
    """수리(Repair) 용접 행인가.

    **E열(RE)이 비어 있지 않기만 하면 수리 시공**이다(현업 확인 2026-08-13,
    2026-09-02 재확인). 값은 `RE`·`R1`·`U1`·`M1`처럼 다양해서 목록으로 셀 수 없다.

    예전에는 기준이 두 곳에서 갈려 있었다 — Check 23은 «비어 있지 않으면»,
    Check 26의 모수 문턱은 «2글자 이상». 같은 «수리인가»를 묻는데 답이 달라지면
    어느 쪽이 맞는지 보는 사람이 알 방법이 없어서 여기 하나로 모았다.
    """
    return bool(_clean(_row_val(row, Col.REPAIR_MARK)))


# 용접재(AL열) 다중값 구분자. **쉼표만이 아니다.**
#
# 실데이터에 `10007488BB22CA1/F902A5B5A7`처럼 슬래시로 이은 표기가 있는데,
# 쉼표로만 나누면 이게 «한 덩어리»가 되어 Check 21이 «1종»으로 세고 Check 18이
# «승인 목록에 없다»로 잡는다. 실측 오탐이 Check 21에서 2,614건(전체의 35.1%),
# Check 18에서 3,275건(8.6%)이었다.
#
# 세미콜론·줄바꿈은 아직 실데이터에서 못 봤지만 함께 넣는다 — 표기가 하나
# 늘어날 때마다 같은 규모의 오탐이 조용히 생기는 자리다.
_CONSUMABLE_SEPARATORS = (",", "/", ";", "\n", "\r")


def _split_consumables(text: str) -> list[str]:
    """용접재(AL열) 표기를 낱개로 나눈다. **Check 18과 21이 같이 쓴다.**

    나누는 방식이 둘로 갈라지면 «21은 2종으로 세는데 18은 한 덩어리로 대조»하는
    상태가 되어, 같은 행에서 한쪽만 결함이 된다.

    앞뒤 공백은 몇 칸이든 지운다(엑셀에 `A, B`처럼 붙는다). 따옴표도 벗겨 낸다 —
    엑셀 표기라 값의 일부가 아니다.
    """
    out = text or ""
    for sep in _CONSUMABLE_SEPARATORS[1:]:
        out = out.replace(sep, _CONSUMABLE_SEPARATORS[0])
    return [p for p in (s.strip().strip('"\'') for s in out.split(",")) if p]

# 「대조 대상」을 세는 검사들. 여기 없는 검사는 **판정 대상 전체**를 본다
# (Check 1·2·3·4·6·11·18·19) — 그건 «대상이 없다»가 아니라 «전부가 대상»이다.
#
# 검사를 추가하면서 관문이 좁으면 여기에도 넣어라. 안 넣으면 그 검사의 0건이
# «검사했고 문제없음»인지 «한 번도 안 돌았는지» 구분되지 않는다.
def check_name(check_id: str) -> str:
    """식별자로 이름을 찾는다. 공통 카탈로그는 **정수 키**를 그대로 둔다 —
    전부 문자열로 바꾸면 정본 문서·테스트·에이전트 정의의 표기가 함께 낡는다."""
    cid = str(check_id).strip()
    if cid.isdigit():
        return CHECK_NAMES.get(int(cid), "")
    return ""            # 프로젝트 규칙 이름은 규칙 정의가 들고 있다


def check_color(check_id: str) -> str:
    cid = str(check_id).strip()
    if cid.isdigit():
        return CHECK_COLORS.get(int(cid), "Gray")
    return "Gray"


_SCOPED_CHECKS: tuple[str, ...] = (
    # 13은 빠졌다 — 결번이라 판정하지 않는다(2026-09-02).
    "7", "8", "9", "12", "14", "16", "17", "20", "21", "22", "23", "24",
    "25", "26", "27")


class QCChecker:
    def __init__(self, loader: QCDataLoader) -> None:
        self.loader        = loader
        self.row_flags:    dict[int, list[Flag]] = {}
        self.row_data:     dict[int, dict]       = {}
        # 상세 결과 화면 "원본 데이터" 패널용 — 행 번호 -> 엑셀 원문 스냅샷.
        # flags_list에 매 플래그마다 중복 저장하면 payload가 커지므로 행당 1회만 보관한다.
        self.row_raw:      dict[int, list[dict]] = {}
        self.stats:        dict[int, int]        = defaultdict(int)
        self.deleted_rows: int                   = 0
        self.unworked_rows: int                  = 0   # Check 0 (판정 대상 아님)
        # 임시부재(1C) — 미작업과 같이 **판정 대상이 아니다.** 건수는 남긴다.
        self.temp_rows: int                      = 0
        self.temp_by_dept: Counter[str]          = Counter()
        # 사외업체(BF열이 Q·C로 시작하지 않음) — 1C와 같이 판정 대상이 아니다.
        self.subcon_rows: int                    = 0
        self.subcon_by_dept: Counter[str]        = Counter()
        # 수리 용접(E열 표기) — **표시용 수량이다.** 정규 항목을 전부 판정받고
        # 분모에도 들어간다. Check 26(NDE 요율)에서만 빠진다.
        self.repair_rows: int                    = 0
        self.repair_by_dept: Counter[str]        = Counter()
        self.unworked_by_dept: dict[str, int]    = defaultdict(int)
        self.unworked_list: list[dict]           = []  # Check 0 상세 목록 (조인트/블록/부서)
        self.welder_missing: dict[str, int]      = defaultdict(int)
        # 대시보드 "용접사별 결함 발생률" (AP열 기준, 전체 부서 통합)
        self.welder_totals:  dict[str, int]      = defaultdict(int)
        self.welder_defects: dict[str, int]      = defaultdict(int)
        # 용접사별 "결함 종류" 약식 표기용 — check_no(6 제외) 별 건수
        self.welder_check_stats: dict[str, dict[int, int]] = defaultdict(lambda: defaultdict(int))
        # "용접 날짜별 결함 발생 추이" (AM열 기준)
        self.defect_by_date: dict[str, int]      = defaultdict(int)
        # 용접일별 **판정 대상** 행수 — 결함 추이의 «분모»다.
        #
        # `flag` 테이블로는 결함 건수만 셀 수 있다(깨끗한 행은 거기 없다). 건수만
        # 보면 «그날 일을 많이 했다»와 «그날 잘못했다»를 구분할 수 없어, 물량이
        # 3배인 달이 «악화»로 읽힌다. 용접사 쪽은 이미 같은 이유로 분모를 갖고
        # 있다(`welder_date_totals`).
        self.judged_by_date: dict[str, int]      = defaultdict(int)
        # "부서별 결함 분류" (BF열 기준)
        self.dept_data: dict[str, dict]          = defaultdict(_dept_bucket)
        # Check 13(이상치)이 1차 판정 이후에 결함 목록에 새로 합류할 때, 기존 defect
        # 항목을 찾아 이어붙이기 위한 인덱스. (dept_data['defects']/teams['defects']에
        # 들어간 dict와 같은 객체를 참조하므로 이걸 통해 갱신하면 양쪽에 다 반영된다.)
        self._defect_entry_by_row: dict[int, dict] = {}
        # Check 13이 전체 분포를 봐야 하므로, 1차 판정 중 만난 판정대상 행을 캐시해둔다.
        self._judged_rows_cache: list[tuple[int, tuple]] = []
        # 이미 '작업성 결함(C6 제외)'으로 집계된 행. 2차 패스(Check 13/14)가
        # 같은 행을 중복 집계하거나, 반대로 C6만 있던 행을 누락하지 않게 한다.
        self._workmanship_rows: set[int] = set()
        # 용접사 -> {(부서, 팀): 행수}. 화면의 «자격 미등록» 목록을 업체에
        # 보낼 때 소속이 없으면 누구에게 물어야 할지 알 수 없다.
        self.welder_orgs: dict[str, Counter[tuple[str, str]]] = defaultdict(Counter)
        # **각 검사가 «무엇을 대조했는가».** 0건에는 두 종류가 있다:
        #
        #     대조했고 위반이 없다        -> 진짜 «문제 없음»
        #     대조할 대상이 아예 없었다    -> 한 번도 판정하지 않았다
        #
        # 화면에서는 둘 다 그냥 «0건»으로 보인다. 실제로 Check 25는 `Q01`로 끝나는
        # WPS가 한 행도 없어 한 번도 안 돌았는데 «통과»로 읽혔다. Check 15가 결번이
        # 된 것도 같은 상황을 뒤늦게 알아차렸기 때문이다.
        #
        # 그래서 검사마다 **적용 관문을 통과한 행 수**를 센다. 0이면
        # `rule_health`가 «대조 대상 없음»을 경고한다.
        #
        # **0으로 미리 채운다.** 관문을 한 번도 통과 못 한 검사는 `Counter`에 키가
        # 아예 안 생겨서, 순회하면 **정작 잡아야 할 «대상 0건»이 빠진다.**
        self._scope: Counter[str] = Counter({no: 0 for no in _SCOPED_CHECKS})
        self._enabled: dict[int, bool] | None = None   # 프로젝트 세팅(한 번만 읽는다)
        # 프로젝트 판정규칙. 회차 안에서 «한 기준»이어야 하므로 한 번만 읽는다.
        self._rules: list | None = None
        self._rule_problems: list[str] = []
        self._rule_matched: dict[str, int] = {}   # 규칙별 선점한 side 수
        # WPS 보정(문서 누락 정정). 판정 코드가 아니라 «자료»라 번호를 따로 갖지
        # 않고 Check 3·11·27이 그대로 쓴다.
        self._wps_overrides: dict | None = None
        self._ov_matched: dict[str, int] = {}     # WPS별 보정이 판정한 side 수
        self._mat_wps: dict[tuple[str, str], int] = {}  # 재질×WPS 분포(규칙 미리보기용)
        self._suppressed: dict[tuple[str, str], int] = {}  # (프로젝트, 공통) -> side 수
        # 임시부재(도면번호 1C*) 중 «판정 대상»인 행수. 대시보드 토글의 분모.
        # Check 16·17의 기준일과 유예기간. run()이 데이터에서 채운다.
        self._ref_date: Optional[date] = None
        self._grace_days: int = wps_rules.inspection_grace_days()
        self.ml_meta: dict | None = None
        self.ml_detail: dict[int, dict] = {}
        # 용접사별 · 용접일별 시공량과 Check별 결함건수.
        # 결함 추이를 '건수'로만 그리면 많이 일한 날과 잘못한 날을 구분할 수 없어
        # 개선/악화 판단이 불가능하다. 분모(그날 시공량)가 있어야 결함률을 그릴 수 있다.
        self.welder_date_totals: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
        self.welder_date_checks: dict[str, dict[str, dict[int, int]]] = defaultdict(
            lambda: defaultdict(lambda: defaultdict(int)))

    def run(self, progress: Callable[[int, str], None] | None = None) -> None:
        self.row_flags      = {}
        self.row_data       = {}
        self.row_raw        = {}
        self.stats          = defaultdict(int)
        self.deleted_rows   = 0
        self.unworked_rows  = 0
        self.temp_rows      = 0
        self.temp_by_dept   = Counter()
        self.subcon_rows    = 0
        self.subcon_by_dept = Counter()
        self.repair_rows    = 0
        self.repair_by_dept = Counter()
        self.unworked_by_dept = defaultdict(int)
        self.unworked_list  = []
        self.welder_missing = defaultdict(int)
        self.welder_totals  = defaultdict(int)
        self.welder_defects = defaultdict(int)
        self.welder_check_stats = defaultdict(lambda: defaultdict(int))
        self.defect_by_date = defaultdict(int)
        self.judged_by_date = defaultdict(int)
        self.dept_data      = defaultdict(_dept_bucket)
        self._defect_entry_by_row = {}
        self._judged_rows_cache   = []
        self._mat_wps             = {}
        self._workmanship_rows    = set()
        self.welder_orgs          = defaultdict(Counter)
        self.ml_meta              = None
        self.ml_detail            = {}
        self.welder_date_totals   = defaultdict(lambda: defaultdict(int))
        self.welder_date_checks   = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))

        # ── Check 16·17의 기준일 ────────────────────────────────────────────
        # "검사가 아직 안 끝난 것"과 "검사를 빠뜨린 것"을 가르려면 기준 시점이
        # 필요하다. **«오늘»을 쓰지 않는다** — 같은 파일을 내일 다시 돌리면 결과가
        # 달라져 재검증 비교가 성립하지 않기 때문이다. 데이터 안에서 가장 늦은
        # 용접일을 «이 데이터가 찍힌 시점»으로 삼는다.
        self._ref_date = None
        for _, r in self.loader.qmg_rows:
            if _is_deleted(r):
                continue
            d = _parse_date(_row_val(r, Col.WELD_DATE))
            if d and (self._ref_date is None or d > self._ref_date):
                self._ref_date = d
        self._grace_days = wps_rules.inspection_grace_days()

        total = len(self.loader.qmg_rows)
        for i, (row_num, row) in enumerate(self.loader.qmg_rows):
            if _is_deleted(row):
                self.deleted_rows += 1
                continue

            welder1_no   = _clean(_row_val(row, Col.WELDER1_NO))
            dept         = _clean(_row_val(row, Col.DEPARTMENT)) or '(부서 미기재)'
            team         = _clean(_row_val(row, Col.TEAM)) or '(팀 미기재)'
            is_temp      = wps_rules.is_temp_member(_row_val(row, Col.DRAWING_NO))
            weld_dt      = _parse_date(_row_val(row, Col.WELD_DATE))
            weld_date_str = weld_dt.isoformat() if weld_dt else ''

            # ── 임시부재(1C 도면)는 판정하지 않는다 — **맨 앞이다** ────────────
            #
            # 현업 결정(§11-13, 2026-08-20): 「1C는 무조건 제외. 최초 그리고
            # 우선 판정이다.」 임시 용접이라 작업도 결과 처리도 불완전해서
            # **볼 필요가 없는 항목**이다.
            #
            # **미작업(Check 0)보다 «앞»이어야 한다.** 뒤에 두면 WPS가 비어
            # 있는 1C 행이 «미작업»으로 세어진다 — 실측으로 미작업 4,475건 중
            # 4,346건(97.1%)이 1C였다. 그러면 미작업 목록도 미작업 Excel 시트도
            # 사실상 1C 목록이 되고, 「1C는 볼 필요가 없다」와 정면으로 어긋난다.
            # 판정 대상 행수는 어느 순서든 같아서 **분모로는 티가 안 난다.**
            #
            # 예전에는 토글이었다 — 판정은 하고 «보기»만 바꿨다(§11-11). 그러면
            # 대시보드와 결함 목록이 다른 기준으로 보였고, 같은 화면 안에서
            # 어느 쪽이 맞는지 보는 사람이 알 방법이 없었다.
            #
            # 행 수는 `temp_rows`로 남긴다 — «몇 건이 빠졌는지»를 화면·Excel·
            # 메일이 말해야 하고, 되돌리기도 이 블록 하나면 된다.
            #
            # **목록도 원본 스냅샷도 담지 않는다.** 여기 걸리는 행은 어느
            # 목록에도 나오지 않아 누를 자리가 없다. 실측 9,488행이다.
            if is_temp:
                self.temp_rows += 1
                self.temp_by_dept[dept] += 1
                self.dept_data[dept]['temp_rows'] += 1
                self.dept_data[dept]['teams'][team]['temp_rows'] += 1
                continue

            # ── Check 0: 미작업 물량은 판정 자체를 하지 않는다 ──────────────────
            # '미작업'과 '결함'은 완전히 다른 영역이라, 결함률 분모(judged_rows)와
            # 용접사·부서·팀 통계 어디에도 섞이지 않도록 여기서 분리한다.
            #
            # **임시부재(1C)는 이 위에서 이미 빠졌다.** 그래서 이 목록에는 1C가
            # 한 행도 없다 — 순서를 바꾸면 목록의 97%가 1C가 된다.
            if _is_unworked(row):
                self.unworked_rows += 1
                self.unworked_by_dept[dept] += 1
                self.dept_data[dept]['unworked_rows'] += 1
                self.dept_data[dept]['teams'][team]['unworked_rows'] += 1
                self.row_raw[row_num] = _row_snapshot(row)
                self.unworked_list.append({
                    'row':        row_num,
                    'drawing_no': _clean(_row_val(row, Col.DRAWING_NO)),
                    'joint_no':   _clean(_row_val(row, Col.JOINT_NO)),
                    'block':      _clean(_row_val(row, Col.BLOCK)),
                    'department': dept,
                    'team':       team,
                })
                continue

            # ── 사외업체는 판정하지 않는다 (현업 결정 2026-09-02) ──────────────
            #
            # 부서명(BF)이 `Q`·`C`로 시작하지 않으면 사외업체다. raw data 관리가
            # 부정확해서 판정해도 그 결함이 시공 품질을 뜻하지 않는다.
            #
            # **미작업 «뒤»다.** BF가 비어 있는 행은 AJ열부터 실적이 통째로 비어
            # 있어 위에서 이미 미작업으로 빠진다 — 순서를 바꾸면 그 행들이
            # «사외업체»로 잘못 분류된다. 실제로는 아직 검사가 진행되지 않은
            # 사내 물량이라, 그 구분이 뒤집히면 미작업 목록에서 조용히 사라진다.
            #
            # 실측(38만 행): `SWYE-세보테크놀로지` 한 곳, 3,255행(판정대상의 0.9%)
            # 에 플래그 7,044건(5.2%)이 달려 있었다.
            if _is_subcontractor(row):
                self.subcon_rows += 1
                self.subcon_by_dept[dept] += 1
                self.dept_data[dept]['subcon_rows'] += 1
                self.dept_data[dept]['teams'][team]['subcon_rows'] += 1
                continue

            # 수리 용접은 **어디서도 빼지 않는다.** 정규 항목을 전부 판정받고
            # `judged_rows`에도 들어간다 — 빠지는 것은 Check 26(NDE 요율)
            # 하나뿐이고, 그 문턱은 `_c26_in_scope()`가 갖고 있다.
            # 여기서는 **표시용 수량만** 센다.
            if _is_repair(row):
                self.repair_rows += 1
                self.repair_by_dept[dept] += 1
                self.dept_data[dept]['repair_rows'] += 1
                self.dept_data[dept]['teams'][team]['repair_rows'] += 1

            self._judged_rows_cache.append((row_num, row))
            # 규칙 편집 화면이 «이 조건에 몇 행 걸리나»를 즉시 세는 데 쓴다.
            # J열과 K열의 재질이 다를 수 있으므로 양쪽을 다 센다.
            _wps_key = _clean(_row_val(row, Col.WPS_NO))
            for _c in (Col.MATERIAL1, Col.MATERIAL2):
                _m = _clean(_row_val(row, _c))
                if _m:
                    _k = (_m, _wps_key)
                    self._mat_wps[_k] = self._mat_wps.get(_k, 0) + 1
            flags = self._check_row(row)
            has_defect = bool(flags)
            # **결함 여부와 무관하게** 센다 — 이것이 분모다
            if weld_date_str:
                self.judged_by_date[weld_date_str] += 1
            # 용접사별 결함률은 실제 작업성 결함만 반영한다.
            # Check 6(미자격 용접사)·7(승인기간 이후 작업)은 **그 사람의 자격
            # 상태**이지 그 행의 용접 품질이 아니므로 제외한다. 넣으면 같은 행의
            # 다른 용접사 세 명에게 오귀속된다.
            has_workmanship_defect = any(f.check_no not in ("6", "7") for f in flags)

            # 검증 건수는 AP(1번 용접사)뿐 아니라 AR/AT/AV(2~4번 용접사)로 참여한 건도 모두 포함해야
            # 실제 총 용접 건수가 된다. 한 조인트에 여러 용접사가 있으면 전원에게 반영.
            row_welders = {
                _clean(_row_val(row, c))
                for c in (Col.WELDER1_NO, Col.WELDER2_NO, Col.WELDER3_NO, Col.WELDER4_NO)
            }
            row_welders.discard('')

            if has_workmanship_defect:
                self._workmanship_rows.add(row_num)

            # 용접사가 «어느 팀에서» 일했는가. 업체에 물어볼 때 번호만으로는
            # 누구에게 물어야 할지 모른다 — 한 사람이 여러 팀에 걸치기도 한다.
            org = (_clean(_row_val(row, Col.DEPARTMENT)),
                   _clean(_row_val(row, Col.TEAM)))
            for wno in row_welders:
                self.welder_orgs[wno][org] += 1
                self.welder_totals[wno] += 1
                if has_workmanship_defect:
                    self.welder_defects[wno] += 1
                # 날짜별 분모(그날 이 용접사가 시공한 판정대상 행 수)
                if weld_date_str:
                    self.welder_date_totals[wno][weld_date_str] += 1

            # 날짜별 Check 결함건수 (C6은 서류 문제라 작업성 추이에서 제외)
            if weld_date_str:
                for f in flags:
                    if f.check_no == "6":
                        continue
                    for wno in row_welders:
                        self.welder_date_checks[wno][weld_date_str][f.check_no] += 1

            d = self.dept_data[dept]
            t = d['teams'][team]
            d['total_rows'] += 1
            t['total_rows'] += 1
            for wno in row_welders:
                d['welder_totals'][wno] += 1
                t['welder_totals'][wno] += 1
                if has_workmanship_defect:
                    d['welder_defects'][wno] += 1
                    t['welder_defects'][wno] += 1

            if flags:
                self.row_flags[row_num] = flags
                ndt_dt = _parse_date(_row_val(row, Col.NDT_DATE))
                self.row_data[row_num] = {
                    'drawing_no':  _clean(_row_val(row, Col.DRAWING_NO)),
                    'joint_no':    _clean(_row_val(row, Col.JOINT_NO)),
                    'block':       _clean(_row_val(row, Col.BLOCK)),
                    'material1':   _clean(_row_val(row, Col.MATERIAL1)),
                    'material2':   _clean(_row_val(row, Col.MATERIAL2)),
                    'thickness1':  _clean(_row_val(row, Col.THICKNESS1)),
                    'thickness2':  _clean(_row_val(row, Col.THICKNESS2)),
                    'wps_no':      _clean(_row_val(row, Col.WPS_NO)),
                    'wps_process': _clean(_row_val(row, Col.WPS_PROCESS)),
                    'ndt_report':  _clean(_row_val(row, Col.NDT_REPORT)),
                    'weld_date':   weld_date_str,
                    'ndt_date':    ndt_dt.isoformat() if ndt_dt else '',
                    'welder1_no':  welder1_no,
                    'department':  dept,
                    'team':        team,
                }
                self.row_raw[row_num] = _row_snapshot(row)
                counted: dict[int, int] = defaultdict(int)
                for f in flags:
                    counted[f.check_no] += 1
                    if f.check_no == "6" and f.welder_no:
                        self.welder_missing[f.welder_no] += 1
                    elif f.check_no != "6":
                        # Check 6(미자격)은 특정 용접사(f.welder_no)에게만 귀속.
                        # 그 외 체크는 조인트 단위 결함이므로 해당 조인트의 용접사 전원에게 반영.
                        for wno in row_welders:
                            self.welder_check_stats[wno][f.check_no] += 1
                for check_no, cnt in counted.items():
                    self.stats[check_no] += cnt

                if weld_date_str:
                    self.defect_by_date[weld_date_str] += 1
                    d['defect_by_date'][weld_date_str] += 1
                    t['defect_by_date'][weld_date_str] += 1

                d['defect_rows'] += 1
                t['defect_rows'] += 1
                check_entries = []
                for f in flags:
                    d['check_stats'][f.check_no] += 1
                    t['check_stats'][f.check_no] += 1
                    check_entries.append({
                        'check_no':   f.check_no,
                        'check_name': self._check_name(f.check_no),
                        'color':      f.color,
                        'msg':        f.msg,
                        'expected':   f.expected,
                        'actual':     f.actual,
                    })
                defect_entry = {
                    'row':        row_num,
                    'joint_no':   self.row_data[row_num]['joint_no'],
                    'block':      self.row_data[row_num]['block'],
                    'wps_no':     self.row_data[row_num]['wps_no'],
                    'ndt_report': self.row_data[row_num]['ndt_report'],
                    'weld_date':  weld_date_str,
                    'welder1_no': welder1_no,
                    'checks':     check_entries,
                }
                d['defects'].append(defect_entry)
                t['defects'].append(defect_entry)
                self._defect_entry_by_row[row_num] = defect_entry

            if progress and (i % 500 == 0 or i == total - 1):
                pct = 60 + int((i / max(total, 1)) * 35)
                progress(pct, f"검사 중… {i + 1:,}/{total:,}행")

        if progress:
            progress(95, "이상치 탐지 중… (비지도학습 탭 전용)")
        self._detect_ml_anomalies()

        if progress:
            progress(97, "Joint 중복(Check 14) 탐지 중…")
        self._detect_check14_duplicates()

        if progress:
            progress(98, "NDE 적용 요율(Check 26) 대조 중…")
        self._detect_check26_ndt_rate()

        logger.info("검사 완료: %d행 플래그", len(self.row_flags))
        if progress:
            progress(100, "검사 완료")

    def _register_flag(self, row_num: int, row: tuple, flag: Flag,
                       dept: str, team: str, weld_date_str: str,
                       row_welders: set[str]) -> None:
        """
        1차 판정 루프가 끝난 뒤에야 알 수 있는 플래그(Check 13처럼 전체 데이터
        분포를 다 봐야 하는 경우)를 이미 끝난 집계(부서/팀/용접사/결함행수 등)에
        안전하게 합류시킨다.

        이 행이 1차 판정에서 이미 결함이었으면 플래그만 추가하고, 처음으로
        결함이 되는 것이면(전부 정상이었다가 이번에 이상치로만 걸리는 경우)
        결함행수·용접사 결함률·날짜별 추이·결함 리스트를 새로 반영해야 한다 —
        안 하면 대시보드 KPI(결함 행 수 등)와 Check별 합계가 서로 안 맞게 된다.
        """
        # **2차 패스도 프로젝트 세팅을 따라야 한다.**
        # 취사선택 필터를 `_check_row()` 끝에만 두었더니 Check 13·14가
        # 그 길을 지나지 않아 «껐는데 938건이 그대로» 나왔다. 2차 패스는
        # `_register_flag`로 뒤늦게 합류하므로 여기에도 같은 문을 둔다.
        # CLAUDE.md가 «2단계 패스가 가장 자주 깨지는 곳»이라고 적어 둔 자리다.
        if not self._rule_on(flag.check_no):
            return

        is_new_defect_row = not self.row_flags.get(row_num)

        if row_num not in self.row_data:
            ndt_dt = _parse_date(_row_val(row, Col.NDT_DATE))
            self.row_data[row_num] = {
                'drawing_no':  _clean(_row_val(row, Col.DRAWING_NO)),
                'joint_no':    _clean(_row_val(row, Col.JOINT_NO)),
                'block':       _clean(_row_val(row, Col.BLOCK)),
                'material1':   _clean(_row_val(row, Col.MATERIAL1)),
                'material2':   _clean(_row_val(row, Col.MATERIAL2)),
                'thickness1':  _clean(_row_val(row, Col.THICKNESS1)),
                'thickness2':  _clean(_row_val(row, Col.THICKNESS2)),
                'wps_no':      _clean(_row_val(row, Col.WPS_NO)),
                'wps_process': _clean(_row_val(row, Col.WPS_PROCESS)),
                'ndt_report':  _clean(_row_val(row, Col.NDT_REPORT)),
                'weld_date':   weld_date_str,
                'ndt_date':    ndt_dt.isoformat() if ndt_dt else '',
                'welder1_no':  _clean(_row_val(row, Col.WELDER1_NO)),
                'department':  dept,
                'team':        team,
            }
        if row_num not in self.row_raw:
            self.row_raw[row_num] = _row_snapshot(row)

        self.row_flags.setdefault(row_num, []).append(flag)
        self.stats[flag.check_no] += 1

        d = self.dept_data[dept]
        t = d['teams'][team]
        d['check_stats'][flag.check_no] += 1
        t['check_stats'][flag.check_no] += 1
        if flag.check_no != "6":
            for wno in row_welders:
                self.welder_check_stats[wno][flag.check_no] += 1

        check_entry = {
            'check_no':   flag.check_no,
            'check_name': self._check_name(flag.check_no),
            'color':      flag.color,
            'msg':        flag.msg,
            'expected':   flag.expected,
            'actual':     flag.actual,
        }

        # 용접사 결함행 수는 '이 행이 처음 결함이 되었는가(is_new_defect_row)'가 아니라
        # '이 행이 처음 작업성 결함이 되었는가'를 기준으로 세야 한다. 1차 판정에서
        # Check 6(서류 문제)만 있던 행이 2차 패스(Check 13/14)로 작업성 결함을 얻으면
        # is_new_defect_row는 False라, 예전에는 용접사 결함행 수에 반영되지 않았다.
        # 실데이터에서 257행이 이 경우였고, 자격 미등록 용접사의 결함률이 크게
        # 과소집계됐다(예: 5361이 52건으로 표시됐으나 실제 192건).
        if flag.check_no not in ("6", "7") and row_num not in self._workmanship_rows:
            self._workmanship_rows.add(row_num)
            for wno in row_welders:
                self.welder_defects[wno] += 1
                d['welder_defects'][wno] += 1
                t['welder_defects'][wno] += 1

        # 2차 패스 플래그도 날짜별 Check 추이에 반영해야 한다(1차와 같은 기준).
        if flag.check_no != "6" and weld_date_str:
            for wno in row_welders:
                self.welder_date_checks[wno][weld_date_str][flag.check_no] += 1

        if is_new_defect_row:
            d['defect_rows'] += 1
            t['defect_rows'] += 1
            if weld_date_str:
                self.defect_by_date[weld_date_str] += 1
                d['defect_by_date'][weld_date_str] += 1
                t['defect_by_date'][weld_date_str] += 1
            defect_entry = {
                'row':        row_num,
                'joint_no':   self.row_data[row_num]['joint_no'],
                'block':      self.row_data[row_num]['block'],
                'wps_no':     self.row_data[row_num]['wps_no'],
                'ndt_report': self.row_data[row_num]['ndt_report'],
                'weld_date':  weld_date_str,
                'welder1_no': self.row_data[row_num]['welder1_no'],
                'checks':     [check_entry],
            }
            d['defects'].append(defect_entry)
            t['defects'].append(defect_entry)
            self._defect_entry_by_row[row_num] = defect_entry
        else:
            entry = self._defect_entry_by_row.get(row_num)
            if entry is not None:
                entry['checks'].append(check_entry)

    def _detect_ml_anomalies(self) -> None:
        """이상치 탐지 — **플래그를 만들지 않는다** (현업 결정 2026-09-02).

        IsolationForest로 판정 대상 분포에서 드문 조합을 찾아 `ml_meta`(분포·투영
        요약)와 `ml_detail`(행별 이탈 근거)에 담는다. '비지도학습' 탭이 이 둘을
        읽어 수량과 산점도를 그린다.

        ## 왜 플래그가 아닌가

        이건 **규칙 위반이 아니라 통계적 이례성**이다. 그런데 플래그가 되는 순간
        결함 목록·부서 실적·결과 Excel·부서 메일이 전부 그것을 «결함»으로 실어
        나른다 — 현업이 「결함이 아닌데 결함처럼 보인다」고 지적했고, 실측
        5,397건이 그렇게 나가고 있었다.

        분석 자체는 그대로 남긴다. 「드문 조합」을 사람이 훑어보는 것은 여전히
        쓸모가 있고, 그건 **결함 목록이 아니라 전용 탭**이 할 일이다.

        Check 13 번호는 결번이다 — `_ANOMALY_IS_NOT_A_CHECK` 주석 참조.
        """
        if not anomaly.is_available():
            return

        row_lookup = dict(self._judged_rows_cache)
        feats: list[tuple[int, dict]] = []
        for row_num, row in self._judged_rows_cache:
            weld_dt = _parse_date(_row_val(row, Col.WELD_DATE))
            ndt_dt  = _parse_date(_row_val(row, Col.NDT_DATE))
            gap = (ndt_dt - weld_dt).days if (weld_dt and ndt_dt) else None
            raw_mat = _clean(_row_val(row, Col.MATERIAL1))
            feats.append((row_num, {
                'material_key': _get_material_key(raw_mat) or raw_mat,
                'wps_no':       _clean(_row_val(row, Col.WPS_NO)),
                'groove':       _clean(_row_val(row, Col.GROOVE)),
                'ndt_cat':      _clean(_row_val(row, Col.NDT_CAT)),
                'department':   _clean(_row_val(row, Col.DEPARTMENT)),
                'team':         _clean(_row_val(row, Col.TEAM)),
                'thickness1':   _to_float(_row_val(row, Col.THICKNESS1)),
                'thickness2':   _to_float(_row_val(row, Col.THICKNESS2)),
                'weld_to_ndt_days': gap,
            }))

        detected = anomaly.detect_anomalies(feats)
        anomalies = detected.get('anomalies') or {}
        # 머신러닝 분석 탭이 쓰는 분포/투영 정보. 행수와 무관하게 크기가 일정하도록
        # 격자/히스토그램으로 요약돼 있어 결과 JSON을 크게 늘리지 않는다.
        self.ml_meta = detected.get('meta')

        if not anomalies:
            logger.info("이상치 없음(또는 비활성화)")
            return

        for row_num, info in anomalies.items():
            row = row_lookup[row_num]
            dept = _clean(_row_val(row, Col.DEPARTMENT)) or '(부서 미기재)'
            team = _clean(_row_val(row, Col.TEAM)) or '(팀 미기재)'

            # **플래그를 만들지 않는다.** 여기서 `_register_flag()`를 부르면
            # 결함 목록·부서 실적·Excel·메일이 전부 이것을 결함으로 실어 나른다.
            # 상세(피처별 이탈도/동종그룹/좌표)만 '비지도학습' 탭용으로 담는다.
            self.ml_detail[row_num] = {
                'score':      info['score'],
                'reason':     info['reason'],
                'deviations': info['deviations'],
                'peers':      info['peers'],
                'xy':         info['xy'],
                'drawing_no': _clean(_row_val(row, Col.DRAWING_NO)),
                'joint_no':   _clean(_row_val(row, Col.JOINT_NO)),
                'department': dept,
                'team':       team,
            }

        logger.info("이상치 %d건 탐지 (비지도학습 탭 전용 — 플래그 없음)",
                    len(anomalies))

    # 예전에는 여기 `_detect_check13_excl_temp()`가 있었다 — 임시부재(1C)를
    # 학습에서 빼고 한 번 더 돌려 두 벌을 담았다. 2026-08-20부터 1C가 판정
    # 대상에서 빠져 **첫 모델이 이미 1C 없는 모집단으로 학습한다.** 두 벌을
    # 담으면 같은 결과가 두 번 실리고, 화면이 «두 기준이 있다»고 잘못 읽는다.

    def _detect_check14_duplicates(self) -> None:
        """같은 이음에 **본용접이 둘 이상** 등록됐는가 (현업 결정 2026-09-02).

        ## 판정 단위는 «도면 + Block + Lot + Joint No»다

        Joint No(D열)만으로는 이음을 특정하지 못한다. 두 단계로 좁힌다:

        1. **도면번호(A열)** — Joint No는 도면 안에서만 유일하다. 실데이터로 확인한
           결과 같은 Joint No 문자열이 서로 다른 도면에서 정상적으로 반복 등장한다
           (도면마다 1번부터 새로 매김, 최대 41개 도면에 같은 번호). 빼면 무관한
           행들이 대량으로 오탐 처리된다.
        2. **Block(B열) + Lot(C열)** — 같은 도면 안에서도 대구분·소구분이 다르면
           다른 이음이다. 이걸 안 넣으면 Block이 다른 정상 시공이 중복으로 잡힌다.

        ## 판정 조건은 «본용접의 개수»다

        E열(RE)이 비어 있는 행이 **본용접**이고, 한 이음에 하나만 있을 수 있다.
        E열에 표기가 있으면 수리 용접이라 여러 번 나오는 것이 정상이다.

            본용접 1 + 수리 N   -> 정상 (수리는 반복될 수 있다)
            본용접 2 이상       -> 결함 (같은 이음을 두 번 등록했다)

        **플래그는 본용접 행에만 붙는다.** 수리 행은 «중복의 원인»이 아니고,
        수리 행은 정규 항목을 전부 판정받지만(2026-09-03 복원), **중복의 원인은
        아니다** — 같은 이음에 여러 번 나오는 것이 정상이라 세지도 지적하지도
        않는다.

        예전에는 «재질/두께/WPS 중 하나라도 다르면» 결함이었다(실측 37,885건).
        현업 결정으로 그 축을 걷어내고 본용접 중복 하나만 본다 — 값이 다른 것은
        각 항목의 전용 검사(Check 3·11 등)가 이미 본다.
        """
        groups: dict[tuple[str, str, str, str], list[int]] = defaultdict(list)
        for row_num, row in self._judged_rows_cache:
            dn = _clean(_row_val(row, Col.DRAWING_NO))
            jn = _clean(_row_val(row, Col.JOINT_NO))
            if not (dn and jn):
                continue
            bl = _clean(_row_val(row, Col.BLOCK))
            lt = _clean(_row_val(row, Col.LOT))
            groups[(dn, bl, lt, jn)].append(row_num)

        row_lookup = dict(self._judged_rows_cache)
        # 관문을 지난 «이음» 수 — 한 이음에 행이 둘 이상인 경우만 대조 대상이다.
        self._scope["14"] += sum(1 for rows in groups.values() if len(rows) >= 2)
        flagged = 0
        for (dn, bl, lt, jn), rows in groups.items():
            if len(rows) < 2:
                continue
            # 본용접만 센다. 수리 행은 여러 번 나오는 것이 정상이다.
            mains = [r for r in rows if not _is_repair(row_lookup[r])]
            if len(mains) < 2:
                continue

            repairs = len(rows) - len(mains)
            where   = ' · '.join(x for x in (bl, lt) if x) or '(구분 미기재)'

            for row_num in mains:
                row = row_lookup[row_num]
                dept = _clean(_row_val(row, Col.DEPARTMENT)) or '(부서 미기재)'
                team = _clean(_row_val(row, Col.TEAM)) or '(팀 미기재)'
                weld_dt = _parse_date(_row_val(row, Col.WELD_DATE))
                weld_date_str = weld_dt.isoformat() if weld_dt else ''
                row_welders = {
                    _clean(_row_val(row, c))
                    for c in (Col.WELDER1_NO, Col.WELDER2_NO, Col.WELDER3_NO, Col.WELDER4_NO)
                }
                row_welders.discard('')
                other_rows = [r for r in mains if r != row_num]

                flag = Flag(14, Col.JOINT_NO, "Brown",
                            f"본용접 중복 등록: Joint '{jn}'({where})에 "
                            f"본용접이 {len(mains)}행 (관련 행: {other_rows})"
                            + (f" · 수리 {repairs}행은 제외" if repairs else ""),
                            expected="한 이음(도면+Block+Lot+Joint No)의 본용접은 "
                                     "1행 (E열 공란). 수리는 여러 행 허용",
                            actual=f"본용접 {len(mains)}행"
                                   + (f" · 수리 {repairs}행" if repairs else ""))
                self._register_flag(row_num, row, flag, dept, team, weld_date_str, row_welders)
                flagged += 1

        if flagged:
            logger.info("Check14: 본용접 중복 %d행 탐지", flagged)

    # ── Check 26의 모수 문턱 ────────────────────────────────────────────────
    #
    # 길이 2000mm를 경계로 판정이 갈린다(현업 확인 2026-08-21).
    _C26_LONG_MM = 2000.0

    def _c26_in_scope(self, row: tuple) -> bool:
        """이 행이 NDE 요율 판정의 **모수**에 드는가 (현업 확인 2026-08-21).

        둘 다 통과해야 한다:

        1. **수리 용접이 아니어야 한다.** 약식 용접이라 이 규정이 적용되지 않는다.
        2. **BE열에 대표 리포트 번호가 있어야 한다.** 비어 있으면 NDT 계획 자체가
           없는 행이라 대조할 것이 없다.

        예전에는 여기서 «E열이 2글자 이상»을 따로 셌다. 같은 «수리인가»를 묻는데
        Check 23은 «비어 있지 않으면»이라 답이 갈렸다 — 2026-09-02에 `_is_repair()`
        하나로 모았다.

        **이 문턱이 수리 행의 유일한 제외 지점이다**(현업 확정 2026-09-03).
        수리 행은 `_check_row()`에서 정규 항목을 전부 판정받고, NDE 요율에서만
        빠진다 — 약식 시공이라 전수 촬영 규정이 적용되지 않기 때문이다.
        """
        if _is_repair(row):
            return False
        return bool(_clean(_row_val(row, Col.NDT_REPORT)))

    def _detect_check26_ndt_rate(self) -> None:
        """NDE 적용 요율을 채웠는가. **2차 패스다.**

        ## 판정 단위는 «블록»이다 (현업 확인 2026-08-21)

        요율은 B열 **Block No.** 단위로 평가한다. 예전에는 리포트 번호(`*`를 뗀
        것)로 묶었는데, 그러면 한 리포트가 여러 블록을 덮을 때 블록별 실적이
        뭉개진다. 실측으로 그렇게 어긋났다:

            리포트 묶음 기준   MT MSOM09316   374행 중 42행 = 13.4%  -> 미달
            블록 기준          NF110  42.9% · NF120  40.0% · NF130  24.6%  -> 전부 충족

        **리포트 번호는 묶음 키가 아니다.** 같은 블록·같은 NDE·같은 요율이면
        리포트 번호가 달라도 한 묶음이다(현업 확인 2026-08-21).

        ## 요율이 섞이면 «요율별로» 나눈다

        한 블록 안에 같은 NDE의 요율이 섞여 온다 — 실데이터의 NF110·NF120·NF130
        세 블록 전부 MT가 20%와 10% 혼재다. 요구가 다르면 분모도 달라야 하므로
        묶음 키에 요율을 넣는다:

            NF110 MT 20%   60행 중 20행 촬영 = 33.3%  -> 충족
            NF110 MT 10%   38행 중 22행 촬영 = 57.9%  -> 충족

        예전에는 묶음 안의 **최댓값**을 요구로 썼다. 그러면 100%짜리가 한 행이라도
        섞인 블록은 전체가 100%를 요구받는다.

        ## 길이 2000mm를 경계로 규칙이 다르다

        ```
        L >= 2000   요율과 무관하게 100% 촬영    <- 행 단위 판정
        L <  2000   요율만큼 촬영                <- 블록·요율 묶음 단위 판정
        ```

        분모를 겹치지 않게 가른다 — 2000 이상 행은 요율 계산에 넣지 않는다.
        한 행이 두 판정에 동시에 들어가면 «어느 규칙으로 걸린 것인지»가 흐려진다.

        ## `*`가 «촬영하지 않음»이다

        검사별 리포트 번호(BN·BQ·BT·BW) 끝의 `*`는 촬영하지 않은 수량이라는
        표기다(현업 확인 2026-08-13). **번호가 아예 비어 있는 것도 같게 본다**
        (현업 확인 2026-08-21) — BE에 대표 번호가 있는데 해당 검사란이 비었다면
        그 검사를 안 한 것이다.

        ## 미달일 때는 «미촬영 행»에만 단다

        묶음 전체에 달면 이미 촬영을 마친 행까지 결함이 된다. 미촬영 행에만 달면
        결함 목록이 곧 **«추가로 촬영해야 할 대상»**이 된다. 블록 하나가 최대
        1,569행이라 이 선택이 결함 건수를 크게 가른다.

        ## 2차 패스라 소급 갱신이 필요하다

        `_register_flag()`를 거치므로 `stats`·`row_flags`·부서/팀 버킷·
        `welder_defects`가 함께 갱신된다. 직접 `row_flags`에 넣지 마라.
        """
        # (블록, 검사종류, 요구요율) -> {전체, 촬영, 미촬영 행 목록}
        groups: dict[tuple[str, str, float], dict[str, Any]] = defaultdict(
            lambda: {"total": 0, "shot": 0, "missing": []})
        long_bad: list[tuple[int, int, str, float]] = []   # (행, 열, 검사종류, 요율)
        scoped_rows: set[int] = set()
        row_lookup = dict(self._judged_rows_cache)

        for row_num, row in self._judged_rows_cache:
            if not self._c26_in_scope(row):
                continue
            block = _clean(_row_val(row, Col.BLOCK)) or '(블록 미기재)'
            # 길이를 못 읽으면 «2000 미만»으로 본다. 실데이터는 전부 숫자지만,
            # 모르는 값을 100% 요구 쪽에 넣으면 근거 없이 결함을 만든다.
            length = _to_float(_row_val(row, Col.LENGTH))
            is_long = length is not None and length >= self._C26_LONG_MM

            for ext_col, rep_col, tag in self._NDT_REPORT_COLS:
                # **숫자가 아닌 값은 «요율 없음»이다.** 실데이터에 S열이
                # `리페어WPS구분?`인 행이 있다 — 비어 있지는 않지만 대조할
                # 요율이 아니다.
                need = _to_float(_clean(_row_val(row, ext_col)))
                if need is None:
                    continue
                scoped_rows.add(row_num)
                rep = _clean(_row_val(row, rep_col))
                shot = bool(rep) and not rep.endswith("*")

                if is_long:
                    if not shot:
                        long_bad.append((row_num, rep_col, tag, need))
                    continue

                g = groups[(block, tag, need)]
                g["total"] += 1
                if shot:
                    g["shot"] += 1
                else:
                    g["missing"].append((row_num, rep_col))

        self._scope["26"] += len(scoped_rows)

        def _flag_row(row_num: int, flag: Flag) -> None:
            row = row_lookup[row_num]
            dept = _clean(_row_val(row, Col.DEPARTMENT)) or '(부서 미기재)'
            team = _clean(_row_val(row, Col.TEAM)) or '(팀 미기재)'
            weld_dt = _parse_date(_row_val(row, Col.WELD_DATE))
            row_welders = {
                _clean(_row_val(row, c))
                for c in (Col.WELDER1_NO, Col.WELDER2_NO, Col.WELDER3_NO, Col.WELDER4_NO)
            }
            row_welders.discard('')
            self._register_flag(row_num, row, flag, dept, team,
                                weld_dt.isoformat() if weld_dt else '', row_welders)

        flagged = 0
        # ① 길이 2000 이상 — 요율과 무관하게 전수 촬영이다
        for row_num, rep_col, tag, need in long_bad:
            _flag_row(row_num, Flag(
                26, rep_col, "Navy",
                f"길이 {self._C26_LONG_MM:g}mm 이상은 {tag} 전수 촬영 대상인데 "
                f"촬영 기록이 없다 (요율 {need:g}%와 무관)",
                expected=f"{tag} 100% 촬영 (길이 {self._C26_LONG_MM:g}mm 이상)",
                actual="리포트 번호 없음 또는 «*»(미촬영)"))
            flagged += 1

        # ② 길이 2000 미만 — 블록·요율 묶음의 촬영율
        for (block, tag, need), g in groups.items():
            if not g["total"]:
                continue
            rate = 100.0 * g["shot"] / g["total"]
            if rate + 1e-9 >= need:
                continue
            for row_num, rep_col in g["missing"]:
                _flag_row(row_num, Flag(
                    26, rep_col, "Navy",
                    f"블록 '{block}'의 {tag} 촬영율 {rate:.1f}% (요구 {need:g}%) — "
                    f"{g['total']}건 중 {g['shot']}건만 촬영",
                    expected=f"{tag} 촬영율 {need:g}% 이상 (블록 '{block}')",
                    actual=f"{rate:.1f}% ({g['shot']}/{g['total']}) · 이 행은 미촬영"))
                flagged += 1

        if flagged:
            logger.info("Check26: NDE 요율 미달 %d행 탐지 "
                        "(2000이상 %d · 요율묶음 %d)",
                        flagged, len(long_bad), flagged - len(long_bad))

    def _check_row(self, row: tuple) -> list[Flag]:
        flags: list[Flag] = []
        wps_no  = _clean(_row_val(row, Col.WPS_NO))
        wps_prc = _normalize_process(_row_val(row, Col.WPS_PROCESS))
        repair  = _is_repair_wps(wps_no)

        # ── 수리(Repair) 행도 «정규 항목을 전부» 판정한다 ──────────────────────
        #
        # E열(RE)에 표기가 있으면 수리 용접이지만, **여기서 걸러 내지 않는다.**
        # 빠지는 것은 **Check 26(NDE 요율) 하나뿐**이고 그 문턱은
        # `_c26_in_scope()`가 갖고 있다 (현업 확정 2026-09-03).
        #
        # 2026-09-02에 한때 「수리 행은 Check 23만」으로 두었다가 되돌렸다.
        # 그러면 실측 **824건의 판정이 통째로 사라졌다** — Check 13 253 · 14 201 ·
        # 18 160 · 21 74 · 3 54 · 11 35 · 4 16 · 17 9 · 24 9 …
        # 수리 용접이라고 해서 두께·재질·용접봉·자격이 면제되는 것이 아니다.
        # 면제되는 것은 «전수 촬영 요율»뿐이다.
        #
        # 수리 행 수는 `repair_rows`로 세지만 그건 **표시용**이다 —
        # `judged_rows`에서 빼지 않는다.
        #
        # 참고: 아래 `repair` 변수는 **축이 다르다.** E열이 아니라 WPS 이름
        # (`_is_repair_wps`)을 보고 Check 2·4·11을 건너뛴다. 이번 복원과 무관하다.

        f1 = self._c1_schedule(row)
        if f1: flags.append(f1)

        f2 = self._c2_wps_process(row, wps_no, wps_prc, repair)
        if f2: flags.append(f2)

        f3 = self._c3_thickness(row, wps_no)
        if f3: flags.append(f3)

        f4 = self._c4_groove(row, wps_no, repair)
        if f4: flags.append(f4)

        # Check 5(NDT Cat A/B -> TR-FC-G03)는 현업 확인(2026-08-10, §11-2)으로
        # **규칙 자체가 불필요**하다고 확인돼 제거했다. 그에 딸린 Check 7(중복 2+5)도
        # 성립하지 않으므로 함께 뺐다.
        #
        # 번호 5·7은 **재사용하지 않는다** — 검토 기록 키가 `…|Check No`라서
        # 재사용하면 과거 검토 의견이 무관한 항목에 붙는다(§11-7과 같은 사고).
        # 두 번호의 색/이름 정의는 남겨 둔다. 이미 붙은 라벨 426건이 화면에서
        # 읽히려면 필요하다.
        flags.extend(self._c6_welders(row, wps_prc))

        # 6과 같은 용접사 열을 본다 — 6은 «자격이 있는가», 7은 «그 자격이 아직
        # 살아 있는가»다. 만료일 파일이 없으면 7은 한 행도 판정하지 않는다.
        flags.extend(self._c7_welder_expired(row))

        f8 = self._c8_tr_fc_g03(row, wps_no)
        if f8: flags.append(f8)

        f9 = self._c9_tr_smfc_g01(row, wps_no)
        if f9: flags.append(f9)

        # 두께 플래그는 이제 공통 Check 3일 수도, 프로젝트 규칙(101~199)일 수도
        # 있다. `f3.check_no == 3`으로 좁히면 프로젝트 규칙이 선점한 행에서
        # **Check 10이 조용히 0건**이 된다.
        if f3 and f8:
            flags.append(Flag(10, Col.THICKNESS1, "Black", "복합 오류: 두께 범위 초과 + TR-FC-G03 특수 동시 발생",
                              expected=f"{f3.expected} / {f8.expected}",
                              actual=f"{f3.actual} / {f8.actual}"))

        f11 = self._c11_material_not_allowed(row, wps_no, repair)
        if f11: flags.append(f11)

        f12 = self._c12_tubular_dia_review(row)
        if f12: flags.append(f12)

        f18 = self._c18_consumable_lot(row)
        if f18: flags.append(f18)

        flags.extend(self._c16_ndt_extent(row))

        f17 = self._c17_vt_missing(row)
        if f17: flags.append(f17)

        f21 = self._c21_mixed_consumables(row, wps_prc)
        if f21: flags.append(f21)

        f22 = self._c22_ndt_report_pending(row)
        if f22: flags.append(f22)

        f23 = self._c23_repair_wps_mark(row, wps_no)
        if f23: flags.append(f23)

        f24 = self._c24_tky_wps(row, wps_no, wps_prc)
        if f24: flags.append(f24)

        f25 = self._c25_q01_joint_type(row, wps_no)
        if f25: flags.append(f25)

        f27 = self._c27_dissimilar_grade(row, wps_no)
        if f27: flags.append(f27)

        flags.extend(self._project_row_rules(row, wps_no))

        f19 = self._c19_wps_process_welder(row, wps_prc)
        if f19: flags.append(f19)

        f20 = self._c20_api_groove_process(row, wps_prc)
        if f20: flags.append(f20)

        # 프로젝트 세팅에서 끈 항목은 **판정하지 않는다.** 화면 필터가 아니라
        # 판정 설정이라, 끄면 플래그가 애초에 생기지 않고 결함/클린 행수도
        # 그 기준으로 다시 계산된다. 그래서 바꾸면 재검증이 필요하다.
        return [f for f in flags if self._rule_on(f.check_no)]

    def _project_rules(self) -> list:
        """이 회차가 쓰는 프로젝트 규칙. 행마다 파일을 읽지 않도록 한 번만."""
        if self._rules is None:
            self._rules, self._rule_problems = project_checks.parse(
                rule_catalog.active_checks())
        return self._rules

    def _wps_ov(self) -> dict:
        """이 회차가 쓰는 WPS 보정. `_project_rules()`와 같은 이유로 한 번만 읽는다.

        회차 안에서는 **한 기준**이어야 한다 — 행마다 파일을 다시 읽으면 앞뒤 행이
        다른 기준으로 판정될 수 있다.
        """
        if self._wps_overrides is None:
            self._wps_overrides = wps_overrides.load()
        return self._wps_overrides

    def _check_name(self, check_id: str) -> str:
        """공통이면 `CHECK_NAMES`, 프로젝트면 **규칙 정의의 이름**.

        공통 표에만 물으면 프로젝트 규칙의 이름이 **빈 문자열로 나간다** —
        결과 표·Excel·부서 메일에 이름 없는 결함이 실린다. 예외는 나지 않는다.
        """
        cid = str(check_id).strip()
        name = check_name(cid)
        if name:
            return name
        for r in (self._rules or []):
            if r.no == cid:
                return r.name
        return ""

    def _rule_on(self, check_no: int | str) -> bool:
        """켜져 있는 항목인가. 행마다 파일을 읽지 않도록 한 번만 읽어 둔다.

        **키는 문자열이다.** `Flag`가 정규화하므로 여기서도 맞춰야 한다 —
        정수로 물으면 `{"3": True}`에서 못 찾아 «설정에 없으면 켬»으로 빠진다.
        꺼 둔 항목이 조용히 다시 켜진다.
        """
        if self._enabled is None:
            self._enabled = rule_catalog.enabled_map()
        return self._enabled.get(str(check_no).strip(), True)

    def _c19_wps_process_welder(self, row: tuple, wps_prc: str) -> Optional[Flag]:
        """AK열 WPS Process 자격자가 그 이음에 **최소 한 명**은 있었는가.

        Check 6과 축이 다르다:

            Check 6   각 용접사가 «자기가 시공한 프로세스»(AQ/AS/AU/AW) 자격을
                      가졌는가 — 개인의 서류 문제
            Check 19  «WPS가 요구하는 프로세스»(AK)를 아는 사람이 그 이음에
                      있었는가 — 이음의 시공 적합성

        용접사는 AP~AW에 최대 4명까지 들어간다. 넷 중 **아무도** WPS Process
        자격이 없을 때만 결함이다. 전원에게 요구하면 보조 용접사까지 걸려
        실제로 시정할 수 없는 지적이 대량으로 나온다.

        **혼합 프로세스는 «허용 자격 목록»으로 본다** (현업 확정 2026-09-03).
        `_MIXED_QUAL_ALLOWED`에 있는 자격을 **하나라도** 가진 사람이 있으면 합격:

            GTFC 이음  <-  GTAW 또는 GTFC 자격자 1명   -> 합격
            FCSA 이음  <-  FCAW 또는 SAW 자격자 1명     -> 합격
            SMFC 이음  <-  SMFC 자격자 1명              -> 합격
                       <-  SMAW 한 명 + FCAW 한 명      -> 불합격
            GMSA 이음  <-  GMSA 자격자 1명              -> 합격

        **프로세스마다 목록이 다르다.** 규칙으로 유도할 수 있는 형태가 아니라
        현업이 정한 것이라 표로 못 박았다. 특히 SMFC는 기본 자격(SMAW)을
        인정하지 않고 **합성 자격 자체**를 요구한다 — 실데이터에서 SMFC 이음
        13,000건 중 12,000건 이상에 이미 SMFC 자격자가 투입돼 있다(TRION).

        예전 두 방식은 둘 다 현업 기준과 달랐다:

            ~2026-08-28  개인별로만(`any`) 물어 «FCSA 자격증을 그대로 가진 사람»이
                         아니면 전부 결함 — 정상 시공 244건이 지적됐다
            ~2026-09-03  «요구 집합 ⊆ 보유 집합» — SMFC를 {SMAW,FCAW}로 펴서
                         두 사람이 나눠 가져도 합격이었다
        """
        if not wps_prc:
            return None
        pairs = [Col.WELDER1_NO, Col.WELDER2_NO, Col.WELDER3_NO, Col.WELDER4_NO]
        nos = [_clean(_row_val(row, c)) for c in pairs]
        nos = [n for n in nos if n]
        if not nos:
            return None            # 용접사가 아예 없는 행은 Check 6이 볼 몫이 아니다
        held: set[str] = set()     # 원문 표기 — 메시지에 그대로 싣는다
        known = False
        for no in nos:
            qual = self.loader.welder_qual.get(no)
            if qual is None:
                continue           # 자격 DB에 없는 사람은 판단 근거가 없다 -> Check 6
            known = True
            held |= set(qual['process'])
        # **넷을 합친 뒤에 판단한다.** 루프 안에서 한 명씩 조기 반환하면
        # 나눠 맡은 이음을 영영 알아보지 못한다.
        # **원문 표기 그대로 넘긴다.** 펴서 넘기면 SMFC 규칙(합성 자격 요구)이
        # 성립하지 않는다 — `{SMAW, FCAW}`가 「SMFC 자격자」와 구분되지 않는다.
        if _joint_process_covered(held, wps_prc):
            return None
        if not known:
            # 넷 다 자격 DB에 없으면 «자격이 없다»가 아니라 «알 수 없다»이다.
            # 그건 Check 6이 이미 «자격 DB 미등록»으로 지적한다. 여기서 또
            # 지적하면 같은 원인에 플래그가 둘 붙는다.
            return None
        return Flag(19, Col.WPS_PROCESS, "Maroon",
                    f"WPS Process '{wps_prc}' 자격자 미투입 "
                    f"(용접사 {','.join(nos)} 보유: {','.join(sorted(held)) or '없음'})",
                    expected=f"{wps_prc} 자격 보유자 1명 이상 투입",
                    actual=f"투입 {len(nos)}명 보유자격: {','.join(sorted(held)) or '없음'}")

    def _c20_api_groove_process(self, row: tuple, wps_prc: str) -> Optional[Flag]:
        """API 재질은 Groove에 따라 허용 프로세스가 다르다.

        현업 확인(2026-08-11 · 2026-08-13 보완): **M열 또는 N열** 재질이 `API`로
        시작하면
          - R열 Groove가 **FL 또는 FW** -> FCAW 적용
          - 그 외 Groove(SB 등)         -> **SMFC 또는 GTFC** 적용
        예를 들어 SB에 FCAW를 쓰면 결함이다.

        2026-08-13에 둘을 넓혔다:
          · `FW`(Fillet Weld 표기 변형)를 FL과 같이 본다. 실데이터에 FW가 0건이라
            지금은 결과가 안 바뀌지만, 들어오는 순간 SMFC를 요구해 오탐이 된다.
          · 재질을 **M·N 둘 다** 본다. 한쪽만 API인 이종재 이음이 빠져 있었다.

        실데이터 6건(SB/SMFC 4 · FL/FCAW 2)은 전부 규칙에 맞아 위반 0건이다.
        지금 안 걸린다고 지울 검사가 아니다 — 걸리는 순간이 문제다.
        """
        if not wps_prc:
            return None
        mats = [_clean(_row_val(row, c)).upper() for c in (Col.MATERIAL1, Col.MATERIAL2)]
        api = next((m for m in mats if m.startswith("API")), None)
        if api is None:
            return None
        self._scope["20"] += 1
        mat = api
        groove = _clean(_row_val(row, Col.GROOVE)).upper()
        if not groove:
            return None
        allowed = (["FCAW"] if groove in ("FL", "FW") else ["SMFC", "GTFC"])
        # **대조 전에 표기를 합성 코드로 맞춘다.** `"SMFC" in "SMAW+FCAW"`는
        # 거짓이라, 풀어 쓰는 프로젝트(RUYA 등록부)에서는 같은 이음이 반대로
        # 판정됐다 — `SMFC`는 걸리고 `SMAW+FCAW`는 통과했다.
        #
        # 여기서 «펴지» 않는 이유: FL/FW는 **정확히 FCAW**를 요구한다(SMFC는
        # 부적합 — `tests/test_checks_19_20.py`가 못을 박는다). 집합 포함으로
        # 바꾸면 `SMFC ⊇ FCAW`라 그 규칙이 사라진다.
        prc_c = _mixed_code(wps_prc) or _normalize_process(wps_prc)
        if any(a in prc_c for a in allowed):
            return None
        return Flag(20, Col.WPS_PROCESS, "Indigo",
                    f"API 재질 Groove '{groove}'에는 {'/'.join(allowed)} 적용 "
                    f"(입력 Process={wps_prc}, 재질={mat})",
                    expected=f"{'/'.join(allowed)} (API 재질 · Groove={groove})",
                    actual=f"{wps_prc}")

    def _c18_consumable_lot(self, row: tuple) -> Optional[Flag]:
        """용접봉 Lot 번호(AL열)를 본다 — **기재됐는가, 그리고 승인된 것인가.**

        ## 원래 취지로 돌아온 검사다

        처음 의도는 «WPS가 지정한 용접봉과 다른 것을 썼는가»였는데, **Lot 번호와
        대조할 목록이 없어서** «누락만 본다»로 범위를 줄여 두었다. 현업이 승인
        용접봉 리스트를 확보해(2026-08-20) 그 대조가 가능해졌다.

        ## 왜 번호를 나누지 않았나

        잠깐 Check 28로 따로 두었다가 합쳤다. 실측이 결정했다 —
        **38만 행에서 기재 누락이 2건**이다. 그 2건을 위해 번호를 하나 더 쓰면
        화면·문서·검토 기록이 둘로 갈라지는데, 정작 사람이 보는 것은 «용접봉이
        제대로인가» 하나다. (Check 28은 결번으로 남긴다 — 번호를 재사용하면
        검토 기록 키가 과거 의견을 무관한 항목에 붙인다.)

        ## 두 가지를 본다

            AL이 비었는가          -> 기재 누락
            AL의 각 Lot이 승인 목록에 있는가 -> 미승인

        **둘이 동시에 걸리지 않는다.** 비어 있으면 대조할 것이 없다.

        ## 승인 목록이 없으면 «미승인» 쪽은 돌지 않는다

        그때 이 검사는 «기재 누락»만 본다. 그 상태의 0건은 «승인된 것만 썼다»가
        아니다 — `run_verification()`이 `rule_health`에 경고를 남기고, 업로드
        화면도 「한 행도 대조하지 않습니다」라고 말한다. 그 두 자리가 없으면
        목록을 안 올린 프로젝트가 «용접봉 문제 없음»으로 읽힌다.

        ## 다중값

        혼합 프로세스는 재료를 둘 쓴다. 구분자는 쉼표만이 아니다 — 실데이터에
        `10007488BB22CA1/F902A5B5A7`처럼 **슬래시**로 이은 표기가 있고, 공백이
        붙은 `F902A12L4H4, 10006714BB24KA1`도 있다. 나누는 일은
        `_split_consumables()` **하나**가 하고 Check 21이 같은 것을 쓴다.
        """
        # 켬/끔 스위치는 `rule_catalog` **하나뿐**이다(`_check_row()` 끝 게이트).
        # 예전에는 `wps_rules.check18_enabled()`가 두 번째 스위치였고, JSON이 UI를
        # 이겼다 — '프로젝트 세팅'에서 켰는데 아무 일도 안 일어나고, 결과의
        # `rules` 스냅샷에는 «18 = 켬»으로 기록되어 **결과가 거짓말을 했다.**
        lot = _clean(_row_val(row, Col.CONSUMABLE_LOT))
        if not lot:
            return Flag(18, Col.CONSUMABLE_LOT, "Orange",
                        "용접봉 Lot 미기재 (AL열 공란)",
                        expected="용접봉 Lot 번호 기재 필요",
                        actual="공란")

        approved = self.loader.consumable_lots
        if not approved:
            return None                  # 대조할 목록이 없다 (rule_health가 알린다)
        parts = _split_consumables(lot)
        unknown = [p for p in parts if p.upper() not in approved]
        if not unknown:
            return None
        return Flag(18, Col.CONSUMABLE_LOT, "Orange",
                    f"승인 목록에 없는 용접봉 Lot ({', '.join(unknown)})",
                    expected=f"승인 용접봉 리스트에 등재된 Lot (등재 {len(approved)}종)",
                    actual=f"AL열='{lot}'" +
                           (f" 중 {len(unknown)}종 미승인" if len(parts) > 1 else ""))

    def _project_row_rules(self, row: tuple, wps_no: str) -> list[Flag]:
        """행 단위 프로젝트 규칙(`forbid` · `require_wps`).

        두께 규칙(`thickness_range`)과 평가 지점이 다르다 — 그쪽은 `_c3_side()`가
        공통 Check 3을 **선점**하며 부르고, 여기는 대체할 공통 검사가 없어 그냥
        추가 판정이다. 그래서 `_suppressed`를 건드리지 않는다.

        `_rule_matched`는 갱신한다 — «이 규칙이 몇 행에 걸렸는가»는 0행 경고
        (`rule_health`)의 근거이고, 통과한 행도 세어야 «대상이 있었는데 전부
        통과»와 «대상이 아예 없다»를 구분할 수 있다.
        """
        rules = self._project_rules()
        if not rules or not wps_no:
            return []
        materials = [_clean(_row_val(row, c)) for c in (Col.MATERIAL1, Col.MATERIAL2)]
        ndt_cat = _clean(_row_val(row, Col.NDT_CAT))
        out: list[Flag] = []
        for r in project_checks.row_rules(rules, materials, wps_no, ndt_cat):
            if not self._rule_on(r.no):
                continue
            self._rule_matched[r.no] = self._rule_matched.get(r.no, 0) + 1
            if r.judge_row(wps_no):
                continue
            if r.kind == "require_wps":
                msg = (f"{r.name}: WPS에 '{r.required_wps_text}'가 있어야 함 "
                       f"(WPS={wps_no})")
                exp, act = f"WPS에 '{r.required_wps_text}' 포함", f"'{wps_no}'"
            else:
                msg = f"{r.name}: 이 조합은 사용할 수 없음 (WPS={wps_no})"
                exp, act = f"{r.name} 대상이 아닐 것", f"WPS={wps_no}, 재질={'/'.join(m for m in materials if m)}"
            out.append(Flag(r.no, Col.WPS_NO, r.color or "Blue", msg,
                            expected=exp, actual=act))
        return out

    def _c21_mixed_consumables(self, row: tuple, wps_prc: str) -> Optional[Flag]:
        """혼합 프로세스 이음은 용접재료를 **둘** 적어야 한다 (AL열).

        GTFC·SMFC는 한 이음에서 두 프로세스를 쓰므로 소모품도 둘이다. AL열에
        쉼표로 구분해 둘을 적는다(예: `F902A4L5D7, K71TG-1`).

        Check 18과 축이 다르다 — 18은 «비었는가», 21은 «몇 개인가»다. AL이 아예
        비면 18이 지적하므로 여기서는 값이 있을 때만 개수를 센다. 둘 다 걸면
        같은 원인에 플래그가 둘 붙는다.

        실데이터: 혼합 프로세스 40행 중 **2행**이 재료 하나뿐이다
        (`TR-GTFC-G01`, AL=`F902A4L5D7`).
        """
        if not _is_mixed_process(wps_prc):
            return None
        self._scope["21"] += 1
        lot = _clean(_row_val(row, Col.CONSUMABLE_LOT))
        if not lot:
            return None                      # 공란은 Check 18의 몫이다
        parts = _split_consumables(lot)       # 나누는 방식은 Check 18과 **같다**
        if len(parts) >= 2:
            return None
        return Flag(21, Col.CONSUMABLE_LOT, "Rose",
                    f"혼합 프로세스({wps_prc})인데 용접재료가 {len(parts)}종 "
                    f"(AL열='{lot}')",
                    expected=f"용접재료 2종 (쉼표·슬래시 등으로 구분) — "
                             f"{wps_prc}는 프로세스가 둘",
                    actual=f"{len(parts)}종: {lot}")

    # NDT 종류별 (요구 요율 열, 리포트 번호 열, 이름). 리포트는 수행일 바로 오른쪽이다.
    _NDT_REPORT_COLS = (
        (Col.NDT_EXT_RT, Col.RT_REPORT, "RT"),
        (Col.NDT_EXT_UT, Col.UT_REPORT, "UT"),
        (Col.NDT_EXT_MT, Col.MT_REPORT, "MT"),
        (Col.NDT_EXT_PT, Col.PT_REPORT, "PT"),
    )

    def _c22_ndt_report_pending(self, row: tuple) -> Optional[Flag]:
        """NDT 100% 구간인데 리포트 번호가 확정되지 않았다.

        현업 확인(2026-08-13): 요구 요율이 **100**인 구간은 전수 검사라 리포트가
        반드시 나와야 한다. 그런데 계획/신청일(BD)까지 잡혀 있으면서
          · 리포트 번호가 **공란**이거나
          · 번호가 **`*`로 끝나면**(예: `MSOM03084*` — 촬영하지 않은 수량 표기)
        그 구간은 «검사를 걸어 놓고 결과가 없는» 상태다.

        **요율이 100인 구간만 본다.** 20%·10% 구간의 별표는 정상이다 — 애초에
        전수를 찍지 않기 때문이다. 그 구간의 실제 촬영율은 Check 26이 묶음
        단위로 본다.

        실데이터 위반 0건이다. 100% 구간에는 별표가 하나도 없다 —
        **«문제가 없다»가 맞는 쪽**이고, 100%가 아닌 구간에는 248행이 있다.
        """
        if not _clean(_row_val(row, Col.NDT_PLAN_DATE)):
            return None                      # 계획 자체가 없으면 볼 것이 없다
        for ext_col, rep_col, tag in self._NDT_REPORT_COLS:
            if _clean(_row_val(row, ext_col)) != "100":
                continue
            self._scope["22"] += 1
            rep = _clean(_row_val(row, rep_col))
            if rep and not rep.endswith("*"):
                continue
            why = "공란" if not rep else f"미촬영 표기 '{rep}'"
            return Flag(22, rep_col, "Olive",
                        f"{tag} 100% 구간인데 리포트 번호가 확정되지 않음 ({why})",
                        expected=f"{tag} 리포트 번호 (100% 구간은 전수 검사)",
                        actual=why)
        return None

    def _c23_repair_wps_mark(self, row: tuple, wps_no: str) -> Optional[Flag]:
        """수리 시공(E열)인데 WPS가 수리용이 아니다.

        E열(헤더 `RE`)에 값이 있으면 수리 시공이다. 값은 `RE`·`R1`·`U1`·`M1`처럼
        다양하고 **비어 있지 않기만 하면 해당**이다(현업 확인 2026-08-13).
        그때 WPS No는 끝에서 **세 번째 문자가 `R`**이어야 한다(예: `TR-FC-R01`).

        `_is_repair_wps()`(접두사 기반)와 축이 다르다:

            _is_repair_wps   그 WPS가 수리용인가        -> Check 2·4·11을 건너뛴다
            Check 23         수리인데 수리 WPS를 썼는가  -> 기재 자체를 지적한다

        접두사 판정은 «어떤 WPS가 수리용인가»를 프로젝트 설정으로 정하고, 여기는
        «이 행이 수리인가»를 원본 표기로 본다. 둘이 갈라지면 이 검사가 드러낸다.

        실데이터: E열에 값이 있는 판정 대상 **3행**이 전부 `TR-FC-G01`(끝 세 글자
        `G01`)이라 3건 위반이다.
        """
        mark = _clean(_row_val(row, Col.REPAIR_MARK))
        if not _is_repair(row) or not wps_no:
            return None
        self._scope["23"] += 1
        third_last = wps_no[-3] if len(wps_no) >= 3 else ""
        if third_last.upper() == "R":
            return None
        return Flag(23, Col.WPS_NO, "Gray",
                    f"수리 시공(E열='{mark}')인데 수리 WPS가 아님 (WPS={wps_no})",
                    expected="WPS No 끝에서 세 번째 문자가 'R' (예: TR-FC-R01)",
                    actual=f"'{wps_no}' (끝 세 번째='{third_last or '없음'}')")

    def _c24_tky_wps(self, row: tuple, wps_no: str,
                     wps_prc: str = "") -> Optional[Flag]:
        """이음 Type(Q열)에 맞는 WPS 끝자리를 썼는가. **양방향으로 본다.**

        ## ① TKY 이음(Q열 `TT`)은 GK를 써야 한다 — 프로세스와 무관

        현업 확인(2026-08-13): Q열이 `TT`면 TKY 이음(관재 교차부)이라 WPS의
        **마지막 구분자 뒤가 `GK`로 시작**해야 한다 — `TR-SMFC-GK01` 형태다.

        마지막 토큰만 본다. 앞의 프로세스 표기(`FC`·`SMFC`·`GTFC`)는 프로젝트마다
        다르고, 여기서 볼 것은 «이음 종류»를 나타내는 끝자리이기 때문이다.

        ## ② SMFC 이음은 끝자리가 `G`로 시작해야 한다 (현업 확인 2026-09-02)

        `TT`가 아닌 SMFC는 `GK`·`G` 둘 다 허용한다. **`G`로 시작하지 않으면**
        결함이다.

        처음 요청은 「비TT는 GK가 아닌 G」로 더 좁았는데, 그러면 비TT인 `GK01`
        행이 전부 결함이 된다(실측 최대 6,726 플래그 규모). 현업이 «둘 다 허용»
        으로 확정했다.

        실측(38만 행): SMFC의 WPS 끝자리는 `G01` 12,826 · `GK01` 6,726 **둘뿐**
        이라 ②는 **위반 0건**이다. 「대조할 대상이 0건」이 아니라 «검사했고 위반
        0»이다 — SMFC 행 전체가 관문을 지난다. 다음 프로젝트의 표기가 갈릴 때
        이 문턱이 없으면 조용히 지나간다.
        """
        if not wps_no:
            return None
        is_tt    = _clean(_row_val(row, Col.JOINT_TYPE)).upper() == "TT"
        # 표기가 프로젝트마다 다르다 — `SMAW+FCAW`도 SMFC 이음이다.
        # 부분문자열로 물으면 풀어 쓰는 프로젝트에서 이 관문이 조용히 0이 된다.
        is_smfc  = _mixed_code(wps_prc) == "SMFC"
        if not (is_tt or is_smfc):
            return None
        self._scope["24"] += 1
        last = wps_no.replace("_", "-").split("-")[-1].strip().upper()

        if is_tt:
            if last.startswith("GK"):
                return None
            return Flag(24, Col.WPS_NO, "Cyan",
                        f"TKY 이음(Q열='TT')에 전용 WPS 미적용 (WPS={wps_no})",
                        expected="WPS 마지막 구분이 GK로 시작 (예: TR-SMFC-GK01)",
                        actual=f"'{wps_no}' (마지막 구분='{last}')")

        # 비TT SMFC — GK·G 모두 허용, G가 아니면 결함
        if last.startswith("G"):
            return None
        return Flag(24, Col.WPS_NO, "Cyan",
                    f"SMFC 이음인데 WPS 끝자리가 G 계열이 아님 (WPS={wps_no})",
                    expected="WPS 마지막 구분이 G로 시작 (G01·G02… 또는 GK01)",
                    actual=f"'{wps_no}' (마지막 구분='{last}')")

    def _c25_q01_joint_type(self, row: tuple, wps_no: str) -> Optional[Flag]:
        """`Q01` WPS는 Q열 Type이 `B`인 이음에만 쓴다.

        현업 확인(2026-08-13). Q열 분포는 `T` 9,626 · `B` 361 · `TT` 8이다.

        실데이터: `Q01`로 끝나는 WPS가 0건이라 위반 0건이다 —
        **«대조할 대상이 0건»**이지 «문제가 없다»가 아니다.
        """
        if not wps_no:
            return None
        last = wps_no.replace("_", "-").split("-")[-1].strip().upper()
        if last != "Q01":
            return None
        self._scope["25"] += 1
        jt = _clean(_row_val(row, Col.JOINT_TYPE)).upper()
        if not jt or jt == "B":
            return None
        return Flag(25, Col.JOINT_TYPE, "Teal",
                    f"Q01 WPS는 Type 'B'만 가능 (Q열='{jt}', WPS={wps_no})",
                    expected="Q열 Type = B",
                    actual=f"'{jt}'")

    def _c27_dissimilar_grade(self, row: tuple, wps_no: str) -> Optional[Flag]:
        """이종재 이음은 **상위 그레이드** 재질 기준으로 WPS를 골라야 한다.

        ## [보류] — 등급표가 아직 없다

        현업 확인(2026-08-13): 지금은 **두 가지만** 비교할 수 있다.

            · 재질명 끝의 시험온도 — 낮을수록 상위 (`-40` > `-20`)
            · S355 < S420

        그 외 조합(`ASTM-A36` + `SM355A` 등)은 상하를 판단할 근거가 없다.
        **전체 등급표는 현업이 별도로 만들어 주기로 했고, 받으면 여기를 채운다.**
        그때까지는 판단 가능한 조합만 보고 나머지는 조용히 지나간다 — 근거 없이
        찍으면 오탐이 되고, 오탐은 «이 검사는 못 믿는다»로 이어진다.

        실데이터: 재질 2종 조합 20건이 **전부** 온도 표기도 S355/S420도 없어
        위반 0건이다. 등급표가 오기 전까지는 이 검사가 도는 대상이 0건이다.
        """
        raw1 = _clean(_row_val(row, Col.MATERIAL1))
        raw2 = _clean(_row_val(row, Col.MATERIAL2))
        if not raw1 or not raw2 or raw1 == raw2 or not wps_no:
            return None
        hi = _higher_material_grade(raw1, raw2)
        if hi is None:
            return None                      # 등급표가 오기 전까지 판단 불가
        wps = self.loader.wps_of(wps_no)
        if not wps:
            return None                      # WPS를 모르면 Check 2의 몫이다
        # 상위 그레이드 재질이 이 WPS의 허용 재질에 들어 있는가
        hi_key = _get_material_key(hi)
        if hi_key is None:
            return None
        base_metals = [m.get('base_metal', '') for m in (wps.get('materials') or [])]
        if not base_metals:
            return None
        # ── scope는 «실제로 판정할 수 있는 행»만 센다 ──────────────────────
        #
        # 예전에는 `hi`를 구한 직후에 세서, 뒤의 «판단 불가» 관문에서 전부
        # 빠져나가는 프로젝트가 **「검사했고 위반 0」으로 보였다.** RUYA가 그
        # 상태다 — 재질이 `S420 KL/T-40`뿐이라 `_get_material_key()`가 늘
        # None을 주고, 플래그가 **구조적으로 나갈 수 없는데** 화면에는
        # 「통과」로 읽힌다. `_scope`가 막으려던 오독 그 자체다.
        #
        # TRION 영향 없음: 판정 대상 4,356행이 뒤 관문을 **전부** 통과한다.
        self._scope["27"] += 1
        f = self._c11_check_one_material(wps, wps_no, hi_key, hi,
                                         base_metals, Col.MATERIAL1, 'M')
        if f is None:
            return None
        lo = raw2 if hi == raw1 else raw1
        return Flag(27, Col.MATERIAL1, "Purple",
                    f"이종재 이음의 상위 그레이드({hi})가 WPS 허용 재질이 아님 "
                    f"(하위={lo}, WPS={wps_no})",
                    expected=f"상위 그레이드 '{hi}'를 허용하는 WPS",
                    actual=f"{wps_no} (상위={hi}, 하위={lo})")

    # ── 검사 이행 여부 (Check 16·17) ─────────────────────────────────────────
    #
    # Check 1~12는 «기재된 값이 규칙에 맞는가»를 본다. 16·17은 성격이 다르다 —
    # **«해야 할 검사를 했는가»**를 본다. 원본 매크로에 없던 축이고, 실제로
    # 놓치면 선급 검사에서 걸리는 쪽은 이쪽이다.
    #
    # 둘 다 유예기간(_grace_days)을 둔다. 용접 직후 검사가 아직 안 끝난 것은
    # 정상이므로, 유예 없이 «공란=미수행»으로 보면 최근 용접분이 통째로 결함이
    # 되어 지표가 못 쓰게 된다.

    def _overdue_days(self, row: tuple) -> Optional[int]:
        """기준일까지 며칠 지났는지. 유예 안이거나 판단 불가면 None."""
        if self._ref_date is None:
            return None
        weld_dt = _parse_date(_row_val(row, Col.WELD_DATE))
        if weld_dt is None:
            return None                  # 용접일이 없으면 Check 1의 영역이다
        days = (self._ref_date - weld_dt).days
        return days if days >= self._grace_days else None

    def _c16_ndt_extent(self, row: tuple) -> list[Flag]:
        """NDT Extent(S~V열)에 비율이 잡혀 있는데 해당 검사 수행일이 공란인 경우.

        Extent는 «이 조인트에 요구되는 NDT 비율(%)»이다. 값이 있다는 것은 그 검사가
        요구된다는 뜻이므로, 대응하는 NDT Inspection Result 날짜(BM/BP/BS/BV)가
        비어 있으면 요구된 검사를 수행하지 않은 것이다.

        **숫자로 읽히는 값만 요구로 본다.** 실데이터의 RT Extent 열에는 담당자가
        메모로 적어 넣은 문자열이 1건 섞여 있었다("리페어WPS구분?"). 공란이 아니라는
        이유로 요구로 세면 오탐이 된다.

        실데이터 기준 0건이다(UT 1,085/1,085, MT 5,516/5,516 전량 수행). 지금 걸리는
        게 없다고 지울 검사가 아니다 — 이건 «앞으로 빠지면 잡는» 쪽이다.
        """
        days = self._overdue_days(row)
        if days is None:
            return []
        flags: list[Flag] = []
        for name, ext_col, date_col in _NDT_EXTENT_PAIRS:
            pct = _to_float(_row_val(row, ext_col))
            if pct is None or pct <= 0:
                continue
            self._scope["16"] += 1
            if _clean(_row_val(row, date_col)):
                continue
            flags.append(Flag(16, date_col, "Olive",
                              f"NDT 미수행: {name} Extent={_clean(_row_val(row, ext_col))}% 요구 "
                              f"— 수행일 공란 (용접 후 {days}일 경과)",
                              expected=f"{name} 수행일 기재 필요 (요구 Extent {pct:g}%)",
                              actual=f"{name} 수행일 공란"))
        return flags

    def _c17_vt_missing(self, row: tuple) -> Optional[Flag]:
        """육안검사(VT) 수행일(BI열)이 공란인 경우.

        VT는 Extent 열이 없다 — **모든 용접부에 요구되는 기본 검사**라 별도로 비율을
        지정하지 않기 때문이다. 그래서 «용접했으면 VT는 있어야 한다»가 판정 규칙이다.

        실데이터: 판정대상 5,516행 중 VT 공란 265행, 그중 유예 30일을 넘긴 것이 99건.
        """
        days = self._overdue_days(row)
        if days is None:
            return None                      # 유예 안이거나 용접일이 없다
        self._scope["17"] += 1
        if _clean(_row_val(row, Col.VT_DATE)):
            return None
        return Flag(17, Col.VT_DATE, "Navy",
                    f"VT 미수행: 용접 후 {days}일 경과했으나 육안검사일 공란",
                    expected=f"육안검사(VT) 수행일 기재 (유예 {self._grace_days}일)",
                    actual="VT 수행일 공란")

    def _c1_schedule(self, row: tuple) -> Optional[Flag]:
        weld_dt = _parse_date(_row_val(row, Col.WELD_DATE))
        ndt_dt  = _parse_date(_row_val(row, Col.NDT_DATE))
        if weld_dt and ndt_dt and ndt_dt < weld_dt:
            return Flag(1, Col.NDT_DATE, "Red",
                        f"일정오류: 용접일({weld_dt}) > NDT계획일({ndt_dt})",
                        expected=f"NDT계획일 ≥ 용접일({weld_dt})",
                        actual=f"NDT계획일={ndt_dt}")
        if weld_dt is None and ndt_dt is not None:
            return Flag(1, Col.WELD_DATE, "Red",
                        f"일정오류: 용접일 미기재 (NDT계획일={ndt_dt} 설정됨)",
                        expected="용접일 기재 필요",
                        actual="용접일 미기재")
        return None

    def _c2_wps_process(self, row: tuple, wps_no: str, wps_prc: str,
                        repair: bool) -> Optional[Flag]:
        if not wps_no or repair:
            return None
        wps = self.loader.wps_of(wps_no)
        if wps is None:
            return Flag(2, Col.WPS_NO, "Green", f"WPS '{wps_no}' WPS List에 없음",
                        expected="WPS List에 등록된 WPS No",
                        actual=f"'{wps_no}' (WPS List에 없음)")
        reg_prc = wps['process']
        if wps_prc and reg_prc and wps_prc != reg_prc:
            # (1) 예전부터 있던 완화 — **그대로 둔다.** 실데이터에서 통과하던 것이
            #     새로 걸리기 시작하면 그게 더 나쁘다.
            legacy = (('SMFC' in wps_prc and 'SMFC' in reg_prc) or
                      ('GTFC' in wps_prc and 'GTFC' in reg_prc) or
                      ('FCSA' in wps_prc and 'FCSA' in reg_prc))
            # (2) WPS가 프로세스를 **둘 이상** 등록했으면 그중 하나만 써도 맞다.
            #     `SMAW / + / FCAW`처럼 적힌 칸을 한 덩어리로 비교하면 그 WPS를
            #     쓰는 행이 무엇을 써도 전부 걸린다(현업 질문 2026-08-24).
            used, reg = _process_set(wps_prc), _process_set(reg_prc)
            allowed = bool(used) and bool(reg) and used <= reg
            if not (legacy or allowed):
                return Flag(2, Col.WPS_NO, "Green",
                            f"Process 불일치: 입력={wps_prc}, 등록={reg_prc} (WPS={wps_no})",
                            expected=f"{reg_prc} (WPS={wps_no} 등록 프로세스)",
                            actual=f"{wps_prc} (입력값)")
        return None

    def _c3_thickness(self, row: tuple, wps_no: str) -> Optional[Flag]:
        if not wps_no:
            return None
        wps = self.loader.wps_of(wps_no)
        if not wps:
            return None
        thk1 = _to_float(_row_val(row, Col.THICKNESS1))
        if thk1 is None:
            return None
        raw1 = _clean(_row_val(row, Col.MATERIAL1))
        if _is_tubular_material(raw1):
            # 관재는 J열 두께가 아니라 I열 Out Dia 규격이 기준이므로 여기서 판정하지
            # 않는다. 대신 Check 12가 '수동 확인 필요'로 표시한다.
            return None

        # K열(두께2)이 채워진 행은 이음부 반대쪽 부재도 있다는 뜻이다.
        # N열(재질2)이 비어 있으면 이음 반대쪽도 J와 같은 모재로 본다.
        thk2 = _to_float(_row_val(row, Col.THICKNESS2))
        raw2 = _clean(_row_val(row, Col.MATERIAL2))

        # ── 이종재 이음은 «낮은 두께»만 본다 (현업 확인 2026-08-13) ──────────
        #
        # M·N 재질이 **서로 다르면** WPS를 상위 그레이드 재질과 **낮은 두께**
        # 기준으로 고른다. 그래서 높은 쪽 두께가 WPS 범위를 벗어나도 부적합이
        # 아니다 — 실측 12행이 여기 해당한다(전부 `ASTM-A36` 20~15T 정상 +
        # `SM355A` 25T 범위 밖).
        #
        # **같은 재질이면 지금 그대로 J·K를 각각 본다.** ASME IX QW-451의 두께
        # 자격범위는 이음을 구성하는 각 부재에 대해 성립해야 하고, 감사에서
        # «J는 정상인데 K만 초과» 8건을 실제로 찾아낸 판정이 이것이다.
        # 범위를 이종재로 좁힌 것은 현업이 «그때는 낮은 쪽으로 WPS를 고른다»고
        # 확인해 준 만큼이다 — 더 넓히면 그 8건 유형을 통째로 놓친다.
        # **표기 흔들림은 이종재가 아니다.** `ASTM-A36`과 `ASTMA36`은 같은 강재인데
        # 문자열만 다르다 — 그대로 비교하면 이종재로 보고 낮은 두께만 판정해서
        # **K열 판정이 조용히 사라진다.** 하이픈·공백·대소문자를 지우고 본다.
        #
        # 재질 «키»(`_get_material_key`)로 비교하면 안 된다. 그건 두께 범위를 고르는
        # 키라 `NV-E36`(-40℃)과 `NV-DW36`(-20℃)이 둘 다 `E36`으로 뭉개진다 —
        # 그 둘은 등급이 달라 **진짜 이종재**다(실데이터 4행).
        if (thk2 is not None and raw2
                and _material_token(raw2) != _material_token(raw1)
                and not _is_tubular_material(raw2)):
            lo_thk, lo_raw, lo_lbl, lo_col = min(
                ((thk1, raw1, 'J', Col.THICKNESS1), (thk2, raw2, 'K', Col.THICKNESS2)),
                key=lambda s: s[0])
            return self._c3_side(wps, wps_no, lo_thk, lo_raw, lo_lbl, lo_col)

        f1 = self._c3_side(wps, wps_no, thk1, raw1, 'J', Col.THICKNESS1)
        if f1:
            return f1
        if thk2 is None:
            return None
        raw2 = raw2 or raw1
        if _is_tubular_material(raw2):
            return None
        return self._c3_side(wps, wps_no, thk2, raw2, 'K', Col.THICKNESS2)

    def _c3_side(self, wps: dict, wps_no: str, thk: float, raw_material: str,
                 side_label: str, col: int) -> Optional[Flag]:
        """이 side를 누가 판정하는가 — 프로젝트 규칙이 먼저 묻는다.

        **선점을 재질 키 조회보다 앞에 둔다.** 프로젝트 규칙은 원문 표기를 보고
        (`S355KT-40`처럼 등급이 재질명에 붙어 온다) 공통 판정은 표준 키를 본다.
        순서를 반대로 하면 **매핑표에 없는 프로젝트 재질이 선점에 닿지도 못하고**
        조용히 판정에서 빠진다 — 실제로 `S355KT-40`·`S355KL-0` 둘 다
        `_get_material_key()`가 None을 준다.
        """
        # ── WPS 보정이 가장 먼저다 ─────────────────────────────────────────
        # 특정 WPS×재질을 **콕 집어** 고친 값이라 전역 규칙보다 구체적이다.
        # 프로젝트 규칙보다 뒤에 두면, 전역 규칙이 걸리는 재질은 보정을 해도
        # 아무 일이 일어나지 않는다 — 사용자는 고쳤다고 믿는다.
        #
        # **재질 키 조회보다도 앞이다.** 보정 행은 자유 표기(`match`)로도 걸리므로
        # `_get_material_key()`가 None을 주는 재질(`S355KT-40`)에 닿아야 한다.
        # 뒤에 두면 그런 재질은 보정해도 선점에 도달하지 못한다.
        ov = wps_overrides.find_material(self._wps_ov(), wps_no,
                                         _get_material_key(raw_material),
                                         raw_material)
        if ov is not None:
            self._ov_matched[wps_no] = self._ov_matched.get(wps_no, 0) + 1
            # 보정은 «자료의 정정»이라 Check 3 자리에서 그대로 판정한다.
            # 새 번호를 따면 색 정의 여섯 곳·축 분류를 함께 갱신해야 하고,
            # 무엇보다 검토 기록 키(`…|Check No`)가 흔들린다.
            if _thickness_in_range(thk, ov["range"]):
                return None
            label = ov.get("id") or (ov.get("match") or [""])[0]
            return Flag(3, col, "Blue",
                        f"두께범위 초과({side_label}열): {thk}mm, WPS={wps_no}, "
                        f"재질={label}, 허용범위={ov['range']} (WPS 보정값)",
                        expected=f"{ov['range']}mm (WPS={wps_no} 보정 · 재질={label}, "
                                 f"{side_label}열)",
                        actual=f"{thk}mm")

        rule = project_checks.claim_thickness(self._project_rules(),
                                              raw_material, wps_no)
        if rule is not None and self._rule_on(rule.no):
            self._rule_matched[rule.no] = self._rule_matched.get(rule.no, 0) + 1
            for common in rule.overrides:
                k = (rule.no, common)
                self._suppressed[k] = self._suppressed.get(k, 0) + 1
            if rule.judge_thickness(thk):
                return None
            return Flag(rule.no, col, rule.color,
                        f"두께범위 초과({side_label}열): {thk}mm, "
                        f"{rule.name} 허용 {rule.range_text}mm "
                        f"(공통 Check 3 대신 판정)",
                        expected=f"{rule.range_text}mm (프로젝트 규칙 · {rule.name}, "
                                 f"{side_label}열)",
                        actual=f"{thk}mm")

        # 선점이 없으면 지금까지와 똑같다.
        # 매핑표에 없는 재질은 'E36'으로 임의 폴백하면 무관한 재질에 느슨한 범위가
        # 잘못 적용될 수 있어(감사 결과) 검사하지 않고 건너뛴다.
        mat_key = _get_material_key(raw_material)
        if mat_key is None:
            return None
        return self._c3_thickness_side(wps, wps_no, thk, mat_key,
                                       side_label, col, raw_material)

    def _c3_thickness_side(self, wps: dict, wps_no: str, thk: float, mat_key: str,
                           side_label: str, col: int,
                           raw_material: str = "") -> Optional[Flag]:
        # 프로젝트 규칙 선점은 `_c3_side()`가 이미 물었다. 여기는 «선점이 없을
        # 때»만 도달하므로 WPS List G열 판정만 한다.
        for mat_entry in wps.get('materials', []):
            thk_range_text = mat_entry.get('thk_range', '')
            base_metal_text = mat_entry.get('base_metal', '')
            if not thk_range_text:
                continue

            # 1) G열 셀 내부를 "재질별 항목"으로 분리 시도(실제 셀 구조 반영).
            #    성공하면 이 재질에 해당하는 항목의 범위로만 정확히 판정한다 —
            #    예: TR-FC-G01에서 EO420은 25~38mm 전용 범위로만 검사되고,
            #    "~E36"(3~50) 같은 다른 재질의 범위와 섞이지 않는다.
            parsed = _parse_material_thickness_entries(thk_range_text)
            matched = [(lbl, rng) for lbl, rng in parsed if _label_matches_material(mat_key, lbl)]
            if matched:
                # §11-1은 현업 확인(2026-08-10)으로 종결됐다 — **G열의 값이 맞다.**
                # 한동안 PQR 승인범위(12.5~50)로 덮어쓰고 있었는데, WPS가 PQR보다
                # 좁게 제한한 경우였고 그건 표준상 허용된다(WPS 범위 ⊆ PQR 범위).
                # 오버라이드를 걷어냈으므로 여기서는 G열 그대로 판정한다.
                if not any(_thickness_in_range(thk, rng) for _, rng in matched):
                    allowed = ', '.join(f"{lbl}:{rng.strip()}" for lbl, rng in matched)
                    return Flag(3, col, "Blue",
                                f"두께범위 초과({side_label}열): {thk}mm, WPS={wps_no}, 재질={mat_key}, 허용범위={allowed[:80]}",
                                expected=f"{allowed[:80]}mm (WPS={wps_no}, 재질={mat_key}, {side_label}열)",
                                actual=f"{thk}mm")
                return None  # 재질 전용 범위 안에 있음 → 정상

            # 2) 셀 구조를 재질별로 분리하지 못했을 때만(자유 서식 WPS) 기존 방식으로
            #    안전하게 폴백 — base_metal 전체가 이 재질을 포함하면 셀 전체
            #    범위(여러 재질이 섞여 느슨할 수 있음, 기존과 동일한 한계)로 판정.
            if not parsed and _material_covered_by_wps(mat_key, base_metal_text):
                if not _thickness_in_range(thk, thk_range_text):
                    return Flag(3, col, "Blue",
                                f"두께범위 초과({side_label}열): {thk}mm, WPS={wps_no}, "
                                f"재질={mat_key}, 허용범위={thk_range_text[:60]}",
                                expected=f"{thk_range_text[:60]}mm (WPS={wps_no}, 재질={mat_key}, {side_label}열)",
                                actual=f"{thk}mm")
                return None
        # 매칭되는 재질 항목 없음 → 건너뜀 (재질 불일치는 Check 3 범위 밖)
        return None

    def _c4_groove(self, row: tuple, wps_no: str, repair: bool) -> Optional[Flag]:
        if not wps_no or repair:
            return None
        groove = _clean(_row_val(row, Col.GROOVE))
        if not groove:
            return None
        wps = self.loader.wps_of(wps_no)
        if not wps or not wps['joint_detail']:
            return None
        if not _groove_in_joint_detail(groove, wps['joint_detail']):
            allowed = ', '.join(sorted(_joint_detail_tokens(wps['joint_detail'])))
            return Flag(4, Col.GROOVE, "Yellow",
                        f"Groove 불일치: '{groove}' not in [{allowed}]",
                        expected=f"{allowed} 중 하나 (WPS={wps_no})",
                        actual=f"'{groove}'")
        return None

    def _c7_welder_expired(self, row: tuple) -> list[Flag]:
        """용접일이 **그 용접사의 자격 만료일/박탈일 이후**인가.

        ## §11-6이 예고한 검사다

        「자격 DB에 만료일 데이터가 없어 소급 검증할 수 없다. **향후 만료일
        컬럼이 채워지면 «용접일 > 만료일»만 별도로 걸러내는 정식 검사로 전환할
        것**」 — 현업이 만료일 파일을 확보해(2026-08-20) 그 전환을 했다.

        ## 번호 7을 되살린 근거

        7은 「중복 오류 (2+5)」였다가 현업 답변으로 규칙이 걷혔다. 번호 재사용은
        원칙적으로 금지인데(검토 기록 키가 `…|Check No`라 과거 의견이 무관한
        항목에 붙는다), **실측으로 Check 7 검토 기록이 0건**이라 붙을 자리가
        없었다. Check 5는 337건이라 절대 재사용하면 안 된다.

        ## 유효 만료일은 «이른 쪽»이다

        M(만료)과 N(박탈)이 둘 다 있으면 이른 쪽을 쓴다(`load_welder_expiry`).
        늦은 쪽을 쓰면 «자격이 없던 기간»을 놓친다.

        ## 용접사 결함률에서는 뺀다 — Check 6과 같은 이유

        이건 «그 행의 작업 품질»이 아니라 **그 사람의 자격 상태**다. 넣으면 같은
        행의 다른 용접사 세 명에게 오귀속된다 — 판정 엔진은 한 행을 용접사 4명
        전원에게 귀속시키기 때문이다.

        ## 세 가지를 잡는다

            표에 없는 사람          -> 「만료일 자료에 미등재」
            표에 있는데 M·N 공란    -> 「만료일 누락」
            용접일 > 유효 만료일    -> 「자격 만료/박탈 이후 작업」

        앞의 둘은 **승인기간을 확인할 수 없다**는 같은 결과인데 할 일이 다르다 —
        하나는 자료의 빈칸을 채우는 일이고, 하나는 명단에 넣는 일이다.

        ## 만료일 파일이 없으면 한 행도 판정하지 않는다

        그 0건은 «전원 유효»가 아니라 «대조하지 않았다»다. `_scope["7"]`이 0으로
        남아 화면에 「대상 없음」이 붙는다.
        """
        table = self.loader.welder_expiry
        if not table:
            # **동작이 아니라 비용을 위한 조기 반환이다.** 표가 비면 아래에서
            # `table.get(no)`가 전부 None이라 결과는 같다 — 다만 38만 행 x 4칸의
            # 날짜 파싱을 건너뛴다. 지워도 판정은 안 바뀐다(돌연변이로 확인).
            return []
        # 용접일이 없으면 «이후»는 물을 수 없지만, **만료일 누락은 그와 무관하다.**
        # 여기서 되돌아가면 용접일이 빈 행의 누락을 놓친다.
        wdate = _parse_date(_row_val(row, Col.WELD_DATE))

        flags: list[Flag] = []
        seen: set[str] = set()
        for no_col in (Col.WELDER1_NO, Col.WELDER2_NO,
                       Col.WELDER3_NO, Col.WELDER4_NO):
            no = _clean(_row_val(row, no_col))
            # 같은 사람이 두 칸에 적힌 행이 있다. 한 번만 지적한다 —
            # 두 번 세면 그 한 명 때문에 건수가 부푼다.
            if not no or no in seen:
                continue
            seen.add(no)
            self._scope["7"] += 1
            rec = table.get(no)
            # ── «승인기간을 확인할 수 없다»도 결함이다 (현업 확인 2026-08-20) ──
            #
            # 예전에는 둘 다 조용히 넘겼다. 그러면 만료일이 빠진 사람이 «문제
            # 없음»으로 읽힌다 — 정작 확인해야 할 사람이 결과에서 사라진다.
            # 원인이 다르므로 **메시지를 구분한다**: 자료의 빈칸인지, 아예
            # 명단에 없는지에 따라 할 일이 다르다.
            if rec is None:
                flags.append(Flag(7, no_col, "Yellow",
                                  f"용접사 '{no}' 만료일 자료에 미등재",
                                  welder_no=no,
                                  expected="만료일 자료에 등재된 용접사",
                                  actual=f"'{no}' 미등재 — 승인기간 확인 불가"))
                continue
            eff = rec["effective"]
            if eff is None:
                flags.append(Flag(7, no_col, "Yellow",
                                  f"용접사 '{no}' 만료일 누락 (M·N열 공란)",
                                  welder_no=no,
                                  expected="자격 만료일 또는 박탈일 기재 필요",
                                  actual="공란 — 승인기간 확인 불가"))
                continue
            if not wdate or wdate <= eff:
                continue
            # 만료인지 박탈인지 구분해 말한다 — 조치가 다르다.
            # 박탈(기능불량 계약해지)이 만료보다 무겁고, 둘 다면 이른 쪽이 사유다.
            why = ("자격 박탈" if rec["disq"] and rec["disq"] == eff else "자격 만료")
            flags.append(Flag(7, no_col, "Yellow",
                              f"용접사 '{no}' {why}일({eff}) 이후 작업 "
                              f"(용접일 {wdate})",
                              welder_no=no,
                              expected=f"{why}일 {eff} 이전 시공",
                              actual=f"용접일 {wdate} ({(wdate - eff).days}일 초과)"))
        return flags

    def _c6_welders(self, row: tuple, wps_prc: str = "") -> list[Flag]:
        pairs = [
            (Col.WELDER1_NO, Col.WELDER1_PROC),
            (Col.WELDER2_NO, Col.WELDER2_PROC),
            (Col.WELDER3_NO, Col.WELDER3_PROC),
            (Col.WELDER4_NO, Col.WELDER4_PROC),
        ]
        # ── 혼합 프로세스는 «4명 중 1명»이면 된다 (현업 확인 2026-08-13) ──────
        #
        # GTFC·SMFC 같은 혼합 프로세스 이음은 그 자격자가 **한 명만** 있으면 되고,
        # 나머지 인원은 FCAW로 시공해도 된다. 그래서 자격자가 한 명이라도 있으면
        # 나머지에게 «혼합 프로세스 자격 없음»을 묻지 않는다.
        #
        # **자격자가 아무도 없으면 완화하지 않는다** — 그건 Check 19가 «자격자
        # 미투입»으로 따로 지적하지만, 여기서도 개인별 사실은 그대로 남겨야 한다.
        # 완화를 무조건 걸면 «자격 없는 사람이 혼자 시공한 경우»까지 통과한다.
        #
        # 2026-08-28에 «합쳐서»의 뜻이 확정됐다 — FCSA 이음은 FCAW 자격자와 SAW
        # 자격자가 함께 들어가면 정상 시공이다(둘 중 하나만이면 불합격).
        # **Check 19와 같은 기준을 쓴다.** 다르면 «6에서는 통과인데 19에서는 결함»이
        # 되어, 보는 사람이 어느 쪽이 맞는지 알 방법이 없다.
        # **원문 표기 그대로 넘긴다** — Check 19와 같은 이유다(SMFC 규칙이
        # 합성 자격 자체를 요구하므로, 펴면 그 구분이 사라진다).
        relaxed = _is_mixed_process(wps_prc) and _joint_process_covered(
            {
                q
                for c, _ in pairs if _clean(_row_val(row, c))
                for q in ((self.loader.welder_qual.get(_clean(_row_val(row, c))) or {})
                          .get('process') or ())
            },
            wps_prc)

        flags: list[Flag] = []
        for no_col, pr_col in pairs:
            no  = _clean(_row_val(row, no_col))
            prc = _normalize_process(_row_val(row, pr_col))
            if not no or not prc:
                continue
            qual = self.loader.welder_qual.get(no)
            # 자격 DB에 아예 없음(협력사 미등록 등)과, DB엔 있지만 시공 프로세스 자격이
            # 없는 경우는 원인이 다르므로 메시지를 구분한다(11-5). 퇴사자는 자격에서
            # 제외하지 않으므로(11-6) 여기서 별도 분기가 필요 없다 — qual이 존재하면
            # 재직/퇴사 여부와 무관하게 프로세스만 검사한다.
            if qual is None:
                flags.append(Flag(6, no_col, "Orange",
                                  f"용접사 '{no}' 자격 DB 미등록 (협력사 등 DB 미등재 추정)",
                                  welder_no=no,
                                  expected="자격 DB에 등록된 용접사",
                                  actual=f"'{no}' 미등록"))
            elif relaxed and _is_mixed_process(prc) and any(
                    _process_covers(q, "FCAW") for q in qual['process']):
                # 혼합 프로세스로 기재됐지만 FCAW 자격이 있고, 같은 이음에 혼합
                # 자격자가 이미 있다 -> 허용. 이 분기가 없으면 «보조 인원»이 전부
                # 지적되어 실제로 시정할 수 없는 건이 대량으로 나온다.
                continue
            elif not any(_process_covers(q, prc) for q in qual['process']):
                retired_note = " [퇴사자]" if no in self.loader.retired_welders else ""
                flags.append(Flag(6, no_col, "Orange",
                                  f"용접사 '{no}'{retired_note} 프로세스 '{prc}' 자격 없음 "
                                  f"(보유: {','.join(sorted(qual['process']))})",
                                  welder_no=no,
                                  expected=f"{prc} 자격 보유",
                                  actual=f"보유자격: {','.join(sorted(qual['process']))}"))
        return flags

    def _c8_tr_fc_g03(self, row: tuple, wps_no: str) -> Optional[Flag]:
        """대상 WPS에 «충격시험 온도가 낮은» 재질을 쓸 때의 두께 상한.

        **상한값과 온도 임계도 설정에서 읽는다.** 예전에는 `target_wps`만 설정이고
        12mm·-40℃는 소스에 박혀 있었다. 설정 파일에 `max_thickness`를 써도 판정이
        안 바뀌는데 **예외도 경고도 나지 않았다** — 이 모듈이 경계하던 «조용히
        죽는» 패턴이 설정값 쪽에서 재현된 것이다.

        선급 룰에 따라 값이 달라지는 항목이라, 프로젝트마다 코드를 고칠 수는 없다.
        """
        cfg = wps_rules.check8()
        target = (cfg.get('target_wps') or '').upper()
        # 맨 앞 «TR»은 프로젝트 번호라 빼고 맞춘다(현업 확인 2026-08-14).
        # 통째로 비교하면 프로젝트가 바뀌는 순간 이 검사가 조용히 0건이 된다.
        if not target or not _same_wps(wps_no, target):
            return None
        self._scope["8"] += 1
        limit = _to_float(cfg.get('max_thickness'))
        if limit is None:
            limit = 12.0
        temp_c = _to_float(cfg.get('impact_temp_c'))
        if temp_c is None:
            temp_c = -40.0
        mat1 = _clean(_row_val(row, Col.MATERIAL1)).upper()
        mat2 = _clean(_row_val(row, Col.MATERIAL2)).upper()
        temp1 = _material_impact_temp_c(mat1)
        temp2 = _material_impact_temp_c(mat2) if mat2 else None
        has_low = ((temp1 is not None and temp1 <= temp_c)
                   or (temp2 is not None and temp2 <= temp_c))
        thk1 = _to_float(_row_val(row, Col.THICKNESS1)) or 0
        thk2 = _to_float(_row_val(row, Col.THICKNESS2)) or 0
        thk  = min(thk1, thk2) if thk2 else thk1
        if has_low and 0 < thk <= limit:
            return Flag(8, Col.THICKNESS1, "Blue",
                        f"{target} 특수: {temp_c:g}℃급 재질({mat1}) + "
                        f"두께({thk}mm)≤{limit:g}mm",
                        expected=f"두께 > {limit:g}mm (또는 {temp_c:g}℃급 재질 아님)",
                        actual=f"재질={mat1}, 두께={thk}mm")
        return None

    def _c9_tr_smfc_g01(self, row: tuple, wps_no: str) -> Optional[Flag]:
        """대상 WPS에 **API 재질일 때 쓸 수 없는 두께**가 들어왔는가.

        현업 확인(2026-08-13)으로 규칙이 바뀌었다:

            예전  대상 WPS + 두께 12.7 -> «확인 필요» (재질 조건 없음)
            지금  대상 WPS + M·N에 API 재질 + 두께 12.7·8.2·6 -> **사용 불가**

        «확인 필요»에서 «금지»로 성격이 바뀌었지만 **번호는 9를 그대로 쓴다** —
        검토 기록 키가 `도면번호|Joint No|WPS No|Check No`라 번호를 옮기면 과거
        의견이 고아가 된다. 두께 목록과 대상 WPS는 프로젝트 값이라 설정에서 읽는다.

        실데이터: 대상(API + `TR-SMFC-G01`) 4건이 전부 9.5T라 위반 0건이다.
        **«문제가 없다»가 아니라 «금지 두께가 안 들어왔다»**이다.
        """
        cfg = wps_rules.check9()
        target = (cfg.get('target_wps') or '').upper()
        # 맨 앞 «TR»은 프로젝트 번호라 빼고 맞춘다(현업 확인 2026-08-14).
        # 통째로 비교하면 프로젝트가 바뀌는 순간 이 검사가 조용히 0건이 된다.
        if not target or not _same_wps(wps_no, target):
            return None
        self._scope["9"] += 1
        # M·N 중 하나라도 API면 대상이다. 이종재 이음에서 한쪽만 API인 경우가 빠진다.
        mats = [_clean(_row_val(row, c)).upper() for c in (Col.MATERIAL1, Col.MATERIAL2)]
        api = next((m for m in mats if m.startswith("API")), None)
        if api is None:
            return None
        banned = [t for t in (_to_float(x) for x in (cfg.get('banned_thickness') or ()))
                  if t is not None]
        if not banned:
            banned = [12.7, 8.2, 6.0]
        tol = _to_float(cfg.get('tolerance'))
        if tol is None:
            tol = 0.05
        for col, label in ((Col.THICKNESS1, 'J'), (Col.THICKNESS2, 'K')):
            thk = _to_float(_row_val(row, col))
            if thk is None or thk <= 0:
                continue
            hit = next((b for b in banned if abs(thk - b) < tol), None)
            if hit is None:
                continue
            return Flag(9, col, "Green",
                        f"{target}은 API 재질({api})에 두께 {hit:g}mm 사용 불가 "
                        f"({label}열={thk:g}mm)",
                        expected=f"{', '.join(f'{b:g}' for b in banned)}mm 외의 두께 "
                                 f"(API 재질 + {target})",
                        actual=f"{label}열 두께={thk:g}mm, 재질={api}")
        return None

    def _c11_material_not_allowed(self, row: tuple, wps_no: str,
                                  repair: bool) -> Optional[Flag]:
        """
        해당 WPS의 허용 재질 목록(F열)에 없는 재질로 용접한 경우를 감지한다.
        두께 범위 문제(Check 3)와 달리 "이 WPS로는 이 재질을 용접할 자격이 없다"는
        더 근본적인 부적합이므로 별도 항목으로 표시한다.

        오탐을 막기 위해 아래 경우는 검사하지 않는다:
          - WPS 미기재 / WPS List에 없는 WPS (각각 다른 Check의 관할)
          - 수리 WPS(TR-FC-R*) — 임시 절차라 재질 목록이 관리되지 않음
          - 재질 표기를 표준 키로 인식하지 못한 경우 (근거 없이 단정하지 않음)
        """
        if not wps_no or repair:
            return None
        wps = self.loader.wps_of(wps_no)
        if not wps:
            return None
        raw1 = _clean(_row_val(row, Col.MATERIAL1))
        if not raw1:
            return None
        key1 = _get_material_key(raw1)
        if key1 is None:
            return None

        base_metals = [me.get('base_metal', '') for me in wps.get('materials', [])]
        if not any(bm.strip() for bm in base_metals):
            return None  # WPS에 허용 재질 정보 자체가 없으면 판단 불가

        f1 = self._c11_check_one_material(wps, wps_no, key1, raw1, base_metals, Col.MATERIAL1, 'M')
        if f1:
            return f1

        # N열(재질2)이 있으면 이음 반대쪽 부재도 이 WPS의 허용 재질이어야 한다
        # (Check 3 K열 확장과 같은 이유 — ASME IX QW-451은 이음을 구성하는 각
        # 부재에 대해 자격이 성립해야 한다고 본다).
        raw2 = _clean(_row_val(row, Col.MATERIAL2))
        if not raw2:
            return None
        key2 = _get_material_key(raw2)
        if key2 is None:
            return None
        return self._c11_check_one_material(wps, wps_no, key2, raw2, base_metals, Col.MATERIAL2, 'N')

    def _c11_check_one_material(self, wps: dict, wps_no: str, mat_key: str, raw_material: str,
                                base_metals: list[str], col: int, side_label: str) -> Optional[Flag]:
        # WPS 보정으로 이 재질을 얹었으면 **허용된 재질**로 본다.
        # 안 하면 같은 행을 Check 3은 보정값으로 정상 판정하는데 Check 11은
        # «허용 재질이 아님»으로 찍는 모순이 난다 — 현업 표현대로
        # «WPS-재질-두께»가 한 구조라 두 검사가 같은 보정을 봐야 한다.
        if wps_overrides.find_material(self._wps_ov(), wps_no,
                                       mat_key, raw_material) is not None:
            return None

        for bm in base_metals:
            if _material_covered_by_wps(mat_key, bm):
                return None

        # F열(허용 재질)에 빠져 있어도 G열(두께범위)에 그 재질의 전용 항목이
        # 명시돼 있으면 실질적으로 허용된 재질로 본다 — 실제 WPS에 F열 기재가
        # 누락된 사례가 있다(TR-FC-G01은 F열에 EW420이 없는데 G열에는
        # 'EW420 : 13~50' 항목이 있음). 이 보정이 없으면 오탐이 발생한다.
        for me in wps.get('materials', []):
            for label, _rng in _parse_material_thickness_entries(me.get('thk_range', '')):
                if _label_matches_material(mat_key, label):
                    return None

        allowed = ' / '.join(bm.replace('\n', ' ').strip() for bm in base_metals if bm.strip())
        return Flag(11, col, "Purple",
                    f"재질 부적합({side_label}열): '{raw_material}'({mat_key})은 WPS={wps_no}의 허용 재질이 아님",
                    expected=f"{allowed[:80]} (WPS={wps_no} 허용 재질, {side_label}열)",
                    actual=f"'{raw_material}'")

    def _c12_tubular_dia_review(self, row: tuple) -> Optional[Flag]:
        """
        관재(A500 등 각관·강관)는 철판이 아니므로 두께 판정 기준이 J열(Thickness)이
        아니라 I열(Out Dia)의 형상 규격이다. 그런데 I열 값이 'SHS80X6'처럼 숫자가
        아닌 규격 표기라 자동 판정이 불가능하고, 기준값과 실측값에 차이가 있어
        사람이 직접 확인해야 한다 → '결함 확정'이 아니라 '확인 필요'로 분류한다.
        """
        if not _is_tubular_material(_clean(_row_val(row, Col.MATERIAL1))):
            return None
        self._scope["12"] += 1
        out_dia = _clean(_row_val(row, Col.OUT_DIA))
        thk     = _clean(_row_val(row, Col.THICKNESS1))
        return Flag(12, Col.OUT_DIA, "Teal",
                    f"관재 확인 필요: 재질={_clean(_row_val(row, Col.MATERIAL1))}, "
                    f"Out Dia='{out_dia}' (두께가 아닌 DIA 기준이라 수동 확인 필요)",
                    expected=f"I열 Out Dia 규격 기준 확인 (J열 두께 {thk}mm 기준 아님)",
                    actual=f"Out Dia='{out_dia}'")

# ─── 진입점 ──────────────────────────────────────────────────────────────────
def _scope_map(checker: "QCChecker") -> dict[str, int]:
    """**각 검사가 대조한 대상 수.** 0건에는 두 종류가 있다 —

        대조했고 위반이 없다        -> 진짜 «문제 없음»
        대조할 대상이 아예 없었다    -> 한 번도 판정하지 않았다

    화면에서는 둘 다 그냥 «0건»으로 보인다. **여기 없는 번호는 판정 대상 전체를
    본 검사다**(Check 1·2·3·4·6·11·18·19).

    프로젝트 규칙은 `_SCOPED_CHECKS`에 못 박을 수 없다 — 규칙마다 번호가 다르다.
    그런데 이쪽이야말로 **항상 관문이 좁다**(`when`이 재질·WPS·NDT Category를
    지목한다). 키가 없으면 화면이 「없으면 전부가 대상」을 적용해 **대조 대상이
    0건인 규칙에 「대상 없음」이 안 붙는다** — 그 구분이 가장 필요한 쪽에서
    빠지는 셈이다. 대조한 수는 `_rule_matched`가 이미 세고 있으므로 합쳐 준다.

    **한 번도 안 걸린 규칙은 0으로 채운다.** 채우지 않으면 키가 아예 안 생겨서
    정작 잡아야 할 «대상 0건»이 빠진다 — `_scope`를 0으로 미리 채우는 것과 같은
    이유다.
    """
    out = {str(k): int(v) for k, v in checker._scope.items()}
    for r in checker._project_rules():
        if r.no:
            out[r.no] = int(checker._rule_matched.get(r.no, 0))
    return out


def _noscope_findings(checker: "QCChecker",
                      enabled: dict[int, bool]) -> list[dict[str, Any]]:
    """켜져 있는데 **대조할 대상이 하나도 없었던** 검사를 경고한다.

    이 저장소에서 「0건」은 두 가지 뜻이다:

        대조했고 위반이 없다        -> 진짜 «문제 없음»
        대조할 대상이 아예 없었다    -> 한 번도 판정하지 않았다

    화면에서는 둘 다 그냥 «0건»으로 보인다. 실제로 Check 25는 `Q01`로 끝나는
    WPS가 한 행도 없어 한 번도 안 돌았는데 «통과»로 읽혔다. Check 15가 결번이
    된 것도 「위반 0건」을 뒤늦게 「대조 조합 0건」으로 정정한 결과다.

    프로젝트 규칙(101~199)은 `project_checks.health()`가 이미 같은 경고를 낸다.
    여기는 **공통 Check** 몫이다.

    계측하지 않은 검사(판정 대상 전체를 보는 것들 — Check 1·2·3·4·6·11·18·19)는
    `_scope`에 아예 없다. 그건 «대상이 없다»가 아니라 «전부가 대상»이라 뺀다.
    """
    out: list[dict[str, Any]] = []
    for no in sorted(checker._scope, key=project_checks.sort_key):
        if checker._scope[no] > 0:
            continue
        if not enabled.get(no, True):
            continue                 # 꺼 둔 검사가 0인 것은 당연하다
        name = check_name(no)
        out.append({"level": "noscope", "check_no": no,
                    "msg": f"Check {project_checks.label(no)}({name})이 대조한 대상이 0건이다 — "
                           f"«위반이 없다»가 아니라 «한 번도 판정하지 않았다»이다. "
                           f"대상이 생기는 순간이 확인할 때다"})
    return out


def run_verification(
    qmg_path: str | Path,
    welder_path: str | Path,
    wps_ref_path: str | Path,
    qmg_filename: str = "",
    welder_filename: str = "",
    wps_cache: dict | None = None,
    consumable_lots: list[str] | None = None,
    project: str | None = None,
    progress: Callable[[int, str], None] | None = None,
) -> dict:
    """검증 실행 → JSON 직렬화 가능한 dict 반환.

    `project`는 **이 회차를 어느 프로젝트 기준으로 판정할지**다. 주지 않으면
    지금 활성인 프로파일을 쓴다.

    판정에 쓴 항목 목록(`rules`)을 결과에 **함께 박아 넣는다.** 이름만 남기면
    같은 이름 안에서 항목을 켜고 껐을 때 «이 결과가 무엇으로 판정됐는지»를
    되짚을 수 없다. 실제로 다음이 가능했다:

        A 프로젝트로 검증 -> 세팅에서 B로 전환 -> 화면은 A의 숫자인데
        보는 사람은 B 결과로 읽는다 (오류도 경고도 없다)
    """
    if project:
        rule_catalog.switch_profile(project)
    active_project = rule_catalog.active_profile_name()
    rules_snapshot = rule_catalog.enabled_map()
    loader = QCDataLoader()
    if wps_cache:
        loader.load_wps_from_dict(wps_cache, progress)
    else:
        loader.load_wps(wps_ref_path, progress)
    loader.load_welders(welder_path, progress)
    # 승인 용접봉 목록. **없어도 검증은 돈다** — Check 28만 «대상 없음»이 된다.
    # 없다고 막으면 목록을 아직 못 받은 프로젝트가 아무 검증도 못 한다.
    if consumable_lots:
        loader.load_consumables_from_list(consumable_lots)
    loader.load_qmg(qmg_path, progress)

    # 규칙이 지목하는 WPS가 실제로 존재/사용되는지 확인한다.
    # 접두사가 다른 프로젝트가 들어오면 Check 5/8/9가 조용히 0건이 되는데,
    # 그걸 "문제가 없다"로 읽지 않도록 여기서 경고를 남긴다 (§11-9, 개선계획 12번).
    # qmg_rows는 (엑셀 행번호, 행 튜플) 형태다 — 행 튜플만 꺼내 써야 한다.
    used_wps = {
        _clean(_row_val(row, Col.WPS_NO)).upper()
        for _, row in loader.qmg_rows if _clean(_row_val(row, Col.WPS_NO))
    }
    rule_findings = wps_rules.check_rules_alive(set(loader.wps_table), used_wps)

    # **승인 용접봉 목록이 없으면 Check 18의 «미승인» 쪽이 돌지 않는다.**
    # 번호를 나누지 않기로 했으므로(위 `_c18_consumable_lot` 참조) `_scope`로는
    # 그 사실을 말할 수 없다 — 18은 모든 판정 행에서 «기재 누락»을 보기 때문이다.
    # 그래서 여기에 남긴다. 없으면 목록을 안 올린 프로젝트가 «용접봉 문제 없음»
    # 으로 읽힌다. 「0건」이 «대조했고 위반 없음»인지 «대조하지 않음»인지는
    # 결과만 봐서는 알 수 없다.
    if not loader.consumable_lots:
        rule_findings.append({
            "wps": "", "level": "missing",
            "msg": "승인 용접봉 리스트가 없다 — Check 18이 «미승인 용접봉»을 "
                   "한 행도 대조하지 않았다. 기재 누락만 본 결과다 "
                   "('업로드' 탭에서 승인 목록을 올려라)"})

    checker = QCChecker(loader)
    # 판정 중에 설정이 바뀌어도 회차 안에서는 «한 기준»이어야 한다.
    # 행마다 파일을 다시 읽으면 앞뒤 행이 다른 기준으로 판정될 수 있다.
    checker._enabled = dict(rules_snapshot)
    checker.run(progress)

    flags_list: list[dict] = []
    for row_num in sorted(checker.row_flags):
        rd = checker.row_data.get(row_num, {})
        for f in checker.row_flags[row_num]:
            flags_list.append({
                "row":        row_num,
                "check_no":   f.check_no,
                "check_name": checker._check_name(f.check_no),
                "col":        f.col,
                "col_letter": get_column_letter(f.col),
                "color":      f.color,
                "msg":        f.msg,
                "expected":   f.expected,
                "actual":     f.actual,
                "drawing_no":  rd.get('drawing_no', ''),
                "joint_no":    rd.get('joint_no', ''),
                "block":       rd.get('block', ''),
                "material1":   rd.get('material1', ''),
                "material2":   rd.get('material2', ''),
                "thickness1":  rd.get('thickness1', ''),
                "thickness2":  rd.get('thickness2', ''),
                "wps_no":      rd.get('wps_no', ''),
                "wps_process": rd.get('wps_process', ''),
                # 산출물의 추적 키 — 현업은 도면번호가 아니라 이 번호로 원본을 찾는다
                "ndt_report":  rd.get('ndt_report', ''),
                "weld_date":   rd.get('weld_date', ''),
                "ndt_date":    rd.get('ndt_date', ''),
                # Check 14 중복 그룹 비교 시 "누가 각 중복행을 시공했는지"가 판단 근거가 된다
                "welder1_no":  rd.get('welder1_no', ''),
                "department":  rd.get('department', ''),
                "team":        rd.get('team', ''),
            })

    def _check_breakdown(wno: str, check_stats: dict, missing: dict) -> dict[str, int]:
        """'C1: 0, C6: 74' 형태 약식 표기용 — check_no(1~10)별 건수. Check 6은 미자격(서류) 건수."""
        breakdown = {str(n): 0 for n in CHECK_NAMES}
        for check_no, cnt in check_stats.get(wno, {}).items():
            breakdown[str(check_no)] = cnt
        breakdown["6"] = missing.get(wno, 0)
        return breakdown

    # 용접사별 결함 발생률 (AP/AR/AT/AV열 전체 참여 건 기준) — 교육 참고용, 결함 발생률 높은 순
    welder_defect_rate: list[dict] = []
    for wno, tot in checker.welder_totals.items():
        defect = checker.welder_defects.get(wno, 0)
        if defect == 0:
            continue
        welder_defect_rate.append({
            "welder_no": wno,
            "total":     tot,
            "defect":    defect,
            "rate":      round(defect / tot * 100, 1) if tot else 0.0,
            "check_breakdown": _check_breakdown(wno, checker.welder_check_stats, checker.welder_missing),
        })
    welder_defect_rate.sort(key=lambda w: (-w["rate"], -w["defect"], w["welder_no"]))
    # 동점자까지 정렬 키에 넣는 이유: 앞의 두 값만 쓰면 남는 순서가 «먼저 들어온
    # 순»이 되는데, 그 삽입 순서가 `row_welders`(set) 순회에 좌우돼 파이썬
    # 프로세스마다 달라진다. 같은 파일을 두 번 돌려도 같은 결과가 나와야
    # 검증 이력 비교(개선계획 9번)가 성립한다.

    # 용접사 부가 정보 (이름 + 자격 상세) — 번호만으로는 관리자가 대상자를 특정할 수 없어
    # 화면/리포트에서 이름과 보유 자격을 함께 보여주기 위한 조회용 맵.
    # 각 목록(결함발생률/미등록/반복패턴)에 이름을 중복 저장하지 않고 여기서 조회해 쓴다.
    # 자격 DB에 없는 용접사(협력사 등)는 registered=False로만 남는다.
    def _fmt_d(d) -> str:
        return d.isoformat() if d else ""

    welder_info: dict[str, dict] = {}
    for wno in set(checker.welder_totals) | set(checker.welder_missing):
        cert = loader.welder_certs.get(wno)
        qual = loader.welder_qual.get(wno)
        # 실적 수치도 함께 담아 welder_info 하나만으로 용접사 관리 화면을 구성할 수 있게
        # 한다. 예전에는 welder_defect_rate(결함 있는 용접사만)와 welder_missing(C6
        # 대상만) 두 목록을 따로 써서 같은 사람이 양쪽에 다른 숫자로 나타났고, 결함이
        # 0건인 용접사는 어느 쪽에도 없어 "결함 없이 많이 시공한 사람"을 볼 수 없었다.
        total  = checker.welder_totals.get(wno, 0)
        defect = checker.welder_defects.get(wno, 0)   # C6 제외(실제 작업성 결함)
        welder_info[wno] = {
            "name":       loader.welder_names.get(wno, ""),
            "registered": qual is not None,
            "retired":    wno in loader.retired_welders,
            "processes":  sorted(qual['process']) if qual else [],
            "positions":  sorted(qual['position']) if qual else [],
            "specs":      sorted(cert['specs']) if cert else [],
            "classes":    sorted(cert['classes']) if cert else [],
            "cert_count": len(cert['cert_nos']) if cert else 0,
            "first_cert_date": _fmt_d(cert['first_cert_date']) if cert else "",
            "last_cert_date":  _fmt_d(cert['last_cert_date']) if cert else "",
            # ── 실적 ──
            "total":          total,
            "defect":         defect,
            "rate":           round(defect / total * 100, 1) if total else 0.0,
            # 소속 — 건수 많은 순. 한 사람이 여러 팀에 걸치면 전부 싣는다.
            "orgs": [{"department": d, "team": t, "rows": n}
                     for (d, t), n in checker.welder_orgs.get(wno, Counter()).most_common()],
            "missing_flags":  checker.welder_missing.get(wno, 0),   # C6 건수
            "check_breakdown": _check_breakdown(wno, checker.welder_check_stats,
                                                checker.welder_missing),
            # 날짜별 추이 — [{date, total, checks:{check_no: 건수}}] (용접일 오름차순).
            # total(그날 시공량)이 함께 있어야 결함률로 그릴 수 있고, 그래야
            # "많이 일한 날"과 "잘못한 날"이 구분된다.
            "date_stats": [
                {
                    "date":   dt,
                    "total":  cnt,
                    "checks": {str(k): v for k, v in
                               sorted(checker.welder_date_checks.get(wno, {}).get(dt, {}).items())},
                }
                for dt, cnt in sorted(checker.welder_date_totals.get(wno, {}).items())
            ],
        }

    # 용접 날짜별 결함 발생 추이 (AM열 기준) — 날짜 오름차순
    defect_trend_by_date = [
        {"date": d, "count": c}
        for d, c in sorted(checker.defect_by_date.items())
    ]
    # 같은 날짜의 **판정 대상 행수** — 위 추이의 분모다.
    #
    # **저장해야 한다.** 깨끗한 행은 flag 테이블에 없어서 꺼낼 때 셀 수가 없다
    # (`total_rows`·`welder_totals`와 같은 이유다). 없으면 결함 «건수»만 남고,
    # 물량이 는 달과 품질이 나빠진 달을 구분할 수 없다.
    judged_trend_by_date = [
        {"date": d, "count": c}
        for d, c in sorted(checker.judged_by_date.items())
    ]

    def _welder_rate_list(bucket: dict) -> list[dict]:
        rate_list: list[dict] = []
        for wno, tot in bucket['welder_totals'].items():
            defect = bucket['welder_defects'].get(wno, 0)
            if defect == 0:
                continue
            rate_list.append({
                "welder_no": wno,
                "total":     tot,
                "defect":    defect,
                "rate":      round(defect / tot * 100, 1) if tot else 0.0,
            })
        # 위 welder_defect_rate와 같은 이유로 welder_no까지 넣는다.
        rate_list.sort(key=lambda w: (-w["rate"], -w["defect"], w["welder_no"]))
        return rate_list

    def _trend_list(bucket: dict) -> list[dict]:
        return [{"date": d, "count": c} for d, c in sorted(bucket['defect_by_date'].items())]

    # 부서별 결함 분류 (BF열 기준) — 그 아래 팀(BG열) 단위로 한 번 더 집계해 "부서별 대시보드"
    # 탭에서 부서 -> 팀 순으로 드릴다운해 볼 수 있게 한다.
    departments: dict[str, dict] = {}
    for dept, d in checker.dept_data.items():
        teams: dict[str, dict] = {}
        for team, t in d['teams'].items():
            teams[team] = {
                "total_rows":          t['total_rows'],
                "unworked_rows":       t['unworked_rows'],
                "defect_rows":         t['defect_rows'],
                "check_stats":         {str(k): v for k, v in t['check_stats'].items()},
                "welder_defect_rate":  _welder_rate_list(t),
                "defects":             t['defects'],
                "defect_trend_by_date": _trend_list(t),
                "temp_rows":           t['temp_rows'],
                "subcon_rows":         t['subcon_rows'],
                "repair_rows":         t['repair_rows'],
            }
        departments[dept] = {
            "total_rows":          d['total_rows'],      # 판정 대상 (미작업 제외)
            "unworked_rows":       d['unworked_rows'],   # 미작업 (Check 0, 결함률 분모 아님)
            "defect_rows":         d['defect_rows'],
            "check_stats":         {str(k): v for k, v in d['check_stats'].items()},
            "welder_defect_rate":  _welder_rate_list(d),
            "defects":             d['defects'],
            "defect_trend_by_date": _trend_list(d),
            "temp_rows":           d['temp_rows'],
            "subcon_rows":         d['subcon_rows'],
            "repair_rows":         d['repair_rows'],
            "teams":               teams,
            # 6번 서브에이전트: 같은 용접사가 같은 Check에서 서로 다른 날짜에 반복
            # 발생하는 패턴 (부서별 결함 탭 + 부서 리포트 메일에서 참고용으로 노출).
            "recurring_patterns":  recurrence.detect_recurring_patterns(d['defects']),
        }

    active = len(loader.qmg_rows) - checker.deleted_rows
    # 판정 대상 = 삭제도 · 미작업도 · 임시부재(1C)도 · **사외업체도** 아닌 행.
    # 결함률 통계의 분모는 항상 이 값을 쓴다.
    #
    #     total_rows  = deleted_rows + active_rows
    #     active_rows = unworked_rows + temp_rows + subcon_rows + judged_rows
    #     judged_rows = flagged_rows + clean_rows
    #
    # 1C가 분모에서 빠진 것은 2026-08-20 현업 결정이다 — 예전에는 판정에 넣고
    # 화면 토글로만 뺐는데, 그러면 대시보드와 결함 목록이 다른 기준으로 보였다.
    # 사외업체는 2026-09-02 결정으로 같은 자리에 들어왔다.
    #
    # **수리 용접(`repair_rows`)은 여기서 빼지 않는다.** 판정 대상 «안»에 있고
    # 정규 항목을 전부 판정받는다 — 빠지는 것은 Check 26(NDE 요율)뿐이다.
    judged = (active - checker.unworked_rows - checker.temp_rows
              - checker.subcon_rows)
    return {
        "run_at":          datetime.now().strftime('%Y-%m-%d %H:%M'),
        # 이 회차를 «무엇으로» 판정했는가. 이름과 항목 목록을 함께 남긴다.
        "project":         active_project,
        "rules":           {str(k): bool(v) for k, v in rules_snapshot.items()},
        # **잠정 표식** — 「이 항목은 다른 프로젝트 값을 빌려 쓰는 중이라 재확인이
        # 필요하다」. 켬/끔과 같은 이유로 **결과에 박는다** — 나중에 설정을 고쳐도
        # «이 회차가 무슨 상태에서 나온 숫자인가»는 변하지 않아야 한다.
        # 표식이 없으면 빌려 온 값으로 나온 숫자를 확정된 판정으로 읽게 된다.
        "provisional":     {str(k): str(v) for k, v in
                            (wps_rules.load().get("provisional") or {}).items()},
        "scope":           _scope_map(checker),
        # 규칙의 **정의**도 함께 박는다. 번호와 켬/끔만 남기면 옛 회차의
        # «허용 12~50»이 어디서 왔는지 복원할 수 없다.
        "project_checks":  [r.as_dict() for r in checker._project_rules()],
        # 프로젝트 규칙이 공통 Check를 대신 판정한 side 수. **통과해서 플래그가
        # 없는 경우는 이 카운터가 아니면 어디에도 안 보인다.**
        "suppression":     [{"project_check": pno, "common_check": cno, "sides": n}
                            for (pno, cno), n in sorted(checker._suppressed.items())],
        # WPS 보정도 **정의를 그대로** 박는다. 보정은 번호를 갖지 않아
        # `rules`·`project_checks` 어디에도 안 남는데, 그러면 옛 회차의
        # «허용 25~38»이 문서값인지 보정값인지 되짚을 수 없다.
        "wps_overrides":   checker._wps_ov(),
        # 보정이 실제로 판정한 side 수. 0이면 «고쳤는데 한 행도 안 걸렸다» —
        # 표기가 실데이터와 다를 때가 대부분이라 화면이 그걸 말해야 한다.
        "wps_override_matched": dict(sorted(checker._ov_matched.items())),
        "qmg_filename":    qmg_filename,
        # 검증시트 이름. 기본값은 업로드한 QMG 파일명이고, 사용자가
        # '관리 > 기록'에서 고칠 수 있다(현업 결정 2026-09-04).
        # 확장자를 떼어 탭에 들어갈 만큼 짧게 만든다 — 탭은 폭이 좁다.
        "sheet_name":      re.sub(r"\.(xlsx?|xlsm|csv)$", "", qmg_filename or "",
                                  flags=re.IGNORECASE).strip(),
        "welder_filename": welder_filename,
        "total_rows":      len(loader.qmg_rows),
        "deleted_rows":    checker.deleted_rows,
        "active_rows":     active,
        "unworked_rows":   checker.unworked_rows,
        "judged_rows":     judged,
        # 임시부재(1C) — **판정 대상이 아니다**(2026-08-20). 미작업과 같은 자리다.
        # 건수는 남긴다: «몇 건이 빠졌는지»를 되짚을 수 있어야 하고, 없으면
        # 「원본은 1만 행인데 판정이 374행」이 설명되지 않는다.
        "temp_rows":       checker.temp_rows,
        # 사외업체(BF열이 Q·C로 시작하지 않음) — 판정 대상이 아니다(2026-09-02).
        # 1C와 같은 이유로 건수를 남긴다. 없으면 「3,255행이 어디로 갔는지」가
        # 화면 어디에도 안 보여 «행이 사라졌다»로 읽힌다.
        "subcon_rows":     checker.subcon_rows,
        # 수리 용접(E열 표기) — **판정 대상 «안»의 수량이다.** 대시보드가
        # 「수정 용접 (Repair)」로 보여 준다. judged_rows에서 빼지 않는다.
        "repair_rows":     checker.repair_rows,
        "flagged_rows":    len(checker.row_flags),
        "clean_rows":      judged - len(checker.row_flags),
        "total_flags":     sum(checker.stats.values()),
        "stats":           {str(k): v for k, v in checker.stats.items()},
        "flags":           flags_list,
        # 상세 결과 화면 "원본 데이터" 패널용 — 행 번호(문자열 키) -> 엑셀 원문 스냅샷.
        "row_raw":         {str(k): v for k, v in checker.row_raw.items()},
        # Check 0(미작업) 드릴다운용 — 결함이 아니므로 기준값/실제값은 없다.
        "unworked_list":   checker.unworked_list,
        "welder_missing":  {
            wno: {
                "flag_count": cnt,
                "total":      checker.welder_totals.get(wno, 0),
                # C6(미자격) 제외 — 실제 작업성 결함 건수/발생률
                "workmanship_defect": checker.welder_defects.get(wno, 0),
                "workmanship_rate": (
                    round(checker.welder_defects.get(wno, 0) / checker.welder_totals[wno] * 100, 1)
                    if checker.welder_totals.get(wno, 0) else 0.0
                ),
                "check_breakdown": _check_breakdown(wno, checker.welder_check_stats, checker.welder_missing),
            }
            for wno, cnt in sorted(checker.welder_missing.items(), key=lambda x: -x[1])
        },
        "welder_defect_rate":    welder_defect_rate,
        "welder_info":           welder_info,
        "defect_trend_by_date":  defect_trend_by_date,
        "judged_trend_by_date":  judged_trend_by_date,
        "departments":           departments,
        # 규칙이 죽어 있는지 점검한 결과. 화면(설정/에이전트 탭)에서 확인할 수 있게 싣는다.
        # WPS 규칙 경고 + **프로젝트 규칙 경고**를 한 자리에 모은다.
        # 0행에 걸리는 규칙은 «문제 없음»이 아니라 «표기가 안 맞을 수 있다»이다 —
        # F03·G05·S355KT 계열이 지금 물량에서 정확히 그 상태다.
        # 판정 대상의 «재질 × WPS» 분포. 화면에서 규칙을 넣을 때 «지금 데이터에
        # 몇 행 걸리는가»를 즉시 세는 데 쓴다 — 0행이면 그 자리에서 표기 문제를
        # 알 수 있다(「S355KL -40」이 실데이터 표기와 안 맞아 한 번 막혔다).
        #
        # 행수가 아니라 **조합 수**에 비례한다(이 물량은 재질 16 × WPS 5).
        # 30만 행이어도 크기가 거의 같다.
        "material_wps":          [
            {"material": m, "wps": w, "rows": n}
            for (m, w), n in sorted(checker._mat_wps.items(), key=lambda x: -x[1])],
        "rule_health":           rule_findings + project_checks.health(
            checker._project_rules(), checker._rule_matched,
            checker._rule_problems) + _noscope_findings(checker, rules_snapshot),
        # 머신러닝(비지도) 분석 화면용. meta는 격자/히스토그램으로 요약돼 있고
        # detail은 이상치 행(수십~수천)만 담으므로 결과 JSON 크기에 큰 영향이 없다.
        "ml": {
            "unsupervised": {
                "available": checker.ml_meta is not None,
                "meta":      checker.ml_meta,
                "detail":    {str(k): v for k, v in checker.ml_detail.items()},
            },
        },
    }

def write_result_excel(qmg_path: str | Path, result: dict,
                       out_path: str | Path) -> None:
    """QMG 원본을 복사하여 플래그 색상 마킹 + 기준값/실제값 주석 후 저장."""
    wb = load_workbook(str(qmg_path))
    ws = wb.active

    best: dict[int, dict[int, dict]] = defaultdict(dict)
    for f in result['flags']:
        row, col = f['row'], f['col']
        prev = best[row].get(col)
        if prev is None or _PRIORITY[f['color']] < _PRIORITY[prev['color']]:
            best[row][col] = f

    for row_num, col_map in best.items():
        for col, f in col_map.items():
            cell = ws.cell(row=row_num, column=col)
            cell.fill = _FILLS[f['color']]
            if f['color'] == 'Black':
                cell.font = Font(color="FFFFFF")
            comment_lines = [f"[Check {f['check_no']}] {f['check_name']}"]
            if f.get('expected') or f.get('actual'):
                comment_lines.append(f"기준값: {f.get('expected', '')}")
                comment_lines.append(f"실제값: {f.get('actual', '')}")
            else:
                comment_lines.append(f['msg'])
            comment = Comment("\n".join(comment_lines), "QC Verifier")
            comment.width  = 320
            comment.height = 110
            cell.comment = comment

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(out_path))
    logger.info("Excel 결과 저장: %s", out_path)
