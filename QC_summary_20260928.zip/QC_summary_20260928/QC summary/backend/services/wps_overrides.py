"""WPS 보정 레이어 — 문서에서 읽은 WPS 값을 «덮지 않고 얹는다».

## 왜 원본을 고치지 않는가

WPS 요약 엑셀에는 **재질·두께가 비어 있는 칸이 있다.** 그런데 두께 텍스트가
비면 `verifier._thickness_in_range()`가 **참**을 돌려준다 — 즉 «자료가 없으면
결함이 아니다»가 되어, 그 재질은 두께를 아무리 벗어나도 걸리지 않는다.
오류도 경고도 나지 않는다.

고칠 자리가 필요한데, `wps_cache.json`을 직접 고치면 안 된다:

- WPS 엑셀을 다시 올리면 **파싱 결과로 통째로 덮여** 보정이 사라진다
  (`POST /api/files/wps`는 파싱 후 원본 파일을 지우고 JSON만 남긴다)
- «문서에 뭐라고 적혀 있었는지»와 «무엇을 왜 고쳤는지»가 사라진다

그래서 원본은 그대로 두고 **보정만 따로 쌓는다.** 화면은 둘을 나란히 보여주고,
보정을 지우면 문서값으로 돌아간다.

## 구조 — WPS → 재질 → 두께

현업이 보는 단위가 그렇다. 다만 **문서의 한 칸이 이미 재질 여러 개**라서
(`base_metal`에 8개가 콤마로, `thk_range`에 라벨별 블록 3개) 문서 텍스트를
쪼개 고치는 대신, **재질 단위의 구조화된 행**을 따로 둔다.

```
profiles.<프로젝트>.wps_overrides = {
  "TR-FC-G01": {
    "materials": [
      {"id": "EO420", "match": [],                  "range": "25~38", "note": "G열 누락"},
      {"id": "kt40",  "match": ["S355KT-40","KT-40"], "range": "12~50", "note": "매핑표에 없는 재질"}
    ],
    "note": "...", "edited_by": "A446955", "edited_at": "2026-08-28"
  }
}
```

`id` — `verifier.MATERIAL_MAP`의 재질 키(`E36`·`EO420` 등)이거나, 매핑표에 없는
재질을 위해 사람이 붙인 이름이다. **`match`가 있으면 원문 표기에 부분일치**로
찾는다 — `_get_material_key()`가 `None`을 주는 재질(`S355KT-40`)을 코드 수정
없이 다룰 수 있는 유일한 길이다.

## 판정에 어떻게 닿는가 — 새 검사를 만들지 않는다

보정은 «새 판정»이 아니라 **«WPS 자료의 정정»**이다. 그래서 번호를 새로 따지
않고 기존 Check가 그대로 쓴다. 새 번호를 만들면 색 정의 여섯 곳·축 분류·
카탈로그를 함께 갱신해야 하고, 무엇보다 검토 기록 키(`…|Check No`)가 흔들린다.

| Check | 보정이 닿는 방식 |
|---|---|
| **3** (두께범위) | 보정 범위가 있으면 그 범위로 판정한다. **프로젝트 규칙보다 앞선다** — 특정 WPS×재질을 콕 집은 값이라 전역 규칙보다 구체적이다 |
| **11·27** (재질-WPS 부적합) | 보정으로 재질을 얹으면 «이 WPS에 허용된 재질»로 인정한다. 안 그러면 같은 행을 Check 3은 정상 판정하는데 Check 11은 부적합으로 찍는 모순이 난다 |

두께를 고치는 것과 재질을 얹는 것이 같은 자리에서 일어나므로 — 현업 표현대로
**«WPS-재질-두께»가 하나로 연결된 구조** — 두 Check가 같은 보정을 본다.
"""
from __future__ import annotations

import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

# 보정 행 하나가 가질 수 있는 키. 화면에서 온 것을 그대로 믿지 않는다.
_ROW_KEYS = ("id", "match", "range", "note")


def _norm(text: str) -> str:
    """부분일치 비교용 정규화 — 공백·하이픈·밑줄을 지우고 대문자로.

    `verifier._get_material_key()`와 **같은 규칙**이어야 한다. 다르면 화면에서
    「걸린다」고 본 표기가 판정에서 안 걸리는 일이 생기는데, 그건 사용자가
    확인할 방법이 없다.
    """
    return re.sub(r"[\s\-_]+", "", (text or "").upper())


def load() -> dict[str, dict]:
    """활성 프로파일의 보정. 없으면 빈 dict.

    **여기서 예외가 새면 검증이 통째로 죽는다** — 보정은 부가 기능이라
    깨진 설정 하나가 판정을 막아서는 안 된다.
    """
    try:
        from backend.services import rule_catalog
        raw = rule_catalog.active_overrides()
        return raw if isinstance(raw, dict) else {}
    except Exception as e:                      # noqa: BLE001 - 판정을 막지 않는다
        logger.warning("WPS 보정을 읽지 못했다: %s", e)
        return {}


def normalize(raw: Any) -> dict[str, dict]:
    """화면에서 온 것을 저장 가능한 모양으로 — **잘못된 줄은 버리지 말고 고친다.**

    빈 `range`는 지운다. 범위가 없는 보정 행은 «두께를 안 본다»가 아니라
    **«두께가 비어 있어 무조건 통과»**가 되어 원래 고치려던 문제를 그대로
    재현한다(빈 범위는 `_thickness_in_range()`가 참을 준다).
    """
    out: dict[str, dict] = {}
    if not isinstance(raw, dict):
        return out
    for wps_no, body in raw.items():
        if not isinstance(body, dict):
            continue
        rows: list[dict] = []
        for r in (body.get("materials") or []):
            if not isinstance(r, dict):
                continue
            rid = str(r.get("id") or "").strip()
            rng = str(r.get("range") or "").strip()
            match = [str(m).strip() for m in (r.get("match") or []) if str(m).strip()]
            if not rid and not match:
                continue                       # 무엇을 가리키는지 알 수 없다
            if not rng:
                continue                       # 위 독스트링 참조
            rows.append({"id": rid, "match": match, "range": rng,
                         "note": str(r.get("note") or "").strip()})
        entry = {k: v for k, v in body.items() if k not in ("materials",)}
        entry["materials"] = rows
        # 보정 행도 메모도 없으면 그 WPS는 통째로 뺀다 — 빈 껍데기가 쌓이면
        # 화면에서 «보정됨»으로 보인다.
        if rows or str(entry.get("note") or "").strip():
            out[str(wps_no)] = entry
    return out


def for_wps(overrides: dict, wps_no: str) -> dict | None:
    """그 WPS의 보정. **프로젝트 접두사를 떼고도 찾는다.**

    RUYA는 TRION 자료로 WPS를 만들어서 뒤쪽 구분이 같고 앞자리만 다르다
    (`TR-FC-G01` == `RU-FC-G01`). `wps_rules.apply_corrections()`가 이미 같은
    규칙으로 찾으므로 여기서만 다르게 굴면 «보정이 왜 안 먹는지»를 알 수 없다.
    """
    if not overrides or not wps_no:
        return None
    from backend.services import wps_rules
    got = overrides.get(wps_no)
    if got is not None:
        return got
    stripped = wps_rules.strip_revision(wps_no)
    if stripped and stripped in overrides:
        return overrides[stripped]
    core = wps_rules.wps_core(wps_no)
    if not core:
        return None
    for k, v in overrides.items():
        if wps_rules.wps_core(k) == core:
            return v
    return None


def find_material(overrides: dict, wps_no: str, mat_key: str | None,
                  raw_material: str = "") -> dict | None:
    """이 (WPS, 재질)에 걸리는 보정 행. 없으면 None.

    **재질 키 일치를 먼저 본다.** 자유 표기(`match`)는 매핑표가 답을 못 주는
    재질을 위한 것이라, 키가 있는데도 자유 표기가 먼저 걸리면 예측이 어렵다.
    """
    entry = for_wps(overrides, wps_no)
    if not entry:
        return None
    rows = entry.get("materials") or []
    if mat_key:
        for r in rows:
            if r.get("id") and r["id"].upper() == mat_key.upper():
                return r
    raw_n = _norm(raw_material)
    if raw_n:
        for r in rows:
            for m in (r.get("match") or []):
                if _norm(m) and _norm(m) in raw_n:
                    return r
    return None


def summary(overrides: dict) -> dict:
    """화면·로그용 집계."""
    ov = overrides or {}
    return {"wps": len(ov),
            "materials": sum(len(v.get("materials") or []) for v in ov.values())}
