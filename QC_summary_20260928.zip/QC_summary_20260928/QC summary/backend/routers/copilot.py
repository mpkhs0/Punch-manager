"""Copilot 에이전트에 올릴 자료 세 벌을 내려준다.

현업이 Copilot에 넣을 자료를 **서버가 한 벌로 정리해서** 준다. 폴더 구성은
받는 쪽(Copilot)의 것을 그대로 따른다:

    1. Joint search        WPS 선정 근거 (.txt)      <- WPS 등록부에서 파생
    2. Welder search       용접사 자격 (.xlsx)        <- 업로드된 자격 DB
    3. Weld consumable     승인 용접봉 (.xlsx)        <- 업로드된 승인 리스트

**요청할 때마다 다시 만든다.** 만들어 둔 파일을 내려주면 자격 DB를 새로 올린
뒤에도 옛 파일이 나가고, 받은 사람은 그것이 낡은 것인 줄 알 방법이 없다.
자격 상태(유효/만료)는 날짜가 지나면 값 자체가 달라지므로 더욱 그렇다.

**«없음»과 «비었음»을 가른다.** 자료를 안 올린 상태에서 빈 엑셀을 내려주면
에이전트가 「승인된 용접봉이 하나도 없다」로 읽는다 — 그건 사실이 아니다.
그래서 자료가 없으면 409로 거절하고, 화면은 무엇을 올려야 하는지 말한다.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Header, HTTPException

from backend import config
from backend.routers import verify as vr
from backend.routers.auth import require_login
from backend.services import (copilot_data, joint_export,
                              verifier as svc, wps_export)

logger = logging.getLogger(__name__)
router = APIRouter(tags=["copilot"])

# 업로드가 늘 여기에 쓴다(`verify.upload_welder`). 모듈 전역(`_welder_path`)을
# 보지 않는 이유: 서버를 다시 띄우면 그 전역이 비어 있는데 파일은 남아 있어,
# 「어제 올렸는데 없다고 나온다」가 된다.
_WELDER_FILE = "welder_list.xlsx"
_QMG_FILE = "qmg_data.xlsx"


def _welder_path() -> Path:
    return config.UPLOADS_DIR / _WELDER_FILE


def _wps_table() -> tuple[dict, str]:
    """WPS 목록을 **판정과 같은 우선순위**로 얻는다. (표, 출처 이름)

    `run_verification()`이 보는 순서 그대로다:

        1) 업로드해서 캐시된 목록 (data/wps_cache.json)   <- 보통 이쪽이다
        2) Raw data 폴더의 WPS 참조 파일

    처음에는 2번만 봤는데, 실제 서버는 화면에서 WPS List를 올려 쓰기 때문에
    1번에 들어 있다. 그대로 두면 **판정이 쓰는 WPS와 Copilot에 넘기는 WPS가
    갈라진다** - 「추천대로 썼는데 결함」이 나오고, 원인을 짚을 길이 없다.

    2번은 `config.current_wps_ref()`로 **지금 다시 찾는다.** `config.WPS_REF`는
    기동 때 한 번 정해져서, 서버를 띄운 뒤 파일을 갖다 놓으면 재기동 전까지
    「0건」으로 보인다.
    """
    cache = vr._load_wps_cache()
    if cache:
        loader = svc.QCDataLoader()
        loader.load_wps_from_dict(cache)
        if loader.wps_table:
            return loader.wps_table, (vr._wps_name or "업로드된 WPS 목록")

    ref = config.current_wps_ref()
    if ref.exists():
        loader = svc.QCDataLoader()
        loader.load_wps(str(ref))
        if loader.wps_table:
            return loader.wps_table, ref.name
    return {}, ""


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M")


def _auth(t: str | None, emp: str | None) -> None:
    """헤더가 있으면 그걸로, 없으면 «일회용 표»로 확인한다.

    내려받기는 `<a download>`로 하는데 거기에는 커스텀 헤더를 실을 수 없고,
    사번을 URL에 담으면 접근 로그·방문 기록·Referer에 자격증명이 그대로 남는다.
    표 발급은 결과 Excel과 **같은 것**을 쓴다(`/api/result/excel/ticket`) —
    따로 만들면 만료 규칙이 두 벌이 되어 한쪽만 고쳐진다.
    """
    if emp:
        require_login(emp)
    elif not (t and vr._check_ticket(t)):
        raise HTTPException(401, "다운로드 표가 없거나 만료되었습니다. 다시 시도하세요")


@router.get("/copilot/status")
def copilot_status(x_employee_id: str | None = Header(None)) -> dict:
    """세 자료가 지금 준비돼 있는지. 화면이 버튼을 켜고 끄는 근거다."""
    require_login(x_employee_id)
    wpath = _welder_path()
    qmg = config.UPLOADS_DIR / _QMG_FILE
    joints = joint_export.latest(config.JOINT_EXPORT_DIR)
    files = vr._consumable_files()
    lots  = {str(l).strip().upper()
             for f in files for l in (f.get("lots") or []) if str(l).strip()}
    try:
        wps_table, wps_src = _wps_table()
    except Exception:
        logger.exception("WPS 목록을 읽지 못했다")
        wps_table, wps_src = {}, ""
    return {
        "project": config.PROJECT_NAME,
        "wps": {
            "ready": bool(wps_table),
            "count": len(wps_table),
            "source": wps_src,
            # 안내는 **보통 쓰는 길**을 먼저 말한다. 실제 서버는 화면에서
            # WPS List를 올려 쓰고, Raw data 폴더는 그 다음이다.
            "hint": "" if wps_table else
                    "업로드 화면에서 WPS List를 올리거나, "
                    "'Raw data' 폴더에 WPS 참조 파일(.xlsm/.xlsx)을 두십시오",
        },
        "welders": {
            "ready": wpath.exists(),
            "source": vr._welder_name or (wpath.name if wpath.exists() else ""),
            "hint": "" if wpath.exists() else
                    "업로드 화면에서 용접사 자격 DB를 올리십시오",
        },
        # 4번 - 버튼을 눌러야만 만들어진다. **언제 만든 것인지 반드시 말한다** —
        # 자동 갱신이 아니라서, 표시가 없으면 낡은 자료를 최신으로 읽는다.
        "joints": {
            "ready": bool(joints),
            "source": (joints or {}).get("source", ""),
            "generated_at": (joints or {}).get("generated_at", ""),
            "folder": (joints or {}).get("name", ""),
            "count": (joints or {}).get("rows", 0),
            "blocks": (joints or {}).get("blocks", 0),
            "planned": (joints or {}).get("planned", 0),
            "rec_rows": (joints or {}).get("rec_rows", 0),
            "rec_top2": (joints or {}).get("rec_top2"),
            "rec_none": (joints or {}).get("rec_none", 0),
            "has_qmg": qmg.exists(),
            "hint": "" if joints else (
                "'만들기'를 누르면 생성됩니다" if qmg.exists() else
                "업로드 화면에서 QC Summary 데이터를 먼저 올리십시오"),
        },
        "consumables": {
            "ready": bool(lots),
            "count": len(lots),
            "files": [f.get("filename") or "" for f in files],
            # 원본 열이 함께 저장된 파일이 몇 개인가 — 옛 캐시는 Lot 번호뿐이다
            "with_columns": sum(1 for f in files if f.get("columns")),
            "hint": "" if lots else
                    "업로드 화면에서 승인 용접봉 리스트를 올리십시오",
        },
    }


@router.get("/copilot/wps")
def download_wps(t: str | None = None,
                  x_employee_id: str | None = Header(None)):
    """1. Joint search — WPS 선정 근거.

    **`.txt`로 내려준다.** 받는 쪽(Copilot)이 txt만 인식한다. 내용은 JSON
    그대로다 — 형식을 바꾸면 `WPS JSON for Copilot/README.txt`가 설명하는
    스키마와 갈라진다.
    """
    _auth(t, x_employee_id)
    wps_table, _ = _wps_table()
    if not wps_table:
        raise HTTPException(409,
            "WPS 목록을 읽지 못했습니다 - 업로드 화면에서 WPS List를 올리거나, "
            "'Raw data' 폴더에 WPS 참조 파일(.xlsm/.xlsx)이 있는지 확인하세요")
    data = wps_export.build(wps_table)
    config.COPILOT_DIR.mkdir(parents=True, exist_ok=True)
    out = config.COPILOT_DIR / "wps.txt"
    out.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                   encoding="utf-8")
    name = f"1. Joint search - {config.PROJECT_NAME or 'WPS'} 선정근거 {_stamp()}.txt"
    return vr.stream_file(out, name, media_type="text/plain; charset=utf-8")


@router.get("/copilot/welders")
def download_welders(t: str | None = None,
                  x_employee_id: str | None = Header(None)):
    """2. Welder search — 용접사 자격 (사람당 한 줄)."""
    _auth(t, x_employee_id)
    wpath = _welder_path()
    if not wpath.exists():
        raise HTTPException(409,
            "용접사 자격 DB가 올라와 있지 않습니다 — 업로드 화면에서 먼저 올리세요")
    out = config.COPILOT_DIR / "welders.xlsx"
    try:
        info = copilot_data.build_welder_xlsx(
            wpath, out, source_name=vr._welder_name or wpath.name)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    except Exception as exc:
        logger.exception("용접사 자료 생성 실패")
        raise HTTPException(500, f"용접사 자료를 만들지 못했습니다: {exc}")
    logger.info("Copilot 용접사 자료: %d명 (%s)", info["welders"], info["layout"])
    name = f"2. Welder search - 용접사 자격 {_stamp()}.xlsx"
    return vr.stream_xlsx(out, name)


@router.get("/copilot/consumables")
def download_consumables(t: str | None = None,
                  x_employee_id: str | None = Header(None)):
    """3. Weld consumable search — 승인 용접봉 (여러 파일을 합쳐 Lot당 한 줄)."""
    _auth(t, x_employee_id)
    files = vr._consumable_files()
    if not any(f.get("lots") for f in files):
        raise HTTPException(409,
            "승인 용접봉 리스트가 올라와 있지 않습니다 — 업로드 화면에서 먼저 올리세요")
    out = config.COPILOT_DIR / "consumables.xlsx"
    try:
        info = copilot_data.build_consumable_xlsx(files, out)
    except Exception as exc:
        logger.exception("승인 용접봉 자료 생성 실패")
        raise HTTPException(500, f"승인 용접봉 자료를 만들지 못했습니다: {exc}")
    logger.info("Copilot 용접봉 자료: Lot %d개 · 파일 %d개 · 원본열 %d개",
                info["lots"], info["files"], info["columns"])
    name = f"3. Weld consumable search - 승인 용접봉 {_stamp()}.xlsx"
    return vr.stream_xlsx(out, name)


@router.post("/copilot/joints")
def build_joints(x_employee_id: str | None = Header(None)) -> dict:
    """4. Joint search — 조인트 자료를 «날짜 폴더»에 만든다.

    **버튼을 눌러야만 만든다**(현업 결정 2026-09-18). 검증 때마다 자동으로
    만들면 32,975행을 쓰는 비용이 매 회차에 붙는데, 이 자료는 그만큼 자주
    필요하지 않다. 대신 화면이 «언제 만든 것인지»를 늘 보여 준다.

    **덮어쓰지 않는다.** 같은 날 두 번이면 `_2`, `_3` 으로 새 폴더를 판다 —
    덮어쓰면 블록이 줄어든 회차에서 옛 블록 파일이 남아, 사라진 물량이 그대로
    조회된다(오류도 경고도 없다).
    """
    require_login(x_employee_id)
    qmg = config.UPLOADS_DIR / _QMG_FILE
    if not qmg.exists():
        raise HTTPException(409,
            "QC Summary 데이터가 올라와 있지 않습니다 - 업로드 화면에서 먼저 올리세요")
    # **판정이 쓰는 것과 같은 WPS 목록**을 넘긴다. 다른 것을 쓰면 추천과
    # 판정이 갈라져 「추천대로 썼는데 결함」이 나온다.
    wps_table, wps_src = _wps_table()
    try:
        info = joint_export.build(qmg, config.JOINT_EXPORT_DIR,
                                  wps_table=wps_table, wps_source=wps_src)
    except Exception as exc:
        logger.exception("조인트 자료 생성 실패")
        raise HTTPException(500, f"조인트 자료를 만들지 못했습니다: {exc}")
    return {"ok": True, **info}
