"""WPS 설정 — 업로드된 WPS 목록을 보고, 누락을 보정한다.

## 왜 필요한가

WPS 요약 엑셀에는 **재질·두께가 비어 있는 칸이 있다.** 그런데 두께 텍스트가
비면 `verifier._thickness_in_range()`가 참을 돌려준다 — 그 재질은 두께를 아무리
벗어나도 걸리지 않고, 오류도 경고도 나지 않는다.

지금까지 그걸 고칠 자리가 없었다. `POST /api/files/wps`는 워크북을 파싱해
`data/wps_cache.json`에 쓰고 **원본 파일을 지우며**, 그 JSON을 화면으로 돌려주는
엔드포인트가 없었다. 화면이 아는 것은 「WPS 26개」라는 숫자 하나였다.

## 무엇을 돌려주는가 — 문서값과 보정값을 나란히

한 WPS 아래 재질이 여러 개고, 재질마다 두께가 붙는다(**WPS → 재질 → 두께**).
그런데 문서의 한 칸은 이미 재질 여러 개다 — `base_metal`에 8개가 콤마로,
`thk_range`에 라벨별 블록 3개. 그래서 화면에는 **판정 엔진이 실제로 읽는 단위**
(재질 키 × 두께 범위)로 풀어서 보여주고, 원문도 함께 싣는다.

원문을 함께 싣는 이유: 파서가 못 읽는 형태가 실재한다
(`"12~18 \\n(1pole),\\n\\n16~25\\n(2pole)"`). 파싱 결과만 보여주면 그 WPS는
«재질이 하나도 없는» 것처럼 보이는데, 실제로는 판정이 통째로 느슨해진 상태다.
"""
from __future__ import annotations

import json
import logging
from typing import Any

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from backend import config
from backend.routers.auth import require_login
from backend.routers.settings import _require_admin
from backend.services import rule_catalog, wps_overrides, wps_rules

logger = logging.getLogger(__name__)
router = APIRouter()


def _cache() -> dict:
    """파싱된 WPS 표. 없거나 깨졌으면 빈 dict — **판정과 같은 폴백**이다."""
    try:
        return json.loads(config.WPS_CACHE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _document_materials(entry: dict) -> list[dict]:
    """문서값을 «재질 × 두께» 행으로 편다 — 판정 엔진이 읽는 그 단위로.

    `_parse_material_thickness_entries()`가 라벨/범위를 못 뽑으면 그 사실을
    `parsed: False`로 알린다. **그게 곧 «이 칸은 판정이 느슨하다»는 신호**라
    화면이 감춰서는 안 된다.
    """
    from backend.services import verifier as V

    out: list[dict] = []
    for me in (entry.get("materials") or []):
        bm = me.get("base_metal", "") or ""
        thk = me.get("thk_range", "") or ""
        pairs = V._parse_material_thickness_entries(thk)
        if pairs:
            for label, rng in pairs:
                out.append({"label": label, "range": rng.strip(),
                            "base_metal": bm, "parsed": True})
        else:
            # 라벨을 못 뽑았다 — 칸 전체가 하나의 범위로 쓰인다(또는 비었다).
            out.append({"label": "", "range": thk.strip(),
                        "base_metal": bm, "parsed": False,
                        "empty": not thk.strip()})
    return out


@router.get("/wps")
def list_wps(x_employee_id: str | None = Header(None)) -> dict:
    """WPS 목록 + 문서값 + 보정값.

    **로그인만 요구한다.** 보는 것은 현업도 해야 하고, 고치는 쪽만 관리자다.
    """
    require_login(x_employee_id)
    cache = _cache()
    ov = rule_catalog.active_overrides()

    items = []
    for wps_no in sorted(cache):
        entry = cache[wps_no] or {}
        o = wps_overrides.for_wps(ov, wps_no) or {}
        items.append({
            "wps_no":       wps_no,
            "raw_name":     entry.get("wps_no") or wps_no,
            "process":      entry.get("process", ""),
            "position":     entry.get("position", ""),
            "joint_detail": entry.get("joint_detail", ""),
            # 문서 원문 — 파싱이 실패해도 사람이 읽을 수 있어야 한다
            "raw_materials": entry.get("materials") or [],
            # 판정 엔진이 읽는 단위로 편 것
            "doc_materials": _document_materials(entry),
            "overrides":    o.get("materials") or [],
            "note":         o.get("note", ""),
            "edited_by":    o.get("edited_by", ""),
            "edited_at":    o.get("edited_at", ""),
        })

    return {
        "project":  rule_catalog.active_profile_name(),
        "items":    items,
        "summary":  wps_overrides.summary(ov),
        "has_cache": bool(cache),
        # 매핑표의 재질 키 — 화면의 «재질» 고르는 자리가 이걸 쓴다.
        # 여기에 없는 재질은 자유 표기(`match`)로 넣어야 한다.
        "material_keys": _material_keys(),
    }


def _material_keys() -> list[str]:
    from backend.services import verifier as V
    return sorted(V.MATERIAL_MAP)


class OverridesIn(BaseModel):
    overrides: dict[str, Any]
    project: str | None = None


@router.post("/wps/overrides")
def save_overrides(body: OverridesIn,
                   x_employee_id: str | None = Header(None)) -> dict:
    """보정을 저장한다. **판정 기준이 달라지므로 재검증이 필요하다.**

    검증이 도는 중에는 막는다 — 회차 중간에 기준이 바뀌면 앞뒤 행이 다른
    기준으로 판정된다.
    """
    emp = _require_admin(x_employee_id)
    from backend.routers.verify import _reject_if_busy
    _reject_if_busy()

    clean = wps_overrides.normalize(body.overrides)

    # 범위 표기가 실제로 읽히는지 저장 전에 본다. 안 읽히는 범위는
    # `_thickness_in_range()`가 **참**을 주므로 «무조건 통과»가 되는데,
    # 그건 보정으로 고치려던 문제 그 자체다.
    from backend.services import verifier as V
    bad: list[str] = []
    for wps_no, body_ in clean.items():
        for r in body_.get("materials") or []:
            if not V._parse_thickness_ranges(r["range"]):
                bad.append(f"{wps_no} · {r.get('id') or r['match'][0]}: "
                           f"'{r['range']}'")
    if bad:
        raise HTTPException(400,
            "두께 범위를 읽을 수 없습니다 — 이대로 저장하면 그 재질은 "
            "«무조건 통과»가 됩니다. `12~50` 또는 `12-50` 형태로 적어 주세요: "
            + " / ".join(bad[:5]))

    from datetime import date
    today = date.today().isoformat()
    for b in clean.values():
        b.setdefault("edited_by", emp)
        b["edited_at"] = today

    rule_catalog.save_overrides(clean, body.project)
    logger.info("WPS 보정 저장: %s (WPS %d개 · 재질 %d행)",
                rule_catalog.active_profile_name(),
                len(clean), sum(len(v.get("materials") or []) for v in clean.values()))
    return {"ok": True,
            "project": rule_catalog.active_profile_name(),
            "summary": wps_overrides.summary(clean),
            # 저장만으로는 지금 결과가 안 바뀐다 — 프로젝트 세팅과 같은 이유
            "needs_reverify": True}


class PreviewIn(BaseModel):
    wps_no: str
    material_id: str = ""
    match: list[str] = []


@router.post("/wps/preview")
def preview(body: PreviewIn, x_employee_id: str | None = Header(None)) -> dict:
    """이 (WPS, 재질) 조합이 **지금 실데이터 몇 행에 걸리는가.**

    「S355KL -40」이 실데이터 표기(`S355KT-40`)와 안 맞아 규칙이 조용히 죽은
    적이 있다. 0행을 저장 전에 아는 것이 검증을 한 번 돌린 뒤에 아는 것보다
    훨씬 싸다. 현업도 볼 수 있어야 하므로 로그인만 요구한다.
    """
    require_login(x_employee_id)
    from backend.routers.verify import _state

    result = (_state or {}).get("result") or {}
    combos = result.get("material_wps") or []
    if not combos:
        return {"has_result": False, "rows": 0, "samples": []}

    from backend.services import verifier as V
    want_wps = wps_rules.wps_core(body.wps_no)
    mid = (body.material_id or "").strip().upper()
    matches = [m for m in body.match if m.strip()]

    hits = []
    for c in combos:
        if wps_rules.wps_core(c.get("wps", "")) != want_wps:
            continue
        raw = c.get("material", "")
        key = V._get_material_key(raw)
        ok = bool(mid) and key is not None and key.upper() == mid
        if not ok and matches:
            raw_n = wps_overrides._norm(raw)
            ok = any(wps_overrides._norm(m) in raw_n for m in matches)
        if ok:
            hits.append(c)

    return {"has_result": True,
            "rows": sum(int(h.get("rows", 0)) for h in hits),
            "combos": len(hits),
            "samples": hits[:8]}
