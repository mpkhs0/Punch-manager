"""
범위별 결과 Excel 내보내기 — 생성 요청 / 상태 조회 / 내려받기.

## 왜 백그라운드인가

원본 시트를 범위에 맞게 줄이는 비용이 범위마다 크게 다르다. 실측(10,034행 기준):

    건조5부 (117행 유지, 연속구간  5개):  약  7초
    Q520    (4,430행 유지, 연속구간 79개): 약 61초

큰 부서를 요청 시점에 만들면 사용자가 1분을 기다린다. 그래서 생성은 스레드로 돌리고
화면은 상태를 폴링한다 — 검증 실행과 같은 패턴이다.

## 일괄 생성은 «한 패스»다 — 스레드를 여러 개 띄우지 않는다

범위마다 `build_report()`를 부르면 **원본을 그 횟수만큼 다시 읽는다.** 그 읽기는
범위가 작아도 줄지 않아서, 5행짜리 팀 하나를 만드는 데도 원본 1만 행을 다 읽는다
(실측 3.89초). 31개 범위 순차 합계 124.9초 중 약 118초가 되풀이된 읽기였다.

38만 행이면 읽기 한 번이 2분을 넘으므로 그대로는 한 시간이 읽기로만 나간다.

그렇다고 **스레드를 범위 수만큼 띄우면 안 된다.** 각 스레드가 워크북을 하나씩
들고 있어 메모리가 범위 수에 곱해진다 — 38만 행에서 한 벌이 4.5GB이므로 몇 개만
겹쳐도 워크스테이션이 멎는다. 예전 화면의 「선택 생성」이 정확히 그렇게 동작했다.

지금은 `excel_report.build_reports()`가 **원본을 한 번 읽어 여러 파일에 동시에
흘려보낸다.** 스레드는 하나다. 실측(10,034행 · 31개 범위):

    순차     125.1초  ->  팬아웃 23.5초   (1C 제외)
    순차     169.9초  ->  팬아웃 65.9초   (1C 포함)

## 재검증하면 기존 산출물은 버린다

검증 결과가 바뀌면 이전에 만든 범위 파일은 전부 낡은 것이 된다. 파일이 남아 있다는
이유로 옛 결과를 내려주면 '조용히 틀린 산출물'이 되므로, 새 검증이 끝나면
`invalidate()`로 통째로 버린다.
"""

from __future__ import annotations

import logging
import shutil
import threading
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel

from backend import config
from backend.routers.auth import require_login
from backend.routers.verify import get_last_result, get_qmg_path
from backend.services import excel_report, result_store
from backend.services import feedback_store
from backend.services.verifier import _PRIORITY

logger = logging.getLogger(__name__)
router = APIRouter()

_lock = threading.Lock()

# key -> {"status": idle|building|ready|error, "info": {...}, "error": str, "run_at": str}
_exports: dict[str, dict[str, Any]] = {}

# 일괄 생성 진행 상황. 화면이 「12/31 완료」로 읽는다.
_batch: dict[str, Any] = {"running": False, "total": 0, "done": 0, "failed": 0,
                          "message": "", "run_at": "", "started_at": ""}


def _key(dept: str | None, team: str | None) -> str:
    """캐시 키 — 범위가 곧 키다.

    예전에는 «임시부재 제외» 여부도 들어갔다. 같은 부서인데 내용이 다른 두
    파일이 존재했기 때문이다. 2026-08-20부터 1C는 판정 대상이 아니라 파일이
    한 가지뿐이고, 키를 가를 이유도 없다.
    """
    return f"{(dept or '').strip()}||{(team or '').strip()}"


def _path_for(scope: excel_report.Scope) -> Path:
    return config.EXPORTS_DIR / f"QC_Result_{scope.slug()}.xlsx"


def _adopt_from_disk(scope: excel_report.Scope, key: str, run_at: str) -> dict | None:
    """서버를 재시작하면 메모리 상태가 비지만 파일은 디스크에 남아 있다.

    그 파일이 현재 검증 결과의 산출물이면 다시 만들 이유가 없다(큰 부서는 1분씩 걸린다).
    판단 기준은 검증 결과가 저장된 시각보다 새것인지다 - 결과 Excel 복원에 쓰는 것과
    같은 기준이라, 낡은 파일을 ready로 착각하지 않는다.

    예전에는 `app_state.json`의 파일 mtime을 그 시각으로 썼다. 저장소가 SQLite가 된
    뒤로는 그 대용이 성립하지 않는다 - **업로드 파일명만 바뀌어도 DB 파일의 mtime이
    움직여서**, 검증은 그대로인데 멀쩡한 파일이 통째로 낡은 것으로 판정된다.
    그래서 회차에 기록된 저장 시각(`run.saved_at`)을 직접 쓴다.
    """
    path = _path_for(scope)
    if not path.exists():
        return None
    saved_at = result_store.latest_saved_at()
    if saved_at is None:
        return None
    try:
        if path.stat().st_mtime < saved_at:
            return None
    except OSError:
        return None
    st = {
        "status": "ready",
        "info": {"scope": scope.label, "path": str(path), "size": path.stat().st_size},
        "error": None,
        "run_at": run_at,
        "message": "이전에 생성된 파일",
    }
    _exports[key] = st
    return st


def invalidate(run_id: int | None = None) -> None:
    """검증 결과가 바뀌었을 때 호출 — 만들어둔 범위 파일을 버린다.

    `run_id`는 «어느 시트 때문에 버리는가»를 로그에 남기기 위한 것이다. 지금은
    범위 파일이 **보고 있는 시트 기준으로 그때그때 만들어지므로**, 시트가 하나
    지워지거나 새 검증이 끝나면 캐시 전체를 버리는 편이 안전하다.

    **부분만 버리지 않는 이유**: 캐시 키가 범위(부서·팀)뿐이라 어느 시트의
    산출물인지 파일만 봐서는 알 수 없다. 남겨 두면 «없는 시트의 Excel»이
    내려갈 수 있고, 그건 받은 사람이 열어 보기 전에는 알 수 없다.
    """
    with _lock:
        _exports.clear()
        _batch.update({"running": False, "total": 0, "done": 0, "failed": 0,
                       "message": "", "run_at": "", "started_at": ""})
    try:
        if config.EXPORTS_DIR.is_dir():
            shutil.rmtree(config.EXPORTS_DIR)
        config.EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
        logger.info("범위별 내보내기 캐시 비움%s",
                    f" (검증시트 {run_id})" if run_id else "")
    except OSError:
        logger.exception("내보내기 캐시 삭제 실패")


def _build(scope: excel_report.Scope, key: str, run_at: str) -> None:
    """스레드에서 도는 실제 생성 작업."""
    def progress(msg: str) -> None:
        with _lock:
            st = _exports.get(key)
            if st:
                st["message"] = msg

    try:
        result = get_last_result()
        qmg = get_qmg_path()
        if result is None or qmg is None or not qmg.exists():
            raise RuntimeError("검증 결과 또는 원본 파일이 없습니다")

        info = excel_report.build_report(
            qmg, result, _path_for(scope),
            dept=scope.dept, team=scope.team,
            feedback=feedback_store.load_feedback(),
            priority=_PRIORITY,
            progress=progress,
        )
        with _lock:
            _exports[key] = {"status": "ready", "info": info, "error": None,
                             "run_at": run_at, "message": "완료"}
    except Exception as exc:
        logger.exception("범위 Excel 생성 실패: %s", scope.label)
        with _lock:
            _exports[key] = {"status": "error", "info": None, "error": str(exc),
                             "run_at": run_at, "message": f"오류: {exc}"}


def _build_many(scopes: list[excel_report.Scope], run_at: str) -> None:
    """일괄 생성 — 스레드 **하나**에서 원본을 한 번 읽어 전부 만든다."""
    def progress(msg: str) -> None:
        with _lock:
            _batch["message"] = msg

    def ready(scope: excel_report.Scope, info: dict) -> None:
        with _lock:
            _batch["done"] += 1
            _exports[_key(scope.dept, scope.team)] = {
                "status": "ready", "info": info, "error": None,
                "run_at": run_at, "message": "완료"}

    def failed(scope: excel_report.Scope, exc: Exception) -> None:
        with _lock:
            _batch["failed"] += 1
            _exports[_key(scope.dept, scope.team)] = {
                "status": "error", "info": None, "error": str(exc),
                "run_at": run_at, "message": f"오류: {exc}"}

    try:
        result = get_last_result()
        qmg = get_qmg_path()
        if result is None or qmg is None or not qmg.exists():
            raise RuntimeError("검증 결과 또는 원본 파일이 없습니다")
        excel_report.build_reports(
            qmg, result, scopes, _path_for,
            feedback=feedback_store.load_feedback(),
            priority=_PRIORITY,
            progress=progress, on_ready=ready, on_error=failed,
        )
    except Exception as exc:
        # 준비 단계에서 통째로 실패하면 아직 «생성 중»인 범위가 남는다.
        # 그대로 두면 화면이 영원히 폴링한다.
        logger.exception("일괄 생성 실패")
        with _lock:
            _batch["message"] = f"오류: {exc}"
            for sc in scopes:
                k = _key(sc.dept, sc.team)
                if (_exports.get(k) or {}).get("status") == "building":
                    _exports[k] = {"status": "error", "info": None, "error": str(exc),
                                   "run_at": run_at, "message": f"오류: {exc}"}
    finally:
        with _lock:
            _batch["running"] = False
            if not _batch["message"].startswith("오류"):
                _batch["message"] = "완료"


def ensure_built(dept: str | None, team: str | None, wait: bool = False) -> dict:
    """생성돼 있지 않으면 시작한다. wait=True면 끝날 때까지 기다린다(메일 첨부용)."""
    result = get_last_result()
    if result is None:
        raise HTTPException(404, "검증 결과가 없습니다. 먼저 검증을 실행하세요")

    scope = excel_report.Scope(dept, team)
    key = _key(dept, team)
    run_at = result.get("run_at", "")

    with _lock:
        # 일괄이 도는 중에 단건을 또 띄우면 워크북이 겹쳐 메모리가 두 배가 되고,
        # 같은 파일을 두 스레드가 쓰면 `os.replace`가 서로를 덮는다.
        if _batch["running"]:
            raise HTTPException(409, "일괄 생성이 진행 중입니다. 끝난 뒤에 다시 시도하세요")
        st = _exports.get(key)
        # 다른 검증 결과로 만든 것은 낡은 것이다
        if st and st.get("run_at") != run_at:
            st = None
            _exports.pop(key, None)
        if st is None:
            st = _adopt_from_disk(scope, key, run_at)
        if st and st["status"] in ("ready", "building"):
            if st["status"] == "ready" and not _path_for(scope).exists():
                _exports.pop(key, None)   # 파일이 사라졌으면 다시 만든다
            else:
                return dict(st, key=key, scope=scope.label)
        _exports[key] = {"status": "building", "info": None, "error": None,
                         "run_at": run_at, "message": "대기 중"}

    t = threading.Thread(target=_build, args=(scope, key, run_at), daemon=True)
    t.start()
    if wait:
        t.join()
    with _lock:
        return dict(_exports[key], key=key, scope=scope.label)


# ─── 엔드포인트 ───────────────────────────────────────────────────────────────
class BuildIn(BaseModel):
    dept: str | None = None
    team: str | None = None


@router.get("/exports")
def list_exports(x_employee_id: str | None = Header(None)) -> dict:
    """선택 가능한 범위 목록 + 각각의 생성 상태.

    표에 적히는 건수는 **파일에 담기는 것과 같은 기준**이어야 한다. 임시부재
    (1C)는 판정 대상이 아니라 양쪽 모두에서 빠져 있으므로 여기서 따로 뺄 것이
    없다 — `judged_rows`와 `defect_rows`가 이미 그 기준이다.
    """
    require_login(x_employee_id)
    result = get_last_result()
    if result is None:
        return {"has_result": False, "scopes": []}

    scopes: list[dict[str, Any]] = []

    def add(dept: str | None, team: str | None, label: str,
            judged: int, defects: int, kind: str) -> None:
        key = _key(dept, team)
        st = _exports.get(key) or {}
        if st.get("run_at") and st["run_at"] != result.get("run_at"):
            st = {}
        if not st:
            st = _adopt_from_disk(excel_report.Scope(dept, team), key,
                                  result.get("run_at", "")) or {}
        scopes.append({
            "kind": kind, "dept": dept, "team": team, "label": label,
            "judged_rows": judged, "defect_rows": defects,
            "status": st.get("status", "idle"),
            "message": st.get("message", ""),
            "info": st.get("info"),
            "error": st.get("error"),
        })

    add(None, None, "전체", result.get("judged_rows", 0),
        result.get("flagged_rows", 0), "all")
    for name, d in sorted((result.get("departments") or {}).items(),
                          key=lambda x: -x[1].get("defect_rows", 0)):
        add(name, None, name, d.get("total_rows", 0), d.get("defect_rows", 0), "dept")
        for tname, t in sorted((d.get("teams") or {}).items(),
                               key=lambda x: -x[1].get("defect_rows", 0)):
            add(name, tname, f"{name} > {tname}",
                t.get("total_rows", 0), t.get("defect_rows", 0), "team")

    with _lock:
        batch = dict(_batch)
    return {"has_result": True, "run_at": result.get("run_at", ""),
            "scopes": scopes, "batch": batch}


@router.post("/exports/build")
def build_export(body: BuildIn, x_employee_id: str | None = Header(None)) -> dict:
    require_login(x_employee_id)
    return ensure_built(body.dept, body.team)


class ScopeIn(BaseModel):
    dept: str | None = None
    team: str | None = None


class BuildManyIn(BaseModel):
    scopes: list[ScopeIn]


@router.post("/exports/build-many")
def build_many(body: BuildManyIn, x_employee_id: str | None = Header(None)) -> dict:
    """여러 범위를 한 번에 만든다 — 원본을 한 번만 읽는다.

    화면의 「전부 생성」과 「선택 생성」이 둘 다 이걸 쓴다. 예전에는 화면이
    `/exports/build`를 범위 수만큼 연달아 불렀는데, 그러면 서버에 스레드가
    그만큼 떠서 메모리가 범위 수에 곱해졌다.
    """
    require_login(x_employee_id)
    result = get_last_result()
    if result is None:
        raise HTTPException(404, "검증 결과가 없습니다. 먼저 검증을 실행하세요")
    run_at = result.get("run_at", "")

    with _lock:
        if _batch["running"]:
            raise HTTPException(409, "이미 일괄 생성이 진행 중입니다")
        # 단건 생성이 돌고 있으면 겹치지 않게 기다리게 한다
        busy = [k for k, st in _exports.items() if st.get("status") == "building"]
        if busy:
            raise HTTPException(409, "생성 중인 범위가 있습니다. 끝난 뒤에 다시 시도하세요")

    scopes: list[excel_report.Scope] = []
    seen: set[str] = set()
    for s in body.scopes:
        try:
            sc = excel_report.Scope(s.dept, s.team)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        k = _key(sc.dept, sc.team)
        if k in seen:
            continue
        seen.add(k)
        scopes.append(sc)
    if not scopes:
        raise HTTPException(400, "생성할 범위가 없습니다")

    with _lock:
        for sc in scopes:
            _exports[_key(sc.dept, sc.team)] = {
                "status": "building", "info": None, "error": None,
                "run_at": run_at, "message": "대기 중"}
        _batch.update({"running": True, "total": len(scopes), "done": 0, "failed": 0,
                       "message": "준비 중", "run_at": run_at,
                       "started_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})

    threading.Thread(target=_build_many, args=(scopes, run_at), daemon=True).start()
    logger.info("일괄 생성 시작: 범위 %d개", len(scopes))
    return {"started": len(scopes), "batch": dict(_batch)}


@router.get("/exports/download")
def download_export(
    dept: str | None = Query(None),
    team: str | None = Query(None),
    t: str | None = Query(None),
    x_employee_id: str | None = Header(None),
) -> FileResponse:
    # 결과 Excel과 같은 방식이다 — `<a download>`는 커스텀 헤더를 못 실어서
    # 표를 쓴다. 예전에는 `fetch().blob()`으로 받았는데, 파일 크기만큼
    # 브라우저 메모리를 잡고 서버가 바쁘면 «Failed to fetch»로 끝난다.
    from backend.routers.verify import check_download_ticket
    if x_employee_id:
        require_login(x_employee_id)
    elif not check_download_ticket(t):
        raise HTTPException(401, "다운로드 표가 없거나 만료되었습니다. 다시 시도하세요")
    scope = excel_report.Scope(dept, team)
    key = _key(dept, team)

    with _lock:
        st = _exports.get(key) or {}
    if st.get("status") == "building":
        raise HTTPException(409, "파일을 생성 중입니다. 잠시 후 다시 시도하세요")
    if st.get("status") == "error":
        raise HTTPException(500, f"생성 실패: {st.get('error')}")

    path = _path_for(scope)
    if not path.exists():
        raise HTTPException(404, "아직 생성되지 않았습니다. 먼저 생성을 요청하세요")

    # 결과 Excel과 같은 방식으로 보낸다 — `FileResponse`는 신버전 Starlette에서
    # Range 요청에 206으로 답하는데, 크기를 먼저 재고 나중에 파일을 열어서
    # 그 사이 파일이 갈아 끼워지면 «Too little data for declared Content-Length»로
    # 죽는다. 창구를 하나로 둔다.
    from backend.routers.verify import stream_xlsx
    return stream_xlsx(path, path.name)
