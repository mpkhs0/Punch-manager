"""WPS 선정 로직을 **기계가 읽을 수 있는 형태**로 내보낸다.

## 무엇을 위한 것인가

외부 에이전트(Copilot 등)가 raw data의 A~V(계획 정보)만 보고 «이 이음에 쓸 수
있는 WPS»를 판단하려면, 이 시스템이 가진 **판정 근거**를 넘겨받아야 한다.

## 원문을 그대로 주지 않는다 — 이게 핵심이다

WPS 목록의 두께 칸은 사람이 읽으라고 만든 자유 서식이다:

    "~E36\\n: 3~50\\n\\nEO420 (For Dissimilar)\\n:25~38\\n\\nEW420\\n:13~50"

이걸 그대로 넘기면 받는 쪽이 **다시 파싱**해야 하고, 거기서 조용히 어긋난다 —
`~E36`이 «A(AW)~E(EW)36 계열»이라는 것도, `(For Dissimilar)`가 조건이라는 것도
글자만 봐서는 알 수 없다.

그래서 **이 시스템이 이미 해석한 결과**를 내보낸다:

    원문  "~E36\\n: 3~50"
    내보냄 {"material_keys": ["E36","AH36","DH36","EH36"], "thickness": [[3.0, 50.0]]}

받는 쪽은 «표에서 찾아보기»만 하면 되고, 해석은 판정과 같은 코드가 한 번만 한다.

## 두께 자료가 없으면 «통과»다 — 반드시 명시한다

`_thickness_in_range()`는 범위가 비면 **참**을 준다(자료가 없으면 결함이 아니다).
이걸 안 적으면 받는 쪽이 «범위 없음 = 사용 불가»로 읽어 정반대로 판단한다.
그래서 `thickness: null`과 함께 `thickness_note`를 싣는다.

## 이 파일이 판정과 갈라지면 안 된다

내보내는 값은 전부 `verifier`의 상수와 함수에서 뽑는다. 여기에 값을 손으로
적으면 판정이 바뀌었을 때 이 파일만 옛말이 남는다 — 그걸로 판단한 에이전트는
«추천대로 썼는데 결함»을 만들어 낸다.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

from openpyxl.utils import get_column_letter

from .. import config
from . import verifier as V
from . import project_checks, rule_catalog, wps_overrides, wps_rules

logger = logging.getLogger(__name__)

SCHEMA = "qc-wps-selection/1"

# 에이전트가 raw data에서 읽어야 하는 열 — **A~V(계획 정보)만**이다.
# AJ(WPS)·AK(Process) 이후는 «용접 실적»이라, 추천 시점에는 아직 없다.
_INPUT_COLS: list[tuple[int, str, str, str]] = [
    (V.Col.DRAWING_NO,  "drawing_no",  "도면번호",        "text"),
    (V.Col.BLOCK,       "block",       "블록(대구분)",     "text"),
    (V.Col.LOT,         "lot",         "Lot(소구분)",      "text"),
    (V.Col.JOINT_NO,    "joint_no",    "Joint No",        "text"),
    (V.Col.REPAIR_MARK, "repair_mark", "수리 표기(RE)",    "text"),
    (V.Col.OUT_DIA,     "out_dia",     "Out Dia(관재 규격)", "text"),
    (V.Col.THICKNESS1,  "thickness1",  "두께 1",          "number"),
    (V.Col.THICKNESS2,  "thickness2",  "두께 2",          "number"),
    (V.Col.LENGTH,      "length",      "용접선 길이(mm)",  "number"),
    (V.Col.MATERIAL1,   "material1",   "재질 1",          "text"),
    (V.Col.MATERIAL2,   "material2",   "재질 2",          "text"),
    (V.Col.NDT_CAT,     "ndt_cat",     "NDT Category",    "text"),
    (V.Col.JOINT_TYPE,  "joint_type",  "이음 Type",        "text"),
    (V.Col.GROOVE,      "groove",      "Groove",          "text"),
    (V.Col.NDT_EXT_RT,  "ndt_rt",      "NDT 요구 요율 RT", "number"),
    (V.Col.NDT_EXT_UT,  "ndt_ut",      "NDT 요구 요율 UT", "number"),
    (V.Col.NDT_EXT_MT,  "ndt_mt",      "NDT 요구 요율 MT", "number"),
    (V.Col.NDT_EXT_PT,  "ndt_pt",      "NDT 요구 요율 PT", "number"),
]


def _ranges(text: str) -> list[list[float]] | None:
    """두께 범위 문자열을 숫자 구간으로. **비면 None**(= 거르지 않는다)."""
    if not (text or "").strip():
        return None
    got = V._parse_thickness_ranges(text)
    return [[lo, hi] for lo, hi in got] or None


def _keys_covered_by(base_metal: str) -> list[str]:
    """이 base_metal 문구가 덮는 **표준 재질 키**를 미리 풀어 둔다.

    받는 쪽이 문구를 패턴 매칭할 필요가 없어진다 — 판정과 같은 함수
    (`_material_covered_by_wps`)로 한 번만 계산한다.
    """
    if not (base_metal or "").strip():
        return []
    return sorted(k for k in V.MATERIAL_MAP
                  if V._material_covered_by_wps(k, base_metal))


def _wps_entry(wps_no: str, w: dict) -> dict[str, Any]:
    mats: list[dict[str, Any]] = []
    for m in (w.get("materials") or []):
        base = (m.get("base_metal") or "").strip()
        thk_text = (m.get("thk_range") or "").strip()
        covered = _keys_covered_by(base)

        # G열 셀을 «재질별 항목»으로 나눌 수 있으면 그 단위로 내보낸다.
        # 나누지 못하면(자유 서식) 셀 전체 범위를 base_metal 전체에 적용한다 —
        # 판정(`_c3_thickness_side`)이 하는 폴백과 **같은 처리**여야 한다.
        parsed = V._parse_material_thickness_entries(thk_text)
        if parsed:
            for label, rng in parsed:
                keys = sorted(k for k in V.MATERIAL_MAP
                              if V._label_matches_material(k, label))
                mats.append({
                    "label": label.strip(),
                    "material_keys": keys or covered,
                    # **원문을 함께 싣는다.** 표준 키로 해석되지 않는 재질이
                    # 있다(프로젝트마다 어휘가 다르다 — RUYA는 `S420 KL/T-40`
                    # 계열인데 공통 매핑표는 선급강·ASTM 중심이다). 그때는
                    # 받는 쪽이 이 문자열로 대조해야 한다.
                    "base_metal_raw": base,
                    "thickness": _ranges(rng),
                    "source": "labelled",
                })
        else:
            mats.append({
                "label": base[:80],
                "material_keys": covered,
                "base_metal_raw": base,
                "thickness": _ranges(thk_text),
                "thickness_raw": thk_text,
                "source": "whole_cell",
            })

    last = wps_no.replace("_", "-").split("-")[-1].strip().upper()
    proc = (w.get("process") or "").strip()
    # 프로세스 표기가 프로젝트마다 다르다 — TRION은 합성 코드(`SMFC`), RUYA는
    # 명시적 조합(`SMAW+FCAW`)을 쓴다. 받는 쪽이 표기에 걸리지 않도록
    # **기본 프로세스 집합**을 함께 싣는다. 둘은 같은 것을 가리킨다.
    proc_set = sorted(V._process_set(proc))
    return {
        "wps_no": wps_no,
        "process": proc,
        "process_set": proc_set,
        "is_mixed": len(proc_set) > 1,
        "position": (w.get("position") or "").strip(),
        "grooves": sorted(V._joint_detail_tokens(w.get("joint_detail") or "")),
        "groove_raw": (w.get("joint_detail") or "").strip(),
        "materials": mats,
        # 끝자리 — 이음 Type 규칙(Check 24·25)이 이걸 본다.
        "suffix": last,
        "is_repair": V._is_repair_wps(wps_no),
        # 'WPS 설정' 탭의 보정. **문서값보다 우선한다** — 특정 WPS×재질을 콕
        # 집은 값이라 전역 규칙보다 구체적이다. 이걸 안 실으면 받는 쪽이
        # 문서의 «빈 칸»을 그대로 «제한 없음»으로 읽는다.
        "overrides": _overrides_for(wps_no),
    }


def _overrides_for(wps_no: str) -> list[dict[str, Any]]:
    """이 WPS에 걸린 보정 행. 판정(Check 3·11·27)이 보는 것과 같은 자료다.

    WPS 요약 문서에는 재질·두께가 **빈 칸인 자리**가 있다. 두께 범위가 비면
    판정이 «통과»로 보므로(자료가 없으면 결함이 아니다), 현업이 여기에 실제
    허용범위를 적어 둔다. 그 층을 빼고 내보내면 받는 쪽은 그 WPS를
    «두께 제한 없음»으로 읽는다 — 정반대다.

    이름이 없으면 **프로젝트 번호를 뗀 이름**으로도 찾는다 — 판정
    (`wps_overrides.find_material`)이 하는 것과 같은 처리여야 한다.
    """
    table = wps_overrides.load()
    ov = table.get(wps_no)
    if not ov:
        core = wps_rules.wps_core(wps_no)
        for k, v in table.items():
            if wps_rules.wps_core(k) == core:
                ov = v
                break
    out: list[dict[str, Any]] = []
    for m in ((ov or {}).get("materials") or []):
        rng = (m.get("range") or "").strip()
        if not rng:
            continue          # 빈 범위는 «무조건 통과»라 저장 단계에서 버린다
        out.append({
            "material_key": (m.get("id") or "").strip(),
            "match": [str(x).strip() for x in (m.get("match") or [])
                      if str(x).strip()],
            "thickness": _ranges(rng),
            "thickness_raw": rng,
            "note": (m.get("note") or "").strip(),
        })
    return out


def build(wps_table: dict[str, dict] | None = None) -> dict[str, Any]:
    """내보낼 dict 하나. 파일로 쓰든 API로 주든 이 함수가 유일한 출처다."""
    if wps_table is None:
        # **활성 프로젝트의 WPS 참조 파일**을 읽는다. `QC_DATA_DIR`이 가리키는
        # 폴더의 `Raw data/*.xlsm`이라, RUYA 서버에서 돌리면 RUYA의 WPS가 된다.
        # 여기를 고정 경로로 박으면 어느 서버에서 돌려도 같은 파일이 나온다.
        loader = V.QCDataLoader()
        loader.load_wps(str(config.WPS_REF))
        wps_table = loader.wps_table

    prof = wps_rules.load()
    return {
        "schema": SCHEMA,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "project": prof.get("project") or "",
        "purpose": (
            "raw data의 계획 정보(A~V)만 보고 «이 이음에 쓸 수 있는 WPS»를 "
            "가려내기 위한 근거. 판정 엔진이 쓰는 것과 같은 제약이다."),

        # ── 0. 답의 «형태» ─────────────────────────────────────────────
        #
        # **이것이 맨 앞에 있어야 한다.** 지시가 없으면 받는 쪽이 제멋대로
        # 답한다 — 실제로 WPS 이름 대신 `AWS B6 Category` 같은 규격 분류를
        # 답하는 일이 있었다. 이 파일에 `AWS`라는 글자는 한 번도 안 나오는데,
        # «무엇을 답하라»가 없으니 자기 지식으로 메운 것이다.
        "answer_contract": {
            "return": (
                "아래 wps[] 목록의 `wps_no` 를 **그대로** 쓰되, 후보마다 "
                "«왜 남았는지»를 한 줄 붙여 목록으로 답하라. "
                "여러 개가 동시에 가능한 것이 정상이다 — 하나로 좁히지 마라. "
                "형태는 answer_example 을 보라."),
            "must_not": [
                "규격·등급·Category(AWS·ASME·선급 분류 등)를 답하지 마라. "
                "묻는 것은 «이 프로젝트에서 쓸 수 있는 WPS 이름»이다.",
                "wps[] 에 없는 이름을 지어내지 마라. 이 목록이 전부다.",
                "프로세스(FCAW·SMFC…)나 재질명으로 답하지 마라 — 그것은 "
                "WPS 를 고르는 근거이지 답이 아니다.",
            ],
            "when_many": (
                "후보가 여럿이면 **전부** 나열하라. 그 안에서 하나로 좁히는 "
                "근거는 A~V 에 없다(프로세스 배정·자세·용접사 편성이 정한다). "
                "실측으로 96%의 행이 6~9종으로 남는다."),
            "when_none": (
                "후보가 0종이면 «쓸 WPS 가 없다»가 아니라 «자료가 어긋났거나 "
                "목록이 부족하다»는 신호다. 그렇게 말하고, 무엇 때문에 전부 "
                "걸러졌는지(재질·두께·Groove) 밝혀라."),
            "with_reason": (
                "**후보마다 «왜 남았는지»를 한 줄로 함께 적어라.** 어느 재질 "
                "항목·어느 두께 구간·어느 Groove 에 맞았는지를 밝힌다. "
                "「가능하다」만 주면 현업이 그 판단을 되짚을 수 없다. "
                "형태는 answer_example 을 그대로 따르라."),
        },
        "answer_example": _answer_example(wps_table),

        # ── 1. 입력 ────────────────────────────────────────────────────
        "input_columns": [
            {"column": get_column_letter(col), "key": key,
             "name": name, "type": typ}
            for col, key, name, typ in _INPUT_COLS
        ],
        "input_note": (
            "AJ(WPS No)·AK(Process) 이후는 «용접 실적»이라 추천 시점에는 없다. "
            "A~V만으로 판단해야 한다."),

        # ── 2. 재질 표기 정규화 ────────────────────────────────────────
        "material_keys": {
            key: sorted(pats) for key, pats in V.MATERIAL_MAP.items()
        },
        "material_note": (
            "raw data의 재질 표기(M·N열)를 표준 키로 바꾼 뒤 대조한다. "
            "비교 전에 공백·하이픈·언더스코어를 모두 지운다 — "
            "'ASTM A36' · 'ASTM-A36' · 'ASTMA36'이 같은 키여야 한다. "
            "어느 키에도 안 맞으면 **재질로 거르지 않는다**(근거 없이 단정하지 "
            "않는다). 임의로 비슷한 키에 넣지 마라."),

        # ── 3. WPS 카탈로그 (해석된 제약) ──────────────────────────────
        "wps": [_wps_entry(no, w) for no, w in sorted(wps_table.items())],

        # ── 4. 판정 규칙 ───────────────────────────────────────────────
        "rules": [
            {"id": "material", "source_check": 11,
             "text": "행의 재질(M열, N열이 있으면 그것도)이 그 WPS의 "
                     "material_keys 중 하나에 들어야 한다. "
                     "**material_keys가 비어 있으면** 그 재질이 공통 매핑표에 "
                     "없다는 뜻이다(프로젝트 고유 강종). 그때는 base_metal_raw "
                     "문자열로 대조하라 — 예: 행의 'S420 KL/T-40'은 "
                     "'S420 KL/T-40 or Equiv. / Lower'에 해당한다. "
                     "'or Equiv. / Lower'는 «동등 이하 강종 포함»이라는 뜻이다. "
                     "확신이 서지 않으면 후보에서 빼지 말고 «확인 필요»로 남겨라 "
                     "— 근거 없이 거르면 쓸 수 있는 WPS를 잃는다."},
            {"id": "thickness", "source_check": 3,
             "text": "행의 두께(J열, K열이 있으면 그것도)가 «그 재질에 해당하는» "
                     "thickness 구간 중 하나에 들어야 한다. 다른 재질의 구간과 "
                     "섞어 쓰지 마라. thickness가 null이면 자료가 없다는 뜻이고 "
                     "**두께로 거르지 않는다**."},
            {"id": "groove", "source_check": 4,
             "text": "행의 Groove(R열)가 그 WPS의 grooves 목록에 있어야 한다. "
                     "목록이 비어 있으면 거르지 않는다."},
            {"id": "joint_type_tky", "source_check": 24,
             "text": "이음 Type(Q열)이 'TT'면 suffix가 'GK'로 시작해야 한다. "
                     "TT가 아니고 그 WPS의 process_set이 {SMAW, FCAW}이면 "
                     "(표기가 'SMFC'든 'SMAW+FCAW'든 같다) suffix가 'G'로 "
                     "시작해야 한다(GK도 G로 시작하므로 허용)."},
            {"id": "q01_joint_type", "source_check": 25,
             "text": "suffix가 'Q01'이면 이음 Type(Q열)이 'B'여야 한다. "
                     "Q열이 비어 있으면 거르지 않는다."},
            {"id": "repair", "source_check": 23,
             "text": "E열(RE)에 표기가 있으면 수리 시공이다. 이때는 is_repair가 "
                     "true인 WPS를 써야 한다. 반대로 E열이 비면 수리 WPS를 "
                     "권하지 마라."},
        ],

        # ── 4-1. 이 프로젝트에서만 성립하는 «별도 판정항목» (101~199) ──
        #
        # 공통 Check를 덮어쓰지 않고 **선점**한다: `when`이 맞는 자리에서는
        # 이 규칙이 판정하고, 안 맞으면 공통 Check가 그대로 돈다.
        # 빼고 내보내면 받는 쪽이 공통 두께만 보고 «되는 조합»이라고 답한다.
        "project_checks": _project_check_entries(),
        "project_checks_note": (
            "**목록 순서가 곧 의미다** — 위에서부터 먼저 맞는 것을 쓴다. "
            "좁은 조건이 앞에 있다(`KT-40`이 `KT`보다 앞). 정렬하지 마라."),

        # 어느 판정항목이 지금 켜져 있는가. **꺼 둔 항목은 플래그가 아예
        # 생기지 않는다** — 받는 쪽이 그 규칙을 «지켜야 하는 것»으로 읽으면
        # 서버보다 엄하게 답한다.
        "enabled_checks": {k: v for k, v in sorted(
            rule_catalog.enabled_map().items(), key=project_checks.sort_key)},

        # 같은 (WPS, 재질)에 여러 층이 걸릴 때의 순서. 판정과 같다.
        "precedence": [
            "1. wps[].overrides       'WPS 설정' 탭의 보정 (가장 구체적)",
            "2. project_checks[]      when이 맞으면 그 자리를 선점",
            "3. wps[].materials[]     WPS 문서에서 읽은 값",
        ],

        # ── 5. 프로젝트 고유 제약 ──────────────────────────────────────
        "project_rules": {
            "repair_prefix": wps_rules.repair_prefixes(),
            "check8": prof.get("check8") or {},
            "check9": prof.get("check9") or {},
            "groove_aliases": {k: sorted(v)
                               for k, v in wps_rules.groove_aliases().items()},
            "note": ("프로젝트마다 다른 값이다. WPS 이름 맨 앞 마디는 "
                     "«프로젝트 번호»라 비교에서 뗀다 — TR-FC-G01과 "
                     "RU-FC-G01은 같은 WPS다(세 마디 이상일 때만 뗀다)."),
        },

        # ── 6. 받는 쪽이 반드시 알아야 하는 것 ─────────────────────────
        "cautions": [
            "이 목록은 «쓸 수 있는 후보»이지 «이것을 쓰라»가 아니다. 실측으로 "
            "26종이 평균 7종까지 좁혀지고, 96%의 행이 6~9종으로 남는다. "
            "그 안에서 하나를 고르는 근거는 A~V에 없다(프로세스 배정·자세· "
            "용접사 편성이 정한다).",
            "후보가 0종이면 «쓸 WPS가 없다»가 아니라 «자료가 어긋났거나 WPS "
            "목록이 부족하다»는 신호로 읽어라. 실측 0.7%가 그 상태다.",
            "thickness가 null인 항목을 «사용 불가»로 읽지 마라. 자료가 없다는 "
            "뜻이고 판정도 통과시킨다. 다만 그 WPS는 두께로 걸러지지 않으므로 "
            "후보에 남는 것이 «검증됐다»는 뜻은 아니다.",
            "material_keys가 빈 항목은 두 가지 뜻이다 — (a) 그 WPS에 허용 재질 "
            "정보가 없거나, (b) 프로젝트 고유 강종이라 공통 매핑표에 없다. "
            "둘을 base_metal_raw 로 구분하라: 비어 있으면 (a), 값이 있으면 (b)다. "
            "(b)이면 문자열로 대조해야 한다.",
            "이 프로젝트(RUYA)는 재질 어휘가 S420/S355 KL/T 계열이라 공통 매핑표 "
            "(선급강·ASTM 중심)와 겹치지 않는 것이 많다. 판정 엔진의 Check 3·11도 "
            "같은 이유로 그 재질을 «판단하지 않고 넘긴다» — 후보에 남아 있다고 "
            "재질이 검증된 것은 아니다.",
        ],
    }


def _answer_example(wps_table: dict[str, dict]) -> dict[str, Any] | None:
    """실제 목록으로 «이렇게 답하라»를 하나 만들어 보인다.

    지시문만으로는 부족했다 — 받는 쪽(Copilot)이 WPS 이름 대신 규격·Category
    같은 것을 답하는 일이 실제로 있었다. **정답 한 벌을 보여 주는 것**이
    설명 열 줄보다 낫다.

    거르는 데 쓰는 것은 **판정 함수 그대로**다. 여기서 다시 구현하면 예시와
    실제 판정이 갈라져, 예시를 믿은 쪽이 틀린 답을 하게 된다.

    **예시를 못 만들면 조용히 뺀다.** 이건 곁들이는 것이라, 여기서 예외가
    나서 내보내기 전체가 멈추면 안 된다.
    """
    try:
        loader = V.QCDataLoader()
        loader.wps_table = wps_table
        chk = V.QCChecker(loader)
        chk._enabled, chk._rules, chk._rule_problems = {}, [], []

        # 실제 목록에서 «가장 흔한» 조건을 하나 고른다 — 지어내지 않는다.
        pick = next((w for n, w in sorted(wps_table.items())
                     if not V._is_repair_wps(n) and (w.get("materials") or [])), None)
        if pick is None:
            return None
        m = (pick.get("materials") or [])[0]
        cell = (m.get("base_metal") or "").replace("\n", " ").strip()
        # 한 칸에 재질이 여럿 적혀 있다. raw data 의 M열은 **하나**이므로
        # 가장 짧은(= 가장 깔끔한) 이름 하나를 골라 실제 행처럼 만든다.
        material = min((t.strip() for t in cell.split(",") if t.strip()),
                       key=len, default="")
        rng = V._parse_thickness_ranges(m.get("thk_range") or "")
        if not material or not rng:
            return None
        thk = round((rng[0][0] + rng[0][1]) / 2, 1)
        groove = next(iter(sorted(
            V._joint_detail_tokens(pick.get("joint_detail") or ""))), "")

        row = [None] * 80
        for col, val in ((V.Col.MATERIAL1, material), (V.Col.THICKNESS1, thk),
                         (V.Col.GROOVE, groove), (V.Col.JOINT_TYPE, "T")):
            row[col - 1] = val
        row_t = tuple(row)

        ok: list[str] = []
        for no in sorted(wps_table):
            prc = (wps_table[no].get("process") or "")
            if any(f is not None for f in (
                    chk._c11_material_not_allowed(row_t, no, False),
                    chk._c3_thickness(row_t, no),
                    chk._c4_groove(row_t, no, False),
                    chk._c24_tky_wps(row_t, no, prc),
                    chk._c25_q01_joint_type(row_t, no),
                    chk._c27_dissimilar_grade(row_t, no))):
                continue
            ok.append({"wps_no": no,
                       "why": _why(wps_table[no], material, thk, groove)})
        if not ok:
            return None
        return {
            "input": {"M(재질1)": material, "J(두께1)": thk,
                      "R(Groove)": groove, "Q(이음 Type)": "T"},
            "answer": {"usable_wps": ok, "count": len(ok)},
        }
    except Exception:                        # noqa: BLE001 - 곁들이는 것이다
        logger.warning("답변 예시를 만들지 못했다", exc_info=True)
        return None


def _why(w: dict, material: str, thk: float, groove: str) -> str:
    """이 WPS 가 후보에 남은 이유를 한 줄로. **사실만 적는다.**

    「가능하다」만 주면 현업이 그 판단을 되짚을 수 없다. 무엇에 맞아서
    남았는지(재질 항목·두께 구간·Groove)를 함께 줘야 검토가 된다.
    """
    bits: list[str] = []
    for m in (w.get("materials") or []):
        rngs = V._parse_thickness_ranges(m.get("thk_range") or "")
        hit = next((r for r in rngs if r[0] <= thk <= r[1]), None)
        if hit:
            label = (m.get("base_metal") or "").replace("\n", " ").strip()
            bits.append(f"두께 {hit[0]:g}~{hit[1]:g}mm 구간에 {thk:g} 포함"
                        + (f" (재질 항목 '{label[:34]}')" if label else ""))
            break
    else:
        bits.append("두께 자료가 없어 두께로 거르지 않음")
    toks = V._joint_detail_tokens(w.get("joint_detail") or "")
    bits.append(f"Groove '{groove}' 허용" if groove.upper() in toks
                else "Groove 목록이 없어 거르지 않음")
    prc = (w.get("process") or "").strip()
    if prc:
        bits.append(f"프로세스 {prc}")
    return " · ".join(bits)


def _project_check_entries() -> list[dict[str, Any]]:
    """프로젝트 판정규칙(101~199)을 받는 쪽이 읽을 수 있는 형태로.

    이 규칙들은 «두께 허용범위»를 프로젝트 합의로 정한 것이라, 공통 Check 3의
    문서값을 **선점**한다. 위반일 때만 선점하는 것이 아니라 **`when`이 맞으면
    그 자리를 통째로** 가져간다 — 안 그러면 범위 «안»인 행이 문서값 판정으로
    흘러가 없던 결함이 새로 생긴다.

    깨진 규칙(`_rule_problems`)은 싣지 않는다. 판정도 그것을 쓰지 않는다.
    """
    rules, _problems = project_checks.parse(rule_catalog.active_checks())
    out: list[dict[str, Any]] = []
    for r in rules:
        out.append({
            "check_no": r.no,
            "name": r.name,
            "kind": r.kind,
            # 어떤 (재질, WPS)에 걸리는가 — 부분일치다
            "when": {
                "material_contains": list(r.when.get("material_contains") or []),
                "wps_contains": list(r.when.get("wps_contains") or []),
            },
            "param": dict(r.param),
            "scope": r.scope,
            "summary": r.summary,
            "logic": r.logic,
            "preempts": r.overrides,
        })
    return out


def write(path: str | Path) -> Path:
    """파일로 쓴다. 확장자는 `.json`."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(build(), ensure_ascii=False, indent=2),
                 encoding="utf-8")
    logger.info("WPS 선정 로직 내보냄: %s", p)
    return p
