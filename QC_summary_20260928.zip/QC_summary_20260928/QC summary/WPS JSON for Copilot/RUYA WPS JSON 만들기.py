"""RUYA 프로젝트의 WPS 선정 로직을 JSON으로 내보낸다.

**반드시 RUYA 데이터 폴더를 가리켜서 실행해야 한다.**
그러지 않으면 TRION의 WPS 목록으로 만들어지는데, 파일 이름은 RUYA라서
받는 쪽이 알아챌 방법이 없다.

사용법 (저장소 루트에서):

    RUYA 서버 기준으로 만들기
      set QC_DATA_DIR=c:\QC data\RUYA
      python "WPS JSON for Copilot\RUYA WPS JSON 만들기.py"

    PowerShell 이면
      $env:QC_DATA_DIR = "c:\QC data\RUYA"
      python "WPS JSON for Copilot\RUYA WPS JSON 만들기.py"
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

OUT = Path(__file__).resolve().parent / "RUYA WPS JSON.json"


def main() -> int:
    data_dir = os.environ.get("QC_DATA_DIR", "")
    print(f"QC_DATA_DIR = {data_dir or '(미지정 — 저장소의 data/ 를 씁니다)'}")

    from backend import config
    from backend.services import wps_export, wps_rules

    print(f"WPS 참조 파일 = {config.WPS_REF}")
    if not Path(config.WPS_REF).exists():
        print("\n[중단] WPS 참조 파일을 찾지 못했습니다.")
        print("       RUYA 데이터 폴더의 'Raw data' 안에 .xlsm 이 있어야 합니다.")
        return 1

    project = (wps_rules.load().get("project") or "").strip()
    print(f"활성 프로파일 = {project or '(이름 없음)'}")

    # **프로젝트 확인.** RUYA 파일을 만든다면서 TRION 기준으로 돌면
    # 조용히 틀린 파일이 나간다 — 이름만 봐서는 알 수 없다.
    if "RUYA" not in project.upper() and "--force" not in sys.argv:
        print("\n[경고] 활성 프로파일이 RUYA 가 아닙니다.")
        print("       QC_DATA_DIR 을 'c:\\QC data\\RUYA' 로 지정하고 다시 실행하거나,")
        print("       그래도 이대로 만들려면 아래에 y 를 입력하십시오.")
        # 비대화식(배치·파이프)으로 돌면 물어볼 수 없다. 그때는 **만들지 않는다** —
        # 확인 없이 만들면 TRION 기준 파일이 'RUYA'라는 이름으로 나간다.
        try:
            ans = input("       계속할까요? [y/N] ").strip().lower()
        except EOFError:
            print("\n       (확인을 받을 수 없어 중단합니다. --force 를 주면 그대로 만듭니다)")
            return 1
        if ans != "y":
            print("       중단했습니다.")
            return 1

    data = wps_export.build()
    n_wps = len(data.get("wps") or [])
    if not n_wps:
        print("\n[중단] WPS 를 한 건도 읽지 못했습니다. 참조 파일을 확인하십시오.")
        return 1

    import json
    OUT.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    kb = OUT.stat().st_size / 1024
    print(f"\n생성 완료 : {OUT}")
    print(f"  프로젝트 {data.get('project') or '(이름 없음)'} · WPS {n_wps}종 · {kb:.1f} KB")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
