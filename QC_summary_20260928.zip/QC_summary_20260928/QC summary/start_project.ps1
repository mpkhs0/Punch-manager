﻿#
# 프로젝트 서버 하나를 띄운다. 코드는 한 벌이고 **데이터 폴더와 포트만** 다르다.
#
#   .\start_project.ps1 -Project TRION -Port 8001
#   .\start_project.ps1 -Project RUYA  -Port 8002 -DataDir "D:\QC data\RUYA"
#
# **-DataDir을 주지 않으면 `data\projects.json`에서 찾는다** — 그 파일이
# 정본이다. `start_all.ps1`이 같은 파일을 읽으므로, 여기서 다른 규칙을 쓰면
# **같은 프로젝트가 실행 방법에 따라 다른 폴더를 물게 된다.** 오류도 경고도
# 나지 않고 «그동안의 결과가 전부 사라졌다»로만 보인다.
#
#   start_TRION.bat  ->  c:\QC data\TRION      <- 예전의 이 자리 기본값
#   start_all.bat    ->  c:\QC summary\data    <- projects.json의 data_dir=""
#
# 목록에 없는 프로젝트만 `..\QC data\<Project>`로 떨어진다(새 프로젝트를
# 목록에 넣기 전에 한번 띄워 보는 경우). 저장소 **밖**에 두는 이유: 저장소
# 안에 두면 git이 사내 데이터를 추적할 위험이 생기고, 저장소를 통째로
# 복사·이동할 때 남의 프로젝트 데이터가 따라다닌다.
#
param(
    [Parameter(Mandatory = $true)][string]$Project,
    [Parameter(Mandatory = $true)][int]$Port,
    [string]$DataDir = ""
)

Set-Location $PSScriptRoot

# ── 데이터 폴더를 정한다 ─────────────────────────────────────────────────────
# -DataDir을 직접 준 경우가 가장 세다. 안 줬으면 projects.json에서 찾는다.
# **포트로 먼저 찾는다** — 이름은 화면 표시용이라 바뀔 수 있지만 포트는 그
# 서버를 가리키는 주소다(`project_servers.validate()`가 둘 다 유일하게 막는다).
$fromList = $false
if (-not $PSBoundParameters.ContainsKey('DataDir')) {
    $listFile = Join-Path $PSScriptRoot "data\projects.json"
    if (Test-Path $listFile) {
        try {
            $list = (Get-Content $listFile -Raw -Encoding UTF8 | ConvertFrom-Json).projects
            $hit = @($list | Where-Object { [int]$_.port -eq $Port })
            if ($hit.Count -eq 0) {
                $hit = @($list | Where-Object { $_.name -eq $Project })
            }
            if ($hit.Count -gt 0) {
                $DataDir = if ($hit[0].PSObject.Properties.Name -contains 'data_dir') {
                    [string]$hit[0].data_dir
                } else { "" }
                $fromList = $true
            }
        } catch {
            # 목록을 못 읽어도 서버는 떠야 한다. 아래 기본값으로 떨어진다.
            Write-Host "  * data\projects.json을 읽지 못했습니다: $_" -ForegroundColor Yellow
        }
    }
    # 목록에 없는 프로젝트만 예전 기본값으로 간다.
    if (-not $fromList) {
        $DataDir = Join-Path (Split-Path $PSScriptRoot -Parent) "QC data\$Project"
    }
}

# 빈 값은 «저장소 안의 data\를 쓴다»는 뜻이다(폴더를 나누기 전의 설치).
# 여기서 새 폴더를 만들어 버리면 «그동안의 결과가 사라졌다»가 되는데,
# 실제로는 빈 폴더를 새로 보고 있을 뿐이라 원인을 찾기 어렵다.
$useRepoData = [string]::IsNullOrWhiteSpace($DataDir)
$rootDir     = if ($useRepoData) { $PSScriptRoot } else { $DataDir }

if (-not $useRepoData) {
    # 없으면 만든다. **처음 띄우는 프로젝트는 빈 폴더가 정상이다** — 검증 결과도
    # 판정 규칙도 아직 없고, 파일을 올리면서 채워진다.
    if (-not (Test-Path $DataDir)) {
        New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
        Write-Host "데이터 폴더를 새로 만들었습니다: $DataDir" -ForegroundColor Yellow
    }
}

$rawDir = Join-Path $rootDir "Raw data"
if (-not (Test-Path $rawDir)) { New-Item -ItemType Directory -Force -Path $rawDir | Out-Null }

# WPS 참조 파일이 없으면 **켜지긴 하는데 검증이 안 된다.** 그 사실을 여기서
# 말해 주지 않으면 파일을 올리고 검증을 눌러 본 뒤에야 알게 된다.
$wps = @(Get-ChildItem -Path $rawDir -Filter *.xlsm -ErrorAction SilentlyContinue)
if ($wps.Count -eq 0) {
    Write-Host ""
    Write-Host "  * WPS 참조 파일(.xlsm)이 없습니다." -ForegroundColor Yellow
    Write-Host "    이 폴더에 넣어 주세요: $rawDir" -ForegroundColor Yellow
    Write-Host "    (data\wps_cache.json이 있으면 없이도 검증됩니다)" -ForegroundColor DarkGray
}

# 예전 설치는 저장소 안(`.\data`)에 결과를 두고 돌았다. 새 폴더가 비어 있는데
# 저장소 쪽에 결과 DB가 남아 있으면 **«그동안의 검증 결과가 전부 사라졌다»로 보인다**
# — 실제로는 옮기지 않았을 뿐이다. 여기서 말해 주지 않으면 원인을 찾기 어렵다.
# 저장소 안을 쓰는 설치는 해당 없다(옮길 것이 없다).
if (-not $useRepoData) {
    $oldDb = Join-Path $PSScriptRoot "data\qc.db"
    $newDb = Join-Path $DataDir "data\qc.db"
    if ((Test-Path $oldDb) -and -not (Test-Path $newDb)) {
        Write-Host ""
        Write-Host "  * 저장소 안에 예전 데이터가 남아 있습니다." -ForegroundColor Yellow
        Write-Host "    이 서버는 새 폴더($DataDir)를 쓰므로 빈 상태로 시작합니다." -ForegroundColor Yellow
        Write-Host "    옛 결과를 그대로 쓰려면 아래를 새 폴더로 옮기세요:" -ForegroundColor Yellow
        Write-Host "      data\  qc_uploads\  qc_results\  'Raw data'\" -ForegroundColor DarkGray
        Write-Host "      (data\employees.json 과 data\outlook_settings.json 은 공용이라 그대로 둡니다)" -ForegroundColor DarkGray
        Write-Host ""
    }
}

$localIp = (Get-NetIPAddress -AddressFamily IPv4 |
    Where-Object { $_.IPAddress -notlike '169.254.*' -and $_.IPAddress -ne '127.0.0.1' } |
    Select-Object -First 1 -ExpandProperty IPAddress)

# 어디서 정해진 값인지 함께 적는다. 두 실행 방법이 다른 폴더를 물던 시절에는
# 화면에 폴더만 나와서 «왜 이 폴더인가»를 알 방법이 없었다.
$origin = if ($PSBoundParameters.ContainsKey('DataDir')) { "명령줄" }
          elseif ($fromList)                             { "data\projects.json" }
          else                                           { "기본값(목록에 없음)" }

Write-Host ""
Write-Host "  프로젝트     : $Project" -ForegroundColor Cyan
Write-Host ("  데이터 폴더  : {0}   [{1}]" -f `
            $(if ($useRepoData) { "$PSScriptRoot  (저장소 안)" } else { $DataDir }), $origin)
Write-Host "  내 PC        : http://localhost:$Port"
Write-Host ("  같은 네트워크: http://{0}:{1}" -f $localIp, $Port)
Write-Host ""
Write-Host "  * 새로 뜨는 'QC Server' 창을 닫으면 이 프로젝트 서버가 종료됩니다." -ForegroundColor Yellow
Write-Host "    (지금 이 창은 잠시 후 자동으로 닫히는 게 정상입니다)" -ForegroundColor Yellow
Write-Host ""

# 환경변수는 **자식 프로세스에만** 넘긴다. 이 창의 $env:를 바꾸면 같은 창에서
# 다른 프로젝트를 띄울 때 앞의 값이 남아, 두 서버가 한 폴더를 물게 된다.
#
# **저장소 안을 쓸 때는 QC_DATA_DIR을 아예 넘기지 않는다** — `config.py`가
# 빈 값이 아니라 «없음»을 보고 BASE로 떨어지고, `start_all.ps1`도 같게 한다.
if ($useRepoData) {
    $cmd = "`$env:QC_PROJECT='$Project'; " +
           "cd '$PSScriptRoot'; " +
           "py -3 -m uvicorn backend.main:app --host 0.0.0.0 --port $Port"
} else {
    $cmd = "`$env:QC_DATA_DIR='$DataDir'; `$env:QC_PROJECT='$Project'; " +
           "cd '$PSScriptRoot'; " +
           "py -3 -m uvicorn backend.main:app --host 0.0.0.0 --port $Port"
}
Start-Process powershell -ArgumentList @("-NoExit", "-NoProfile", "-Command", $cmd)

Start-Sleep -Seconds 3
Start-Process "http://localhost:$Port"
