"""
RUYA Painting Report Review Engine — Python Server
=====================================================
기능: PDF 문서 관리, 사진 저장/분석, 엑셀 스탬프 내보내기, AI 분석 프록시
실행: python server.py  또는  start.bat 더블클릭
"""
import os, sys, json, hashlib, datetime, base64, io, glob, re, traceback
from pathlib import Path
from flask import Flask, request, jsonify, send_file, send_from_directory
from flask_cors import CORS

# ── 경로 설정 ─────────────────────────────────────────────────────
BASE_DIR   = Path(__file__).parent
CACHE_DIR  = BASE_DIR / 'cache'
PHOTOS_DIR = BASE_DIR / 'photos'
STAMPS_DIR = BASE_DIR / 'stamps'
EXPORT_DIR = BASE_DIR / 'exports'
DOCS_DIR   = BASE_DIR / 'docs'
STATIC_DIR = BASE_DIR / 'static'
CONFIG_PATH = BASE_DIR / 'config.json'

for d in [CACHE_DIR, PHOTOS_DIR, STAMPS_DIR, EXPORT_DIR,
          DOCS_DIR/'spec', DOCS_DIR/'procedure', DOCS_DIR/'standard', STATIC_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ── Flask 앱 ──────────────────────────────────────────────────────
app = Flask(__name__, static_folder=str(STATIC_DIR))
CORS(app, resources={r"/api/*": {
    "origins": "*",
    "methods": ["GET","POST","OPTIONS"],
    "allow_headers": ["Content-Type","Accept"]
}})

# 파일 업로드 최대 크기: 50MB (기본값 없음 → ERR_CONTENT_LENGTH_MISMATCH 방지)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB

KST = datetime.timezone(datetime.timedelta(hours=9))

def _now_kst():
    return datetime.datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S')

def _load_config():
    if CONFIG_PATH.exists():
        return json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
    return {}

def _save_config(cfg):
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding='utf-8')


# ══════════════════════════════════════════════════════════════════
#  1. 서버 상태
# ══════════════════════════════════════════════════════════════════
@app.route('/')
def index():
    """RUYA HTML 앱 서빙"""
    return send_from_directory(str(STATIC_DIR), 'index.html')

@app.route('/api/status')
def status():
    cfg = _load_config()
    docs_count = sum(1 for _ in DOCS_DIR.rglob('*.pdf'))
    cached = sum(1 for _ in CACHE_DIR.glob('*.txt'))
    photos = sum(1 for _ in PHOTOS_DIR.rglob('*') if _.is_file())
    return jsonify({
        'status': 'ok',
        'version': 'RUYA Server 1.0',
        'time_kst': _now_kst(),
        'api_key_set': bool(cfg.get('anthropic_key')),
        'docs_count': docs_count,
        'cached_docs': cached,
        'photos_count': photos,
    })


# ══════════════════════════════════════════════════════════════════
#  2. 설정 (API 키)
# ══════════════════════════════════════════════════════════════════
@app.route('/api/config', methods=['GET','POST'])
def config():
    cfg = _load_config()
    if request.method == 'POST':
        data = request.json or {}
        if 'anthropic_key' in data:
            cfg['anthropic_key'] = data['anthropic_key']
        _save_config(cfg)
        return jsonify({'status':'saved'})
    safe = dict(cfg)
    if 'anthropic_key' in safe:
        k = safe['anthropic_key']
        safe['anthropic_key'] = k[:12]+'...' if len(k)>12 else '***'
    return jsonify(safe)


# ══════════════════════════════════════════════════════════════════
#  3. PDF 문서 관리 (스펙/절차서/스탠다드)
# ══════════════════════════════════════════════════════════════════
@app.route('/api/docs', methods=['GET'])
def list_docs():
    """카테고리별 등록된 문서 목록"""
    result = {}
    for cat in ['spec','procedure','standard']:
        cat_dir = DOCS_DIR / cat
        files = []
        for f in sorted(cat_dir.glob('*.pdf')):
            cache_file = CACHE_DIR / (f.stem + '.txt')
            files.append({
                'name': f.name,
                'size': f.stat().st_size,
                'cached': cache_file.exists(),
                'cached_chars': len(cache_file.read_text(encoding='utf-8')) if cache_file.exists() else 0,
            })
        result[cat] = files
    return jsonify(result)

@app.route('/api/docs/upload', methods=['POST'])
def upload_doc():
    """PDF 업로드 → 텍스트 추출 → 캐시 저장"""
    import pdfplumber
    cat = request.form.get('category', 'spec')
    if cat not in ('spec','procedure','standard'):
        return jsonify({'error':'Invalid category'}), 400
    file = request.files.get('file')
    if not file or not file.filename.endswith('.pdf'):
        return jsonify({'error':'PDF file required'}), 400

    # 저장
    cat_dir = DOCS_DIR / cat
    save_path = cat_dir / file.filename
    file.save(str(save_path))

    # 텍스트 추출 + 캐시
    text = ''
    try:
        with pdfplumber.open(str(save_path)) as pdf:
            for page in pdf.pages:
                t = page.extract_text()
                if t: text += t + '\n'
    except Exception as e:
        return jsonify({'error': f'PDF 추출 실패: {e}'}), 500

    cache_file = CACHE_DIR / (save_path.stem + '.txt')
    cache_file.write_text(text, encoding='utf-8')

    return jsonify({
        'status': 'ok',
        'filename': file.filename,
        'category': cat,
        'pages': len(text.split('\n\n')),
        'chars': len(text),
        'cached': True,
    })

@app.route('/api/docs/text', methods=['GET'])
def get_doc_text():
    """캐시된 텍스트 반환 (파일명으로 조회)"""
    name = request.args.get('name','')
    stem = name.replace('.pdf','')
    cache_file = CACHE_DIR / (stem + '.txt')
    if cache_file.exists():
        return jsonify({'text': cache_file.read_text(encoding='utf-8'), 'cached':True})
    # 캐시 없으면 PDF 직접 읽기
    for cat in ['spec','procedure','standard']:
        pdf_path = DOCS_DIR / cat / name
        if pdf_path.exists():
            import pdfplumber
            text = ''
            with pdfplumber.open(str(pdf_path)) as pdf:
                for page in pdf.pages:
                    t = page.extract_text()
                    if t: text += t + '\n'
            cache_file.write_text(text, encoding='utf-8')
            return jsonify({'text':text, 'cached':False})
    return jsonify({'error':'Document not found'}), 404

@app.route('/api/docs/all-text', methods=['GET'])
def get_all_doc_texts():
    """AI 기준검토용 — 모든 카테고리 문서 텍스트 합산 반환 (토큰 제한 적용)"""
    max_chars = int(request.args.get('max_chars', 30000))
    result = {}
    total = 0
    for cat in ['spec','procedure','standard']:
        cat_texts = []
        for f in sorted((DOCS_DIR/cat).glob('*.pdf')):
            cache = CACHE_DIR / (f.stem+'.txt')
            if cache.exists():
                t = cache.read_text(encoding='utf-8')
            else:
                continue
            remain = max_chars - total
            if remain <= 0: break
            chunk = t[:remain]
            cat_texts.append({'name':f.name, 'text':chunk, 'truncated':len(t)>len(chunk)})
            total += len(chunk)
        result[cat] = cat_texts
    return jsonify(result)

@app.route('/api/docs/delete', methods=['POST'])
def delete_doc():
    data = request.json or {}
    name = data.get('name','')
    for cat in ['spec','procedure','standard']:
        path = DOCS_DIR / cat / name
        if path.exists():
            path.unlink()
            cache = CACHE_DIR / (path.stem+'.txt')
            if cache.exists(): cache.unlink()
            return jsonify({'status':'deleted','name':name})
    return jsonify({'error':'Not found'}), 404


# ══════════════════════════════════════════════════════════════════
#  4. 사진 저장 & 관리
# ══════════════════════════════════════════════════════════════════
@app.route('/api/photos/upload', methods=['POST'])
def upload_photo():
    """레포트 사진 저장"""
    report_no = request.form.get('report_no', 'unknown')
    safe_name = re.sub(r'[^\w\-]', '_', report_no)
    report_dir = PHOTOS_DIR / safe_name
    report_dir.mkdir(exist_ok=True)

    saved = []
    for key in request.files:
        f = request.files[key]
        if f.filename:
            path = report_dir / f.filename
            f.save(str(path))
            saved.append({'name':f.filename, 'size':path.stat().st_size, 'path':str(path)})

    return jsonify({'status':'ok', 'report_no':report_no, 'saved':saved, 'count':len(saved)})

@app.route('/api/photos/list')
def list_photos():
    """레포트별 사진 목록"""
    report_no = request.args.get('report_no','')
    if report_no:
        safe = re.sub(r'[^\w\-]', '_', report_no)
        d = PHOTOS_DIR / safe
        if d.exists():
            files = [{'name':f.name,'size':f.stat().st_size} for f in d.iterdir() if f.is_file()]
            return jsonify({'report_no':report_no, 'photos':files})
        return jsonify({'report_no':report_no, 'photos':[]})
    # 전체
    result = {}
    for d in PHOTOS_DIR.iterdir():
        if d.is_dir():
            result[d.name] = [f.name for f in d.iterdir() if f.is_file()]
    return jsonify(result)

@app.route('/api/photos/get/<report_no>/<filename>')
def get_photo(report_no, filename):
    safe = re.sub(r'[^\w\-]', '_', report_no)
    path = PHOTOS_DIR / safe / filename
    if path.exists():
        return send_file(str(path))
    return jsonify({'error':'Not found'}), 404


# ══════════════════════════════════════════════════════════════════
#  5. 사진 분석 (Claude Vision API)
# ══════════════════════════════════════════════════════════════════
@app.route('/api/photos/analyze', methods=['POST'])
def analyze_photo():
    """사진 화질 판정 + 기본 검사 코멘트"""
    import requests as req

    cfg = _load_config()
    api_key = cfg.get('anthropic_key','')
    if not api_key:
        return jsonify({'error':'API 키 미설정'}), 400

    # Base64 이미지 또는 파일
    if 'file' in request.files:
        f = request.files['file']
        img_data = base64.b64encode(f.read()).decode('utf-8')
        media_type = f.content_type or 'image/jpeg'
    elif request.json and 'image_base64' in request.json:
        img_data = request.json['image_base64']
        media_type = request.json.get('media_type', 'image/jpeg')
    else:
        return jsonify({'error':'No image provided'}), 400

    context = request.form.get('context', request.json.get('context','') if request.json else '')

    prompt = (
        '당신은 해양/플랜트 도장 검사 사진 분석 전문가입니다.\n'
        '이 사진을 분석해서 아래 항목을 JSON으로 답변하세요:\n'
        '1. image_quality: "GOOD" / "POOR" / "UNUSABLE"\n'
        '2. quality_issues: 화질 문제 설명 (흐림, 어두움, 초점불량 등)\n'
        '3. improvement_comment: 사진 개선 코멘트 (POOR/UNUSABLE일 때)\n'
        '4. visible_defects: 육안으로 보이는 도장 결함 목록 (있다면)\n'
        '5. surface_condition: 표면 상태 평가 (판정 가능한 경우만)\n'
        '6. confidence: 판정 신뢰도 (HIGH/MEDIUM/LOW)\n\n'
        f'추가 맥락: {context}\n\n'
        '반드시 순수 JSON만 응답하세요.'
    )

    try:
        resp = req.post('https://api.anthropic.com/v1/messages', headers={
            'Content-Type': 'application/json',
            'x-api-key': api_key,
            'anthropic-version': '2023-06-01',
        }, json={
            'model': 'claude-haiku-4-5-20251001',
            'max_tokens': 1024,
            'messages': [{
                'role': 'user',
                'content': [
                    {'type':'image','source':{'type':'base64','media_type':media_type,'data':img_data}},
                    {'type':'text','text': prompt}
                ]
            }]
        }, timeout=60)

        if resp.status_code != 200:
            return jsonify({'error':f'API {resp.status_code}: {resp.text[:200]}'}), resp.status_code

        result = resp.json()
        answer = result['content'][0]['text']

        # JSON 파싱
        clean = answer.strip()
        if clean.startswith('```'): clean = re.sub(r'^```json?\s*','',clean); clean = re.sub(r'```\s*$','',clean).strip()
        try:
            parsed = json.loads(clean)
        except:
            parsed = {'raw': answer}

        return jsonify({'status':'ok', 'analysis': parsed, 'raw': answer})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ══════════════════════════════════════════════════════════════════
#  6. 엑셀 스탬프 내보내기
# ══════════════════════════════════════════════════════════════════
@app.route('/api/upload/template', methods=['POST'])
def upload_template():
    """원본 템플릿 파일을 서버에 미리 업로드 (대용량 파일 분리 처리)"""
    report_no = request.form.get('report_no', 'template')
    safe = re.sub(r'[^\w\-]', '_', report_no)
    if 'file' not in request.files:
        return jsonify({'error': 'file required'}), 400
    f = request.files['file']
    save_path = EXPORT_DIR / f'{safe}_orig.xlsx'
    # 청크 단위로 저장
    chunks = []
    while True:
        chunk = f.read(65536)
        if not chunk: break
        chunks.append(chunk)
    save_path.write_bytes(b''.join(chunks))
    return jsonify({'status': 'ok', 'path': str(save_path), 'size': save_path.stat().st_size})


@app.route('/api/export/xlsx', methods=['POST'])
def export_xlsx():
    """엑셀 스탬프 내보내기
    우선순위: uploaded_path(미리 업로드된 파일) > 직접 전송 파일 > base64
    """
    from stamp_generator import export_xlsx_with_stamps

    # 파라미터 파싱
    if request.content_type and 'multipart' in request.content_type:
        code         = int(request.form.get('code', 1))
        report_no    = request.form.get('report_no', 'UNKNOWN')
        timestamp    = request.form.get('timestamp', _now_kst())
        ai_code_raw  = request.form.get('ai_code', '')
        ai_code      = int(ai_code_raw) if ai_code_raw and ai_code_raw.strip() else None
        uploaded_path= request.form.get('uploaded_path', '')
        try: comments = json.loads(request.form.get('comments', '[]'))
        except: comments = []
    else:
        data         = request.json or {}
        code         = int(data.get('code', 1))
        report_no    = data.get('report_no', 'UNKNOWN')
        timestamp    = data.get('timestamp', _now_kst())
        ai_code      = data.get('ai_code') or None
        if ai_code: ai_code = int(ai_code)
        comments     = data.get('comments', [])
        uploaded_path= data.get('uploaded_path', '')

    import re as _re
    safe        = _re.sub(r'[^\w\-]', '_', report_no)
    output_name = f'{safe}_stamped.xlsx'
    output_path = EXPORT_DIR / output_name
    logo_path   = STATIC_DIR / 'logo.png'
    tmp_in      = None

    # 원본 파일 확보 (우선순위 순)
    if uploaded_path and Path(uploaded_path).exists():
        # 1순위: 미리 업로드된 파일 경로 (ERR_CONTENT_LENGTH_MISMATCH 방지)
        tmp_in = Path(uploaded_path)
        print(f'[export] 미리업로드 파일 사용: {tmp_in.stat().st_size:,}bytes')

    elif 'template' in request.files:
        # 2순위: 직접 전송 파일
        f_obj = request.files['template']
        chunks = []
        while True:
            chunk = f_obj.read(65536)
            if not chunk: break
            chunks.append(chunk)
        data_bytes = b''.join(chunks)
        tmp_path = EXPORT_DIR / f'{safe}_template_orig.xlsx'
        tmp_path.write_bytes(data_bytes)
        tmp_in = tmp_path
        print(f'[export] 직접전송 파일: {len(data_bytes):,}bytes')

    elif request.content_type and 'json' in request.content_type:
        # 3순위: base64
        b64 = (request.json or {}).get('template_base64','')
        if b64:
            tmp_path = EXPORT_DIR / f'{safe}_template_orig.xlsx'
            tmp_path.write_bytes(base64.b64decode(b64))
            tmp_in = tmp_path

    if not tmp_in:
        return jsonify({'error': 'template required: use /api/upload/template first'}), 400

    try:
        export_xlsx_with_stamps(
            template_path=str(tmp_in),
            output_path=str(output_path),
            code=code, report_no=report_no,
            comments=comments, ai_code=ai_code,
            logo_path=str(logo_path) if logo_path.exists() else None,
            timestamp=timestamp,
        )
        # 파일을 응답으로 직접 안 보냄 — GET /api/download/<filename> 으로 분리
        # (ERR_CONTENT_LENGTH_MISMATCH 완전 방지)
        return jsonify({
            'status': 'ok',
            'filename': output_name,
            'size': output_path.stat().st_size
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500
    finally:
        # 임시 파일 정리 (미리업로드된 파일은 유지)
        try:
            if tmp_in and str(tmp_in) != str(uploaded_path) and Path(str(tmp_in)).exists():
                tmp_in.unlink()
        except: pass


@app.route('/api/download/<filename>')
def download_file(filename):
    """생성된 파일 GET 방식 직접 다운로드 (fetch 불필요, ERR_CONTENT_LENGTH_MISMATCH 방지)"""
    import re as _re2
    safe_name = _re2.sub(r'[^\w\-\.]', '_', filename)
    file_path = EXPORT_DIR / safe_name
    if not file_path.exists():
        return jsonify({'error': 'File not found'}), 404
    with open(str(file_path), 'rb') as f:
        file_bytes = f.read()
    from flask import Response as FlaskResponse
    resp = FlaskResponse(
        file_bytes,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    resp.headers['Content-Disposition'] = f'attachment; filename="{safe_name}"'
    resp.headers['Content-Length'] = str(len(file_bytes))
    resp.headers['Cache-Control'] = 'no-cache'
    return resp


# ══════════════════════════════════════════════════════════════════
#  7. AI 분석 프록시 (CORS 우회 + 스트리밍)
# ══════════════════════════════════════════════════════════════════
@app.route('/api/ai/analyze', methods=['POST'])
def ai_analyze():
    """Anthropic API 프록시 — CORS 이슈 없이 호출"""
    import requests as req

    cfg = _load_config()
    api_key = request.json.get('api_key') or cfg.get('anthropic_key','')
    if not api_key:
        return jsonify({'error':'API 키 미설정'}), 400

    body = request.json.get('body', {})
    body.setdefault('model', 'claude-haiku-4-5-20251001')
    body.setdefault('max_tokens', 4096)

    # 문서 텍스트 자동 첨부 (요청 시)
    if request.json.get('include_docs'):
        doc_texts = []
        for cat in ['spec','procedure','standard']:
            for f in (DOCS_DIR/cat).glob('*.pdf'):
                cache = CACHE_DIR / (f.stem+'.txt')
                if cache.exists():
                    doc_texts.append(f'[{cat}: {f.name}]\n' + cache.read_text(encoding='utf-8')[:10000])
        if doc_texts and body.get('messages'):
            doc_section = '\n\n'.join(doc_texts)[:30000]
            body['messages'][-1]['content'] += f'\n\n[참조 문서]\n{doc_section}'

    try:
        resp = req.post('https://api.anthropic.com/v1/messages', headers={
            'Content-Type': 'application/json',
            'x-api-key': api_key,
            'anthropic-version': '2023-06-01',
        }, json=body, timeout=120)

        return jsonify(resp.json()), resp.status_code

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai/stream', methods=['POST'])
def ai_stream():
    """Anthropic 스트리밍 프록시"""
    import requests as req
    from flask import Response, stream_with_context

    cfg = _load_config()
    api_key = request.json.get('api_key') or cfg.get('anthropic_key','')
    if not api_key:
        return jsonify({'error':'API 키 미설정'}), 400

    body = request.json.get('body', {})
    body['stream'] = True
    body.setdefault('model', 'claude-haiku-4-5-20251001')
    body.setdefault('max_tokens', 4096)

    def generate():
        try:
            resp = req.post('https://api.anthropic.com/v1/messages', headers={
                'Content-Type': 'application/json',
                'x-api-key': api_key,
                'anthropic-version': '2023-06-01',
            }, json=body, stream=True, timeout=120)
            for chunk in resp.iter_content(chunk_size=None):
                yield chunk
        except Exception as e:
            yield f'data: {{"type":"error","error":"{str(e)}"}}\n\n'.encode()

    return Response(stream_with_context(generate()),
                    content_type='text/event-stream',
                    headers={'Cache-Control':'no-cache','X-Accel-Buffering':'no'})


# ══════════════════════════════════════════════════════════════════
#  8. 리비전 추적 (RPA)
# ══════════════════════════════════════════════════════════════════
@app.route('/api/revision/compare', methods=['POST'])
def revision_compare():
    """두 레포트(rev00 vs rev01) 비교 — 변경된 항목 추적"""
    data = request.json or {}
    old_data = data.get('old', {})  # rev00 검증 결과
    new_data = data.get('new', {})  # rev01 검증 결과

    changes = []
    all_keys = set(list(old_data.keys()) + list(new_data.keys()))

    for key in sorted(all_keys):
        old_val = old_data.get(key)
        new_val = new_data.get(key)
        if old_val != new_val:
            changes.append({
                'field': key,
                'old': old_val,
                'new': new_val,
                'status': 'added' if old_val is None else ('removed' if new_val is None else 'modified')
            })

    return jsonify({
        'total_fields': len(all_keys),
        'changed': len(changes),
        'unchanged': len(all_keys) - len(changes),
        'changes': changes,
    })


# ══════════════════════════════════════════════════════════════════
#  9. 로고 업로드
# ══════════════════════════════════════════════════════════════════
@app.route('/api/logo/upload', methods=['POST'])
def upload_logo():
    f = request.files.get('file')
    if not f:
        return jsonify({'error':'No file'}), 400
    path = STATIC_DIR / 'logo.png'
    # PNG 변환
    from PIL import Image as PILImage
    img = PILImage.open(f.stream).convert('RGBA')
    img.save(str(path), 'PNG')
    return jsonify({'status':'ok', 'path':str(path), 'size':path.stat().st_size})


# ══════════════════════════════════════════════════════════════════
#  메인
# ══════════════════════════════════════════════════════════════════

# ══ 메일 동기화 API ══
# ──────────────────────────────────────────────────────────────────
# server.py에 추가할 메일 동기화 API 엔드포인트
# (server.py 파일 끝에 붙여넣기)
# ──────────────────────────────────────────────────────────────────

import threading
_mail_thread  = None
_mail_running = False

@app.route('/api/mail/status')
def mail_status():
    """메일 동기화 현황 조회"""
    try:
        sys.path.insert(0, str(BASE_DIR))
        from mail_sync import get_status
        st = get_status()
        st['running'] = _mail_running
        return jsonify(st)
    except Exception as e:
        return jsonify({'error': str(e), 'running': _mail_running})

@app.route('/api/mail/start', methods=['POST'])
def mail_start():
    """메일 동기화 스케줄러 시작"""
    global _mail_thread, _mail_running
    if _mail_running:
        return jsonify({'status': 'already_running'})
    try:
        sys.path.insert(0, str(BASE_DIR))
        import mail_sync
        mail_sync._stop_flag = False
        _mail_running = True
        _mail_thread = threading.Thread(target=mail_sync.run_scheduler, daemon=True)
        _mail_thread.start()
        return jsonify({'status': 'started'})
    except Exception as e:
        _mail_running = False
        return jsonify({'error': str(e)}), 500

@app.route('/api/mail/stop', methods=['POST'])
def mail_stop():
    """메일 동기화 스케줄러 중지"""
    global _mail_running
    try:
        sys.path.insert(0, str(BASE_DIR))
        import mail_sync
        mail_sync._stop_flag = True
        _mail_running = False
        return jsonify({'status': 'stopped'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mail/sync_now', methods=['POST'])
def mail_sync_now():
    """즉시 1회 동기화 실행 (테스트용)"""
    try:
        sys.path.insert(0, str(BASE_DIR))
        from mail_sync import sync_once
        new_c, skip_c = sync_once()
        return jsonify({'status':'ok', 'new': new_c, 'skipped': skip_c})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mail/processed', methods=['GET', 'DELETE'])
def mail_processed():
    """처리 완료 목록 조회 / 초기화"""
    from mail_sync import PROCESSED_PATH, load_processed, save_processed
    if request.method == 'DELETE':
        save_processed(set())
        return jsonify({'status': 'cleared'})
    ids = load_processed()
    return jsonify({'count': len(ids), 'ids': list(ids)[-20:]})  # 최근 20개만


if __name__ == '__main__':
    import traceback as _tb
    # 시작 오류를 server.log에 기록
    _log = Path(__file__).parent / 'server.log'
    try:
        _log.write_text('', encoding='utf-8')  # 초기화
    except: pass
    class _TeeWriter:
        def __init__(self, f, orig):
            self._f = f; self._o = orig
        def write(self, s):
            self._o.write(s)
            try: self._f.write(s); self._f.flush()
            except: pass
        def flush(self): self._o.flush()
    try:
        _lf = open(str(_log), 'w', encoding='utf-8', errors='replace')
        sys.stdout = _TeeWriter(_lf, sys.__stdout__)
        sys.stderr = _TeeWriter(_lf, sys.__stderr__)
    except: pass
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    print(f"""
╔══════════════════════════════════════════════════════╗
║     RUYA Painting Report Review Engine Server        ║
║     v1.0 — Python + Flask                            ║
╠══════════════════════════════════════════════════════╣
║  http://localhost:{port}                               ║
║  API 상태: http://localhost:{port}/api/status            ║
╠══════════════════════════════════════════════════════╣
║  📁 docs/spec/       → 도장 스펙 PDF                  ║
║  📁 docs/procedure/  → 절차서 PDF                     ║
║  📁 docs/standard/   → 산업 스탠다드 PDF               ║
║  📁 photos/          → 레포트 사진                     ║
║  📁 static/logo.png  → 회사 로고                      ║
╚══════════════════════════════════════════════════════╝
    """)
    app.run(host='0.0.0.0', port=port, debug=False)
