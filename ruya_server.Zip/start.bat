@echo off
cd /d "%~dp0"
title RUYA Server

rem Check Python
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo Python not found. Install from python.org
    pause
    exit /b 1
)

rem Install packages if needed
if not exist ".installed" (
    echo Installing packages...
    pip install flask flask-cors pdfplumber openpyxl Pillow requests numpy pywin32 schedule
    if %ERRORLEVEL% NEQ 0 ( echo Install failed. & pause & exit /b 1 )
    echo done > .installed
    echo Packages installed OK.
)

rem Start mail sync in separate window
if exist "start_mail.bat" (
    start "RUYA Mail Sync" start_mail.bat
)

rem Start server
echo Starting server at http://localhost:8765
python server.py

echo Server stopped.
pause
