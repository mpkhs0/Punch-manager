# RUYA Painting Report Review Engine — Python Server

## 빠른 시작

1. `start.bat` 더블클릭 (최초 실행 시 자동 패키지 설치)
2. 브라우저에서 RUYA HTML 앱 실행
3. 설정 탭에서 서버 주소 `http://localhost:8765` 확인

## 폴더 구조

```
RUYA_Server/
├── server.py           ← 메인 서버 (Flask)
├── stamp_generator.py  ← 엑셀 스탬프 생성 모듈
├── start.bat           ← 실행 파일
├── requirements.txt    ← Python 패키지 목록
├── config.json         ← 설정 (API 키)
│
├── docs/               ← PDF 문서 (자동 캐싱)
│   ├── spec/           ← 도장 스펙 (COR-350 등)
│   ├── procedure/      ← 절차서
│   └── standard/       ← 산업 스탠다드 (ISO 12944 등)
│
├── cache/              ← PDF 텍스트 캐시 (자동 생성)
├── photos/             ← 레포트별 사진 저장
├── stamps/             ← 스탬프 이미지 (자동 생성)
├── exports/            ← 엑셀 내보내기 파일
└── static/
    └── logo.png        ← 회사 로고 (스탬프에 사용)
```

## API 엔드포인트

| 기능 | Method | URL |
|------|--------|-----|
| 서버 상태 | GET | `/api/status` |
| 설정 | GET/POST | `/api/config` |
| 문서 목록 | GET | `/api/docs` |
| 문서 업로드 | POST | `/api/docs/upload` |
| 문서 텍스트 | GET | `/api/docs/text?name=XXX` |
| 전체 문서 텍스트 | GET | `/api/docs/all-text` |
| 사진 업로드 | POST | `/api/photos/upload` |
| 사진 목록 | GET | `/api/photos/list` |
| 사진 분석 (AI) | POST | `/api/photos/analyze` |
| 엑셀 스탬프 내보내기 | POST | `/api/export/xlsx` |
| AI 분석 프록시 | POST | `/api/ai/analyze` |
| AI 스트리밍 | POST | `/api/ai/stream` |
| 리비전 비교 | POST | `/api/revision/compare` |
| 로고 업로드 | POST | `/api/logo/upload` |

## 최초 설정

1. `static/` 폴더에 `logo.png` (회사 로고) 넣기
2. `docs/spec/` 폴더에 도장 스펙 PDF 넣기
3. `config.json`에 Anthropic API 키 입력 또는 HTML 앱 설정에서 입력

## 요구사항

- Python 3.9+
- Windows / macOS / Linux
