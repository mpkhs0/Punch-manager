"""RUYA Stamp Generator — Excel 스탬프 이미지 생성 모듈"""
from PIL import Image, ImageDraw, ImageFont
import datetime, os, io

KST = datetime.timezone(datetime.timedelta(hours=9))

CODE_CFG = {
    1: {'bar':(0,140,50),  'label':'CODE 1','desc':'APPROVED'},
    2: {'bar':(15,70,160), 'label':'CODE 2','desc':'APPROVED WITH COMMENTS'},
    3: {'bar':(180,80,0),  'label':'CODE 3','desc':'DOCUMENT REVISION REQUIRED'},
    4: {'bar':(180,20,20), 'label':'CODE 4','desc':'RE-WORK REQUIRED'},
}

def _get_font(bold=False, size=14):
    paths = [
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        'C:/Windows/Fonts/arialbd.ttf' if bold else 'C:/Windows/Fonts/arial.ttf',
        'C:/Windows/Fonts/malgunbd.ttf' if bold else 'C:/Windows/Fonts/malgun.ttf',
    ]
    for p in paths:
        if os.path.exists(p):
            try: return ImageFont.truetype(p, size)
            except: pass
    return ImageFont.load_default()

def _load_logo(logo_path, target_w=120, target_h=120):
    if not (logo_path and os.path.exists(logo_path)):
        return None
    try:
        img = Image.open(logo_path).convert('RGBA')
        try:
            # numpy 방식 (설치된 경우)
            import numpy as np
            arr = np.array(img)
            r,g,b = arr[:,:,0], arr[:,:,1], arr[:,:,2]
            a = arr[:,:,3] if arr.shape[2]==4 else None
            bright = (r>200)&(g>200)&(b>200)
            dark   = (r<40) &(g<40) &(b<40)
            if a is not None:
                arr[bright|dark, 3] = 0
            result = Image.fromarray(arr, 'RGBA')
        except ImportError:
            # numpy 없을 때 — PIL만으로 배경 제거
            result = img
        white = Image.new('RGBA', result.size, (255,255,255,255))
        white.paste(result, mask=result.split()[3])
        return white.convert('RGB').resize((target_w, target_h), Image.LANCZOS)
    except Exception as e:
        print(f'로고 로드 실패: {e}')
        return None

def create_stamp(code, report_no, timestamp=None, is_ai=False, logo_path=None):
    cfg = CODE_CFG.get(code, CODE_CFG[1])
    W, H = 1340, 280
    img = Image.new('RGB', (W, H), (255,255,255))
    draw = ImageDraw.Draw(img)

    f28 = _get_font(True, 28)
    f20 = _get_font(True, 20)
    f17 = _get_font(True, 17)
    f15 = _get_font(False, 15)
    f13 = _get_font(False, 13)
    f11 = _get_font(False, 11)
    f10 = _get_font(False, 10)

    if timestamp is None:
        timestamp = datetime.datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S')
    dt = datetime.datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S') if isinstance(timestamp, str) else timestamp

    bar_color = (200,160,0) if is_ai else cfg['bar']
    draw.rectangle([0,0,W,10], fill=bar_color)
    draw.rectangle([0,H-8,W,H], fill=bar_color)
    draw.rectangle([0,0,W-1,H-1], outline=bar_color, width=3)

    # 좌측 로고
    LOGO_W = 340
    LOGO_SIZE = 120
    lx, ly = 18, (H-LOGO_SIZE)//2
    logo = _load_logo(logo_path, LOGO_SIZE, LOGO_SIZE)
    if logo:
        img.paste(logo, (lx, ly))

    tx = lx + LOGO_SIZE + 18
    ty = ly + 8
    draw.text((tx, ty),    'HYUNDAI',           fill=(20,55,155), font=f20)
    draw.text((tx, ty+26), 'HEAVY INDUSTRIES',  fill=(20,55,155), font=f15)

    label_text = 'by AI Analysis' if is_ai else 'by Automation'
    label_fg   = (150,110,0) if is_ai else (40,40,40)
    label_bg   = (255,248,210) if is_ai else (240,245,252)
    label_bd   = (210,170,0) if is_ai else (175,200,225)
    bb = draw.textbbox((0,0), label_text, font=f17)
    lw = bb[2]-bb[0]+22
    bx, by = tx, ty+54
    draw.rectangle([bx,by,bx+lw,by+28], fill=label_bg, outline=label_bd, width=1)
    draw.text((bx+11,by+6), label_text, fill=label_fg, font=f17)

    draw.text((16, H-24), 'Reviewed by HD Report Review Engine.', fill=(160,172,185), font=f10)
    draw.line([(LOGO_W,16),(LOGO_W,H-16)], fill=(215,222,230), width=1)

    # 중앙 CODE 원형
    CX = LOGO_W + 270
    ox, oy, r = CX, H//2+5, 115
    draw.ellipse([ox-r,oy-r,ox+r,oy+r], fill=cfg['bar'])
    draw.ellipse([ox-r+9,oy-r+9,ox+r-9,oy+r-9], outline=(255,255,255), width=2)
    draw.text((ox,oy-26), cfg['label'], fill=(255,255,255), font=f28, anchor='mm')
    words = cfg['desc'].split(); lines=[]; line=''
    for w in words:
        t = (line+' '+w).strip()
        bb2 = draw.textbbox((0,0), t, font=f13)
        if bb2[2]-bb2[0] > r*1.75: lines.append(line); line=w
        else: line=t
    if line: lines.append(line)
    for i, dl in enumerate(lines):
        draw.text((ox, oy+10+i*17), dl, fill=(255,255,220), font=f13, anchor='mm')

    # 우측 정보
    RX = LOGO_W + 558
    draw.line([(RX-8,16),(RX-8,H-16)], fill=(215,222,230), width=1)
    rows = [
        ('REPORT NO',  report_no,              f17, f15),
        ('DATE',       dt.strftime('%Y-%m-%d'), f13, f15),
        ('TIME (KST)', dt.strftime('%H:%M:%S'), f13, f15),
    ]
    iy = 28
    for lbl, val, lf, vf in rows:
        draw.text((RX+14, iy),    lbl, fill=(140,158,175), font=f11)
        draw.text((RX+14, iy+15), val, fill=(20,40,85),    font=vf)
        iy += 68

    wm = f"RUYA Engine Auto-Generated  |  {dt.strftime('%Y-%m-%d %H:%M:%S')} KST  |  {'AI-Assisted' if is_ai else 'RPA'} Digital Stamp"
    draw.text((W//2, H-14), wm, fill=(190,200,210), font=f10, anchor='mm')

    return img


def export_xlsx_with_stamps(template_path, output_path, code, report_no,
                            comments=None, ai_code=None, logo_path=None, timestamp=None):
    from openpyxl import load_workbook
    from openpyxl.styles import Font as XFont, PatternFill, Alignment, Border, Side
    from openpyxl.drawing.image import Image as XLImage

    if timestamp is None:
        timestamp = datetime.datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S')

    # data_only=True: 수식 캐시 보존 (openpyxl이 저장 시 캐시 지우는 문제 방지)
    # 회신 파일에서 M66(Pull-off 기준) 등 수식 셀이 빈칸으로 보이는 문제 해결
    wb = load_workbook(template_path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    side = Side(style='thin', color='1A3A1A' if code<=2 else '3A1A0A')
    row = 87

    # 코멘트 블록
    if comments and code in (2,3,4):
        bg_map = {2:'0B1A05', 3:'1A0B00', 4:'1A0000'}
        fg_map = {2:'88D050', 3:'FF9040', 4:'FF5050'}
        icon = '\U0001F4CB' if code==2 else '\u26A0'
        ws.row_dimensions[row].height = 14
        ws.merge_cells(f'B{row}:S{row}')
        ws[f'B{row}'] = f'  {icon}  INSPECTION COMMENTS  \u2014  {len(comments)} item(s)'
        ws[f'B{row}'].fill = PatternFill('solid', start_color=bg_map.get(code,'1A1A1A'))
        ws[f'B{row}'].font = XFont(color=fg_map.get(code,'FFFFFF'), bold=True, size=9, name='Arial')
        ws[f'B{row}'].alignment = Alignment(horizontal='left', vertical='center')
        ws[f'B{row}'].border = Border(left=side,right=side,top=side,bottom=side)
        row += 1
        for cmt in comments:
            ws.row_dimensions[row].height = 26
            ws.merge_cells(f'B{row}:S{row}')
            ws[f'B{row}'] = f'    \u2022  {cmt}'
            ws[f'B{row}'].fill = PatternFill('solid', start_color='060E03' if code==2 else '120700')
            ws[f'B{row}'].font = XFont(color='A8D870' if code==2 else 'F0A060', size=9, name='Arial')
            ws[f'B{row}'].alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
            ws[f'B{row}'].border = Border(left=side,right=side,top=side,bottom=side)
            row += 1

    # RPA 스탬프
    stamps_dir = os.path.join(os.path.dirname(output_path) or '.', '..', 'stamps')
    os.makedirs(stamps_dir, exist_ok=True)

    for is_ai, c in [(False, code)] + ([(True, ai_code)] if ai_code else []):
        stamp = create_stamp(c, report_no, timestamp, is_ai=is_ai, logo_path=logo_path)
        path = os.path.join(stamps_dir, f'stamp_{row}.png')
        stamp.save(path, dpi=(150,150))
        xl = XLImage(path)
        xl.anchor = f'B{row}'
        xl.width = 790; xl.height = 148
        ws.add_image(xl)
        ws.row_dimensions[row].height = 112
        row += 1

    wb.save(output_path)
    return output_path
