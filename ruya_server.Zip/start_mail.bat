@echo off
cd /d "%~dp0"
title RUYA Mail Sync - Outlook
color 0A
echo.
echo  ====================================
echo  RUYA Mail Sync - Outlook
echo  ====================================
echo.
echo  [INFO] Starting Outlook mail automation
echo  [INFO] Interval: every 30 minutes
echo  [INFO] Filter: subject contains "Painting report"
echo  [INFO] Press Ctrl+C to stop
echo.

python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  [ERROR] Python not found. Run start.bat first.
    pause
    exit /b 1
)

python -c "import win32com.client" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  [INSTALL] Installing pywin32...
    pip install pywin32
    if %ERRORLEVEL% NEQ 0 (
        echo  [ERROR] pywin32 install failed.
        pause
        exit /b 1
    )
    echo.
)

if not exist "mail_sync.py" (
    echo  [ERROR] mail_sync.py not found.
    pause
    exit /b 1
)

echo  [START] Running mail sync...
echo  ----------------------------------------
python mail_sync.py

echo.
echo  [STOP] Mail sync stopped.
pause
