"""
RUYA Mail Sync — Outlook 자동 메일 처리기
=========================================
- 30분마다 Outlook 받은 편지함 조회
- "RUYA-PAINT-REPORT" 제목 (대소문자 무관) 메일 중 48시간 이내 수신 건
- xlsx 첨부파일 → RPA + AI 자동 처리 → 스탬프 찍어 회신
- processed_mails.json 으로 중복 처리 방지

실행: python mail_sync.py
      (start.bat 또는 서버와 함께 자동 실행)
"""
import os, sys, json, time, datetime, re, shutil, traceback
from pathlib import Path

# ── 경로 설정 ─────────────────────────────────────────────────────
BASE_DIR    = Path(__file__).parent
LOG_PATH    = BASE_DIR / 'mail_sync.log'
PROCESSED_PATH = BASE_DIR / 'processed_mails.json'
INBOX_TEMP  = BASE_DIR / 'exports' / '_mail_temp'
CONFIG_PATH = BASE_DIR / 'config.json'
DOCS_DIR    = BASE_DIR / 'docs'

INBOX_TEMP.mkdir(parents=True, exist_ok=True)

# ── 로깅 ─────────────────────────────────────────────────────────
def log(msg, level='INFO'):
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f'[{ts}] [{level}] {msg}'
    print(line)
    try:
        with open(LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except:
        pass

# ── 처리 완료 목록 관리 ──────────────────────────────────────────
def load_processed():
    try:
        if PROCESSED_PATH.exists():
            return set(json.loads(PROCESSED_PATH.read_text(encoding='utf-8')))
    except:
        pass
    return set()

def save_processed(ids):
    try:
        PROCESSED_PATH.write_text(
            json.dumps(list(ids), ensure_ascii=False, indent=2),
            encoding='utf-8'
        )
    except Exception as e:
        log(f'처리목록 저장 실패: {e}', 'WARN')

# ── Config 로드 ──────────────────────────────────────────────────
def load_config():
    try:
        if CONFIG_PATH.exists():
            return json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
    except:
        pass
    return {}

# ── 스펙/절차서 텍스트 로드 ─────────────────────────────────────
def load_doc_texts():
    spec_text = ''
    proc_text = ''
    # cache 디렉토리의 txt 파일들 확인
    cache_dir = BASE_DIR / 'cache'
    for txt_file in cache_dir.glob('*.txt'):
        content = txt_file.read_text(encoding='utf-8', errors='replace')
        if 'spec' in txt_file.name.lower():
            spec_text = content
        elif 'proc' in txt_file.name.lower():
            proc_text = content
    # docs 디렉토리 직접 확인
    spec_dir = DOCS_DIR / 'spec'
    proc_dir = DOCS_DIR / 'procedure'
    for f in spec_dir.glob('*.txt'):
        spec_text += f.read_text(encoding='utf-8', errors='replace')
    for f in proc_dir.glob('*.txt'):
        proc_text += f.read_text(encoding='utf-8', errors='replace')
    return spec_text, proc_text

# ── 회신 메일 본문 생성 ──────────────────────────────────────────
def build_reply_body(summary):
    code_colors = {1:'✅', 2:'💬', 3:'🔧', 4:'🚨'}
    icon = code_colors.get(summary['final_code'], '📋')

    lines = [
        '안녕하세요,',
        '',
        'RUYA 도장 검사 자동화 시스템에서 레포트 검토 결과를 회신드립니다.',
        '',
        '━' * 50,
        f'📋 레포트 번호  : {summary["report_no"]}',
        f'🏗  도장 시스템  : {summary["paint_sys"]}',
        f'🏢 벤더          : {summary["vendor"]}',
        '━' * 50,
        f'🔍 RPA 자동 판정 : CODE {summary["rpa_code"]}',
        f'🤖 AI 종합 판정  : CODE {summary["ai_code"]}',
        f'{icon} 최종 판정      : {summary["code_label"]}',
        '━' * 50,
    ]

    if summary['fail_count'] > 0:
        lines.append('')
        lines.append(f'⚠ 불합격 항목 ({summary["fail_count"]}건):')
        for i, f in enumerate(summary['fails'][:6], 1):
            lines.append(f'  {i}. [{f["sec"]}] {f["lbl"]}')
            lines.append(f'     실측: {f["val"]}  |  기준: {f["ac"]}')
            if f['msg']:
                lines.append(f'     사유: {f["msg"]}')
    else:
        lines.append('')
        lines.append('✅ 전 항목 기준 충족 — 불합격 사항 없음')

    if summary.get('ai_summary'):
        lines.append('')
        lines.append('[ AI 종합 평가 ]')
        lines.append(summary['ai_summary'])

    if summary.get('ai_recommendation'):
        lines.append('')
        lines.append('[ 권고 사항 ]')
        lines.append(summary['ai_recommendation'])

    lines.extend([
        '',
        '━' * 50,
        '첨부 파일: 스탬프 적용 엑셀 파일을 확인하시기 바랍니다.',
        '',
        '본 검토는 RUYA 도장 검사 자동화 시스템(RPA+AI)에 의해 자동 생성되었습니다.',
        '검토 결과에 이의가 있으시면 담당 검사원에게 문의하시기 바랍니다.',
        '',
        'RUYA 공사 도장 검사팀',
    ])

    return '\r\n'.join(lines)

# ── 메일 1건 처리 ─────────────────────────────────────────────────
def process_mail(mail, processed_ids):
    """Outlook 메일 아이템 1건 처리"""
    try:
        mail_id   = mail.EntryID
        subject   = mail.Subject or ''
        sender    = mail.SenderEmailAddress or ''
        recv_time = mail.ReceivedTime

        log(f'처리 시작: "{subject}" from {sender}')

        # 중복 체크
        if mail_id in processed_ids:
            log(f'  이미 처리됨 — 건너뜀')
            return False

        # 첨부파일 중 xlsx 찾기
        xlsx_files = []
        attachments = mail.Attachments
        for i in range(1, attachments.Count + 1):
            att = attachments.Item(i)
            fname = att.FileName or ''
            if fname.lower().endswith('.xlsx') or fname.lower().endswith('.xlsm'):
                save_path = INBOX_TEMP / fname
                att.SaveAsFile(str(save_path))
                xlsx_files.append(save_path)
                log(f'  첨부파일 저장: {fname}')

        if not xlsx_files:
            log(f'  xlsx 첨부파일 없음 — 건너뜀')
            processed_ids.add(mail_id)  # 재시도 안 함
            return False

        # Config 로드
        cfg = load_config()
        api_key = cfg.get('anthropic_key', '')
        spec_text, proc_text = load_doc_texts()

        if not api_key:
            log('  API 키 없음 — RPA 판정만 실행', 'WARN')

        # 각 xlsx 처리
        results = []
        for xlsx_path in xlsx_files:
            try:
                # report_processor 동적 임포트 (같은 디렉토리)
                sys.path.insert(0, str(BASE_DIR))
                from report_processor import process_report

                summary = process_report(
                    xlsx_path=str(xlsx_path),
                    api_key=api_key,
                    spec_text=spec_text,
                    proc_text=proc_text,
                    base_dir=str(BASE_DIR),
                )
                results.append(summary)
                log(f'  처리 완료: CODE {summary["final_code"]} ({summary["report_no"]})')
            except Exception as e:
                log(f'  레포트 처리 오류 ({xlsx_path.name}): {e}', 'ERROR')
                traceback.print_exc()

        if not results:
            log('  처리된 결과 없음', 'WARN')
            return False

        # 회신 작성 (첫 번째 결과 기준)
        summary    = results[0]
        body       = build_reply_body(summary)
        reply_mail = mail.Reply()
        reply_mail.Body = body

        # 스탬프 엑셀 첨부
        for r in results:
            if r.get('stamped_path') and Path(r['stamped_path']).exists():
                reply_mail.Attachments.Add(r['stamped_path'])
                log(f'  첨부: {Path(r["stamped_path"]).name}')

        # 발송
        reply_mail.Send()
        log(f'  회신 발송 완료 → {sender}')

        # 처리 완료 표시
        processed_ids.add(mail_id)
        save_processed(processed_ids)

        # 임시 파일 정리
        for xlsx_path in xlsx_files:
            try:
                xlsx_path.unlink()
            except:
                pass

        return True

    except Exception as e:
        log(f'  메일 처리 오류: {e}', 'ERROR')
        traceback.print_exc()
        return False

# ── 메인 동기화 함수 ─────────────────────────────────────────────
def sync_once():
    """Outlook 동기화 1회 실행"""
    try:
        import win32com.client
        import pythoncom
        pythoncom.CoInitialize()
    except ImportError:
        log('win32com 미설치. pip install pywin32 실행 필요', 'ERROR')
        return 0, 0

    log('=== 메일 동기화 시작 ===')
    processed = load_processed()
    new_count  = 0
    skip_count = 0

    try:
        outlook = win32com.client.Dispatch('Outlook.Application')
        ns      = outlook.GetNamespace('MAPI')
        inbox   = ns.GetDefaultFolder(6)  # olFolderInbox = 6

        # 48시간 이전 기준 시각 (Outlook 필터 형식)
        cutoff = datetime.datetime.now() - datetime.timedelta(hours=48)
        cutoff_str = cutoff.strftime('%m/%d/%Y %H:%M %p')

        # 필터: 제목에 "RUYA-PAINT-REPORT" 포함 + 48시간 이내 (대소문자 무관)
        filter_str = (
            f"@SQL=(\"urn:schemas:httpmail:subject\" LIKE '%RUYA-PAINT-REPORT%' OR "
            f"\"urn:schemas:httpmail:subject\" LIKE '%ruya-paint-report%') AND "
            f"\"urn:schemas:httpmail:datereceived\" >= '{cutoff_str}'"
        )

        try:
            items = inbox.Items.Restrict(filter_str)
        except Exception:
            # 필터 실패 시 전체 조회 후 Python에서 필터링
            log('Outlook 필터 미지원 — 전체 조회 후 Python 필터 적용', 'WARN')
            items = inbox.Items
            items = [
                m for m in items
                if hasattr(m, 'Subject')
                and 'ruya-paint-report' in str(m.Subject or '').lower()
                and hasattr(m, 'ReceivedTime')
                and (datetime.datetime.now() - m.ReceivedTime.replace(tzinfo=None)
                     ).total_seconds() <= 48 * 3600
            ]

        log(f'대상 메일: {len(items) if hasattr(items,"Count") else len(list(items))}건')

        mail_list = list(items) if not hasattr(items, 'Count') else [items.Item(i) for i in range(1, items.Count+1)]

        for mail in mail_list:
            if not hasattr(mail, 'Subject'):
                continue
            subj = str(mail.Subject or '').lower()
            if 'ruya-paint-report' not in subj:
                continue

            mail_id = mail.EntryID
            if mail_id in processed:
                skip_count += 1
                continue

            ok = process_mail(mail, processed)
            if ok:
                new_count += 1

    except Exception as e:
        log(f'동기화 오류: {e}', 'ERROR')
        traceback.print_exc()
    finally:
        try:
            import pythoncom
            pythoncom.CoUninitialize()
        except:
            pass

    log(f'=== 동기화 완료: 처리 {new_count}건 / 건너뜀 {skip_count}건 ===')
    return new_count, skip_count


# ── 30분 스케줄러 ─────────────────────────────────────────────────
SYNC_INTERVAL_MIN = 30
_stop_flag = False

def run_scheduler():
    """30분마다 sync_once() 실행"""
    global _stop_flag
    log(f'메일 동기화 스케줄러 시작 (주기: {SYNC_INTERVAL_MIN}분)')
    log(f'  대상 폴더: 받은 편지함')
    log(f'  조회 범위: 최근 48시간 / 제목: "RUYA-PAINT-REPORT" (대소문자 무관)')
    log(f'  중복 방지: processed_mails.json')

    # 시작 즉시 1회 실행
    sync_once()

    while not _stop_flag:
        # 30분 대기 (10초 단위로 체크 → 빠른 종료 가능)
        for _ in range(SYNC_INTERVAL_MIN * 6):
            if _stop_flag:
                break
            time.sleep(10)
        if not _stop_flag:
            sync_once()

    log('스케줄러 종료')


# ── Flask 연동용 함수 (server.py에서 호출) ─────────────────────
def get_status():
    """현재 처리 현황 반환"""
    processed = load_processed()
    log_lines = []
    try:
        if LOG_PATH.exists():
            lines = LOG_PATH.read_text(encoding='utf-8').splitlines()
            log_lines = lines[-50:]  # 최근 50줄
    except:
        pass
    return {
        'processed_count': len(processed),
        'interval_min': SYNC_INTERVAL_MIN,
        'log_tail': log_lines,
    }


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--once', action='store_true', help='1회만 실행')
    args = parser.parse_args()

    if args.once:
        sync_once()
    else:
        run_scheduler()
