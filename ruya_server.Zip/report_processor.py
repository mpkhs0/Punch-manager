"""
RUYA Report Processor v2 — JS parseXL/buildVR 완전 이식
JS 원본 기준으로 정확히 재작성 (셀 위치/판정 로직 동일)
"""
import re, json, datetime, requests
from pathlib import Path
from openpyxl import load_workbook

KST = datetime.timezone(datetime.timedelta(hours=9))

# ── 시스템 프리셋 (JS SYSTEM_PRESETS와 동일) ─────────────────────
SYSTEM_PRESETS = {
    'T02C': dict(sys='T02C', std='SD-NOC-COR-350', sa='Sa 3', salt=30, salti=20,
                 dust=2, rh=85, dew=3, adh=6.0, adhm='ISO 16276-1', cond=150, mp=80,
                 coats=[dict(name='1st Coat',ndft=75,mp=80,row=45),
                        dict(name='2nd Coat',ndft=125,mp=80,row=47),
                        dict(name='3rd Coat',ndft=125,mp=80,row=49),
                        dict(name='4th Coat',ndft=50,mp=80,row=51)]),
    'T02J': dict(sys='T02J', std='SD-NOC-COR-350', sa='Sa 3', salt=30, salti=20,
                 dust=2, rh=85, dew=3, adh=6.0, adhm='ISO 16276-1', cond=150, mp=80,
                 coats=[dict(name='1st Coat',ndft=75,mp=80,row=45),
                        dict(name='2nd Coat',ndft=125,mp=80,row=47),
                        dict(name='3rd Coat',ndft=125,mp=80,row=49),
                        dict(name='4th Coat',ndft=50,mp=80,row=51)]),
    'T02H': dict(sys='T02H', std='SD-NOC-COR-350', sa='Sa 3', salt=30, salti=20,
                 dust=2, rh=85, dew=3, adh=6.0, adhm='ISO 16276-1', cond=150, mp=80,
                 coats=[dict(name='1st Coat',ndft=80,mp=80,row=45),
                        dict(name='2nd Coat',ndft=80,mp=80,row=47),
                        dict(name='Final Coat',ndft=90,mp=80,row=49)]),
    'T03':  dict(sys='T03',  std='SD-NOC-COR-350', sa='Sa 3', salt=20, salti=10,
                 dust=2, rh=85, dew=3, adh=5.0, adhm='ISO 16276-1', cond=150, mp=80,
                 coats=[dict(name='1st Coat',ndft=100,mp=80,row=45),
                        dict(name='2nd Coat',ndft=100,mp=80,row=47)]),
    'T06C': dict(sys='T06C', std='SD-NOC-COR-350', sa='Sweep Blast', salt=30, salti=20,
                 dust=2, rh=85, dew=3, adh=4.0, adhm='ISO 16276-1', cond=150, mp=80,
                 coats=[dict(name='1st Coat',ndft=75,mp=80,row=45),
                        dict(name='2nd Coat',ndft=75,mp=80,row=47)]),
    'T06J': dict(sys='T06J', std='SD-NOC-COR-350', sa='Sweep Blast', salt=30, salti=20,
                 dust=2, rh=85, dew=3, adh=4.0, adhm='ISO 16276-1', cond=150, mp=80,
                 coats=[dict(name='1st Coat',ndft=75,mp=80,row=45),
                        dict(name='2nd Coat',ndft=75,mp=80,row=47)]),
    'T07J': dict(sys='T07J', std='SD-NOC-COR-350', sa='Sa 3', salt=30, salti=20,
                 dust=2, rh=85, dew=3, adh=5.0, adhm='ISO 16276-1', cond=150, mp=80,
                 coats=[dict(name='Primer',ndft=75,mp=80,row=45),
                        dict(name='MIO Coat',ndft=125,mp=80,row=47),
                        dict(name='Top Coat',ndft=50,mp=80,row=49)]),
}

# ── 헬퍼 ─────────────────────────────────────────────────────────
def _cv(ws, row, col):
    v = ws.cell(row, col).value
    if v is None: return None
    if isinstance(v, (int, float)): return v
    s = str(v).strip()
    return s if s else None

def _fne(ws, row, c1, c2):
    """범위 내 첫 번째 비어있지 않은 값"""
    for c in range(c1, c2+1):
        v = _cv(ws, row, c)
        if v is not None: return v
    return None

def _tf(v):
    """숫자 변환"""
    if v is None: return None
    try: return float(str(v).replace(',','').strip())
    except: return None

def _accept(v):
    return bool(re.match(r'^accept$', str(v or '').strip(), re.I))

def _na_val(v):
    if v is None: return True
    s = str(v).strip()
    return not s or bool(re.match(r'^n[./]?\s*a\.?$', s, re.I)) or s in ('—','-')

def _get_cfg(paint_sys_raw):
    """시스템 코드로 프리셋 매칭"""
    ps = str(paint_sys_raw or '').strip().upper().replace(' ','')
    # 정확히 일치
    if ps in SYSTEM_PRESETS: return SYSTEM_PRESETS[ps]
    # 앞 4자리
    for k in SYSTEM_PRESETS:
        if ps[:4] == k[:4]: return SYSTEM_PRESETS[k]
    # 앞 3자리
    for k in SYSTEM_PRESETS:
        if ps[:3] == k[:3]: return SYSTEM_PRESETS[k]
    return SYSTEM_PRESETS['T02J']


# ── parseXL — JS와 동일한 셀 위치 ─────────────────────────────────
def parse_xl(xlsx_path):
    wb = load_workbook(str(xlsx_path), data_only=True)
    ws = wb[wb.sheetnames[0]]
    d = {}

    # ── 헤더 정보 ─────────────────────────────────────────────────
    # Report No: P3-Q3-R3(_S3) = cols 16,17,18,19
    p3 = str(_cv(ws,3,16) or '')
    q3 = str(_cv(ws,3,17) or '')
    r3 = str(_cv(ws,3,18) or '')
    s3 = str(_cv(ws,3,19) or '')
    if p3 and q3 and r3:
        d['report_no'] = 'PAINT-'+p3+'-'+q3+'-'+r3+('_'+s3 if s3 else '')
    else:
        d['report_no'] = str(_cv(ws,3,15) or '')

    # Paint System: N6(col14)
    d['paint_sys_raw'] = _cv(ws,6,14) or _fne(ws,6,12,20) or ''

    # Vendor: E5~J5(cols5~10)
    d['vendor'] = _fne(ws,5,5,10) or _cv(ws,5,3) or ''

    # Inspector: N83~P83(cols14~16)
    d['insp_name'] = _fne(ws,83,14,16) or _cv(ws,7,7) or ''

    # CFG 매칭
    cfg = _get_cfg(d['paint_sys_raw'])
    d['cfg'] = cfg
    d['paint_sys'] = cfg['sys']

    is_sweep = 'sweep' in str(cfg.get('sa','')).lower() or \
               str(cfg['sys'])[:3].upper() in ('T06','T07')

    # ── Surface Prep — Pre-blasting (22~26행) ─────────────────────
    # accept=P(16), meas=Q(17), rs_meas=R(18)
    d['surf_prep'] = [
        dict(key='sp0',label='Compressed Air',   ac='No oil detected',
             accept=_cv(ws,22,16), meas=_cv(ws,22,17), rs_meas=_cv(ws,22,18)),
        dict(key='sp1',label='Imperfections',     ac='P3 & 2R or P3 & 3R',
             accept=_cv(ws,23,16), meas=_cv(ws,23,17), rs_meas=_cv(ws,23,18)),
        dict(key='sp2',label='Pre-cleaning',      ac='Free of contamination',
             accept=_cv(ws,24,16), meas=_cv(ws,24,17), rs_meas=_cv(ws,24,18)),
        dict(key='sp3',label='Conductivity',      ac=f'< {cfg["cond"]} ×10⁻⁶ S/cm',
             accept=_cv(ws,25,16), meas=_cv(ws,25,17), rs_meas=_cv(ws,25,18),
             th=cfg['cond']),
        dict(key='sp4',label='Abrasive Oil',      ac='No oil detected',
             accept=_cv(ws,26,16), meas=_cv(ws,26,17), rs_meas=_cv(ws,26,18)),
    ]

    # ── Cleanliness — Blasting (30~32행) ──────────────────────────
    # grade: K~M열(cols 11~13), app: C(col3), 환경: Q/R/S(17/18/19)
    d['cleanliness'] = []
    for row in range(30, 33):
        t = _cv(ws, row, 2)
        if not t: continue
        d['cleanliness'].append(dict(
            type  = t,
            app   = _cv(ws, row, 3),
            prof  = _cv(ws, row, 4),
            grade = _cv(ws, row, 11) or _fne(ws, row, 11, 13),
            rh    = _cv(ws, row, 17),
            dew   = _cv(ws, row, 18),
            steel = _cv(ws, row, 19),
        ))

    # ── Contamination (37~40행) ───────────────────────────────────
    # accept=P(16), meas=Q(17), rs_meas=R(18)
    salt_th = 20 if str(cfg['sys'])[:3].upper() == 'T03' else 30
    d['contamination'] = [
        dict(key='ct0',label='Dust Test',          ac=f'Max Level {cfg["dust"]}',
             accept=_cv(ws,37,16), meas=_cv(ws,37,17), rs_meas=_cv(ws,37,18)),
        dict(key='ct1',label='Profile Test',        ac='Medium or Fine',
             accept=_cv(ws,38,16), meas=_cv(ws,38,17), rs_meas=_cv(ws,38,18)),
        dict(key='ct2',label='Water Soluble Salt',  ac=f'≤{salt_th} mg/m²',
             accept=_cv(ws,39,16), meas=_cv(ws,39,17), rs_meas=_cv(ws,39,18),
             th=salt_th),
        dict(key='ct3',label='Ferrous',             ac='No pollution / N/A',
             accept=_cv(ws,40,16), meas=_cv(ws,40,17), rs_meas=_cv(ws,40,18)),
    ]

    # ── DFT (45,47,49,51행) ───────────────────────────────────────
    # spec=F(6누계), m=H~L(8~12), ave=M(13)
    DR = [45, 47, 49, 51]
    d['dft'] = []
    for i, coat in enumerate(cfg['coats']):
        dr = coat['row']
        d['dft'].append(dict(
            name  = coat['name'],
            ndft  = coat['ndft'],
            mp    = coat['mp'],
            row   = coat['row'],
            spec  = _cv(ws, dr, 6),        # F열 = 누계 기준
            m     = [_cv(ws,dr,c) for c in range(8,13)],  # H~L
            ave   = _cv(ws, dr, 13),       # M열 평균
        ))

    # ── Adhesion (76행) ───────────────────────────────────────────
    # E,H,K,N,Q = cols 5,8,11,14,17
    DC = [5, 8, 11, 14, 17]
    d['adhesion'] = dict(
        actual  = [_cv(ws,76,c) for c in DC],
        req     = [_cv(ws,75,c) for c in DC],
    )

    d['is_sweep'] = is_sweep
    return d


# ── buildVR — JS와 동일한 판정 로직 ──────────────────────────────
def build_vr(raw):
    cfg      = raw['cfg']
    res      = []
    is_sweep = raw.get('is_sweep', False)
    sys3     = str(cfg['sys'])[:3].upper()
    is_t03   = sys3 == 'T03'
    is_t06   = sys3 == 'T06'
    is_t07   = sys3 == 'T07'

    # ── Surf Prep 판정 (22~26행) ──────────────────────────────────
    for item in raw['surf_prep']:
        p   = str(item['accept'] or '').strip()
        rs  = str(item['rs_meas'] or item['meas'] or '').strip()
        p_ok = _accept(p)

        if item['key'] == 'sp3':
            # Conductivity 수치 판정
            n = _tf(re.sub(r'[^\d.]','', rs))
            ok = p_ok and (n is not None and n < cfg['cond'])
            msg = '' if ok else (f'{rs} ≥ {cfg["cond"]}' if p_ok else f'P미합격:{p}')
        else:
            # 텍스트 Accept 판정
            ok = p_ok and bool(rs)
            msg = '' if ok else (f'P미합격:{p}' if not p_ok else '측정값없음')

        res.append(dict(sec='Surface Prep', key=item['key'], lbl=item['label'],
                        val=rs or p, ac=item['ac'], ok=ok, msg=msg, row=22+['sp0','sp1','sp2','sp3','sp4'].index(item['key'])))

    # ── Cleanliness (30~32행) ─────────────────────────────────────
    for i, bl in enumerate(raw['cleanliness']):
        app_val = str(bl['app'] or '').strip().lower()
        is_na   = not app_val or app_val in ('n/a','na')
        bl_type = str(bl['type'] or '').lower()
        is_blasting = 'blast' in bl_type and 'sweep' not in bl_type
        is_sweep_row = 'sweep' in bl_type

        if is_sweep:
            if is_blasting:
                if not is_na:
                    res.append(dict(sec='Cleanliness', key=f'bl_g{i}',
                        lbl='Blasting Grade (N/A for Sweep sys)',
                        val=bl['grade'] or '—', ac='N/A (Sweep system)',
                        ok=True, msg='', row=30+i))
                continue
            if is_sweep_row:
                if is_na: continue
                app_ok = bool(re.search(r'applicable', str(bl['app'] or ''), re.I))
                g_ok   = bool(bl['grade'] and re.search(r'sspc\s*sp\s*16|sweep', str(bl['grade']), re.I))
                ok     = app_ok and g_ok
                msg    = '' if ok else (f'App:{bl["app"]} / Grade:{bl["grade"]}')
                res.append(dict(sec='Cleanliness', key=f'bl_g{i}',
                    lbl='Sweep Blasting Grade',
                    val=f'App:{bl["app"] or "—"} / Grade:{bl["grade"] or "—"}',
                    ac='Applicable + SSPC SP16', ok=ok, msg=msg, row=30+i))
            else:
                if is_na: continue
        else:
            # T02/T03: Sa 3 검증
            if is_na: continue
            g_ok = bool(bl['grade'] and 'sa3' in str(bl['grade']).lower().replace(' ',''))
            res.append(dict(sec='Cleanliness', key=f'bl_g{i}',
                lbl=f'{bl["type"]} Grade',
                val=bl['grade'] or '—', ac=cfg['sa'],
                ok=g_ok,
                msg='' if g_ok else f'기준:{cfg["sa"]} 실제:{bl["grade"]}',
                row=30+i))

        if is_na: continue
        # RH 판정
        if bl['rh'] is not None:
            rh = _tf(bl['rh'])
            ok_rh = rh is not None and rh <= cfg['rh']
            res.append(dict(sec='Cleanliness', key=f'bl_rh{i}',
                lbl=f'{bl["type"]} RH%', val=f'{bl["rh"]}%', ac=f'≤{cfg["rh"]}%',
                ok=ok_rh, msg='' if ok_rh else f'{bl["rh"]}% > {cfg["rh"]}%', row=30+i))
        # 결로 판정
        if bl['steel'] is not None and bl['dew'] is not None:
            st = _tf(bl['steel']); dp = _tf(bl['dew'])
            ok_dew = st is not None and dp is not None and st >= dp + cfg['dew']
            res.append(dict(sec='Cleanliness', key=f'bl_dew{i}',
                lbl=f'{bl["type"]} ST vs DP',
                val=f'ST={bl["steel"]}/DP={bl["dew"]}°C',
                ac=f'ST≥DP+{cfg["dew"]}°C',
                ok=ok_dew, msg='' if ok_dew else f'ST({st})< DP({dp})+{cfg["dew"]}', row=30+i))

    # ── Contamination 판정 (37~40행) ─────────────────────────────
    salt_th = 20 if is_t03 else 30
    for item in raw['contamination']:
        p   = str(item['accept'] or '').strip()
        rs  = str(item['rs_meas'] or item['meas'] or '').strip()
        p_ok = _accept(p)
        row  = 37 + ['ct0','ct1','ct2','ct3'].index(item['key'])

        if item['key'] == 'ct0':
            # Dust: Level ≤ 2
            m = re.search(r'level\s*(\d)', rs, re.I)
            lvl = int(m.group(1)) if m else None
            ok  = p_ok and lvl is not None and lvl <= 2
            msg = '' if ok else (f'기준:Level≤2 / 실제:{rs}' if p_ok else f'P미합격:{p}')
            res.append(dict(sec='Surface Contamination', key='ct0', lbl='Dust Test',
                val=rs, ac='Level ≤ 2', ok=ok, msg=msg, row=row))

        elif item['key'] == 'ct1':
            # Profile: T06/T07=Fine, T02/T03=Medium
            prof_req = 'Fine' if (is_t06 or is_t07) else 'Medium'
            ok  = p_ok and bool(re.search(prof_req, rs, re.I))
            msg = '' if ok else (f'기준:{prof_req} / 실제:{rs}' if p_ok else f'P미합격:{p}')
            res.append(dict(sec='Surface Contamination', key='ct1', lbl='Profile Test',
                val=rs, ac=f'Profile: {prof_req}', ok=ok, msg=msg, row=row))

        elif item['key'] == 'ct2':
            # Salt
            n  = _tf(re.sub(r'[^\d.]','', rs))
            ok = p_ok and n is not None and n <= salt_th
            msg = '' if ok else (f'기준:≤{salt_th} / 실제:{rs}' if p_ok else f'P미합격:{p}')
            res.append(dict(sec='Surface Contamination', key='ct2', lbl='Water Soluble Salt',
                val=rs, ac=f'≤{salt_th} mg/m²', ok=ok, msg=msg, row=row))

        elif item['key'] == 'ct3':
            # Ferrous: N/A = Carbon Steel = 합격
            is_na = (_na_val(p) or _na_val(rs))
            if is_na:
                res.append(dict(sec='Surface Contamination', key='ct3',
                    lbl='Ferrous (SS only)', val='N/A', ac='N/A (Carbon Steel)',
                    ok=True, msg='', row=row))
            else:
                ok  = p_ok and bool(re.search(r'no\s*(surface\s*)?pollution', rs, re.I))
                msg = '' if ok else (f'오염감지:{rs}' if p_ok else f'P미합격:{p}')
                res.append(dict(sec='Surface Contamination', key='ct3',
                    lbl='Ferrous Contamination', val=rs, ac='No pollution',
                    ok=ok, msg=msg, row=row))

    # ── DFT 판정 ──────────────────────────────────────────────────
    for i, coat in enumerate(raw['dft']):
        spec_v = _tf(coat['spec'])
        if spec_v is None: continue
        cum_ndft = spec_v
        cum_min  = cum_ndft * coat['mp'] / 100
        pts      = [_tf(v) for v in coat['m']]
        valid    = [v for v in pts if v is not None]
        rep_ave  = _tf(coat['ave'])
        avg      = rep_ave if rep_ave is not None else (sum(valid)/len(valid) if valid else None)

        if avg is None and not valid:
            res.append(dict(sec=f'DFT — {coat["name"]}', key=f'dft_{i}',
                lbl=f'DFT {coat["name"]}', val='—', ac=f'누계NDFT={cum_ndft}㎛',
                ok=False, msg='측정값 없음', row=coat['row']))
            continue

        avg_ok  = avg >= cum_ndft if avg is not None else False
        fail_pts = [v for v in valid if v < cum_min]
        overall  = avg_ok and not fail_pts
        iss = []
        if fail_pts:
            iss.append(f'미달:{[round(v) for v in fail_pts]}㎛<기준{round(cum_min)}㎛({coat["mp"]}%룰)')
        if not avg_ok and avg is not None:
            iss.append(f'평균{round(avg,1)}㎛<누계NDFT{cum_ndft}㎛')
        res.append(dict(sec=f'DFT — {coat["name"]}', key=f'dft_{i}',
            lbl=f'DFT {coat["name"]} (누계≥{cum_ndft}㎛, min{round(cum_min)}㎛)',
            val=str(coat['m']), ac=f'누계NDFT={cum_ndft}㎛',
            ok=overall, msg=' / '.join(iss), row=coat['row']))

    # ── Adhesion 판정 ─────────────────────────────────────────────
    adh_min = cfg['adh']
    actuals = raw['adhesion']['actual']
    has_adh = any(v is not None for v in actuals)
    if not has_adh:
        res.append(dict(sec='Adhesion', key='adh_na', lbl='Adhesion Pull-off (N/A)',
                        val='N/A', ac='해당없음', ok=True, msg='', row=76))
    else:
        for i, v in enumerate(actuals):
            n = _tf(v)
            if n is None: continue
            ok = n >= adh_min
            res.append(dict(sec='Adhesion', key=f'adh_{i}',
                lbl=f'Dolly #{i+1} — {cfg["adhm"]}',
                val=f'{n} MPa', ac=f'≥{adh_min} MPa', ok=ok,
                msg='' if ok else f'{n} MPa < {adh_min} MPa', row=76))
    return res


def calc_rpa_code(vr):
    fails = [v for v in vr if not v['ok']]
    if not fails:       return 1
    elif len(fails) < 5: return 2
    else:                return 3


def call_anthropic_for_report(api_key, raw, vr, spec_text='', proc_text=''):
    cfg      = raw['cfg']
    fails    = [v for v in vr if not v['ok']]
    rpa_code = calc_rpa_code(vr)

    fail_summary = '\n'.join([
        f"- [{v['sec']}] {v['lbl']}: {v['val']} (기준 {v['ac']}) — {v.get('msg','')}"
        for v in fails[:8]
    ])

    prompt = (
        f'도장 검사 레포트를 분석하고 JSON으로만 응답하세요.\n\n'
        f'레포트: {raw["report_no"]}\n'
        f'시스템: {cfg["sys"]} | 벤더: {raw.get("vendor","")}\n'
        f'RPA 판정: CODE {rpa_code} (불합격 {len(fails)}건)\n\n'
        f'불합격 항목:\n{fail_summary if fail_summary else "없음"}\n\n'
    )
    if spec_text:
        prompt += f'\n[프로젝트 스펙]\n{spec_text}\n'
    if proc_text:
        prompt += f'\n[도장 절차서]\n{proc_text}\n'
    prompt += (
        '\n다음 JSON 형식으로만 응답:\n'
        '{"ai_code_verdict":1~4,"overall_summary":"전체 평가 2~3문장",'
        '"critical_issues":["심각 문제"],"recommendation":"조치 권고"}\n'
    )
    try:
        resp = requests.post(
            'https://api.anthropic.com/v1/messages',
            headers={'Content-Type':'application/json',
                     'x-api-key':api_key,'anthropic-version':'2023-06-01'},
            json={'model':'claude-haiku-4-5-20251001','max_tokens':1000,
                  'system':'해양/플랜트 도장 검사 전문가. JSON으로만 응답.',
                  'messages':[{'role':'user','content':prompt}]},
            timeout=60
        )
        if resp.status_code == 200:
            text = resp.json()['content'][0]['text']
            return json.loads(re.sub(r'```json|```','',text).strip())
    except Exception as e:
        print(f'[AI] 실패: {e}')
    return None


def process_report(xlsx_path, api_key='', spec_text='', proc_text='', base_dir=None):
    print(f'[처리] {Path(xlsx_path).name}')
    raw      = parse_xl(xlsx_path)
    print(f'  시스템: {raw["paint_sys"]} | 레포트: {raw["report_no"]}')
    vr       = build_vr(raw)
    rpa_code = calc_rpa_code(vr)
    fails    = [v for v in vr if not v['ok']]
    print(f'  RPA: CODE {rpa_code} (불합격 {len(fails)}건)')

    ai_result = None
    ai_code   = rpa_code
    if api_key:
        ai_result = call_anthropic_for_report(api_key, raw, vr, spec_text, proc_text)
        if ai_result:
            ai_code = max(rpa_code, ai_result.get('ai_code_verdict', rpa_code))
            print(f'  AI: CODE {ai_code}')

    comments = []
    for v in fails[:6]:
        line = f'{v["lbl"]}: {v["val"]} (기준: {v["ac"]})'
        if v.get('msg'): line += f' — {v["msg"]}'
        comments.append(line)

    stamped_path = None
    if base_dir:
        try:
            import sys
            sys.path.insert(0, str(base_dir))
            from stamp_generator import export_xlsx_with_stamps
            safe = re.sub(r'[^\w\-]','_', raw['report_no'] or 'REPORT')
            out  = Path(base_dir)/'exports'/f'{safe}_stamped.xlsx'
            logo = Path(base_dir)/'static'/'logo.png'
            ts   = datetime.datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S')
            export_xlsx_with_stamps(
                template_path=str(xlsx_path), output_path=str(out),
                code=ai_code, report_no=raw['report_no'],
                comments=comments, ai_code=ai_code if ai_result else None,
                logo_path=str(logo) if logo.exists() else None, timestamp=ts)
            stamped_path = str(out)
            print(f'  스탬프: {out.name}')
        except Exception as e:
            print(f'  스탬프 오류: {e}')

    code_labels = {1:'CODE 1 — APPROVED',2:'CODE 2 — APPROVED WITH COMMENTS',
                   3:'CODE 3 — PARTIAL REWORK',4:'CODE 4 — FULL REWORK REQUIRED'}
    return dict(
        report_no=raw['report_no'], paint_sys=raw['paint_sys'],
        vendor=raw.get('vendor',''), rpa_code=rpa_code, ai_code=ai_code,
        final_code=ai_code, code_label=code_labels.get(ai_code,''),
        fail_count=len(fails),
        fails=[dict(sec=v['sec'],lbl=v['lbl'],val=v['val'],ac=v['ac'],msg=v.get('msg','')) for v in fails],
        ai_summary=ai_result.get('overall_summary','') if ai_result else '',
        ai_recommendation=ai_result.get('recommendation','') if ai_result else '',
        stamped_path=stamped_path,
    )
